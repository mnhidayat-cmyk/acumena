<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-11-04 15:40:27 --> Config Class Initialized
INFO - 2025-11-04 15:40:27 --> Hooks Class Initialized
INFO - 2025-11-04 15:40:27 --> UTF-8 Support Enabled
INFO - 2025-11-04 15:40:27 --> Utf8 Class Initialized
INFO - 2025-11-04 15:40:27 --> URI Class Initialized
INFO - 2025-11-04 15:40:27 --> Router Class Initialized
INFO - 2025-11-04 15:40:27 --> Output Class Initialized
INFO - 2025-11-04 15:40:27 --> Security Class Initialized
INFO - 2025-11-04 15:40:27 --> Input Class Initialized
INFO - 2025-11-04 15:40:27 --> Language Class Initialized
INFO - 2025-11-04 15:40:27 --> Loader Class Initialized
INFO - 2025-11-04 15:40:27 --> Helper loaded: url_helper
INFO - 2025-11-04 15:40:27 --> Helper loaded: file_helper
INFO - 2025-11-04 15:40:27 --> Helper loaded: main_helper
INFO - 2025-11-04 15:40:27 --> Database Driver Class Initialized
INFO - 2025-11-04 15:40:27 --> Email Class Initialized
DEBUG - 2025-11-04 15:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 15:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 15:40:27 --> Controller Class Initialized
INFO - 2025-11-04 15:40:27 --> Model "User_model" initialized
INFO - 2025-11-04 15:40:27 --> Model "Project_model" initialized
INFO - 2025-11-04 15:40:27 --> Helper loaded: form_helper
INFO - 2025-11-04 15:40:27 --> Form Validation Class Initialized
ERROR - 2025-11-04 15:40:28 --> Gemini API request error: Client error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyCFKAYDF6qeMB875NuwZnX8w-i3Dyg30TQ` resulted in a `404 Not Found` response:
{
  "error": {
    "code": 404,
    "message": "models/gemini-1.5-flash is not found for API version v1beta, or is not s (truncated...)

INFO - 2025-11-04 15:40:28 --> Final output sent to browser
INFO - 2025-11-04 15:40:28 --> Total execution time: 0.6081
INFO - 2025-11-04 15:41:32 --> Config Class Initialized
INFO - 2025-11-04 15:41:32 --> Hooks Class Initialized
INFO - 2025-11-04 15:41:32 --> UTF-8 Support Enabled
INFO - 2025-11-04 15:41:32 --> Utf8 Class Initialized
INFO - 2025-11-04 15:41:32 --> URI Class Initialized
INFO - 2025-11-04 15:41:32 --> Router Class Initialized
INFO - 2025-11-04 15:41:32 --> Output Class Initialized
INFO - 2025-11-04 15:41:32 --> Security Class Initialized
INFO - 2025-11-04 15:41:32 --> Input Class Initialized
INFO - 2025-11-04 15:41:32 --> Language Class Initialized
INFO - 2025-11-04 15:41:32 --> Loader Class Initialized
INFO - 2025-11-04 15:41:32 --> Helper loaded: url_helper
INFO - 2025-11-04 15:41:32 --> Helper loaded: file_helper
INFO - 2025-11-04 15:41:32 --> Helper loaded: main_helper
INFO - 2025-11-04 15:41:32 --> Database Driver Class Initialized
INFO - 2025-11-04 15:41:32 --> Email Class Initialized
DEBUG - 2025-11-04 15:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 15:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 15:41:32 --> Controller Class Initialized
INFO - 2025-11-04 15:41:32 --> Model "User_model" initialized
INFO - 2025-11-04 15:41:32 --> Model "Project_model" initialized
INFO - 2025-11-04 15:41:32 --> Helper loaded: form_helper
INFO - 2025-11-04 15:41:32 --> Form Validation Class Initialized
ERROR - 2025-11-04 15:41:35 --> Gemini API response missing text: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 10,
    "totalTokenCount": 109,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 10
      }
    ],
    "thoughtsTokenCount": 99
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "qh4KaYbyPMCX4-EPt4vYmAI"
}

INFO - 2025-11-04 15:41:35 --> Final output sent to browser
INFO - 2025-11-04 15:41:35 --> Total execution time: 2.7095
INFO - 2025-11-04 15:47:26 --> Config Class Initialized
INFO - 2025-11-04 15:47:26 --> Hooks Class Initialized
INFO - 2025-11-04 15:47:26 --> UTF-8 Support Enabled
INFO - 2025-11-04 15:47:26 --> Utf8 Class Initialized
INFO - 2025-11-04 15:47:26 --> URI Class Initialized
INFO - 2025-11-04 15:47:26 --> Router Class Initialized
INFO - 2025-11-04 15:47:26 --> Output Class Initialized
INFO - 2025-11-04 15:47:26 --> Security Class Initialized
INFO - 2025-11-04 15:47:26 --> Input Class Initialized
INFO - 2025-11-04 15:47:26 --> Language Class Initialized
INFO - 2025-11-04 15:47:26 --> Loader Class Initialized
INFO - 2025-11-04 15:47:26 --> Helper loaded: url_helper
INFO - 2025-11-04 15:47:26 --> Helper loaded: file_helper
INFO - 2025-11-04 15:47:26 --> Helper loaded: main_helper
INFO - 2025-11-04 15:47:26 --> Database Driver Class Initialized
INFO - 2025-11-04 15:47:26 --> Email Class Initialized
DEBUG - 2025-11-04 15:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 15:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 15:47:26 --> Controller Class Initialized
INFO - 2025-11-04 15:47:26 --> Model "User_model" initialized
INFO - 2025-11-04 15:47:26 --> Model "Project_model" initialized
INFO - 2025-11-04 15:47:26 --> Helper loaded: form_helper
INFO - 2025-11-04 15:47:26 --> Form Validation Class Initialized
DEBUG - 2025-11-04 15:47:28 --> [Gemini attempt 1] HTTP 200 in 1993ms; body(first300)={
  "candidates": [
    {
      "content": {
        "parts": [
          {
            "text": "OK"
          }
        ],
        "role": "model"
      },
      "finishReason": "STOP",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 11,
    "candidatesTokenCount": 1,
    "
DEBUG - 2025-11-04 15:47:28 --> [Gemini attempt 1] OK finishReason=STOP
INFO - 2025-11-04 15:47:28 --> Final output sent to browser
INFO - 2025-11-04 15:47:28 --> Total execution time: 2.0874
INFO - 2025-11-04 16:44:54 --> Config Class Initialized
INFO - 2025-11-04 16:44:54 --> Hooks Class Initialized
INFO - 2025-11-04 16:44:54 --> UTF-8 Support Enabled
INFO - 2025-11-04 16:44:54 --> Utf8 Class Initialized
INFO - 2025-11-04 16:44:54 --> URI Class Initialized
INFO - 2025-11-04 16:44:54 --> Router Class Initialized
INFO - 2025-11-04 16:44:54 --> Output Class Initialized
INFO - 2025-11-04 16:44:54 --> Security Class Initialized
INFO - 2025-11-04 16:44:54 --> Input Class Initialized
INFO - 2025-11-04 16:44:54 --> Language Class Initialized
INFO - 2025-11-04 16:44:54 --> Loader Class Initialized
INFO - 2025-11-04 16:44:54 --> Helper loaded: url_helper
INFO - 2025-11-04 16:44:54 --> Helper loaded: file_helper
INFO - 2025-11-04 16:44:54 --> Helper loaded: main_helper
INFO - 2025-11-04 16:44:54 --> Database Driver Class Initialized
INFO - 2025-11-04 16:44:54 --> Email Class Initialized
DEBUG - 2025-11-04 16:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 16:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 16:44:54 --> Controller Class Initialized
INFO - 2025-11-04 16:44:54 --> Model "User_model" initialized
INFO - 2025-11-04 16:44:54 --> Model "Project_model" initialized
INFO - 2025-11-04 16:44:54 --> Helper loaded: form_helper
INFO - 2025-11-04 16:44:54 --> Form Validation Class Initialized
INFO - 2025-11-04 16:45:02 --> Final output sent to browser
INFO - 2025-11-04 16:45:02 --> Total execution time: 8.9719
INFO - 2025-11-04 22:57:37 --> Config Class Initialized
INFO - 2025-11-04 22:57:37 --> Hooks Class Initialized
INFO - 2025-11-04 22:57:37 --> UTF-8 Support Enabled
INFO - 2025-11-04 22:57:37 --> Utf8 Class Initialized
INFO - 2025-11-04 22:57:37 --> URI Class Initialized
INFO - 2025-11-04 22:57:37 --> Router Class Initialized
INFO - 2025-11-04 22:57:37 --> Output Class Initialized
INFO - 2025-11-04 22:57:37 --> Security Class Initialized
INFO - 2025-11-04 22:57:37 --> Input Class Initialized
INFO - 2025-11-04 22:57:37 --> Language Class Initialized
INFO - 2025-11-04 22:57:37 --> Loader Class Initialized
INFO - 2025-11-04 22:57:37 --> Helper loaded: url_helper
INFO - 2025-11-04 22:57:37 --> Helper loaded: file_helper
INFO - 2025-11-04 22:57:37 --> Helper loaded: main_helper
INFO - 2025-11-04 22:57:37 --> Database Driver Class Initialized
INFO - 2025-11-04 22:57:37 --> Email Class Initialized
DEBUG - 2025-11-04 22:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 22:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 22:57:37 --> Controller Class Initialized
INFO - 2025-11-04 22:58:36 --> Config Class Initialized
INFO - 2025-11-04 22:58:36 --> Hooks Class Initialized
INFO - 2025-11-04 22:58:36 --> UTF-8 Support Enabled
INFO - 2025-11-04 22:58:36 --> Utf8 Class Initialized
INFO - 2025-11-04 22:58:36 --> URI Class Initialized
INFO - 2025-11-04 22:58:36 --> Router Class Initialized
INFO - 2025-11-04 22:58:36 --> Output Class Initialized
INFO - 2025-11-04 22:58:36 --> Security Class Initialized
INFO - 2025-11-04 22:58:36 --> Input Class Initialized
INFO - 2025-11-04 22:58:36 --> Language Class Initialized
INFO - 2025-11-04 22:58:36 --> Loader Class Initialized
INFO - 2025-11-04 22:58:36 --> Helper loaded: url_helper
INFO - 2025-11-04 22:58:36 --> Helper loaded: file_helper
INFO - 2025-11-04 22:58:36 --> Helper loaded: main_helper
INFO - 2025-11-04 22:58:36 --> Database Driver Class Initialized
INFO - 2025-11-04 22:58:36 --> Email Class Initialized
DEBUG - 2025-11-04 22:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 22:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 22:58:36 --> Controller Class Initialized
INFO - 2025-11-04 23:04:07 --> Config Class Initialized
INFO - 2025-11-04 23:04:07 --> Hooks Class Initialized
INFO - 2025-11-04 23:04:07 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:04:07 --> Utf8 Class Initialized
INFO - 2025-11-04 23:04:07 --> URI Class Initialized
INFO - 2025-11-04 23:04:07 --> Router Class Initialized
INFO - 2025-11-04 23:04:07 --> Output Class Initialized
INFO - 2025-11-04 23:04:07 --> Security Class Initialized
INFO - 2025-11-04 23:04:07 --> Input Class Initialized
INFO - 2025-11-04 23:04:07 --> Language Class Initialized
INFO - 2025-11-04 23:04:07 --> Loader Class Initialized
INFO - 2025-11-04 23:04:07 --> Helper loaded: url_helper
INFO - 2025-11-04 23:04:07 --> Helper loaded: file_helper
INFO - 2025-11-04 23:04:07 --> Helper loaded: main_helper
INFO - 2025-11-04 23:04:07 --> Database Driver Class Initialized
INFO - 2025-11-04 23:04:07 --> Email Class Initialized
DEBUG - 2025-11-04 23:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:04:07 --> Controller Class Initialized
INFO - 2025-11-04 23:04:11 --> Config Class Initialized
INFO - 2025-11-04 23:04:11 --> Hooks Class Initialized
INFO - 2025-11-04 23:04:11 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:04:11 --> Utf8 Class Initialized
INFO - 2025-11-04 23:04:11 --> URI Class Initialized
INFO - 2025-11-04 23:04:11 --> Router Class Initialized
INFO - 2025-11-04 23:04:11 --> Output Class Initialized
INFO - 2025-11-04 23:04:11 --> Security Class Initialized
INFO - 2025-11-04 23:04:11 --> Input Class Initialized
INFO - 2025-11-04 23:04:11 --> Language Class Initialized
INFO - 2025-11-04 23:04:11 --> Loader Class Initialized
INFO - 2025-11-04 23:04:11 --> Helper loaded: url_helper
INFO - 2025-11-04 23:04:11 --> Helper loaded: file_helper
INFO - 2025-11-04 23:04:11 --> Helper loaded: main_helper
INFO - 2025-11-04 23:04:11 --> Database Driver Class Initialized
INFO - 2025-11-04 23:04:11 --> Email Class Initialized
DEBUG - 2025-11-04 23:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:04:11 --> Controller Class Initialized
INFO - 2025-11-04 23:05:39 --> Config Class Initialized
INFO - 2025-11-04 23:05:39 --> Hooks Class Initialized
INFO - 2025-11-04 23:05:39 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:05:39 --> Utf8 Class Initialized
INFO - 2025-11-04 23:05:39 --> URI Class Initialized
INFO - 2025-11-04 23:05:39 --> Router Class Initialized
INFO - 2025-11-04 23:05:39 --> Output Class Initialized
INFO - 2025-11-04 23:05:39 --> Security Class Initialized
INFO - 2025-11-04 23:05:39 --> Input Class Initialized
INFO - 2025-11-04 23:05:39 --> Language Class Initialized
INFO - 2025-11-04 23:05:39 --> Loader Class Initialized
INFO - 2025-11-04 23:05:39 --> Helper loaded: url_helper
INFO - 2025-11-04 23:05:39 --> Helper loaded: file_helper
INFO - 2025-11-04 23:05:39 --> Helper loaded: main_helper
INFO - 2025-11-04 23:05:39 --> Database Driver Class Initialized
INFO - 2025-11-04 23:05:39 --> Email Class Initialized
DEBUG - 2025-11-04 23:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:05:39 --> Controller Class Initialized
INFO - 2025-11-04 23:08:00 --> Config Class Initialized
INFO - 2025-11-04 23:08:00 --> Hooks Class Initialized
INFO - 2025-11-04 23:08:00 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:08:00 --> Utf8 Class Initialized
INFO - 2025-11-04 23:08:00 --> URI Class Initialized
INFO - 2025-11-04 23:08:00 --> Router Class Initialized
INFO - 2025-11-04 23:08:00 --> Output Class Initialized
INFO - 2025-11-04 23:08:00 --> Security Class Initialized
INFO - 2025-11-04 23:08:00 --> Input Class Initialized
INFO - 2025-11-04 23:08:00 --> Language Class Initialized
INFO - 2025-11-04 23:08:00 --> Loader Class Initialized
INFO - 2025-11-04 23:08:00 --> Helper loaded: url_helper
INFO - 2025-11-04 23:08:00 --> Helper loaded: file_helper
INFO - 2025-11-04 23:08:00 --> Helper loaded: main_helper
INFO - 2025-11-04 23:08:00 --> Database Driver Class Initialized
INFO - 2025-11-04 23:08:00 --> Email Class Initialized
DEBUG - 2025-11-04 23:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:08:00 --> Controller Class Initialized
INFO - 2025-11-04 23:08:03 --> Config Class Initialized
INFO - 2025-11-04 23:08:03 --> Hooks Class Initialized
INFO - 2025-11-04 23:08:03 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:08:03 --> Utf8 Class Initialized
INFO - 2025-11-04 23:08:03 --> URI Class Initialized
INFO - 2025-11-04 23:08:03 --> Router Class Initialized
INFO - 2025-11-04 23:08:03 --> Output Class Initialized
INFO - 2025-11-04 23:08:03 --> Security Class Initialized
INFO - 2025-11-04 23:08:03 --> Input Class Initialized
INFO - 2025-11-04 23:08:03 --> Language Class Initialized
INFO - 2025-11-04 23:08:03 --> Loader Class Initialized
INFO - 2025-11-04 23:08:03 --> Helper loaded: url_helper
INFO - 2025-11-04 23:08:03 --> Helper loaded: file_helper
INFO - 2025-11-04 23:08:03 --> Helper loaded: main_helper
INFO - 2025-11-04 23:08:03 --> Database Driver Class Initialized
INFO - 2025-11-04 23:08:03 --> Email Class Initialized
DEBUG - 2025-11-04 23:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:08:03 --> Controller Class Initialized
INFO - 2025-11-04 23:09:22 --> Config Class Initialized
INFO - 2025-11-04 23:09:22 --> Hooks Class Initialized
INFO - 2025-11-04 23:09:22 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:09:22 --> Utf8 Class Initialized
INFO - 2025-11-04 23:09:22 --> URI Class Initialized
INFO - 2025-11-04 23:09:22 --> Router Class Initialized
INFO - 2025-11-04 23:09:22 --> Output Class Initialized
INFO - 2025-11-04 23:09:22 --> Security Class Initialized
INFO - 2025-11-04 23:09:22 --> Input Class Initialized
INFO - 2025-11-04 23:09:22 --> Language Class Initialized
INFO - 2025-11-04 23:09:22 --> Loader Class Initialized
INFO - 2025-11-04 23:09:22 --> Helper loaded: url_helper
INFO - 2025-11-04 23:09:22 --> Helper loaded: file_helper
INFO - 2025-11-04 23:09:22 --> Helper loaded: main_helper
INFO - 2025-11-04 23:09:22 --> Database Driver Class Initialized
INFO - 2025-11-04 23:09:22 --> Email Class Initialized
DEBUG - 2025-11-04 23:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:09:22 --> Controller Class Initialized
INFO - 2025-11-04 23:11:02 --> Config Class Initialized
INFO - 2025-11-04 23:11:02 --> Hooks Class Initialized
INFO - 2025-11-04 23:11:02 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:11:02 --> Utf8 Class Initialized
INFO - 2025-11-04 23:11:02 --> URI Class Initialized
INFO - 2025-11-04 23:11:02 --> Router Class Initialized
INFO - 2025-11-04 23:11:02 --> Output Class Initialized
INFO - 2025-11-04 23:11:02 --> Security Class Initialized
INFO - 2025-11-04 23:11:02 --> Input Class Initialized
INFO - 2025-11-04 23:11:02 --> Language Class Initialized
INFO - 2025-11-04 23:11:02 --> Loader Class Initialized
INFO - 2025-11-04 23:11:02 --> Helper loaded: url_helper
INFO - 2025-11-04 23:11:02 --> Helper loaded: file_helper
INFO - 2025-11-04 23:11:02 --> Helper loaded: main_helper
INFO - 2025-11-04 23:11:02 --> Database Driver Class Initialized
INFO - 2025-11-04 23:11:02 --> Email Class Initialized
DEBUG - 2025-11-04 23:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:11:02 --> Controller Class Initialized
INFO - 2025-11-04 23:11:03 --> Config Class Initialized
INFO - 2025-11-04 23:11:03 --> Hooks Class Initialized
INFO - 2025-11-04 23:11:03 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:11:03 --> Utf8 Class Initialized
INFO - 2025-11-04 23:11:03 --> URI Class Initialized
INFO - 2025-11-04 23:11:03 --> Router Class Initialized
INFO - 2025-11-04 23:11:03 --> Output Class Initialized
INFO - 2025-11-04 23:11:03 --> Security Class Initialized
INFO - 2025-11-04 23:11:03 --> Input Class Initialized
INFO - 2025-11-04 23:11:03 --> Language Class Initialized
INFO - 2025-11-04 23:11:03 --> Loader Class Initialized
INFO - 2025-11-04 23:11:03 --> Helper loaded: url_helper
INFO - 2025-11-04 23:11:03 --> Helper loaded: file_helper
INFO - 2025-11-04 23:11:03 --> Helper loaded: main_helper
INFO - 2025-11-04 23:11:03 --> Database Driver Class Initialized
INFO - 2025-11-04 23:11:03 --> Email Class Initialized
DEBUG - 2025-11-04 23:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:11:03 --> Controller Class Initialized
INFO - 2025-11-04 23:11:14 --> Config Class Initialized
INFO - 2025-11-04 23:11:14 --> Hooks Class Initialized
INFO - 2025-11-04 23:11:14 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:11:14 --> Utf8 Class Initialized
INFO - 2025-11-04 23:11:14 --> URI Class Initialized
INFO - 2025-11-04 23:11:14 --> Router Class Initialized
INFO - 2025-11-04 23:11:14 --> Output Class Initialized
INFO - 2025-11-04 23:11:14 --> Security Class Initialized
INFO - 2025-11-04 23:11:14 --> Input Class Initialized
INFO - 2025-11-04 23:11:14 --> Language Class Initialized
INFO - 2025-11-04 23:11:14 --> Loader Class Initialized
INFO - 2025-11-04 23:11:14 --> Helper loaded: url_helper
INFO - 2025-11-04 23:11:14 --> Helper loaded: file_helper
INFO - 2025-11-04 23:11:14 --> Helper loaded: main_helper
INFO - 2025-11-04 23:11:14 --> Database Driver Class Initialized
INFO - 2025-11-04 23:11:14 --> Email Class Initialized
DEBUG - 2025-11-04 23:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:11:14 --> Controller Class Initialized
INFO - 2025-11-04 23:11:15 --> Config Class Initialized
INFO - 2025-11-04 23:11:15 --> Hooks Class Initialized
INFO - 2025-11-04 23:11:15 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:11:15 --> Utf8 Class Initialized
INFO - 2025-11-04 23:11:15 --> URI Class Initialized
INFO - 2025-11-04 23:11:15 --> Router Class Initialized
INFO - 2025-11-04 23:11:15 --> Output Class Initialized
INFO - 2025-11-04 23:11:15 --> Security Class Initialized
INFO - 2025-11-04 23:11:15 --> Input Class Initialized
INFO - 2025-11-04 23:11:15 --> Language Class Initialized
INFO - 2025-11-04 23:11:15 --> Loader Class Initialized
INFO - 2025-11-04 23:11:15 --> Helper loaded: url_helper
INFO - 2025-11-04 23:11:15 --> Helper loaded: file_helper
INFO - 2025-11-04 23:11:15 --> Helper loaded: main_helper
INFO - 2025-11-04 23:11:15 --> Database Driver Class Initialized
INFO - 2025-11-04 23:11:15 --> Email Class Initialized
DEBUG - 2025-11-04 23:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:11:15 --> Controller Class Initialized
INFO - 2025-11-04 23:11:31 --> Config Class Initialized
INFO - 2025-11-04 23:11:31 --> Hooks Class Initialized
INFO - 2025-11-04 23:11:31 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:11:31 --> Utf8 Class Initialized
INFO - 2025-11-04 23:11:31 --> URI Class Initialized
INFO - 2025-11-04 23:11:31 --> Router Class Initialized
INFO - 2025-11-04 23:11:31 --> Output Class Initialized
INFO - 2025-11-04 23:11:31 --> Security Class Initialized
INFO - 2025-11-04 23:11:31 --> Input Class Initialized
INFO - 2025-11-04 23:11:31 --> Language Class Initialized
INFO - 2025-11-04 23:11:31 --> Loader Class Initialized
INFO - 2025-11-04 23:11:31 --> Helper loaded: url_helper
INFO - 2025-11-04 23:11:31 --> Helper loaded: file_helper
INFO - 2025-11-04 23:11:31 --> Helper loaded: main_helper
INFO - 2025-11-04 23:11:31 --> Database Driver Class Initialized
INFO - 2025-11-04 23:11:31 --> Email Class Initialized
DEBUG - 2025-11-04 23:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:11:31 --> Controller Class Initialized
INFO - 2025-11-04 23:11:35 --> Config Class Initialized
INFO - 2025-11-04 23:11:35 --> Hooks Class Initialized
INFO - 2025-11-04 23:11:35 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:11:35 --> Utf8 Class Initialized
INFO - 2025-11-04 23:11:35 --> URI Class Initialized
INFO - 2025-11-04 23:11:35 --> Router Class Initialized
INFO - 2025-11-04 23:11:35 --> Output Class Initialized
INFO - 2025-11-04 23:11:35 --> Security Class Initialized
INFO - 2025-11-04 23:11:35 --> Input Class Initialized
INFO - 2025-11-04 23:11:35 --> Language Class Initialized
INFO - 2025-11-04 23:11:35 --> Loader Class Initialized
INFO - 2025-11-04 23:11:35 --> Helper loaded: url_helper
INFO - 2025-11-04 23:11:35 --> Helper loaded: file_helper
INFO - 2025-11-04 23:11:35 --> Helper loaded: main_helper
INFO - 2025-11-04 23:11:35 --> Database Driver Class Initialized
INFO - 2025-11-04 23:11:35 --> Email Class Initialized
DEBUG - 2025-11-04 23:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:11:35 --> Controller Class Initialized
INFO - 2025-11-04 23:11:52 --> Config Class Initialized
INFO - 2025-11-04 23:11:52 --> Hooks Class Initialized
INFO - 2025-11-04 23:11:52 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:11:52 --> Utf8 Class Initialized
INFO - 2025-11-04 23:11:52 --> URI Class Initialized
INFO - 2025-11-04 23:11:52 --> Router Class Initialized
INFO - 2025-11-04 23:11:52 --> Output Class Initialized
INFO - 2025-11-04 23:11:52 --> Security Class Initialized
INFO - 2025-11-04 23:11:52 --> Input Class Initialized
INFO - 2025-11-04 23:11:52 --> Language Class Initialized
INFO - 2025-11-04 23:11:52 --> Loader Class Initialized
INFO - 2025-11-04 23:11:52 --> Helper loaded: url_helper
INFO - 2025-11-04 23:11:52 --> Helper loaded: file_helper
INFO - 2025-11-04 23:11:52 --> Helper loaded: main_helper
INFO - 2025-11-04 23:11:52 --> Database Driver Class Initialized
INFO - 2025-11-04 23:11:52 --> Email Class Initialized
DEBUG - 2025-11-04 23:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:11:52 --> Controller Class Initialized
INFO - 2025-11-04 23:12:13 --> Config Class Initialized
INFO - 2025-11-04 23:12:13 --> Hooks Class Initialized
INFO - 2025-11-04 23:12:13 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:12:13 --> Utf8 Class Initialized
INFO - 2025-11-04 23:12:13 --> URI Class Initialized
INFO - 2025-11-04 23:12:13 --> Router Class Initialized
INFO - 2025-11-04 23:12:13 --> Output Class Initialized
INFO - 2025-11-04 23:12:13 --> Security Class Initialized
INFO - 2025-11-04 23:12:13 --> Input Class Initialized
INFO - 2025-11-04 23:12:13 --> Language Class Initialized
INFO - 2025-11-04 23:12:13 --> Loader Class Initialized
INFO - 2025-11-04 23:12:13 --> Helper loaded: url_helper
INFO - 2025-11-04 23:12:13 --> Helper loaded: file_helper
INFO - 2025-11-04 23:12:13 --> Helper loaded: main_helper
INFO - 2025-11-04 23:12:13 --> Database Driver Class Initialized
INFO - 2025-11-04 23:12:13 --> Email Class Initialized
DEBUG - 2025-11-04 23:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:12:13 --> Controller Class Initialized
INFO - 2025-11-04 23:12:21 --> Config Class Initialized
INFO - 2025-11-04 23:12:21 --> Hooks Class Initialized
INFO - 2025-11-04 23:12:21 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:12:21 --> Utf8 Class Initialized
INFO - 2025-11-04 23:12:21 --> URI Class Initialized
DEBUG - 2025-11-04 23:12:21 --> No URI present. Default controller set.
INFO - 2025-11-04 23:12:21 --> Router Class Initialized
INFO - 2025-11-04 23:12:21 --> Output Class Initialized
INFO - 2025-11-04 23:12:21 --> Security Class Initialized
INFO - 2025-11-04 23:12:21 --> Input Class Initialized
INFO - 2025-11-04 23:12:21 --> Language Class Initialized
INFO - 2025-11-04 23:12:21 --> Loader Class Initialized
INFO - 2025-11-04 23:12:21 --> Helper loaded: url_helper
INFO - 2025-11-04 23:12:21 --> Helper loaded: file_helper
INFO - 2025-11-04 23:12:21 --> Helper loaded: main_helper
INFO - 2025-11-04 23:12:21 --> Database Driver Class Initialized
INFO - 2025-11-04 23:12:31 --> Config Class Initialized
INFO - 2025-11-04 23:12:31 --> Hooks Class Initialized
INFO - 2025-11-04 23:12:31 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:12:31 --> Utf8 Class Initialized
INFO - 2025-11-04 23:12:31 --> URI Class Initialized
DEBUG - 2025-11-04 23:12:31 --> No URI present. Default controller set.
INFO - 2025-11-04 23:12:31 --> Router Class Initialized
INFO - 2025-11-04 23:12:31 --> Output Class Initialized
INFO - 2025-11-04 23:12:31 --> Security Class Initialized
INFO - 2025-11-04 23:12:31 --> Input Class Initialized
INFO - 2025-11-04 23:12:31 --> Language Class Initialized
INFO - 2025-11-04 23:12:31 --> Loader Class Initialized
INFO - 2025-11-04 23:12:31 --> Helper loaded: url_helper
INFO - 2025-11-04 23:12:31 --> Helper loaded: file_helper
INFO - 2025-11-04 23:12:31 --> Helper loaded: main_helper
INFO - 2025-11-04 23:12:31 --> Database Driver Class Initialized
INFO - 2025-11-04 23:12:32 --> Email Class Initialized
DEBUG - 2025-11-04 23:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:12:32 --> Controller Class Initialized
INFO - 2025-11-04 23:12:32 --> Config Class Initialized
INFO - 2025-11-04 23:12:32 --> Hooks Class Initialized
INFO - 2025-11-04 23:12:32 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:12:32 --> Utf8 Class Initialized
INFO - 2025-11-04 23:12:32 --> URI Class Initialized
INFO - 2025-11-04 23:12:32 --> Router Class Initialized
INFO - 2025-11-04 23:12:32 --> Output Class Initialized
INFO - 2025-11-04 23:12:32 --> Security Class Initialized
INFO - 2025-11-04 23:12:32 --> Input Class Initialized
INFO - 2025-11-04 23:12:32 --> Language Class Initialized
INFO - 2025-11-04 23:12:32 --> Loader Class Initialized
INFO - 2025-11-04 23:12:32 --> Helper loaded: url_helper
INFO - 2025-11-04 23:12:32 --> Helper loaded: file_helper
INFO - 2025-11-04 23:12:32 --> Helper loaded: main_helper
INFO - 2025-11-04 23:12:32 --> Database Driver Class Initialized
INFO - 2025-11-04 23:12:32 --> Email Class Initialized
DEBUG - 2025-11-04 23:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:12:32 --> Controller Class Initialized
INFO - 2025-11-04 23:12:32 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:12:32 --> Model "User_model" initialized
INFO - 2025-11-04 23:12:32 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:12:32 --> Config Class Initialized
INFO - 2025-11-04 23:12:32 --> Hooks Class Initialized
INFO - 2025-11-04 23:12:32 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:12:32 --> Utf8 Class Initialized
INFO - 2025-11-04 23:12:32 --> URI Class Initialized
INFO - 2025-11-04 23:12:32 --> Router Class Initialized
INFO - 2025-11-04 23:12:32 --> Output Class Initialized
INFO - 2025-11-04 23:12:32 --> Security Class Initialized
INFO - 2025-11-04 23:12:32 --> Input Class Initialized
INFO - 2025-11-04 23:12:32 --> Language Class Initialized
INFO - 2025-11-04 23:12:32 --> Loader Class Initialized
INFO - 2025-11-04 23:12:32 --> Helper loaded: url_helper
INFO - 2025-11-04 23:12:32 --> Helper loaded: file_helper
INFO - 2025-11-04 23:12:32 --> Helper loaded: main_helper
INFO - 2025-11-04 23:12:32 --> Database Driver Class Initialized
INFO - 2025-11-04 23:12:32 --> Email Class Initialized
DEBUG - 2025-11-04 23:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:12:32 --> Controller Class Initialized
INFO - 2025-11-04 23:12:32 --> Config Class Initialized
INFO - 2025-11-04 23:12:32 --> Hooks Class Initialized
INFO - 2025-11-04 23:12:32 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:12:32 --> Utf8 Class Initialized
INFO - 2025-11-04 23:12:32 --> URI Class Initialized
INFO - 2025-11-04 23:12:32 --> Router Class Initialized
INFO - 2025-11-04 23:12:32 --> Output Class Initialized
INFO - 2025-11-04 23:12:32 --> Security Class Initialized
INFO - 2025-11-04 23:12:32 --> Input Class Initialized
INFO - 2025-11-04 23:12:32 --> Language Class Initialized
INFO - 2025-11-04 23:12:32 --> Loader Class Initialized
INFO - 2025-11-04 23:12:32 --> Helper loaded: url_helper
INFO - 2025-11-04 23:12:32 --> Helper loaded: file_helper
INFO - 2025-11-04 23:12:32 --> Helper loaded: main_helper
INFO - 2025-11-04 23:12:32 --> Database Driver Class Initialized
INFO - 2025-11-04 23:12:32 --> Email Class Initialized
DEBUG - 2025-11-04 23:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:12:32 --> Controller Class Initialized
INFO - 2025-11-04 23:12:32 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:12:32 --> Model "User_model" initialized
INFO - 2025-11-04 23:12:32 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:12:32 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-04 23:12:32 --> Final output sent to browser
INFO - 2025-11-04 23:12:32 --> Total execution time: 0.1003
INFO - 2025-11-04 23:12:44 --> Config Class Initialized
INFO - 2025-11-04 23:12:44 --> Hooks Class Initialized
INFO - 2025-11-04 23:12:44 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:12:44 --> Utf8 Class Initialized
INFO - 2025-11-04 23:12:44 --> URI Class Initialized
INFO - 2025-11-04 23:12:44 --> Router Class Initialized
INFO - 2025-11-04 23:12:44 --> Output Class Initialized
INFO - 2025-11-04 23:12:44 --> Security Class Initialized
INFO - 2025-11-04 23:12:44 --> Input Class Initialized
INFO - 2025-11-04 23:12:44 --> Language Class Initialized
INFO - 2025-11-04 23:12:44 --> Loader Class Initialized
INFO - 2025-11-04 23:12:44 --> Helper loaded: url_helper
INFO - 2025-11-04 23:12:44 --> Helper loaded: file_helper
INFO - 2025-11-04 23:12:44 --> Helper loaded: main_helper
INFO - 2025-11-04 23:12:44 --> Database Driver Class Initialized
INFO - 2025-11-04 23:12:44 --> Email Class Initialized
DEBUG - 2025-11-04 23:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:12:44 --> Controller Class Initialized
INFO - 2025-11-04 23:12:44 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:12:44 --> Model "User_model" initialized
INFO - 2025-11-04 23:12:44 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:12:44 --> Final output sent to browser
INFO - 2025-11-04 23:12:44 --> Total execution time: 0.1157
INFO - 2025-11-04 23:12:48 --> Config Class Initialized
INFO - 2025-11-04 23:12:48 --> Hooks Class Initialized
INFO - 2025-11-04 23:12:48 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:12:48 --> Utf8 Class Initialized
INFO - 2025-11-04 23:12:48 --> URI Class Initialized
INFO - 2025-11-04 23:12:48 --> Router Class Initialized
INFO - 2025-11-04 23:12:48 --> Output Class Initialized
INFO - 2025-11-04 23:12:48 --> Security Class Initialized
INFO - 2025-11-04 23:12:48 --> Input Class Initialized
INFO - 2025-11-04 23:12:48 --> Language Class Initialized
INFO - 2025-11-04 23:12:48 --> Loader Class Initialized
INFO - 2025-11-04 23:12:48 --> Helper loaded: url_helper
INFO - 2025-11-04 23:12:48 --> Helper loaded: file_helper
INFO - 2025-11-04 23:12:48 --> Helper loaded: main_helper
INFO - 2025-11-04 23:12:48 --> Database Driver Class Initialized
INFO - 2025-11-04 23:12:48 --> Email Class Initialized
DEBUG - 2025-11-04 23:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:12:48 --> Controller Class Initialized
INFO - 2025-11-04 23:12:48 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:12:48 --> Model "User_model" initialized
INFO - 2025-11-04 23:12:48 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:12:48 --> Final output sent to browser
INFO - 2025-11-04 23:12:48 --> Total execution time: 0.1625
INFO - 2025-11-04 23:12:59 --> Config Class Initialized
INFO - 2025-11-04 23:12:59 --> Hooks Class Initialized
INFO - 2025-11-04 23:12:59 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:12:59 --> Utf8 Class Initialized
INFO - 2025-11-04 23:12:59 --> URI Class Initialized
INFO - 2025-11-04 23:12:59 --> Router Class Initialized
INFO - 2025-11-04 23:12:59 --> Output Class Initialized
INFO - 2025-11-04 23:12:59 --> Security Class Initialized
INFO - 2025-11-04 23:12:59 --> Input Class Initialized
INFO - 2025-11-04 23:12:59 --> Language Class Initialized
INFO - 2025-11-04 23:12:59 --> Loader Class Initialized
INFO - 2025-11-04 23:12:59 --> Helper loaded: url_helper
INFO - 2025-11-04 23:12:59 --> Helper loaded: file_helper
INFO - 2025-11-04 23:12:59 --> Helper loaded: main_helper
INFO - 2025-11-04 23:12:59 --> Database Driver Class Initialized
INFO - 2025-11-04 23:12:59 --> Email Class Initialized
DEBUG - 2025-11-04 23:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:12:59 --> Controller Class Initialized
INFO - 2025-11-04 23:12:59 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:12:59 --> Model "User_model" initialized
INFO - 2025-11-04 23:12:59 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:12:59 --> Final output sent to browser
INFO - 2025-11-04 23:12:59 --> Total execution time: 0.0543
INFO - 2025-11-04 23:13:06 --> Config Class Initialized
INFO - 2025-11-04 23:13:06 --> Hooks Class Initialized
INFO - 2025-11-04 23:13:06 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:13:06 --> Utf8 Class Initialized
INFO - 2025-11-04 23:13:06 --> URI Class Initialized
INFO - 2025-11-04 23:13:06 --> Router Class Initialized
INFO - 2025-11-04 23:13:06 --> Output Class Initialized
INFO - 2025-11-04 23:13:06 --> Security Class Initialized
INFO - 2025-11-04 23:13:06 --> Input Class Initialized
INFO - 2025-11-04 23:13:06 --> Language Class Initialized
INFO - 2025-11-04 23:13:06 --> Loader Class Initialized
INFO - 2025-11-04 23:13:06 --> Helper loaded: url_helper
INFO - 2025-11-04 23:13:06 --> Helper loaded: file_helper
INFO - 2025-11-04 23:13:06 --> Helper loaded: main_helper
INFO - 2025-11-04 23:13:06 --> Database Driver Class Initialized
INFO - 2025-11-04 23:13:06 --> Email Class Initialized
DEBUG - 2025-11-04 23:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:13:06 --> Controller Class Initialized
INFO - 2025-11-04 23:13:06 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:13:06 --> Model "User_model" initialized
INFO - 2025-11-04 23:13:06 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:13:06 --> Final output sent to browser
INFO - 2025-11-04 23:13:06 --> Total execution time: 0.0815
INFO - 2025-11-04 23:13:11 --> Config Class Initialized
INFO - 2025-11-04 23:13:11 --> Hooks Class Initialized
INFO - 2025-11-04 23:13:11 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:13:11 --> Utf8 Class Initialized
INFO - 2025-11-04 23:13:11 --> URI Class Initialized
INFO - 2025-11-04 23:13:11 --> Router Class Initialized
INFO - 2025-11-04 23:13:11 --> Output Class Initialized
INFO - 2025-11-04 23:13:11 --> Security Class Initialized
INFO - 2025-11-04 23:13:11 --> Input Class Initialized
INFO - 2025-11-04 23:13:11 --> Language Class Initialized
INFO - 2025-11-04 23:13:11 --> Loader Class Initialized
INFO - 2025-11-04 23:13:11 --> Helper loaded: url_helper
INFO - 2025-11-04 23:13:11 --> Helper loaded: file_helper
INFO - 2025-11-04 23:13:11 --> Helper loaded: main_helper
INFO - 2025-11-04 23:13:11 --> Database Driver Class Initialized
INFO - 2025-11-04 23:13:11 --> Email Class Initialized
DEBUG - 2025-11-04 23:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:13:11 --> Controller Class Initialized
INFO - 2025-11-04 23:13:11 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:13:11 --> Model "User_model" initialized
INFO - 2025-11-04 23:13:11 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:13:11 --> Final output sent to browser
INFO - 2025-11-04 23:13:11 --> Total execution time: 0.0532
INFO - 2025-11-04 23:13:13 --> Config Class Initialized
INFO - 2025-11-04 23:13:13 --> Hooks Class Initialized
INFO - 2025-11-04 23:13:13 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:13:13 --> Utf8 Class Initialized
INFO - 2025-11-04 23:13:13 --> URI Class Initialized
INFO - 2025-11-04 23:13:13 --> Router Class Initialized
INFO - 2025-11-04 23:13:13 --> Output Class Initialized
INFO - 2025-11-04 23:13:13 --> Security Class Initialized
INFO - 2025-11-04 23:13:13 --> Input Class Initialized
INFO - 2025-11-04 23:13:13 --> Language Class Initialized
INFO - 2025-11-04 23:13:13 --> Loader Class Initialized
INFO - 2025-11-04 23:13:13 --> Helper loaded: url_helper
INFO - 2025-11-04 23:13:13 --> Helper loaded: file_helper
INFO - 2025-11-04 23:13:13 --> Helper loaded: main_helper
INFO - 2025-11-04 23:13:13 --> Database Driver Class Initialized
INFO - 2025-11-04 23:13:13 --> Email Class Initialized
DEBUG - 2025-11-04 23:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:13:13 --> Controller Class Initialized
INFO - 2025-11-04 23:13:13 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:13:13 --> Model "User_model" initialized
INFO - 2025-11-04 23:13:13 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:13:13 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-04 23:13:13 --> Final output sent to browser
INFO - 2025-11-04 23:13:13 --> Total execution time: 0.0571
INFO - 2025-11-04 23:13:15 --> Config Class Initialized
INFO - 2025-11-04 23:13:15 --> Hooks Class Initialized
INFO - 2025-11-04 23:13:15 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:13:15 --> Utf8 Class Initialized
INFO - 2025-11-04 23:13:15 --> URI Class Initialized
INFO - 2025-11-04 23:13:15 --> Router Class Initialized
INFO - 2025-11-04 23:13:15 --> Output Class Initialized
INFO - 2025-11-04 23:13:15 --> Security Class Initialized
INFO - 2025-11-04 23:13:15 --> Input Class Initialized
INFO - 2025-11-04 23:13:15 --> Language Class Initialized
ERROR - 2025-11-04 23:13:15 --> 404 Page Not Found: Auth/forgot-password
INFO - 2025-11-04 23:13:22 --> Config Class Initialized
INFO - 2025-11-04 23:13:22 --> Hooks Class Initialized
INFO - 2025-11-04 23:13:22 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:13:22 --> Utf8 Class Initialized
INFO - 2025-11-04 23:13:22 --> URI Class Initialized
INFO - 2025-11-04 23:13:22 --> Router Class Initialized
INFO - 2025-11-04 23:13:22 --> Output Class Initialized
INFO - 2025-11-04 23:13:22 --> Security Class Initialized
INFO - 2025-11-04 23:13:22 --> Input Class Initialized
INFO - 2025-11-04 23:13:22 --> Language Class Initialized
INFO - 2025-11-04 23:13:22 --> Loader Class Initialized
INFO - 2025-11-04 23:13:22 --> Helper loaded: url_helper
INFO - 2025-11-04 23:13:22 --> Helper loaded: file_helper
INFO - 2025-11-04 23:13:22 --> Helper loaded: main_helper
INFO - 2025-11-04 23:13:22 --> Database Driver Class Initialized
INFO - 2025-11-04 23:13:22 --> Email Class Initialized
DEBUG - 2025-11-04 23:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:13:22 --> Controller Class Initialized
INFO - 2025-11-04 23:13:22 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:13:22 --> Model "User_model" initialized
INFO - 2025-11-04 23:13:22 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:13:22 --> File loaded: D:\laragon\www\acumena\application\views\auth/register.php
INFO - 2025-11-04 23:13:22 --> Final output sent to browser
INFO - 2025-11-04 23:13:22 --> Total execution time: 0.0919
INFO - 2025-11-04 23:13:30 --> Config Class Initialized
INFO - 2025-11-04 23:13:30 --> Hooks Class Initialized
INFO - 2025-11-04 23:13:30 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:13:30 --> Utf8 Class Initialized
INFO - 2025-11-04 23:13:30 --> URI Class Initialized
INFO - 2025-11-04 23:13:30 --> Router Class Initialized
INFO - 2025-11-04 23:13:30 --> Output Class Initialized
INFO - 2025-11-04 23:13:30 --> Security Class Initialized
INFO - 2025-11-04 23:13:30 --> Input Class Initialized
INFO - 2025-11-04 23:13:30 --> Language Class Initialized
INFO - 2025-11-04 23:13:30 --> Loader Class Initialized
INFO - 2025-11-04 23:13:30 --> Helper loaded: url_helper
INFO - 2025-11-04 23:13:30 --> Helper loaded: file_helper
INFO - 2025-11-04 23:13:30 --> Helper loaded: main_helper
INFO - 2025-11-04 23:13:30 --> Database Driver Class Initialized
INFO - 2025-11-04 23:13:30 --> Email Class Initialized
DEBUG - 2025-11-04 23:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:13:30 --> Controller Class Initialized
INFO - 2025-11-04 23:13:30 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:13:30 --> Model "User_model" initialized
INFO - 2025-11-04 23:13:30 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:13:30 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-04 23:13:30 --> Final output sent to browser
INFO - 2025-11-04 23:13:30 --> Total execution time: 0.0547
INFO - 2025-11-04 23:13:44 --> Config Class Initialized
INFO - 2025-11-04 23:13:44 --> Hooks Class Initialized
INFO - 2025-11-04 23:13:44 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:13:44 --> Utf8 Class Initialized
INFO - 2025-11-04 23:13:44 --> URI Class Initialized
INFO - 2025-11-04 23:13:44 --> Router Class Initialized
INFO - 2025-11-04 23:13:44 --> Output Class Initialized
INFO - 2025-11-04 23:13:44 --> Security Class Initialized
INFO - 2025-11-04 23:13:44 --> Input Class Initialized
INFO - 2025-11-04 23:13:44 --> Language Class Initialized
INFO - 2025-11-04 23:13:44 --> Loader Class Initialized
INFO - 2025-11-04 23:13:44 --> Helper loaded: url_helper
INFO - 2025-11-04 23:13:44 --> Helper loaded: file_helper
INFO - 2025-11-04 23:13:44 --> Helper loaded: main_helper
INFO - 2025-11-04 23:13:44 --> Database Driver Class Initialized
INFO - 2025-11-04 23:13:44 --> Email Class Initialized
DEBUG - 2025-11-04 23:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:13:44 --> Controller Class Initialized
INFO - 2025-11-04 23:13:44 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:13:44 --> Model "User_model" initialized
INFO - 2025-11-04 23:13:44 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:13:44 --> Final output sent to browser
INFO - 2025-11-04 23:13:44 --> Total execution time: 0.0880
INFO - 2025-11-04 23:13:47 --> Config Class Initialized
INFO - 2025-11-04 23:13:47 --> Hooks Class Initialized
INFO - 2025-11-04 23:13:47 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:13:47 --> Utf8 Class Initialized
INFO - 2025-11-04 23:13:47 --> URI Class Initialized
INFO - 2025-11-04 23:13:47 --> Router Class Initialized
INFO - 2025-11-04 23:13:47 --> Output Class Initialized
INFO - 2025-11-04 23:13:47 --> Security Class Initialized
INFO - 2025-11-04 23:13:47 --> Input Class Initialized
INFO - 2025-11-04 23:13:47 --> Language Class Initialized
INFO - 2025-11-04 23:13:47 --> Loader Class Initialized
INFO - 2025-11-04 23:13:47 --> Helper loaded: url_helper
INFO - 2025-11-04 23:13:47 --> Helper loaded: file_helper
INFO - 2025-11-04 23:13:47 --> Helper loaded: main_helper
INFO - 2025-11-04 23:13:47 --> Database Driver Class Initialized
INFO - 2025-11-04 23:13:47 --> Email Class Initialized
DEBUG - 2025-11-04 23:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:13:47 --> Controller Class Initialized
INFO - 2025-11-04 23:13:47 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:13:47 --> Model "User_model" initialized
INFO - 2025-11-04 23:13:47 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:13:47 --> Final output sent to browser
INFO - 2025-11-04 23:13:47 --> Total execution time: 0.0523
INFO - 2025-11-04 23:14:00 --> Config Class Initialized
INFO - 2025-11-04 23:14:00 --> Hooks Class Initialized
INFO - 2025-11-04 23:14:00 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:14:00 --> Utf8 Class Initialized
INFO - 2025-11-04 23:14:00 --> URI Class Initialized
INFO - 2025-11-04 23:14:00 --> Router Class Initialized
INFO - 2025-11-04 23:14:00 --> Output Class Initialized
INFO - 2025-11-04 23:14:00 --> Security Class Initialized
INFO - 2025-11-04 23:14:00 --> Input Class Initialized
INFO - 2025-11-04 23:14:00 --> Language Class Initialized
INFO - 2025-11-04 23:14:00 --> Loader Class Initialized
INFO - 2025-11-04 23:14:00 --> Helper loaded: url_helper
INFO - 2025-11-04 23:14:00 --> Helper loaded: file_helper
INFO - 2025-11-04 23:14:00 --> Helper loaded: main_helper
INFO - 2025-11-04 23:14:00 --> Database Driver Class Initialized
INFO - 2025-11-04 23:14:00 --> Email Class Initialized
DEBUG - 2025-11-04 23:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:14:00 --> Controller Class Initialized
INFO - 2025-11-04 23:14:00 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:14:00 --> Model "User_model" initialized
INFO - 2025-11-04 23:14:00 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:14:00 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-04 23:14:00 --> Final output sent to browser
INFO - 2025-11-04 23:14:00 --> Total execution time: 0.0669
INFO - 2025-11-04 23:14:10 --> Config Class Initialized
INFO - 2025-11-04 23:14:10 --> Hooks Class Initialized
INFO - 2025-11-04 23:14:10 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:14:10 --> Utf8 Class Initialized
INFO - 2025-11-04 23:14:10 --> URI Class Initialized
INFO - 2025-11-04 23:14:10 --> Router Class Initialized
INFO - 2025-11-04 23:14:10 --> Output Class Initialized
INFO - 2025-11-04 23:14:10 --> Security Class Initialized
INFO - 2025-11-04 23:14:10 --> Input Class Initialized
INFO - 2025-11-04 23:14:10 --> Language Class Initialized
INFO - 2025-11-04 23:14:10 --> Loader Class Initialized
INFO - 2025-11-04 23:14:10 --> Helper loaded: url_helper
INFO - 2025-11-04 23:14:10 --> Helper loaded: file_helper
INFO - 2025-11-04 23:14:10 --> Helper loaded: main_helper
INFO - 2025-11-04 23:14:10 --> Database Driver Class Initialized
INFO - 2025-11-04 23:14:10 --> Email Class Initialized
DEBUG - 2025-11-04 23:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:14:10 --> Controller Class Initialized
INFO - 2025-11-04 23:14:10 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:14:10 --> Model "User_model" initialized
INFO - 2025-11-04 23:14:10 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:14:10 --> Final output sent to browser
INFO - 2025-11-04 23:14:10 --> Total execution time: 0.0564
INFO - 2025-11-04 23:14:15 --> Config Class Initialized
INFO - 2025-11-04 23:14:15 --> Hooks Class Initialized
INFO - 2025-11-04 23:14:15 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:14:15 --> Utf8 Class Initialized
INFO - 2025-11-04 23:14:15 --> URI Class Initialized
INFO - 2025-11-04 23:14:15 --> Router Class Initialized
INFO - 2025-11-04 23:14:15 --> Output Class Initialized
INFO - 2025-11-04 23:14:15 --> Security Class Initialized
INFO - 2025-11-04 23:14:15 --> Input Class Initialized
INFO - 2025-11-04 23:14:15 --> Language Class Initialized
INFO - 2025-11-04 23:14:15 --> Loader Class Initialized
INFO - 2025-11-04 23:14:15 --> Helper loaded: url_helper
INFO - 2025-11-04 23:14:15 --> Helper loaded: file_helper
INFO - 2025-11-04 23:14:15 --> Helper loaded: main_helper
INFO - 2025-11-04 23:14:15 --> Database Driver Class Initialized
INFO - 2025-11-04 23:14:15 --> Email Class Initialized
DEBUG - 2025-11-04 23:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:14:15 --> Controller Class Initialized
INFO - 2025-11-04 23:14:15 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:14:15 --> Model "User_model" initialized
INFO - 2025-11-04 23:14:15 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:14:15 --> Final output sent to browser
INFO - 2025-11-04 23:14:15 --> Total execution time: 0.0653
INFO - 2025-11-04 23:14:15 --> Config Class Initialized
INFO - 2025-11-04 23:14:15 --> Hooks Class Initialized
INFO - 2025-11-04 23:14:15 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:14:15 --> Utf8 Class Initialized
INFO - 2025-11-04 23:14:15 --> URI Class Initialized
INFO - 2025-11-04 23:14:15 --> Router Class Initialized
INFO - 2025-11-04 23:14:15 --> Output Class Initialized
INFO - 2025-11-04 23:14:15 --> Security Class Initialized
INFO - 2025-11-04 23:14:15 --> Input Class Initialized
INFO - 2025-11-04 23:14:15 --> Language Class Initialized
INFO - 2025-11-04 23:14:15 --> Loader Class Initialized
INFO - 2025-11-04 23:14:15 --> Helper loaded: url_helper
INFO - 2025-11-04 23:14:15 --> Helper loaded: file_helper
INFO - 2025-11-04 23:14:15 --> Helper loaded: main_helper
INFO - 2025-11-04 23:14:15 --> Database Driver Class Initialized
INFO - 2025-11-04 23:14:15 --> Email Class Initialized
DEBUG - 2025-11-04 23:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:14:15 --> Controller Class Initialized
INFO - 2025-11-04 23:14:15 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:14:15 --> Model "User_model" initialized
INFO - 2025-11-04 23:14:15 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:14:15 --> Final output sent to browser
INFO - 2025-11-04 23:14:15 --> Total execution time: 0.0638
INFO - 2025-11-04 23:14:22 --> Config Class Initialized
INFO - 2025-11-04 23:14:22 --> Hooks Class Initialized
INFO - 2025-11-04 23:14:22 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:14:22 --> Utf8 Class Initialized
INFO - 2025-11-04 23:14:22 --> URI Class Initialized
INFO - 2025-11-04 23:14:22 --> Router Class Initialized
INFO - 2025-11-04 23:14:22 --> Output Class Initialized
INFO - 2025-11-04 23:14:22 --> Security Class Initialized
INFO - 2025-11-04 23:14:22 --> Input Class Initialized
INFO - 2025-11-04 23:14:22 --> Language Class Initialized
INFO - 2025-11-04 23:14:22 --> Loader Class Initialized
INFO - 2025-11-04 23:14:22 --> Helper loaded: url_helper
INFO - 2025-11-04 23:14:22 --> Helper loaded: file_helper
INFO - 2025-11-04 23:14:22 --> Helper loaded: main_helper
INFO - 2025-11-04 23:14:22 --> Database Driver Class Initialized
INFO - 2025-11-04 23:14:22 --> Email Class Initialized
DEBUG - 2025-11-04 23:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:14:22 --> Controller Class Initialized
INFO - 2025-11-04 23:14:22 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:14:22 --> Model "User_model" initialized
INFO - 2025-11-04 23:14:22 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:14:22 --> Final output sent to browser
INFO - 2025-11-04 23:14:22 --> Total execution time: 0.0949
INFO - 2025-11-04 23:14:35 --> Config Class Initialized
INFO - 2025-11-04 23:14:35 --> Hooks Class Initialized
INFO - 2025-11-04 23:14:35 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:14:35 --> Utf8 Class Initialized
INFO - 2025-11-04 23:14:35 --> URI Class Initialized
INFO - 2025-11-04 23:14:35 --> Router Class Initialized
INFO - 2025-11-04 23:14:35 --> Output Class Initialized
INFO - 2025-11-04 23:14:35 --> Security Class Initialized
INFO - 2025-11-04 23:14:35 --> Input Class Initialized
INFO - 2025-11-04 23:14:35 --> Language Class Initialized
INFO - 2025-11-04 23:14:35 --> Loader Class Initialized
INFO - 2025-11-04 23:14:35 --> Helper loaded: url_helper
INFO - 2025-11-04 23:14:35 --> Helper loaded: file_helper
INFO - 2025-11-04 23:14:35 --> Helper loaded: main_helper
INFO - 2025-11-04 23:14:35 --> Database Driver Class Initialized
INFO - 2025-11-04 23:14:35 --> Email Class Initialized
DEBUG - 2025-11-04 23:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:14:35 --> Controller Class Initialized
INFO - 2025-11-04 23:14:35 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:14:35 --> Model "User_model" initialized
INFO - 2025-11-04 23:14:35 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:14:35 --> Final output sent to browser
INFO - 2025-11-04 23:14:35 --> Total execution time: 0.0705
INFO - 2025-11-04 23:14:41 --> Config Class Initialized
INFO - 2025-11-04 23:14:41 --> Hooks Class Initialized
INFO - 2025-11-04 23:14:41 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:14:41 --> Utf8 Class Initialized
INFO - 2025-11-04 23:14:41 --> URI Class Initialized
INFO - 2025-11-04 23:14:41 --> Router Class Initialized
INFO - 2025-11-04 23:14:41 --> Output Class Initialized
INFO - 2025-11-04 23:14:41 --> Security Class Initialized
INFO - 2025-11-04 23:14:41 --> Input Class Initialized
INFO - 2025-11-04 23:14:41 --> Language Class Initialized
ERROR - 2025-11-04 23:14:41 --> 404 Page Not Found: Auth/forgot-password
INFO - 2025-11-04 23:15:33 --> Config Class Initialized
INFO - 2025-11-04 23:15:33 --> Hooks Class Initialized
INFO - 2025-11-04 23:15:33 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:15:33 --> Utf8 Class Initialized
INFO - 2025-11-04 23:15:33 --> URI Class Initialized
INFO - 2025-11-04 23:15:33 --> Router Class Initialized
INFO - 2025-11-04 23:15:33 --> Output Class Initialized
INFO - 2025-11-04 23:15:33 --> Security Class Initialized
INFO - 2025-11-04 23:15:33 --> Input Class Initialized
INFO - 2025-11-04 23:15:33 --> Language Class Initialized
INFO - 2025-11-04 23:15:33 --> Loader Class Initialized
INFO - 2025-11-04 23:15:33 --> Helper loaded: url_helper
INFO - 2025-11-04 23:15:33 --> Helper loaded: file_helper
INFO - 2025-11-04 23:15:33 --> Helper loaded: main_helper
INFO - 2025-11-04 23:15:33 --> Database Driver Class Initialized
INFO - 2025-11-04 23:15:33 --> Email Class Initialized
DEBUG - 2025-11-04 23:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:15:33 --> Controller Class Initialized
INFO - 2025-11-04 23:17:09 --> Config Class Initialized
INFO - 2025-11-04 23:17:09 --> Hooks Class Initialized
INFO - 2025-11-04 23:17:09 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:17:09 --> Utf8 Class Initialized
INFO - 2025-11-04 23:17:09 --> URI Class Initialized
INFO - 2025-11-04 23:17:09 --> Router Class Initialized
INFO - 2025-11-04 23:17:09 --> Output Class Initialized
INFO - 2025-11-04 23:17:09 --> Security Class Initialized
INFO - 2025-11-04 23:17:09 --> Input Class Initialized
INFO - 2025-11-04 23:17:09 --> Language Class Initialized
INFO - 2025-11-04 23:17:09 --> Loader Class Initialized
INFO - 2025-11-04 23:17:09 --> Helper loaded: url_helper
INFO - 2025-11-04 23:17:09 --> Helper loaded: file_helper
INFO - 2025-11-04 23:17:09 --> Helper loaded: main_helper
INFO - 2025-11-04 23:17:09 --> Database Driver Class Initialized
INFO - 2025-11-04 23:17:09 --> Email Class Initialized
DEBUG - 2025-11-04 23:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:17:09 --> Controller Class Initialized
INFO - 2025-11-04 23:17:09 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-04 23:17:09 --> Final output sent to browser
INFO - 2025-11-04 23:17:09 --> Total execution time: 0.0445
INFO - 2025-11-04 23:17:32 --> Config Class Initialized
INFO - 2025-11-04 23:17:32 --> Hooks Class Initialized
INFO - 2025-11-04 23:17:32 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:17:32 --> Utf8 Class Initialized
INFO - 2025-11-04 23:17:32 --> URI Class Initialized
INFO - 2025-11-04 23:17:32 --> Router Class Initialized
INFO - 2025-11-04 23:17:32 --> Output Class Initialized
INFO - 2025-11-04 23:17:32 --> Security Class Initialized
INFO - 2025-11-04 23:17:32 --> Input Class Initialized
INFO - 2025-11-04 23:17:32 --> Language Class Initialized
INFO - 2025-11-04 23:17:32 --> Loader Class Initialized
INFO - 2025-11-04 23:17:32 --> Helper loaded: url_helper
INFO - 2025-11-04 23:17:32 --> Helper loaded: file_helper
INFO - 2025-11-04 23:17:32 --> Helper loaded: main_helper
INFO - 2025-11-04 23:17:32 --> Database Driver Class Initialized
INFO - 2025-11-04 23:17:32 --> Email Class Initialized
DEBUG - 2025-11-04 23:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:17:32 --> Controller Class Initialized
INFO - 2025-11-04 23:17:32 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-04 23:17:32 --> Final output sent to browser
INFO - 2025-11-04 23:17:32 --> Total execution time: 0.0851
INFO - 2025-11-04 23:22:03 --> Config Class Initialized
INFO - 2025-11-04 23:22:03 --> Hooks Class Initialized
INFO - 2025-11-04 23:22:03 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:22:03 --> Utf8 Class Initialized
INFO - 2025-11-04 23:22:03 --> URI Class Initialized
INFO - 2025-11-04 23:22:03 --> Router Class Initialized
INFO - 2025-11-04 23:22:03 --> Output Class Initialized
INFO - 2025-11-04 23:22:03 --> Security Class Initialized
INFO - 2025-11-04 23:22:03 --> Input Class Initialized
INFO - 2025-11-04 23:22:03 --> Language Class Initialized
INFO - 2025-11-04 23:22:03 --> Loader Class Initialized
INFO - 2025-11-04 23:22:03 --> Helper loaded: url_helper
INFO - 2025-11-04 23:22:03 --> Helper loaded: file_helper
INFO - 2025-11-04 23:22:03 --> Helper loaded: main_helper
INFO - 2025-11-04 23:22:03 --> Database Driver Class Initialized
INFO - 2025-11-04 23:22:03 --> Email Class Initialized
DEBUG - 2025-11-04 23:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:22:03 --> Controller Class Initialized
INFO - 2025-11-04 23:22:03 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-04 23:22:03 --> Final output sent to browser
INFO - 2025-11-04 23:22:03 --> Total execution time: 0.0456
INFO - 2025-11-04 23:25:54 --> Config Class Initialized
INFO - 2025-11-04 23:25:54 --> Hooks Class Initialized
INFO - 2025-11-04 23:25:54 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:25:54 --> Utf8 Class Initialized
INFO - 2025-11-04 23:25:54 --> URI Class Initialized
INFO - 2025-11-04 23:25:54 --> Router Class Initialized
INFO - 2025-11-04 23:25:54 --> Output Class Initialized
INFO - 2025-11-04 23:25:54 --> Security Class Initialized
INFO - 2025-11-04 23:25:54 --> Input Class Initialized
INFO - 2025-11-04 23:25:54 --> Language Class Initialized
INFO - 2025-11-04 23:25:54 --> Loader Class Initialized
INFO - 2025-11-04 23:25:54 --> Helper loaded: url_helper
INFO - 2025-11-04 23:25:54 --> Helper loaded: file_helper
INFO - 2025-11-04 23:25:54 --> Helper loaded: main_helper
INFO - 2025-11-04 23:25:54 --> Database Driver Class Initialized
INFO - 2025-11-04 23:25:54 --> Email Class Initialized
DEBUG - 2025-11-04 23:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:25:54 --> Controller Class Initialized
INFO - 2025-11-04 23:25:54 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-04 23:25:54 --> Final output sent to browser
INFO - 2025-11-04 23:25:54 --> Total execution time: 0.0534
INFO - 2025-11-04 23:41:01 --> Config Class Initialized
INFO - 2025-11-04 23:41:01 --> Hooks Class Initialized
INFO - 2025-11-04 23:41:01 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:41:01 --> Utf8 Class Initialized
INFO - 2025-11-04 23:41:01 --> URI Class Initialized
INFO - 2025-11-04 23:41:01 --> Router Class Initialized
INFO - 2025-11-04 23:41:01 --> Output Class Initialized
INFO - 2025-11-04 23:41:01 --> Security Class Initialized
INFO - 2025-11-04 23:41:01 --> Input Class Initialized
INFO - 2025-11-04 23:41:01 --> Language Class Initialized
INFO - 2025-11-04 23:41:01 --> Loader Class Initialized
INFO - 2025-11-04 23:41:01 --> Helper loaded: url_helper
INFO - 2025-11-04 23:41:01 --> Helper loaded: file_helper
INFO - 2025-11-04 23:41:01 --> Helper loaded: main_helper
INFO - 2025-11-04 23:41:01 --> Database Driver Class Initialized
INFO - 2025-11-04 23:41:01 --> Email Class Initialized
DEBUG - 2025-11-04 23:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:41:01 --> Controller Class Initialized
INFO - 2025-11-04 23:41:01 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-04 23:41:01 --> Final output sent to browser
INFO - 2025-11-04 23:41:01 --> Total execution time: 0.2156
INFO - 2025-11-04 23:41:07 --> Config Class Initialized
INFO - 2025-11-04 23:41:07 --> Hooks Class Initialized
INFO - 2025-11-04 23:41:07 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:41:07 --> Utf8 Class Initialized
INFO - 2025-11-04 23:41:07 --> URI Class Initialized
INFO - 2025-11-04 23:41:07 --> Router Class Initialized
INFO - 2025-11-04 23:41:07 --> Output Class Initialized
INFO - 2025-11-04 23:41:07 --> Security Class Initialized
INFO - 2025-11-04 23:41:07 --> Input Class Initialized
INFO - 2025-11-04 23:41:07 --> Language Class Initialized
INFO - 2025-11-04 23:41:07 --> Loader Class Initialized
INFO - 2025-11-04 23:41:07 --> Helper loaded: url_helper
INFO - 2025-11-04 23:41:07 --> Helper loaded: file_helper
INFO - 2025-11-04 23:41:07 --> Helper loaded: main_helper
INFO - 2025-11-04 23:41:07 --> Database Driver Class Initialized
INFO - 2025-11-04 23:41:07 --> Email Class Initialized
DEBUG - 2025-11-04 23:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:41:07 --> Controller Class Initialized
INFO - 2025-11-04 23:41:07 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:41:07 --> Model "User_model" initialized
INFO - 2025-11-04 23:41:07 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:41:07 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-04 23:41:07 --> Final output sent to browser
INFO - 2025-11-04 23:41:07 --> Total execution time: 0.0785
INFO - 2025-11-04 23:41:08 --> Config Class Initialized
INFO - 2025-11-04 23:41:08 --> Hooks Class Initialized
INFO - 2025-11-04 23:41:08 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:41:08 --> Utf8 Class Initialized
INFO - 2025-11-04 23:41:08 --> URI Class Initialized
INFO - 2025-11-04 23:41:08 --> Router Class Initialized
INFO - 2025-11-04 23:41:08 --> Output Class Initialized
INFO - 2025-11-04 23:41:08 --> Security Class Initialized
INFO - 2025-11-04 23:41:08 --> Input Class Initialized
INFO - 2025-11-04 23:41:08 --> Language Class Initialized
INFO - 2025-11-04 23:41:08 --> Loader Class Initialized
INFO - 2025-11-04 23:41:08 --> Helper loaded: url_helper
INFO - 2025-11-04 23:41:08 --> Helper loaded: file_helper
INFO - 2025-11-04 23:41:08 --> Helper loaded: main_helper
INFO - 2025-11-04 23:41:08 --> Database Driver Class Initialized
INFO - 2025-11-04 23:41:08 --> Email Class Initialized
DEBUG - 2025-11-04 23:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:41:08 --> Controller Class Initialized
INFO - 2025-11-04 23:41:08 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-04 23:41:08 --> Final output sent to browser
INFO - 2025-11-04 23:41:08 --> Total execution time: 0.0472
INFO - 2025-11-04 23:41:12 --> Config Class Initialized
INFO - 2025-11-04 23:41:12 --> Hooks Class Initialized
INFO - 2025-11-04 23:41:12 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:41:12 --> Utf8 Class Initialized
INFO - 2025-11-04 23:41:12 --> URI Class Initialized
INFO - 2025-11-04 23:41:12 --> Router Class Initialized
INFO - 2025-11-04 23:41:12 --> Output Class Initialized
INFO - 2025-11-04 23:41:12 --> Security Class Initialized
INFO - 2025-11-04 23:41:12 --> Input Class Initialized
INFO - 2025-11-04 23:41:12 --> Language Class Initialized
INFO - 2025-11-04 23:41:12 --> Loader Class Initialized
INFO - 2025-11-04 23:41:12 --> Helper loaded: url_helper
INFO - 2025-11-04 23:41:12 --> Helper loaded: file_helper
INFO - 2025-11-04 23:41:12 --> Helper loaded: main_helper
INFO - 2025-11-04 23:41:12 --> Database Driver Class Initialized
INFO - 2025-11-04 23:41:12 --> Email Class Initialized
DEBUG - 2025-11-04 23:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:41:12 --> Controller Class Initialized
INFO - 2025-11-04 23:41:12 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:41:12 --> Model "User_model" initialized
INFO - 2025-11-04 23:41:12 --> Model "Auth_model" initialized
ERROR - 2025-11-04 23:41:12 --> Severity: Deprecated Notice --> trim(): Passing null to parameter #1 ($string) of type string is deprecated D:\laragon\www\acumena\application\controllers\Api_auth.php 352
INFO - 2025-11-04 23:41:12 --> Final output sent to browser
INFO - 2025-11-04 23:41:12 --> Total execution time: 0.0516
INFO - 2025-11-04 23:41:18 --> Config Class Initialized
INFO - 2025-11-04 23:41:18 --> Hooks Class Initialized
INFO - 2025-11-04 23:41:18 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:41:18 --> Utf8 Class Initialized
INFO - 2025-11-04 23:41:18 --> URI Class Initialized
INFO - 2025-11-04 23:41:18 --> Router Class Initialized
INFO - 2025-11-04 23:41:18 --> Output Class Initialized
INFO - 2025-11-04 23:41:18 --> Security Class Initialized
INFO - 2025-11-04 23:41:18 --> Input Class Initialized
INFO - 2025-11-04 23:41:18 --> Language Class Initialized
INFO - 2025-11-04 23:41:18 --> Loader Class Initialized
INFO - 2025-11-04 23:41:18 --> Helper loaded: url_helper
INFO - 2025-11-04 23:41:18 --> Helper loaded: file_helper
INFO - 2025-11-04 23:41:18 --> Helper loaded: main_helper
INFO - 2025-11-04 23:41:18 --> Database Driver Class Initialized
INFO - 2025-11-04 23:41:18 --> Email Class Initialized
DEBUG - 2025-11-04 23:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:41:18 --> Controller Class Initialized
INFO - 2025-11-04 23:41:18 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:41:18 --> Model "User_model" initialized
INFO - 2025-11-04 23:41:18 --> Model "Auth_model" initialized
ERROR - 2025-11-04 23:41:18 --> Severity: Deprecated Notice --> trim(): Passing null to parameter #1 ($string) of type string is deprecated D:\laragon\www\acumena\application\controllers\Api_auth.php 352
INFO - 2025-11-04 23:41:18 --> Final output sent to browser
INFO - 2025-11-04 23:41:18 --> Total execution time: 0.0729
INFO - 2025-11-04 23:42:22 --> Config Class Initialized
INFO - 2025-11-04 23:42:22 --> Hooks Class Initialized
INFO - 2025-11-04 23:42:22 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:42:22 --> Utf8 Class Initialized
INFO - 2025-11-04 23:42:22 --> URI Class Initialized
INFO - 2025-11-04 23:42:22 --> Router Class Initialized
INFO - 2025-11-04 23:42:22 --> Output Class Initialized
INFO - 2025-11-04 23:42:22 --> Security Class Initialized
INFO - 2025-11-04 23:42:22 --> Input Class Initialized
INFO - 2025-11-04 23:42:22 --> Language Class Initialized
INFO - 2025-11-04 23:42:22 --> Loader Class Initialized
INFO - 2025-11-04 23:42:22 --> Helper loaded: url_helper
INFO - 2025-11-04 23:42:22 --> Helper loaded: file_helper
INFO - 2025-11-04 23:42:22 --> Helper loaded: main_helper
INFO - 2025-11-04 23:42:22 --> Database Driver Class Initialized
INFO - 2025-11-04 23:42:22 --> Email Class Initialized
DEBUG - 2025-11-04 23:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:42:22 --> Controller Class Initialized
INFO - 2025-11-04 23:42:22 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:42:22 --> Model "User_model" initialized
INFO - 2025-11-04 23:42:22 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:42:22 --> Final output sent to browser
INFO - 2025-11-04 23:42:22 --> Total execution time: 0.0531
INFO - 2025-11-04 23:44:49 --> Config Class Initialized
INFO - 2025-11-04 23:44:49 --> Hooks Class Initialized
INFO - 2025-11-04 23:44:49 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:44:49 --> Utf8 Class Initialized
INFO - 2025-11-04 23:44:49 --> URI Class Initialized
INFO - 2025-11-04 23:44:49 --> Router Class Initialized
INFO - 2025-11-04 23:44:49 --> Output Class Initialized
INFO - 2025-11-04 23:44:49 --> Security Class Initialized
INFO - 2025-11-04 23:44:49 --> Input Class Initialized
INFO - 2025-11-04 23:44:49 --> Language Class Initialized
INFO - 2025-11-04 23:44:49 --> Loader Class Initialized
INFO - 2025-11-04 23:44:49 --> Helper loaded: url_helper
INFO - 2025-11-04 23:44:49 --> Helper loaded: file_helper
INFO - 2025-11-04 23:44:49 --> Helper loaded: main_helper
INFO - 2025-11-04 23:44:49 --> Database Driver Class Initialized
INFO - 2025-11-04 23:44:49 --> Email Class Initialized
DEBUG - 2025-11-04 23:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:44:49 --> Controller Class Initialized
INFO - 2025-11-04 23:44:49 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-04 23:44:49 --> Final output sent to browser
INFO - 2025-11-04 23:44:49 --> Total execution time: 0.0613
INFO - 2025-11-04 23:45:18 --> Config Class Initialized
INFO - 2025-11-04 23:45:18 --> Hooks Class Initialized
INFO - 2025-11-04 23:45:18 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:45:18 --> Utf8 Class Initialized
INFO - 2025-11-04 23:45:18 --> URI Class Initialized
INFO - 2025-11-04 23:45:18 --> Router Class Initialized
INFO - 2025-11-04 23:45:18 --> Output Class Initialized
INFO - 2025-11-04 23:45:18 --> Security Class Initialized
INFO - 2025-11-04 23:45:18 --> Input Class Initialized
INFO - 2025-11-04 23:45:18 --> Language Class Initialized
INFO - 2025-11-04 23:45:18 --> Loader Class Initialized
INFO - 2025-11-04 23:45:18 --> Helper loaded: url_helper
INFO - 2025-11-04 23:45:18 --> Helper loaded: file_helper
INFO - 2025-11-04 23:45:18 --> Helper loaded: main_helper
INFO - 2025-11-04 23:45:18 --> Database Driver Class Initialized
INFO - 2025-11-04 23:45:18 --> Email Class Initialized
DEBUG - 2025-11-04 23:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:45:18 --> Controller Class Initialized
INFO - 2025-11-04 23:45:18 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-04 23:45:18 --> Final output sent to browser
INFO - 2025-11-04 23:45:18 --> Total execution time: 0.0481
INFO - 2025-11-04 23:45:24 --> Config Class Initialized
INFO - 2025-11-04 23:45:24 --> Hooks Class Initialized
INFO - 2025-11-04 23:45:24 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:45:24 --> Utf8 Class Initialized
INFO - 2025-11-04 23:45:24 --> URI Class Initialized
INFO - 2025-11-04 23:45:24 --> Router Class Initialized
INFO - 2025-11-04 23:45:24 --> Output Class Initialized
INFO - 2025-11-04 23:45:24 --> Security Class Initialized
INFO - 2025-11-04 23:45:24 --> Input Class Initialized
INFO - 2025-11-04 23:45:24 --> Language Class Initialized
INFO - 2025-11-04 23:45:24 --> Loader Class Initialized
INFO - 2025-11-04 23:45:24 --> Helper loaded: url_helper
INFO - 2025-11-04 23:45:24 --> Helper loaded: file_helper
INFO - 2025-11-04 23:45:24 --> Helper loaded: main_helper
INFO - 2025-11-04 23:45:24 --> Database Driver Class Initialized
INFO - 2025-11-04 23:45:24 --> Email Class Initialized
DEBUG - 2025-11-04 23:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:45:24 --> Controller Class Initialized
INFO - 2025-11-04 23:45:24 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:45:24 --> Model "User_model" initialized
INFO - 2025-11-04 23:45:24 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:45:24 --> Final output sent to browser
INFO - 2025-11-04 23:45:24 --> Total execution time: 0.0711
INFO - 2025-11-04 23:47:09 --> Config Class Initialized
INFO - 2025-11-04 23:47:09 --> Hooks Class Initialized
INFO - 2025-11-04 23:47:09 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:47:09 --> Utf8 Class Initialized
INFO - 2025-11-04 23:47:09 --> URI Class Initialized
INFO - 2025-11-04 23:47:09 --> Router Class Initialized
INFO - 2025-11-04 23:47:09 --> Output Class Initialized
INFO - 2025-11-04 23:47:09 --> Security Class Initialized
INFO - 2025-11-04 23:47:09 --> Input Class Initialized
INFO - 2025-11-04 23:47:09 --> Language Class Initialized
INFO - 2025-11-04 23:47:09 --> Loader Class Initialized
INFO - 2025-11-04 23:47:09 --> Helper loaded: url_helper
INFO - 2025-11-04 23:47:09 --> Helper loaded: file_helper
INFO - 2025-11-04 23:47:09 --> Helper loaded: main_helper
INFO - 2025-11-04 23:47:09 --> Database Driver Class Initialized
INFO - 2025-11-04 23:47:09 --> Email Class Initialized
DEBUG - 2025-11-04 23:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:47:09 --> Controller Class Initialized
INFO - 2025-11-04 23:47:09 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-04 23:47:09 --> Final output sent to browser
INFO - 2025-11-04 23:47:09 --> Total execution time: 0.2207
INFO - 2025-11-04 23:47:13 --> Config Class Initialized
INFO - 2025-11-04 23:47:13 --> Hooks Class Initialized
INFO - 2025-11-04 23:47:13 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:47:13 --> Utf8 Class Initialized
INFO - 2025-11-04 23:47:13 --> URI Class Initialized
INFO - 2025-11-04 23:47:13 --> Router Class Initialized
INFO - 2025-11-04 23:47:13 --> Output Class Initialized
INFO - 2025-11-04 23:47:13 --> Security Class Initialized
INFO - 2025-11-04 23:47:13 --> Input Class Initialized
INFO - 2025-11-04 23:47:13 --> Language Class Initialized
INFO - 2025-11-04 23:47:13 --> Loader Class Initialized
INFO - 2025-11-04 23:47:13 --> Helper loaded: url_helper
INFO - 2025-11-04 23:47:13 --> Helper loaded: file_helper
INFO - 2025-11-04 23:47:13 --> Helper loaded: main_helper
INFO - 2025-11-04 23:47:13 --> Database Driver Class Initialized
INFO - 2025-11-04 23:47:13 --> Email Class Initialized
DEBUG - 2025-11-04 23:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:47:13 --> Controller Class Initialized
INFO - 2025-11-04 23:47:13 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:47:13 --> Model "User_model" initialized
INFO - 2025-11-04 23:47:13 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:47:13 --> Final output sent to browser
INFO - 2025-11-04 23:47:13 --> Total execution time: 0.0514
INFO - 2025-11-04 23:47:50 --> Config Class Initialized
INFO - 2025-11-04 23:47:50 --> Hooks Class Initialized
INFO - 2025-11-04 23:47:50 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:47:50 --> Utf8 Class Initialized
INFO - 2025-11-04 23:47:50 --> URI Class Initialized
INFO - 2025-11-04 23:47:50 --> Router Class Initialized
INFO - 2025-11-04 23:47:50 --> Output Class Initialized
INFO - 2025-11-04 23:47:50 --> Security Class Initialized
INFO - 2025-11-04 23:47:50 --> Input Class Initialized
INFO - 2025-11-04 23:47:50 --> Language Class Initialized
INFO - 2025-11-04 23:47:50 --> Loader Class Initialized
INFO - 2025-11-04 23:47:50 --> Helper loaded: url_helper
INFO - 2025-11-04 23:47:50 --> Helper loaded: file_helper
INFO - 2025-11-04 23:47:50 --> Helper loaded: main_helper
INFO - 2025-11-04 23:47:50 --> Database Driver Class Initialized
INFO - 2025-11-04 23:47:50 --> Email Class Initialized
DEBUG - 2025-11-04 23:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:47:50 --> Controller Class Initialized
INFO - 2025-11-04 23:47:50 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-04 23:47:50 --> Final output sent to browser
INFO - 2025-11-04 23:47:50 --> Total execution time: 0.0541
INFO - 2025-11-04 23:47:54 --> Config Class Initialized
INFO - 2025-11-04 23:47:54 --> Hooks Class Initialized
INFO - 2025-11-04 23:47:54 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:47:54 --> Utf8 Class Initialized
INFO - 2025-11-04 23:47:54 --> URI Class Initialized
INFO - 2025-11-04 23:47:54 --> Router Class Initialized
INFO - 2025-11-04 23:47:54 --> Output Class Initialized
INFO - 2025-11-04 23:47:54 --> Security Class Initialized
INFO - 2025-11-04 23:47:54 --> Input Class Initialized
INFO - 2025-11-04 23:47:54 --> Language Class Initialized
INFO - 2025-11-04 23:47:54 --> Loader Class Initialized
INFO - 2025-11-04 23:47:54 --> Helper loaded: url_helper
INFO - 2025-11-04 23:47:54 --> Helper loaded: file_helper
INFO - 2025-11-04 23:47:54 --> Helper loaded: main_helper
INFO - 2025-11-04 23:47:54 --> Database Driver Class Initialized
INFO - 2025-11-04 23:47:54 --> Email Class Initialized
DEBUG - 2025-11-04 23:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:47:54 --> Controller Class Initialized
INFO - 2025-11-04 23:47:54 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:47:54 --> Model "User_model" initialized
INFO - 2025-11-04 23:47:54 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:47:54 --> Final output sent to browser
INFO - 2025-11-04 23:47:54 --> Total execution time: 0.0712
INFO - 2025-11-04 23:49:11 --> Config Class Initialized
INFO - 2025-11-04 23:49:11 --> Hooks Class Initialized
INFO - 2025-11-04 23:49:11 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:49:11 --> Utf8 Class Initialized
INFO - 2025-11-04 23:49:11 --> URI Class Initialized
INFO - 2025-11-04 23:49:11 --> Router Class Initialized
INFO - 2025-11-04 23:49:11 --> Output Class Initialized
INFO - 2025-11-04 23:49:11 --> Security Class Initialized
INFO - 2025-11-04 23:49:11 --> Input Class Initialized
INFO - 2025-11-04 23:49:11 --> Language Class Initialized
INFO - 2025-11-04 23:49:11 --> Loader Class Initialized
INFO - 2025-11-04 23:49:11 --> Helper loaded: url_helper
INFO - 2025-11-04 23:49:11 --> Helper loaded: file_helper
INFO - 2025-11-04 23:49:11 --> Helper loaded: main_helper
INFO - 2025-11-04 23:49:11 --> Database Driver Class Initialized
INFO - 2025-11-04 23:49:11 --> Email Class Initialized
DEBUG - 2025-11-04 23:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:49:11 --> Controller Class Initialized
INFO - 2025-11-04 23:49:11 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-04 23:49:11 --> Final output sent to browser
INFO - 2025-11-04 23:49:11 --> Total execution time: 0.0452
INFO - 2025-11-04 23:49:14 --> Config Class Initialized
INFO - 2025-11-04 23:49:14 --> Hooks Class Initialized
INFO - 2025-11-04 23:49:14 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:49:14 --> Utf8 Class Initialized
INFO - 2025-11-04 23:49:14 --> URI Class Initialized
INFO - 2025-11-04 23:49:14 --> Router Class Initialized
INFO - 2025-11-04 23:49:14 --> Output Class Initialized
INFO - 2025-11-04 23:49:14 --> Security Class Initialized
INFO - 2025-11-04 23:49:14 --> Input Class Initialized
INFO - 2025-11-04 23:49:14 --> Language Class Initialized
INFO - 2025-11-04 23:49:14 --> Loader Class Initialized
INFO - 2025-11-04 23:49:14 --> Helper loaded: url_helper
INFO - 2025-11-04 23:49:14 --> Helper loaded: file_helper
INFO - 2025-11-04 23:49:14 --> Helper loaded: main_helper
INFO - 2025-11-04 23:49:14 --> Database Driver Class Initialized
INFO - 2025-11-04 23:49:14 --> Email Class Initialized
DEBUG - 2025-11-04 23:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:49:14 --> Controller Class Initialized
INFO - 2025-11-04 23:49:14 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:49:14 --> Model "User_model" initialized
INFO - 2025-11-04 23:49:14 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:49:14 --> Final output sent to browser
INFO - 2025-11-04 23:49:14 --> Total execution time: 0.0532
INFO - 2025-11-04 23:50:23 --> Config Class Initialized
INFO - 2025-11-04 23:50:23 --> Hooks Class Initialized
INFO - 2025-11-04 23:50:23 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:50:23 --> Utf8 Class Initialized
INFO - 2025-11-04 23:50:23 --> URI Class Initialized
INFO - 2025-11-04 23:50:23 --> Router Class Initialized
INFO - 2025-11-04 23:50:23 --> Output Class Initialized
INFO - 2025-11-04 23:50:23 --> Security Class Initialized
INFO - 2025-11-04 23:50:23 --> Input Class Initialized
INFO - 2025-11-04 23:50:23 --> Language Class Initialized
INFO - 2025-11-04 23:50:23 --> Loader Class Initialized
INFO - 2025-11-04 23:50:23 --> Helper loaded: url_helper
INFO - 2025-11-04 23:50:23 --> Helper loaded: file_helper
INFO - 2025-11-04 23:50:23 --> Helper loaded: main_helper
INFO - 2025-11-04 23:50:24 --> Database Driver Class Initialized
INFO - 2025-11-04 23:50:24 --> Email Class Initialized
DEBUG - 2025-11-04 23:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:50:24 --> Controller Class Initialized
INFO - 2025-11-04 23:50:24 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-04 23:50:24 --> Final output sent to browser
INFO - 2025-11-04 23:50:24 --> Total execution time: 0.0540
INFO - 2025-11-04 23:50:27 --> Config Class Initialized
INFO - 2025-11-04 23:50:27 --> Hooks Class Initialized
INFO - 2025-11-04 23:50:27 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:50:27 --> Utf8 Class Initialized
INFO - 2025-11-04 23:50:27 --> URI Class Initialized
INFO - 2025-11-04 23:50:27 --> Router Class Initialized
INFO - 2025-11-04 23:50:27 --> Output Class Initialized
INFO - 2025-11-04 23:50:27 --> Security Class Initialized
INFO - 2025-11-04 23:50:27 --> Input Class Initialized
INFO - 2025-11-04 23:50:27 --> Language Class Initialized
INFO - 2025-11-04 23:50:27 --> Loader Class Initialized
INFO - 2025-11-04 23:50:27 --> Helper loaded: url_helper
INFO - 2025-11-04 23:50:27 --> Helper loaded: file_helper
INFO - 2025-11-04 23:50:27 --> Helper loaded: main_helper
INFO - 2025-11-04 23:50:27 --> Database Driver Class Initialized
INFO - 2025-11-04 23:50:27 --> Email Class Initialized
DEBUG - 2025-11-04 23:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:50:27 --> Controller Class Initialized
INFO - 2025-11-04 23:50:27 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:50:27 --> Model "User_model" initialized
INFO - 2025-11-04 23:50:27 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:50:27 --> Final output sent to browser
INFO - 2025-11-04 23:50:27 --> Total execution time: 0.0741
INFO - 2025-11-04 23:51:14 --> Config Class Initialized
INFO - 2025-11-04 23:51:14 --> Hooks Class Initialized
INFO - 2025-11-04 23:51:14 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:51:14 --> Utf8 Class Initialized
INFO - 2025-11-04 23:51:14 --> URI Class Initialized
INFO - 2025-11-04 23:51:14 --> Router Class Initialized
INFO - 2025-11-04 23:51:14 --> Output Class Initialized
INFO - 2025-11-04 23:51:14 --> Security Class Initialized
INFO - 2025-11-04 23:51:14 --> Input Class Initialized
INFO - 2025-11-04 23:51:14 --> Language Class Initialized
INFO - 2025-11-04 23:51:14 --> Loader Class Initialized
INFO - 2025-11-04 23:51:14 --> Helper loaded: url_helper
INFO - 2025-11-04 23:51:14 --> Helper loaded: file_helper
INFO - 2025-11-04 23:51:14 --> Helper loaded: main_helper
INFO - 2025-11-04 23:51:14 --> Database Driver Class Initialized
INFO - 2025-11-04 23:51:14 --> Email Class Initialized
DEBUG - 2025-11-04 23:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:51:14 --> Controller Class Initialized
INFO - 2025-11-04 23:51:14 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-04 23:51:14 --> Final output sent to browser
INFO - 2025-11-04 23:51:14 --> Total execution time: 0.0678
INFO - 2025-11-04 23:51:18 --> Config Class Initialized
INFO - 2025-11-04 23:51:18 --> Hooks Class Initialized
INFO - 2025-11-04 23:51:18 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:51:18 --> Utf8 Class Initialized
INFO - 2025-11-04 23:51:18 --> URI Class Initialized
INFO - 2025-11-04 23:51:18 --> Router Class Initialized
INFO - 2025-11-04 23:51:18 --> Output Class Initialized
INFO - 2025-11-04 23:51:18 --> Security Class Initialized
INFO - 2025-11-04 23:51:18 --> Input Class Initialized
INFO - 2025-11-04 23:51:18 --> Language Class Initialized
INFO - 2025-11-04 23:51:18 --> Loader Class Initialized
INFO - 2025-11-04 23:51:18 --> Helper loaded: url_helper
INFO - 2025-11-04 23:51:18 --> Helper loaded: file_helper
INFO - 2025-11-04 23:51:18 --> Helper loaded: main_helper
INFO - 2025-11-04 23:51:18 --> Database Driver Class Initialized
INFO - 2025-11-04 23:51:18 --> Email Class Initialized
DEBUG - 2025-11-04 23:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:51:18 --> Controller Class Initialized
INFO - 2025-11-04 23:51:18 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:51:18 --> Model "User_model" initialized
INFO - 2025-11-04 23:51:18 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:51:18 --> Forgot password request for email: 
INFO - 2025-11-04 23:51:18 --> Final output sent to browser
INFO - 2025-11-04 23:51:18 --> Total execution time: 0.0659
INFO - 2025-11-04 23:54:02 --> Config Class Initialized
INFO - 2025-11-04 23:54:02 --> Hooks Class Initialized
INFO - 2025-11-04 23:54:02 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:54:02 --> Utf8 Class Initialized
INFO - 2025-11-04 23:54:02 --> URI Class Initialized
INFO - 2025-11-04 23:54:02 --> Router Class Initialized
INFO - 2025-11-04 23:54:02 --> Output Class Initialized
INFO - 2025-11-04 23:54:02 --> Security Class Initialized
INFO - 2025-11-04 23:54:02 --> Input Class Initialized
INFO - 2025-11-04 23:54:02 --> Language Class Initialized
INFO - 2025-11-04 23:54:02 --> Loader Class Initialized
INFO - 2025-11-04 23:54:02 --> Helper loaded: url_helper
INFO - 2025-11-04 23:54:02 --> Helper loaded: file_helper
INFO - 2025-11-04 23:54:02 --> Helper loaded: main_helper
INFO - 2025-11-04 23:54:02 --> Database Driver Class Initialized
INFO - 2025-11-04 23:54:02 --> Email Class Initialized
DEBUG - 2025-11-04 23:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:54:02 --> Controller Class Initialized
INFO - 2025-11-04 23:54:02 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-04 23:54:02 --> Final output sent to browser
INFO - 2025-11-04 23:54:02 --> Total execution time: 0.0572
INFO - 2025-11-04 23:54:04 --> Config Class Initialized
INFO - 2025-11-04 23:54:04 --> Hooks Class Initialized
INFO - 2025-11-04 23:54:04 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:54:04 --> Utf8 Class Initialized
INFO - 2025-11-04 23:54:04 --> URI Class Initialized
INFO - 2025-11-04 23:54:04 --> Router Class Initialized
INFO - 2025-11-04 23:54:04 --> Output Class Initialized
INFO - 2025-11-04 23:54:04 --> Security Class Initialized
INFO - 2025-11-04 23:54:04 --> Input Class Initialized
INFO - 2025-11-04 23:54:04 --> Language Class Initialized
INFO - 2025-11-04 23:54:04 --> Loader Class Initialized
INFO - 2025-11-04 23:54:04 --> Helper loaded: url_helper
INFO - 2025-11-04 23:54:04 --> Helper loaded: file_helper
INFO - 2025-11-04 23:54:04 --> Helper loaded: main_helper
INFO - 2025-11-04 23:54:04 --> Database Driver Class Initialized
INFO - 2025-11-04 23:54:04 --> Email Class Initialized
DEBUG - 2025-11-04 23:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:54:04 --> Controller Class Initialized
INFO - 2025-11-04 23:54:04 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:54:04 --> Model "User_model" initialized
INFO - 2025-11-04 23:54:04 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:54:04 --> API /auth/forgot_password invoked; email payload="(empty)"
INFO - 2025-11-04 23:54:04 --> API forgot_password skipped processing due to empty email
INFO - 2025-11-04 23:54:04 --> Final output sent to browser
INFO - 2025-11-04 23:54:04 --> Total execution time: 0.0724
INFO - 2025-11-04 23:54:47 --> Config Class Initialized
INFO - 2025-11-04 23:54:47 --> Hooks Class Initialized
INFO - 2025-11-04 23:54:47 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:54:47 --> Utf8 Class Initialized
INFO - 2025-11-04 23:54:47 --> URI Class Initialized
INFO - 2025-11-04 23:54:47 --> Router Class Initialized
INFO - 2025-11-04 23:54:47 --> Output Class Initialized
INFO - 2025-11-04 23:54:47 --> Security Class Initialized
INFO - 2025-11-04 23:54:47 --> Input Class Initialized
INFO - 2025-11-04 23:54:47 --> Language Class Initialized
INFO - 2025-11-04 23:54:47 --> Loader Class Initialized
INFO - 2025-11-04 23:54:47 --> Helper loaded: url_helper
INFO - 2025-11-04 23:54:47 --> Helper loaded: file_helper
INFO - 2025-11-04 23:54:47 --> Helper loaded: main_helper
INFO - 2025-11-04 23:54:47 --> Database Driver Class Initialized
INFO - 2025-11-04 23:54:47 --> Email Class Initialized
DEBUG - 2025-11-04 23:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:54:47 --> Controller Class Initialized
INFO - 2025-11-04 23:54:47 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-04 23:54:47 --> Final output sent to browser
INFO - 2025-11-04 23:54:47 --> Total execution time: 0.0524
INFO - 2025-11-04 23:54:49 --> Config Class Initialized
INFO - 2025-11-04 23:54:49 --> Hooks Class Initialized
INFO - 2025-11-04 23:54:49 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:54:49 --> Utf8 Class Initialized
INFO - 2025-11-04 23:54:49 --> URI Class Initialized
INFO - 2025-11-04 23:54:49 --> Router Class Initialized
INFO - 2025-11-04 23:54:49 --> Output Class Initialized
INFO - 2025-11-04 23:54:49 --> Security Class Initialized
INFO - 2025-11-04 23:54:49 --> Input Class Initialized
INFO - 2025-11-04 23:54:49 --> Language Class Initialized
INFO - 2025-11-04 23:54:49 --> Loader Class Initialized
INFO - 2025-11-04 23:54:49 --> Helper loaded: url_helper
INFO - 2025-11-04 23:54:49 --> Helper loaded: file_helper
INFO - 2025-11-04 23:54:49 --> Helper loaded: main_helper
INFO - 2025-11-04 23:54:49 --> Database Driver Class Initialized
INFO - 2025-11-04 23:54:49 --> Email Class Initialized
DEBUG - 2025-11-04 23:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:54:49 --> Controller Class Initialized
INFO - 2025-11-04 23:54:49 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:54:49 --> Model "User_model" initialized
INFO - 2025-11-04 23:54:49 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:54:49 --> API /auth/forgot_password invoked; email payload="(empty)"
INFO - 2025-11-04 23:54:49 --> API forgot_password skipped processing due to empty email
INFO - 2025-11-04 23:54:49 --> Final output sent to browser
INFO - 2025-11-04 23:54:49 --> Total execution time: 0.0625
INFO - 2025-11-04 23:55:17 --> Config Class Initialized
INFO - 2025-11-04 23:55:17 --> Hooks Class Initialized
INFO - 2025-11-04 23:55:17 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:55:17 --> Utf8 Class Initialized
INFO - 2025-11-04 23:55:17 --> URI Class Initialized
INFO - 2025-11-04 23:55:17 --> Router Class Initialized
INFO - 2025-11-04 23:55:17 --> Output Class Initialized
INFO - 2025-11-04 23:55:17 --> Security Class Initialized
INFO - 2025-11-04 23:55:17 --> Input Class Initialized
INFO - 2025-11-04 23:55:17 --> Language Class Initialized
INFO - 2025-11-04 23:55:17 --> Loader Class Initialized
INFO - 2025-11-04 23:55:17 --> Helper loaded: url_helper
INFO - 2025-11-04 23:55:17 --> Helper loaded: file_helper
INFO - 2025-11-04 23:55:17 --> Helper loaded: main_helper
INFO - 2025-11-04 23:55:17 --> Database Driver Class Initialized
INFO - 2025-11-04 23:55:17 --> Email Class Initialized
DEBUG - 2025-11-04 23:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:55:17 --> Controller Class Initialized
INFO - 2025-11-04 23:55:17 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-04 23:55:17 --> Final output sent to browser
INFO - 2025-11-04 23:55:17 --> Total execution time: 0.0585
INFO - 2025-11-04 23:55:20 --> Config Class Initialized
INFO - 2025-11-04 23:55:20 --> Hooks Class Initialized
INFO - 2025-11-04 23:55:20 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:55:20 --> Utf8 Class Initialized
INFO - 2025-11-04 23:55:20 --> URI Class Initialized
INFO - 2025-11-04 23:55:20 --> Router Class Initialized
INFO - 2025-11-04 23:55:20 --> Output Class Initialized
INFO - 2025-11-04 23:55:20 --> Security Class Initialized
INFO - 2025-11-04 23:55:20 --> Input Class Initialized
INFO - 2025-11-04 23:55:20 --> Language Class Initialized
ERROR - 2025-11-04 23:55:20 --> Severity: error --> Exception: syntax error, unexpected token "]" D:\laragon\www\acumena\application\controllers\Api_auth.php 371
INFO - 2025-11-04 23:55:31 --> Config Class Initialized
INFO - 2025-11-04 23:55:31 --> Hooks Class Initialized
INFO - 2025-11-04 23:55:31 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:55:31 --> Utf8 Class Initialized
INFO - 2025-11-04 23:55:31 --> URI Class Initialized
INFO - 2025-11-04 23:55:31 --> Router Class Initialized
INFO - 2025-11-04 23:55:31 --> Output Class Initialized
INFO - 2025-11-04 23:55:31 --> Security Class Initialized
INFO - 2025-11-04 23:55:31 --> Input Class Initialized
INFO - 2025-11-04 23:55:31 --> Language Class Initialized
INFO - 2025-11-04 23:55:31 --> Loader Class Initialized
INFO - 2025-11-04 23:55:31 --> Helper loaded: url_helper
INFO - 2025-11-04 23:55:31 --> Helper loaded: file_helper
INFO - 2025-11-04 23:55:31 --> Helper loaded: main_helper
INFO - 2025-11-04 23:55:31 --> Database Driver Class Initialized
INFO - 2025-11-04 23:55:31 --> Email Class Initialized
DEBUG - 2025-11-04 23:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:55:31 --> Controller Class Initialized
INFO - 2025-11-04 23:55:31 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-04 23:55:31 --> Final output sent to browser
INFO - 2025-11-04 23:55:31 --> Total execution time: 0.0563
INFO - 2025-11-04 23:55:36 --> Config Class Initialized
INFO - 2025-11-04 23:55:36 --> Hooks Class Initialized
INFO - 2025-11-04 23:55:36 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:55:36 --> Utf8 Class Initialized
INFO - 2025-11-04 23:55:36 --> URI Class Initialized
INFO - 2025-11-04 23:55:36 --> Router Class Initialized
INFO - 2025-11-04 23:55:36 --> Output Class Initialized
INFO - 2025-11-04 23:55:36 --> Security Class Initialized
INFO - 2025-11-04 23:55:36 --> Input Class Initialized
INFO - 2025-11-04 23:55:36 --> Language Class Initialized
INFO - 2025-11-04 23:55:36 --> Loader Class Initialized
INFO - 2025-11-04 23:55:36 --> Helper loaded: url_helper
INFO - 2025-11-04 23:55:36 --> Helper loaded: file_helper
INFO - 2025-11-04 23:55:36 --> Helper loaded: main_helper
INFO - 2025-11-04 23:55:36 --> Database Driver Class Initialized
INFO - 2025-11-04 23:55:36 --> Email Class Initialized
DEBUG - 2025-11-04 23:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:55:36 --> Controller Class Initialized
INFO - 2025-11-04 23:55:36 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:55:36 --> Model "User_model" initialized
INFO - 2025-11-04 23:55:36 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:55:36 --> API /auth/forgot_password invoked; email payload="(empty)"
INFO - 2025-11-04 23:55:36 --> API forgot_password skipped processing due to empty email
INFO - 2025-11-04 23:55:36 --> Final output sent to browser
INFO - 2025-11-04 23:55:36 --> Total execution time: 0.0572
INFO - 2025-11-04 23:56:24 --> Config Class Initialized
INFO - 2025-11-04 23:56:24 --> Hooks Class Initialized
INFO - 2025-11-04 23:56:24 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:56:24 --> Utf8 Class Initialized
INFO - 2025-11-04 23:56:24 --> URI Class Initialized
INFO - 2025-11-04 23:56:24 --> Router Class Initialized
INFO - 2025-11-04 23:56:24 --> Output Class Initialized
INFO - 2025-11-04 23:56:24 --> Security Class Initialized
INFO - 2025-11-04 23:56:24 --> Input Class Initialized
INFO - 2025-11-04 23:56:24 --> Language Class Initialized
INFO - 2025-11-04 23:56:24 --> Loader Class Initialized
INFO - 2025-11-04 23:56:24 --> Helper loaded: url_helper
INFO - 2025-11-04 23:56:24 --> Helper loaded: file_helper
INFO - 2025-11-04 23:56:24 --> Helper loaded: main_helper
INFO - 2025-11-04 23:56:24 --> Database Driver Class Initialized
INFO - 2025-11-04 23:56:24 --> Email Class Initialized
DEBUG - 2025-11-04 23:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:56:24 --> Controller Class Initialized
INFO - 2025-11-04 23:56:24 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-04 23:56:24 --> Final output sent to browser
INFO - 2025-11-04 23:56:24 --> Total execution time: 0.0573
INFO - 2025-11-04 23:56:29 --> Config Class Initialized
INFO - 2025-11-04 23:56:29 --> Hooks Class Initialized
INFO - 2025-11-04 23:56:29 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:56:29 --> Utf8 Class Initialized
INFO - 2025-11-04 23:56:29 --> URI Class Initialized
INFO - 2025-11-04 23:56:29 --> Router Class Initialized
INFO - 2025-11-04 23:56:29 --> Output Class Initialized
INFO - 2025-11-04 23:56:29 --> Security Class Initialized
INFO - 2025-11-04 23:56:29 --> Input Class Initialized
INFO - 2025-11-04 23:56:29 --> Language Class Initialized
INFO - 2025-11-04 23:56:29 --> Loader Class Initialized
INFO - 2025-11-04 23:56:29 --> Helper loaded: url_helper
INFO - 2025-11-04 23:56:29 --> Helper loaded: file_helper
INFO - 2025-11-04 23:56:29 --> Helper loaded: main_helper
INFO - 2025-11-04 23:56:29 --> Database Driver Class Initialized
INFO - 2025-11-04 23:56:29 --> Email Class Initialized
DEBUG - 2025-11-04 23:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:56:29 --> Controller Class Initialized
INFO - 2025-11-04 23:56:29 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:56:29 --> Model "User_model" initialized
INFO - 2025-11-04 23:56:29 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:56:29 --> API /auth/forgot_password invoked; email payload="(empty)"
INFO - 2025-11-04 23:56:29 --> API forgot_password skipped processing due to empty email
INFO - 2025-11-04 23:56:29 --> Final output sent to browser
INFO - 2025-11-04 23:56:29 --> Total execution time: 0.0660
INFO - 2025-11-04 23:57:30 --> Config Class Initialized
INFO - 2025-11-04 23:57:30 --> Hooks Class Initialized
INFO - 2025-11-04 23:57:30 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:57:30 --> Utf8 Class Initialized
INFO - 2025-11-04 23:57:30 --> URI Class Initialized
INFO - 2025-11-04 23:57:30 --> Router Class Initialized
INFO - 2025-11-04 23:57:30 --> Output Class Initialized
INFO - 2025-11-04 23:57:30 --> Security Class Initialized
INFO - 2025-11-04 23:57:30 --> Input Class Initialized
INFO - 2025-11-04 23:57:30 --> Language Class Initialized
INFO - 2025-11-04 23:57:30 --> Loader Class Initialized
INFO - 2025-11-04 23:57:30 --> Helper loaded: url_helper
INFO - 2025-11-04 23:57:30 --> Helper loaded: file_helper
INFO - 2025-11-04 23:57:30 --> Helper loaded: main_helper
INFO - 2025-11-04 23:57:30 --> Database Driver Class Initialized
INFO - 2025-11-04 23:57:30 --> Email Class Initialized
DEBUG - 2025-11-04 23:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:57:30 --> Controller Class Initialized
INFO - 2025-11-04 23:57:30 --> API /auth/forgot_password invoked
INFO - 2025-11-04 23:57:30 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-04 23:57:30 --> Final output sent to browser
INFO - 2025-11-04 23:57:30 --> Total execution time: 0.0780
INFO - 2025-11-04 23:58:00 --> Config Class Initialized
INFO - 2025-11-04 23:58:00 --> Hooks Class Initialized
INFO - 2025-11-04 23:58:00 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:58:00 --> Utf8 Class Initialized
INFO - 2025-11-04 23:58:00 --> URI Class Initialized
INFO - 2025-11-04 23:58:00 --> Router Class Initialized
INFO - 2025-11-04 23:58:00 --> Output Class Initialized
INFO - 2025-11-04 23:58:00 --> Security Class Initialized
INFO - 2025-11-04 23:58:00 --> Input Class Initialized
INFO - 2025-11-04 23:58:00 --> Language Class Initialized
INFO - 2025-11-04 23:58:00 --> Loader Class Initialized
INFO - 2025-11-04 23:58:00 --> Helper loaded: url_helper
INFO - 2025-11-04 23:58:00 --> Helper loaded: file_helper
INFO - 2025-11-04 23:58:00 --> Helper loaded: main_helper
INFO - 2025-11-04 23:58:00 --> Database Driver Class Initialized
INFO - 2025-11-04 23:58:00 --> Email Class Initialized
DEBUG - 2025-11-04 23:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:58:00 --> Controller Class Initialized
INFO - 2025-11-04 23:58:00 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:58:00 --> Model "User_model" initialized
INFO - 2025-11-04 23:58:00 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:58:00 --> API /auth/forgot_password invoked; email payload="(empty)"
INFO - 2025-11-04 23:58:00 --> API forgot_password skipped processing due to empty email
INFO - 2025-11-04 23:58:00 --> Final output sent to browser
INFO - 2025-11-04 23:58:00 --> Total execution time: 0.0615
INFO - 2025-11-04 23:58:46 --> Config Class Initialized
INFO - 2025-11-04 23:58:46 --> Hooks Class Initialized
INFO - 2025-11-04 23:58:46 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:58:46 --> Utf8 Class Initialized
INFO - 2025-11-04 23:58:46 --> URI Class Initialized
INFO - 2025-11-04 23:58:46 --> Router Class Initialized
INFO - 2025-11-04 23:58:46 --> Output Class Initialized
INFO - 2025-11-04 23:58:46 --> Security Class Initialized
INFO - 2025-11-04 23:58:46 --> Input Class Initialized
INFO - 2025-11-04 23:58:46 --> Language Class Initialized
INFO - 2025-11-04 23:58:46 --> Loader Class Initialized
INFO - 2025-11-04 23:58:46 --> Helper loaded: url_helper
INFO - 2025-11-04 23:58:46 --> Helper loaded: file_helper
INFO - 2025-11-04 23:58:46 --> Helper loaded: main_helper
INFO - 2025-11-04 23:58:46 --> Database Driver Class Initialized
INFO - 2025-11-04 23:58:46 --> Email Class Initialized
DEBUG - 2025-11-04 23:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:58:46 --> Controller Class Initialized
INFO - 2025-11-04 23:58:46 --> API /auth/forgot_password invoked
INFO - 2025-11-04 23:58:46 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-04 23:58:46 --> Final output sent to browser
INFO - 2025-11-04 23:58:46 --> Total execution time: 0.0466
INFO - 2025-11-04 23:58:49 --> Config Class Initialized
INFO - 2025-11-04 23:58:49 --> Hooks Class Initialized
INFO - 2025-11-04 23:58:49 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:58:49 --> Utf8 Class Initialized
INFO - 2025-11-04 23:58:49 --> URI Class Initialized
INFO - 2025-11-04 23:58:49 --> Router Class Initialized
INFO - 2025-11-04 23:58:49 --> Output Class Initialized
INFO - 2025-11-04 23:58:49 --> Security Class Initialized
INFO - 2025-11-04 23:58:49 --> Input Class Initialized
INFO - 2025-11-04 23:58:49 --> Language Class Initialized
INFO - 2025-11-04 23:58:49 --> Loader Class Initialized
INFO - 2025-11-04 23:58:49 --> Helper loaded: url_helper
INFO - 2025-11-04 23:58:49 --> Helper loaded: file_helper
INFO - 2025-11-04 23:58:49 --> Helper loaded: main_helper
INFO - 2025-11-04 23:58:49 --> Database Driver Class Initialized
INFO - 2025-11-04 23:58:49 --> Email Class Initialized
DEBUG - 2025-11-04 23:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:58:49 --> Controller Class Initialized
INFO - 2025-11-04 23:58:49 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:58:49 --> Model "User_model" initialized
INFO - 2025-11-04 23:58:49 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:58:49 --> API /auth/forgot_password invoked; email payload="(empty)"
INFO - 2025-11-04 23:58:49 --> API forgot_password skipped processing due to empty email
INFO - 2025-11-04 23:58:49 --> Final output sent to browser
INFO - 2025-11-04 23:58:49 --> Total execution time: 0.0763
INFO - 2025-11-04 23:59:13 --> Config Class Initialized
INFO - 2025-11-04 23:59:13 --> Hooks Class Initialized
INFO - 2025-11-04 23:59:13 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:59:13 --> Utf8 Class Initialized
INFO - 2025-11-04 23:59:13 --> URI Class Initialized
INFO - 2025-11-04 23:59:13 --> Router Class Initialized
INFO - 2025-11-04 23:59:13 --> Output Class Initialized
INFO - 2025-11-04 23:59:13 --> Security Class Initialized
INFO - 2025-11-04 23:59:13 --> Input Class Initialized
INFO - 2025-11-04 23:59:13 --> Language Class Initialized
INFO - 2025-11-04 23:59:13 --> Loader Class Initialized
INFO - 2025-11-04 23:59:13 --> Helper loaded: url_helper
INFO - 2025-11-04 23:59:13 --> Helper loaded: file_helper
INFO - 2025-11-04 23:59:13 --> Helper loaded: main_helper
INFO - 2025-11-04 23:59:13 --> Database Driver Class Initialized
INFO - 2025-11-04 23:59:13 --> Email Class Initialized
DEBUG - 2025-11-04 23:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:59:13 --> Controller Class Initialized
INFO - 2025-11-04 23:59:13 --> API /auth/forgot_password invoked
INFO - 2025-11-04 23:59:13 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-04 23:59:13 --> Final output sent to browser
INFO - 2025-11-04 23:59:13 --> Total execution time: 0.0844
INFO - 2025-11-04 23:59:16 --> Config Class Initialized
INFO - 2025-11-04 23:59:16 --> Hooks Class Initialized
INFO - 2025-11-04 23:59:16 --> UTF-8 Support Enabled
INFO - 2025-11-04 23:59:16 --> Utf8 Class Initialized
INFO - 2025-11-04 23:59:16 --> URI Class Initialized
INFO - 2025-11-04 23:59:16 --> Router Class Initialized
INFO - 2025-11-04 23:59:16 --> Output Class Initialized
INFO - 2025-11-04 23:59:16 --> Security Class Initialized
INFO - 2025-11-04 23:59:16 --> Input Class Initialized
INFO - 2025-11-04 23:59:16 --> Language Class Initialized
INFO - 2025-11-04 23:59:16 --> Loader Class Initialized
INFO - 2025-11-04 23:59:16 --> Helper loaded: url_helper
INFO - 2025-11-04 23:59:16 --> Helper loaded: file_helper
INFO - 2025-11-04 23:59:16 --> Helper loaded: main_helper
INFO - 2025-11-04 23:59:16 --> Database Driver Class Initialized
INFO - 2025-11-04 23:59:16 --> Email Class Initialized
DEBUG - 2025-11-04 23:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-04 23:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-04 23:59:16 --> Controller Class Initialized
INFO - 2025-11-04 23:59:16 --> Model "Subscription_model" initialized
INFO - 2025-11-04 23:59:16 --> Model "User_model" initialized
INFO - 2025-11-04 23:59:16 --> Model "Auth_model" initialized
INFO - 2025-11-04 23:59:16 --> API /auth/forgot_password invoked; email payload="(empty)"
INFO - 2025-11-04 23:59:16 --> API forgot_password skipped processing due to empty email
INFO - 2025-11-04 23:59:16 --> Final output sent to browser
INFO - 2025-11-04 23:59:16 --> Total execution time: 0.0608
