<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-11-12 13:48:33 --> Config Class Initialized
INFO - 2025-11-12 13:48:33 --> Hooks Class Initialized
INFO - 2025-11-12 13:48:33 --> UTF-8 Support Enabled
INFO - 2025-11-12 13:48:33 --> Utf8 Class Initialized
INFO - 2025-11-12 13:48:33 --> URI Class Initialized
DEBUG - 2025-11-12 13:48:33 --> No URI present. Default controller set.
INFO - 2025-11-12 13:48:33 --> Router Class Initialized
INFO - 2025-11-12 13:48:33 --> Output Class Initialized
INFO - 2025-11-12 13:48:33 --> Security Class Initialized
INFO - 2025-11-12 13:48:33 --> Input Class Initialized
INFO - 2025-11-12 13:48:33 --> Language Class Initialized
INFO - 2025-11-12 13:48:33 --> Loader Class Initialized
INFO - 2025-11-12 13:48:33 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 13:48:33 --> Helper loaded: url_helper
INFO - 2025-11-12 13:48:33 --> Helper loaded: file_helper
INFO - 2025-11-12 13:48:33 --> Helper loaded: main_helper
INFO - 2025-11-12 13:48:33 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 13:48:33 --> Database Driver Class Initialized
INFO - 2025-11-12 13:48:33 --> Email Class Initialized
DEBUG - 2025-11-12 13:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 13:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 13:48:33 --> Controller Class Initialized
INFO - 2025-11-12 13:48:33 --> Config Class Initialized
INFO - 2025-11-12 13:48:33 --> Hooks Class Initialized
INFO - 2025-11-12 13:48:33 --> UTF-8 Support Enabled
INFO - 2025-11-12 13:48:33 --> Utf8 Class Initialized
INFO - 2025-11-12 13:48:33 --> URI Class Initialized
INFO - 2025-11-12 13:48:33 --> Router Class Initialized
INFO - 2025-11-12 13:48:33 --> Output Class Initialized
INFO - 2025-11-12 13:48:33 --> Security Class Initialized
INFO - 2025-11-12 13:48:33 --> Input Class Initialized
INFO - 2025-11-12 13:48:33 --> Language Class Initialized
INFO - 2025-11-12 13:48:33 --> Loader Class Initialized
INFO - 2025-11-12 13:48:33 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 13:48:33 --> Helper loaded: url_helper
INFO - 2025-11-12 13:48:33 --> Helper loaded: file_helper
INFO - 2025-11-12 13:48:33 --> Helper loaded: main_helper
INFO - 2025-11-12 13:48:33 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 13:48:33 --> Database Driver Class Initialized
INFO - 2025-11-12 13:48:33 --> Email Class Initialized
DEBUG - 2025-11-12 13:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 13:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 13:48:33 --> Controller Class Initialized
INFO - 2025-11-12 13:48:33 --> Model "Subscription_model" initialized
INFO - 2025-11-12 13:48:33 --> Model "User_model" initialized
INFO - 2025-11-12 13:48:33 --> Model "Auth_model" initialized
INFO - 2025-11-12 13:48:33 --> Config Class Initialized
INFO - 2025-11-12 13:48:33 --> Hooks Class Initialized
INFO - 2025-11-12 13:48:33 --> UTF-8 Support Enabled
INFO - 2025-11-12 13:48:33 --> Utf8 Class Initialized
INFO - 2025-11-12 13:48:33 --> URI Class Initialized
INFO - 2025-11-12 13:48:33 --> Router Class Initialized
INFO - 2025-11-12 13:48:33 --> Output Class Initialized
INFO - 2025-11-12 13:48:33 --> Security Class Initialized
INFO - 2025-11-12 13:48:33 --> Input Class Initialized
INFO - 2025-11-12 13:48:33 --> Language Class Initialized
INFO - 2025-11-12 13:48:33 --> Loader Class Initialized
INFO - 2025-11-12 13:48:33 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 13:48:33 --> Helper loaded: url_helper
INFO - 2025-11-12 13:48:33 --> Helper loaded: file_helper
INFO - 2025-11-12 13:48:33 --> Helper loaded: main_helper
INFO - 2025-11-12 13:48:33 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 13:48:33 --> Database Driver Class Initialized
INFO - 2025-11-12 13:48:33 --> Email Class Initialized
DEBUG - 2025-11-12 13:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 13:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 13:48:33 --> Controller Class Initialized
INFO - 2025-11-12 13:48:33 --> Config Class Initialized
INFO - 2025-11-12 13:48:33 --> Hooks Class Initialized
INFO - 2025-11-12 13:48:33 --> UTF-8 Support Enabled
INFO - 2025-11-12 13:48:33 --> Utf8 Class Initialized
INFO - 2025-11-12 13:48:33 --> URI Class Initialized
INFO - 2025-11-12 13:48:33 --> Router Class Initialized
INFO - 2025-11-12 13:48:33 --> Output Class Initialized
INFO - 2025-11-12 13:48:33 --> Security Class Initialized
INFO - 2025-11-12 13:48:33 --> Input Class Initialized
INFO - 2025-11-12 13:48:33 --> Language Class Initialized
INFO - 2025-11-12 13:48:33 --> Loader Class Initialized
INFO - 2025-11-12 13:48:33 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 13:48:33 --> Helper loaded: url_helper
INFO - 2025-11-12 13:48:33 --> Helper loaded: file_helper
INFO - 2025-11-12 13:48:33 --> Helper loaded: main_helper
INFO - 2025-11-12 13:48:33 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 13:48:33 --> Database Driver Class Initialized
INFO - 2025-11-12 13:48:33 --> Email Class Initialized
DEBUG - 2025-11-12 13:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 13:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 13:48:33 --> Controller Class Initialized
INFO - 2025-11-12 13:48:33 --> Model "Subscription_model" initialized
INFO - 2025-11-12 13:48:33 --> Model "User_model" initialized
INFO - 2025-11-12 13:48:33 --> Model "Auth_model" initialized
INFO - 2025-11-12 13:48:33 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-12 13:48:33 --> Final output sent to browser
INFO - 2025-11-12 13:48:33 --> Total execution time: 0.0533
INFO - 2025-11-12 13:48:39 --> Config Class Initialized
INFO - 2025-11-12 13:48:39 --> Hooks Class Initialized
INFO - 2025-11-12 13:48:39 --> UTF-8 Support Enabled
INFO - 2025-11-12 13:48:39 --> Utf8 Class Initialized
INFO - 2025-11-12 13:48:39 --> URI Class Initialized
INFO - 2025-11-12 13:48:39 --> Router Class Initialized
INFO - 2025-11-12 13:48:39 --> Output Class Initialized
INFO - 2025-11-12 13:48:39 --> Security Class Initialized
INFO - 2025-11-12 13:48:39 --> Input Class Initialized
INFO - 2025-11-12 13:48:39 --> Language Class Initialized
INFO - 2025-11-12 13:48:39 --> Loader Class Initialized
INFO - 2025-11-12 13:48:39 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 13:48:39 --> Helper loaded: url_helper
INFO - 2025-11-12 13:48:39 --> Helper loaded: file_helper
INFO - 2025-11-12 13:48:39 --> Helper loaded: main_helper
INFO - 2025-11-12 13:48:39 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 13:48:39 --> Database Driver Class Initialized
INFO - 2025-11-12 13:48:39 --> Email Class Initialized
DEBUG - 2025-11-12 13:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 13:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 13:48:39 --> Controller Class Initialized
INFO - 2025-11-12 13:48:39 --> Model "Subscription_model" initialized
INFO - 2025-11-12 13:48:39 --> Model "User_model" initialized
INFO - 2025-11-12 13:48:39 --> Model "Auth_model" initialized
INFO - 2025-11-12 13:48:39 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-12 13:48:39 --> Final output sent to browser
INFO - 2025-11-12 13:48:39 --> Total execution time: 0.0805
INFO - 2025-11-12 13:48:52 --> Config Class Initialized
INFO - 2025-11-12 13:48:52 --> Hooks Class Initialized
INFO - 2025-11-12 13:48:52 --> UTF-8 Support Enabled
INFO - 2025-11-12 13:48:52 --> Utf8 Class Initialized
INFO - 2025-11-12 13:48:52 --> URI Class Initialized
INFO - 2025-11-12 13:48:52 --> Router Class Initialized
INFO - 2025-11-12 13:48:52 --> Output Class Initialized
INFO - 2025-11-12 13:48:52 --> Security Class Initialized
INFO - 2025-11-12 13:48:52 --> Input Class Initialized
INFO - 2025-11-12 13:48:52 --> Language Class Initialized
INFO - 2025-11-12 13:48:52 --> Loader Class Initialized
INFO - 2025-11-12 13:48:52 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 13:48:52 --> Helper loaded: url_helper
INFO - 2025-11-12 13:48:52 --> Helper loaded: file_helper
INFO - 2025-11-12 13:48:52 --> Helper loaded: main_helper
INFO - 2025-11-12 13:48:52 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 13:48:52 --> Database Driver Class Initialized
INFO - 2025-11-12 13:48:52 --> Email Class Initialized
DEBUG - 2025-11-12 13:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 13:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 13:48:52 --> Controller Class Initialized
INFO - 2025-11-12 13:48:52 --> Config Class Initialized
INFO - 2025-11-12 13:48:52 --> Hooks Class Initialized
INFO - 2025-11-12 13:48:52 --> UTF-8 Support Enabled
INFO - 2025-11-12 13:48:52 --> Utf8 Class Initialized
INFO - 2025-11-12 13:48:52 --> URI Class Initialized
INFO - 2025-11-12 13:48:52 --> Router Class Initialized
INFO - 2025-11-12 13:48:52 --> Output Class Initialized
INFO - 2025-11-12 13:48:52 --> Security Class Initialized
INFO - 2025-11-12 13:48:52 --> Input Class Initialized
INFO - 2025-11-12 13:48:52 --> Language Class Initialized
ERROR - 2025-11-12 13:48:52 --> 404 Page Not Found: Faviconico/index
INFO - 2025-11-12 13:49:36 --> Config Class Initialized
INFO - 2025-11-12 13:49:36 --> Hooks Class Initialized
INFO - 2025-11-12 13:49:36 --> UTF-8 Support Enabled
INFO - 2025-11-12 13:49:36 --> Utf8 Class Initialized
INFO - 2025-11-12 13:49:36 --> URI Class Initialized
INFO - 2025-11-12 13:49:36 --> Router Class Initialized
INFO - 2025-11-12 13:49:36 --> Output Class Initialized
INFO - 2025-11-12 13:49:36 --> Security Class Initialized
INFO - 2025-11-12 13:49:36 --> Input Class Initialized
INFO - 2025-11-12 13:49:36 --> Language Class Initialized
INFO - 2025-11-12 13:49:36 --> Loader Class Initialized
INFO - 2025-11-12 13:49:36 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 13:49:36 --> Helper loaded: url_helper
INFO - 2025-11-12 13:49:36 --> Helper loaded: file_helper
INFO - 2025-11-12 13:49:36 --> Helper loaded: main_helper
INFO - 2025-11-12 13:49:36 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 13:49:36 --> Database Driver Class Initialized
INFO - 2025-11-12 13:49:36 --> Email Class Initialized
DEBUG - 2025-11-12 13:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 13:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 13:49:36 --> Controller Class Initialized
INFO - 2025-11-12 13:49:36 --> Model "Subscription_model" initialized
INFO - 2025-11-12 13:49:36 --> Model "User_model" initialized
INFO - 2025-11-12 13:49:36 --> Model "Auth_model" initialized
INFO - 2025-11-12 13:49:36 --> Final output sent to browser
INFO - 2025-11-12 13:49:36 --> Total execution time: 0.1846
INFO - 2025-11-12 13:49:44 --> Config Class Initialized
INFO - 2025-11-12 13:49:44 --> Hooks Class Initialized
INFO - 2025-11-12 13:49:44 --> UTF-8 Support Enabled
INFO - 2025-11-12 13:49:44 --> Utf8 Class Initialized
INFO - 2025-11-12 13:49:44 --> URI Class Initialized
INFO - 2025-11-12 13:49:44 --> Router Class Initialized
INFO - 2025-11-12 13:49:44 --> Output Class Initialized
INFO - 2025-11-12 13:49:44 --> Security Class Initialized
INFO - 2025-11-12 13:49:44 --> Input Class Initialized
INFO - 2025-11-12 13:49:44 --> Language Class Initialized
INFO - 2025-11-12 13:49:44 --> Loader Class Initialized
INFO - 2025-11-12 13:49:44 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 13:49:44 --> Helper loaded: url_helper
INFO - 2025-11-12 13:49:44 --> Helper loaded: file_helper
INFO - 2025-11-12 13:49:44 --> Helper loaded: main_helper
INFO - 2025-11-12 13:49:44 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 13:49:44 --> Database Driver Class Initialized
INFO - 2025-11-12 13:49:44 --> Email Class Initialized
DEBUG - 2025-11-12 13:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 13:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 13:49:44 --> Controller Class Initialized
INFO - 2025-11-12 13:49:44 --> Model "Subscription_model" initialized
INFO - 2025-11-12 13:49:44 --> Model "User_model" initialized
INFO - 2025-11-12 13:49:44 --> Model "Auth_model" initialized
INFO - 2025-11-12 13:49:44 --> Final output sent to browser
INFO - 2025-11-12 13:49:44 --> Total execution time: 0.1967
INFO - 2025-11-12 13:49:55 --> Config Class Initialized
INFO - 2025-11-12 13:49:55 --> Hooks Class Initialized
INFO - 2025-11-12 13:49:55 --> UTF-8 Support Enabled
INFO - 2025-11-12 13:49:55 --> Utf8 Class Initialized
INFO - 2025-11-12 13:49:55 --> URI Class Initialized
INFO - 2025-11-12 13:49:55 --> Router Class Initialized
INFO - 2025-11-12 13:49:55 --> Output Class Initialized
INFO - 2025-11-12 13:49:55 --> Security Class Initialized
INFO - 2025-11-12 13:49:55 --> Input Class Initialized
INFO - 2025-11-12 13:49:55 --> Language Class Initialized
INFO - 2025-11-12 13:49:55 --> Loader Class Initialized
INFO - 2025-11-12 13:49:55 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 13:49:55 --> Helper loaded: url_helper
INFO - 2025-11-12 13:49:55 --> Helper loaded: file_helper
INFO - 2025-11-12 13:49:55 --> Helper loaded: main_helper
INFO - 2025-11-12 13:49:55 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 13:49:55 --> Database Driver Class Initialized
INFO - 2025-11-12 13:49:55 --> Email Class Initialized
DEBUG - 2025-11-12 13:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 13:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 13:49:55 --> Controller Class Initialized
INFO - 2025-11-12 13:49:55 --> Model "Subscription_model" initialized
INFO - 2025-11-12 13:49:55 --> Model "User_model" initialized
INFO - 2025-11-12 13:49:55 --> Model "Auth_model" initialized
INFO - 2025-11-12 13:49:55 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-12 13:49:55 --> Final output sent to browser
INFO - 2025-11-12 13:49:55 --> Total execution time: 0.0978
INFO - 2025-11-12 13:50:10 --> Config Class Initialized
INFO - 2025-11-12 13:50:10 --> Hooks Class Initialized
INFO - 2025-11-12 13:50:10 --> UTF-8 Support Enabled
INFO - 2025-11-12 13:50:10 --> Utf8 Class Initialized
INFO - 2025-11-12 13:50:10 --> URI Class Initialized
INFO - 2025-11-12 13:50:10 --> Router Class Initialized
INFO - 2025-11-12 13:50:10 --> Output Class Initialized
INFO - 2025-11-12 13:50:10 --> Security Class Initialized
INFO - 2025-11-12 13:50:10 --> Input Class Initialized
INFO - 2025-11-12 13:50:10 --> Language Class Initialized
INFO - 2025-11-12 13:50:10 --> Loader Class Initialized
INFO - 2025-11-12 13:50:10 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 13:50:10 --> Helper loaded: url_helper
INFO - 2025-11-12 13:50:10 --> Helper loaded: file_helper
INFO - 2025-11-12 13:50:10 --> Helper loaded: main_helper
INFO - 2025-11-12 13:50:10 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 13:50:10 --> Database Driver Class Initialized
INFO - 2025-11-12 13:50:10 --> Email Class Initialized
DEBUG - 2025-11-12 13:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 13:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 13:50:10 --> Controller Class Initialized
INFO - 2025-11-12 13:50:10 --> Model "Subscription_model" initialized
INFO - 2025-11-12 13:50:10 --> Model "User_model" initialized
INFO - 2025-11-12 13:50:10 --> Model "Auth_model" initialized
INFO - 2025-11-12 13:50:11 --> Final output sent to browser
INFO - 2025-11-12 13:50:11 --> Total execution time: 0.2173
INFO - 2025-11-12 13:50:13 --> Config Class Initialized
INFO - 2025-11-12 13:50:13 --> Hooks Class Initialized
INFO - 2025-11-12 13:50:13 --> UTF-8 Support Enabled
INFO - 2025-11-12 13:50:13 --> Utf8 Class Initialized
INFO - 2025-11-12 13:50:13 --> URI Class Initialized
INFO - 2025-11-12 13:50:13 --> Router Class Initialized
INFO - 2025-11-12 13:50:13 --> Output Class Initialized
INFO - 2025-11-12 13:50:13 --> Security Class Initialized
INFO - 2025-11-12 13:50:13 --> Input Class Initialized
INFO - 2025-11-12 13:50:13 --> Language Class Initialized
INFO - 2025-11-12 13:50:13 --> Loader Class Initialized
INFO - 2025-11-12 13:50:13 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 13:50:13 --> Helper loaded: url_helper
INFO - 2025-11-12 13:50:13 --> Helper loaded: file_helper
INFO - 2025-11-12 13:50:13 --> Helper loaded: main_helper
INFO - 2025-11-12 13:50:13 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 13:50:13 --> Database Driver Class Initialized
INFO - 2025-11-12 13:50:13 --> Email Class Initialized
DEBUG - 2025-11-12 13:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 13:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 13:50:13 --> Controller Class Initialized
INFO - 2025-11-12 13:50:13 --> Model "Subscription_model" initialized
INFO - 2025-11-12 13:50:13 --> Model "User_model" initialized
INFO - 2025-11-12 13:50:13 --> Model "Auth_model" initialized
INFO - 2025-11-12 13:50:13 --> Final output sent to browser
INFO - 2025-11-12 13:50:13 --> Total execution time: 0.1938
INFO - 2025-11-12 13:50:34 --> Config Class Initialized
INFO - 2025-11-12 13:50:34 --> Hooks Class Initialized
INFO - 2025-11-12 13:50:34 --> UTF-8 Support Enabled
INFO - 2025-11-12 13:50:34 --> Utf8 Class Initialized
INFO - 2025-11-12 13:50:34 --> URI Class Initialized
INFO - 2025-11-12 13:50:34 --> Router Class Initialized
INFO - 2025-11-12 13:50:34 --> Output Class Initialized
INFO - 2025-11-12 13:50:34 --> Security Class Initialized
INFO - 2025-11-12 13:50:34 --> Input Class Initialized
INFO - 2025-11-12 13:50:34 --> Language Class Initialized
INFO - 2025-11-12 13:50:34 --> Loader Class Initialized
INFO - 2025-11-12 13:50:35 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 13:50:35 --> Helper loaded: url_helper
INFO - 2025-11-12 13:50:35 --> Helper loaded: file_helper
INFO - 2025-11-12 13:50:35 --> Helper loaded: main_helper
INFO - 2025-11-12 13:50:35 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 13:50:35 --> Database Driver Class Initialized
INFO - 2025-11-12 13:50:35 --> Email Class Initialized
DEBUG - 2025-11-12 13:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 13:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 13:50:35 --> Controller Class Initialized
INFO - 2025-11-12 13:50:35 --> API /auth/forgot_password invoked
INFO - 2025-11-12 13:50:35 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-12 13:50:35 --> Final output sent to browser
INFO - 2025-11-12 13:50:35 --> Total execution time: 0.0877
INFO - 2025-11-12 13:50:38 --> Config Class Initialized
INFO - 2025-11-12 13:50:38 --> Hooks Class Initialized
INFO - 2025-11-12 13:50:38 --> UTF-8 Support Enabled
INFO - 2025-11-12 13:50:38 --> Utf8 Class Initialized
INFO - 2025-11-12 13:50:38 --> URI Class Initialized
INFO - 2025-11-12 13:50:38 --> Router Class Initialized
INFO - 2025-11-12 13:50:38 --> Output Class Initialized
INFO - 2025-11-12 13:50:38 --> Security Class Initialized
INFO - 2025-11-12 13:50:38 --> Input Class Initialized
INFO - 2025-11-12 13:50:38 --> Language Class Initialized
INFO - 2025-11-12 13:50:38 --> Loader Class Initialized
INFO - 2025-11-12 13:50:38 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 13:50:38 --> Helper loaded: url_helper
INFO - 2025-11-12 13:50:38 --> Helper loaded: file_helper
INFO - 2025-11-12 13:50:38 --> Helper loaded: main_helper
INFO - 2025-11-12 13:50:38 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 13:50:38 --> Database Driver Class Initialized
INFO - 2025-11-12 13:50:38 --> Email Class Initialized
DEBUG - 2025-11-12 13:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 13:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 13:50:38 --> Controller Class Initialized
INFO - 2025-11-12 13:50:38 --> Model "Subscription_model" initialized
INFO - 2025-11-12 13:50:38 --> Model "User_model" initialized
INFO - 2025-11-12 13:50:38 --> Model "Auth_model" initialized
INFO - 2025-11-12 13:50:38 --> API /auth/forgot_password invoked; email payload="cranam21@gmail.com"
INFO - 2025-11-12 13:50:38 --> Forgot password requested for active user cranam21@gmail.com (id=1)
INFO - 2025-11-12 13:50:39 --> Reset password email sent via SendGrid to cranam21@gmail.com (code=202)
INFO - 2025-11-12 13:50:39 --> API forgot_password processed for email: cranam21@gmail.com
INFO - 2025-11-12 13:50:39 --> Final output sent to browser
INFO - 2025-11-12 13:50:39 --> Total execution time: 1.6760
INFO - 2025-11-12 13:50:59 --> Config Class Initialized
INFO - 2025-11-12 13:50:59 --> Hooks Class Initialized
INFO - 2025-11-12 13:50:59 --> UTF-8 Support Enabled
INFO - 2025-11-12 13:50:59 --> Utf8 Class Initialized
INFO - 2025-11-12 13:50:59 --> URI Class Initialized
INFO - 2025-11-12 13:50:59 --> Router Class Initialized
INFO - 2025-11-12 13:50:59 --> Output Class Initialized
INFO - 2025-11-12 13:50:59 --> Security Class Initialized
INFO - 2025-11-12 13:50:59 --> Input Class Initialized
INFO - 2025-11-12 13:50:59 --> Language Class Initialized
INFO - 2025-11-12 13:50:59 --> Loader Class Initialized
INFO - 2025-11-12 13:50:59 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 13:50:59 --> Helper loaded: url_helper
INFO - 2025-11-12 13:50:59 --> Helper loaded: file_helper
INFO - 2025-11-12 13:50:59 --> Helper loaded: main_helper
INFO - 2025-11-12 13:50:59 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 13:50:59 --> Database Driver Class Initialized
INFO - 2025-11-12 13:50:59 --> Email Class Initialized
DEBUG - 2025-11-12 13:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 13:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 13:50:59 --> Controller Class Initialized
INFO - 2025-11-12 13:50:59 --> File loaded: D:\laragon\www\acumena\application\views\auth/reset_password.php
INFO - 2025-11-12 13:50:59 --> Final output sent to browser
INFO - 2025-11-12 13:50:59 --> Total execution time: 0.0803
INFO - 2025-11-12 13:51:04 --> Config Class Initialized
INFO - 2025-11-12 13:51:04 --> Hooks Class Initialized
INFO - 2025-11-12 13:51:04 --> UTF-8 Support Enabled
INFO - 2025-11-12 13:51:04 --> Utf8 Class Initialized
INFO - 2025-11-12 13:51:04 --> URI Class Initialized
INFO - 2025-11-12 13:51:04 --> Router Class Initialized
INFO - 2025-11-12 13:51:04 --> Output Class Initialized
INFO - 2025-11-12 13:51:04 --> Security Class Initialized
INFO - 2025-11-12 13:51:04 --> Input Class Initialized
INFO - 2025-11-12 13:51:04 --> Language Class Initialized
INFO - 2025-11-12 13:51:04 --> Loader Class Initialized
INFO - 2025-11-12 13:51:04 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 13:51:04 --> Helper loaded: url_helper
INFO - 2025-11-12 13:51:04 --> Helper loaded: file_helper
INFO - 2025-11-12 13:51:04 --> Helper loaded: main_helper
INFO - 2025-11-12 13:51:04 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 13:51:04 --> Database Driver Class Initialized
INFO - 2025-11-12 13:51:04 --> Email Class Initialized
DEBUG - 2025-11-12 13:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 13:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 13:51:04 --> Controller Class Initialized
INFO - 2025-11-12 13:51:04 --> File loaded: D:\laragon\www\acumena\application\views\auth/reset_password.php
INFO - 2025-11-12 13:51:04 --> Final output sent to browser
INFO - 2025-11-12 13:51:04 --> Total execution time: 0.0795
INFO - 2025-11-12 13:51:11 --> Config Class Initialized
INFO - 2025-11-12 13:51:11 --> Hooks Class Initialized
INFO - 2025-11-12 13:51:11 --> UTF-8 Support Enabled
INFO - 2025-11-12 13:51:11 --> Utf8 Class Initialized
INFO - 2025-11-12 13:51:11 --> URI Class Initialized
INFO - 2025-11-12 13:51:11 --> Router Class Initialized
INFO - 2025-11-12 13:51:11 --> Output Class Initialized
INFO - 2025-11-12 13:51:11 --> Security Class Initialized
INFO - 2025-11-12 13:51:11 --> Input Class Initialized
INFO - 2025-11-12 13:51:11 --> Language Class Initialized
INFO - 2025-11-12 13:51:11 --> Loader Class Initialized
INFO - 2025-11-12 13:51:11 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 13:51:11 --> Helper loaded: url_helper
INFO - 2025-11-12 13:51:11 --> Helper loaded: file_helper
INFO - 2025-11-12 13:51:11 --> Helper loaded: main_helper
INFO - 2025-11-12 13:51:11 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 13:51:11 --> Database Driver Class Initialized
INFO - 2025-11-12 13:51:11 --> Email Class Initialized
DEBUG - 2025-11-12 13:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 13:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 13:51:11 --> Controller Class Initialized
INFO - 2025-11-12 13:51:11 --> Model "Subscription_model" initialized
INFO - 2025-11-12 13:51:11 --> Model "User_model" initialized
INFO - 2025-11-12 13:51:11 --> Model "Auth_model" initialized
INFO - 2025-11-12 13:51:11 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-12 13:51:11 --> Final output sent to browser
INFO - 2025-11-12 13:51:11 --> Total execution time: 0.0996
INFO - 2025-11-12 13:51:19 --> Config Class Initialized
INFO - 2025-11-12 13:51:19 --> Hooks Class Initialized
INFO - 2025-11-12 13:51:19 --> UTF-8 Support Enabled
INFO - 2025-11-12 13:51:19 --> Utf8 Class Initialized
INFO - 2025-11-12 13:51:19 --> URI Class Initialized
INFO - 2025-11-12 13:51:19 --> Router Class Initialized
INFO - 2025-11-12 13:51:19 --> Output Class Initialized
INFO - 2025-11-12 13:51:19 --> Security Class Initialized
INFO - 2025-11-12 13:51:19 --> Input Class Initialized
INFO - 2025-11-12 13:51:19 --> Language Class Initialized
INFO - 2025-11-12 13:51:19 --> Loader Class Initialized
INFO - 2025-11-12 13:51:19 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 13:51:19 --> Helper loaded: url_helper
INFO - 2025-11-12 13:51:19 --> Helper loaded: file_helper
INFO - 2025-11-12 13:51:19 --> Helper loaded: main_helper
INFO - 2025-11-12 13:51:19 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 13:51:19 --> Database Driver Class Initialized
INFO - 2025-11-12 13:51:19 --> Email Class Initialized
DEBUG - 2025-11-12 13:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 13:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 13:51:19 --> Controller Class Initialized
INFO - 2025-11-12 13:51:19 --> Model "Subscription_model" initialized
INFO - 2025-11-12 13:51:19 --> Model "User_model" initialized
INFO - 2025-11-12 13:51:19 --> Model "Auth_model" initialized
INFO - 2025-11-12 13:51:19 --> Final output sent to browser
INFO - 2025-11-12 13:51:19 --> Total execution time: 0.2603
INFO - 2025-11-12 13:51:20 --> Config Class Initialized
INFO - 2025-11-12 13:51:20 --> Hooks Class Initialized
INFO - 2025-11-12 13:51:21 --> UTF-8 Support Enabled
INFO - 2025-11-12 13:51:21 --> Utf8 Class Initialized
INFO - 2025-11-12 13:51:21 --> URI Class Initialized
INFO - 2025-11-12 13:51:21 --> Router Class Initialized
INFO - 2025-11-12 13:51:21 --> Output Class Initialized
INFO - 2025-11-12 13:51:21 --> Security Class Initialized
INFO - 2025-11-12 13:51:21 --> Input Class Initialized
INFO - 2025-11-12 13:51:21 --> Language Class Initialized
INFO - 2025-11-12 13:51:21 --> Loader Class Initialized
INFO - 2025-11-12 13:51:21 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 13:51:21 --> Helper loaded: url_helper
INFO - 2025-11-12 13:51:21 --> Helper loaded: file_helper
INFO - 2025-11-12 13:51:21 --> Helper loaded: main_helper
INFO - 2025-11-12 13:51:21 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 13:51:21 --> Database Driver Class Initialized
INFO - 2025-11-12 13:51:21 --> Email Class Initialized
DEBUG - 2025-11-12 13:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 13:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 13:51:21 --> Controller Class Initialized
INFO - 2025-11-12 13:51:21 --> Model "Subscription_model" initialized
INFO - 2025-11-12 13:51:21 --> Model "User_model" initialized
INFO - 2025-11-12 13:51:21 --> Model "Auth_model" initialized
INFO - 2025-11-12 13:51:21 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-12 13:51:21 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-12 13:51:21 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-12 13:51:21 --> File loaded: D:\laragon\www\acumena\application\views\dashboard.php
INFO - 2025-11-12 13:51:21 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-12 13:51:21 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-12 13:51:21 --> Final output sent to browser
INFO - 2025-11-12 13:51:21 --> Total execution time: 0.1027
INFO - 2025-11-12 13:51:21 --> Config Class Initialized
INFO - 2025-11-12 13:51:21 --> Hooks Class Initialized
INFO - 2025-11-12 13:51:21 --> UTF-8 Support Enabled
INFO - 2025-11-12 13:51:21 --> Utf8 Class Initialized
INFO - 2025-11-12 13:51:21 --> URI Class Initialized
INFO - 2025-11-12 13:51:21 --> Router Class Initialized
INFO - 2025-11-12 13:51:21 --> Output Class Initialized
INFO - 2025-11-12 13:51:21 --> Security Class Initialized
INFO - 2025-11-12 13:51:21 --> Input Class Initialized
INFO - 2025-11-12 13:51:21 --> Language Class Initialized
INFO - 2025-11-12 13:51:21 --> Loader Class Initialized
INFO - 2025-11-12 13:51:21 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 13:51:21 --> Helper loaded: url_helper
INFO - 2025-11-12 13:51:21 --> Helper loaded: file_helper
INFO - 2025-11-12 13:51:21 --> Helper loaded: main_helper
INFO - 2025-11-12 13:51:21 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 13:51:21 --> Database Driver Class Initialized
INFO - 2025-11-12 13:51:21 --> Email Class Initialized
DEBUG - 2025-11-12 13:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 13:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 13:51:21 --> Controller Class Initialized
INFO - 2025-11-12 13:51:21 --> Model "User_model" initialized
INFO - 2025-11-12 13:51:21 --> Model "Project_model" initialized
INFO - 2025-11-12 13:51:21 --> Helper loaded: form_helper
INFO - 2025-11-12 13:51:21 --> Form Validation Class Initialized
INFO - 2025-11-12 13:51:21 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 13:51:21 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 13:51:21 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 13:51:21 --> Model "Swot_model" initialized
INFO - 2025-11-12 13:51:21 --> Model "Swot_model" initialized
INFO - 2025-11-12 13:51:21 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 13:51:21 --> Final output sent to browser
INFO - 2025-11-12 13:51:21 --> Total execution time: 0.0982
INFO - 2025-11-12 13:51:25 --> Config Class Initialized
INFO - 2025-11-12 13:51:25 --> Hooks Class Initialized
INFO - 2025-11-12 13:51:25 --> UTF-8 Support Enabled
INFO - 2025-11-12 13:51:25 --> Utf8 Class Initialized
INFO - 2025-11-12 13:51:25 --> URI Class Initialized
INFO - 2025-11-12 13:51:25 --> Router Class Initialized
INFO - 2025-11-12 13:51:25 --> Output Class Initialized
INFO - 2025-11-12 13:51:25 --> Security Class Initialized
INFO - 2025-11-12 13:51:25 --> Input Class Initialized
INFO - 2025-11-12 13:51:25 --> Language Class Initialized
INFO - 2025-11-12 13:51:25 --> Loader Class Initialized
INFO - 2025-11-12 13:51:25 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 13:51:25 --> Helper loaded: url_helper
INFO - 2025-11-12 13:51:25 --> Helper loaded: file_helper
INFO - 2025-11-12 13:51:25 --> Helper loaded: main_helper
INFO - 2025-11-12 13:51:25 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 13:51:25 --> Database Driver Class Initialized
INFO - 2025-11-12 13:51:25 --> Email Class Initialized
DEBUG - 2025-11-12 13:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 13:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 13:51:25 --> Controller Class Initialized
INFO - 2025-11-12 13:51:25 --> Model "User_model" initialized
INFO - 2025-11-12 13:51:25 --> Model "Project_model" initialized
INFO - 2025-11-12 13:51:25 --> Helper loaded: form_helper
INFO - 2025-11-12 13:51:25 --> Form Validation Class Initialized
INFO - 2025-11-12 13:51:25 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 13:51:25 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 13:51:25 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 13:51:25 --> Model "Swot_model" initialized
INFO - 2025-11-12 13:51:25 --> Model "Swot_model" initialized
INFO - 2025-11-12 13:51:25 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 13:51:25 --> Final output sent to browser
INFO - 2025-11-12 13:51:25 --> Total execution time: 0.0759
INFO - 2025-11-12 13:51:42 --> Config Class Initialized
INFO - 2025-11-12 13:51:42 --> Hooks Class Initialized
INFO - 2025-11-12 13:51:42 --> UTF-8 Support Enabled
INFO - 2025-11-12 13:51:42 --> Utf8 Class Initialized
INFO - 2025-11-12 13:51:42 --> URI Class Initialized
INFO - 2025-11-12 13:51:42 --> Router Class Initialized
INFO - 2025-11-12 13:51:42 --> Output Class Initialized
INFO - 2025-11-12 13:51:42 --> Security Class Initialized
INFO - 2025-11-12 13:51:42 --> Input Class Initialized
INFO - 2025-11-12 13:51:42 --> Language Class Initialized
INFO - 2025-11-12 13:51:42 --> Loader Class Initialized
INFO - 2025-11-12 13:51:42 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 13:51:42 --> Helper loaded: url_helper
INFO - 2025-11-12 13:51:42 --> Helper loaded: file_helper
INFO - 2025-11-12 13:51:42 --> Helper loaded: main_helper
INFO - 2025-11-12 13:51:42 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 13:51:42 --> Database Driver Class Initialized
INFO - 2025-11-12 13:51:43 --> Email Class Initialized
DEBUG - 2025-11-12 13:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 13:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 13:51:43 --> Controller Class Initialized
INFO - 2025-11-12 13:51:43 --> Model "User_model" initialized
INFO - 2025-11-12 13:51:43 --> Model "Project_model" initialized
INFO - 2025-11-12 13:51:43 --> Helper loaded: form_helper
INFO - 2025-11-12 13:51:43 --> Form Validation Class Initialized
INFO - 2025-11-12 13:51:43 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 13:51:43 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 13:51:43 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 13:51:43 --> Model "Swot_model" initialized
INFO - 2025-11-12 13:51:43 --> Model "Swot_model" initialized
INFO - 2025-11-12 13:51:43 --> Model "Topk_service_model" initialized
ERROR - 2025-11-12 13:51:51 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 242,
    "totalTokenCount": 1041,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 242
      }
    ],
    "thoughtsTokenCount": 799
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "9pAUaYibBviz4-EP6Mnu2QQ"
}

ERROR - 2025-11-12 13:51:53 --> Gemini API request error: Server error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `503 Service Unavailable` response:
{
  "error": {
    "code": 503,
    "message": "The model is overloaded. Please try again later.",
    "status": "UNAVAI (truncated...)

INFO - 2025-11-12 13:51:53 --> Final output sent to browser
INFO - 2025-11-12 13:51:53 --> Total execution time: 10.7057
INFO - 2025-11-12 13:54:30 --> Config Class Initialized
INFO - 2025-11-12 13:54:30 --> Hooks Class Initialized
INFO - 2025-11-12 13:54:30 --> UTF-8 Support Enabled
INFO - 2025-11-12 13:54:30 --> Utf8 Class Initialized
INFO - 2025-11-12 13:54:30 --> URI Class Initialized
INFO - 2025-11-12 13:54:30 --> Router Class Initialized
INFO - 2025-11-12 13:54:30 --> Output Class Initialized
INFO - 2025-11-12 13:54:30 --> Security Class Initialized
INFO - 2025-11-12 13:54:30 --> Input Class Initialized
INFO - 2025-11-12 13:54:30 --> Language Class Initialized
INFO - 2025-11-12 13:54:30 --> Loader Class Initialized
INFO - 2025-11-12 13:54:30 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 13:54:30 --> Helper loaded: url_helper
INFO - 2025-11-12 13:54:30 --> Helper loaded: file_helper
INFO - 2025-11-12 13:54:30 --> Helper loaded: main_helper
INFO - 2025-11-12 13:54:30 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 13:54:30 --> Database Driver Class Initialized
INFO - 2025-11-12 13:54:30 --> Email Class Initialized
DEBUG - 2025-11-12 13:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 13:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 13:54:30 --> Controller Class Initialized
INFO - 2025-11-12 13:54:30 --> Model "User_model" initialized
INFO - 2025-11-12 13:54:30 --> Model "Project_model" initialized
INFO - 2025-11-12 13:54:30 --> Helper loaded: form_helper
INFO - 2025-11-12 13:54:30 --> Form Validation Class Initialized
INFO - 2025-11-12 13:54:30 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 13:54:30 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 13:54:30 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 13:54:30 --> Model "Swot_model" initialized
INFO - 2025-11-12 13:54:30 --> Model "Swot_model" initialized
INFO - 2025-11-12 13:54:30 --> Model "Topk_service_model" initialized
ERROR - 2025-11-12 13:54:39 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 242,
    "totalTokenCount": 1041,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 242
      }
    ],
    "thoughtsTokenCount": 799
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "npEUabGiLbP04-EP7oWkwAs"
}

ERROR - 2025-11-12 13:54:41 --> Gemini API request error: Server error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `503 Service Unavailable` response:
{
  "error": {
    "code": 503,
    "message": "The model is overloaded. Please try again later.",
    "status": "UNAVAI (truncated...)

ERROR - 2025-11-12 13:54:41 --> strategies error: AI tidak mengembalikan data strategi (kemungkinan MAX_TOKENS atau respons kosong).
INFO - 2025-11-12 13:54:41 --> Final output sent to browser
INFO - 2025-11-12 13:54:41 --> Total execution time: 10.9267
INFO - 2025-11-12 14:02:01 --> Config Class Initialized
INFO - 2025-11-12 14:02:01 --> Hooks Class Initialized
INFO - 2025-11-12 14:02:01 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:02:01 --> Utf8 Class Initialized
INFO - 2025-11-12 14:02:01 --> URI Class Initialized
INFO - 2025-11-12 14:02:01 --> Router Class Initialized
INFO - 2025-11-12 14:02:01 --> Output Class Initialized
INFO - 2025-11-12 14:02:01 --> Security Class Initialized
INFO - 2025-11-12 14:02:01 --> Input Class Initialized
INFO - 2025-11-12 14:02:01 --> Language Class Initialized
INFO - 2025-11-12 14:02:01 --> Loader Class Initialized
INFO - 2025-11-12 14:02:01 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:02:01 --> Helper loaded: url_helper
INFO - 2025-11-12 14:02:01 --> Helper loaded: file_helper
INFO - 2025-11-12 14:02:01 --> Helper loaded: main_helper
INFO - 2025-11-12 14:02:01 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:02:01 --> Database Driver Class Initialized
INFO - 2025-11-12 14:02:01 --> Email Class Initialized
DEBUG - 2025-11-12 14:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:02:01 --> Controller Class Initialized
INFO - 2025-11-12 14:02:01 --> Model "User_model" initialized
INFO - 2025-11-12 14:02:01 --> Model "Project_model" initialized
INFO - 2025-11-12 14:02:01 --> Helper loaded: form_helper
INFO - 2025-11-12 14:02:01 --> Form Validation Class Initialized
INFO - 2025-11-12 14:02:01 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:02:01 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:02:01 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:02:01 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:02:01 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:02:01 --> Model "Topk_service_model" initialized
ERROR - 2025-11-12 14:02:03 --> OpenAI call error: Client error: `POST https://api.openai.com/v1/chat/completions` resulted in a `400 Bad Request` response:
{
    "error": {
        "message": "We could not parse the JSON body of your request. (HINT: This likely means you aren (truncated...)

ERROR - 2025-11-12 14:02:03 --> strategies error: AI tidak mengembalikan data strategi (kemungkinan MAX_TOKENS atau respons kosong).
INFO - 2025-11-12 14:02:03 --> Final output sent to browser
INFO - 2025-11-12 14:02:03 --> Total execution time: 1.8707
INFO - 2025-11-12 14:04:16 --> Config Class Initialized
INFO - 2025-11-12 14:04:16 --> Hooks Class Initialized
INFO - 2025-11-12 14:04:16 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:04:16 --> Utf8 Class Initialized
INFO - 2025-11-12 14:04:16 --> URI Class Initialized
INFO - 2025-11-12 14:04:16 --> Router Class Initialized
INFO - 2025-11-12 14:04:16 --> Output Class Initialized
INFO - 2025-11-12 14:04:16 --> Security Class Initialized
INFO - 2025-11-12 14:04:16 --> Input Class Initialized
INFO - 2025-11-12 14:04:16 --> Language Class Initialized
INFO - 2025-11-12 14:04:16 --> Loader Class Initialized
INFO - 2025-11-12 14:04:16 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:04:16 --> Helper loaded: url_helper
INFO - 2025-11-12 14:04:16 --> Helper loaded: file_helper
INFO - 2025-11-12 14:04:16 --> Helper loaded: main_helper
INFO - 2025-11-12 14:04:16 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:04:16 --> Database Driver Class Initialized
INFO - 2025-11-12 14:04:16 --> Email Class Initialized
DEBUG - 2025-11-12 14:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:04:16 --> Controller Class Initialized
INFO - 2025-11-12 14:04:16 --> Model "User_model" initialized
INFO - 2025-11-12 14:04:16 --> Model "Project_model" initialized
INFO - 2025-11-12 14:04:16 --> Helper loaded: form_helper
INFO - 2025-11-12 14:04:16 --> Form Validation Class Initialized
INFO - 2025-11-12 14:04:16 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:04:16 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:04:16 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:04:16 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:04:16 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:04:16 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:04:23 --> Final output sent to browser
INFO - 2025-11-12 14:04:23 --> Total execution time: 7.5522
INFO - 2025-11-12 14:08:42 --> Config Class Initialized
INFO - 2025-11-12 14:08:42 --> Hooks Class Initialized
INFO - 2025-11-12 14:08:42 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:08:42 --> Utf8 Class Initialized
INFO - 2025-11-12 14:08:42 --> URI Class Initialized
INFO - 2025-11-12 14:08:42 --> Router Class Initialized
INFO - 2025-11-12 14:08:42 --> Output Class Initialized
INFO - 2025-11-12 14:08:42 --> Security Class Initialized
INFO - 2025-11-12 14:08:42 --> Input Class Initialized
INFO - 2025-11-12 14:08:42 --> Language Class Initialized
INFO - 2025-11-12 14:08:42 --> Loader Class Initialized
INFO - 2025-11-12 14:08:42 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:08:42 --> Helper loaded: url_helper
INFO - 2025-11-12 14:08:42 --> Helper loaded: file_helper
INFO - 2025-11-12 14:08:42 --> Helper loaded: main_helper
INFO - 2025-11-12 14:08:42 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:08:42 --> Database Driver Class Initialized
INFO - 2025-11-12 14:08:42 --> Email Class Initialized
DEBUG - 2025-11-12 14:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:08:42 --> Controller Class Initialized
INFO - 2025-11-12 14:08:42 --> Model "User_model" initialized
INFO - 2025-11-12 14:08:42 --> Model "Project_model" initialized
INFO - 2025-11-12 14:08:42 --> Helper loaded: form_helper
INFO - 2025-11-12 14:08:42 --> Form Validation Class Initialized
INFO - 2025-11-12 14:08:42 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:08:42 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:08:42 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:08:42 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:08:42 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:08:42 --> Model "Topk_service_model" initialized
ERROR - 2025-11-12 14:08:48 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 262,
    "totalTokenCount": 1061,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 262
      }
    ],
    "thoughtsTokenCount": 799
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "8JQUaamaGYDkjuMPy_iKgA8"
}

ERROR - 2025-11-12 14:08:53 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 279,
    "totalTokenCount": 838,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 279
      }
    ],
    "thoughtsTokenCount": 559
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "9JQUaYC3JarZjuMPs-65oAo"
}

ERROR - 2025-11-12 14:08:53 --> strategies error: AI tidak mengembalikan data strategi (respons kosong atau format tidak sesuai).
INFO - 2025-11-12 14:08:53 --> Final output sent to browser
INFO - 2025-11-12 14:08:53 --> Total execution time: 10.2732
INFO - 2025-11-12 14:11:17 --> Config Class Initialized
INFO - 2025-11-12 14:11:17 --> Hooks Class Initialized
INFO - 2025-11-12 14:11:17 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:11:17 --> Utf8 Class Initialized
INFO - 2025-11-12 14:11:17 --> URI Class Initialized
INFO - 2025-11-12 14:11:17 --> Router Class Initialized
INFO - 2025-11-12 14:11:17 --> Output Class Initialized
INFO - 2025-11-12 14:11:17 --> Security Class Initialized
INFO - 2025-11-12 14:11:17 --> Input Class Initialized
INFO - 2025-11-12 14:11:17 --> Language Class Initialized
INFO - 2025-11-12 14:11:17 --> Loader Class Initialized
INFO - 2025-11-12 14:11:17 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:11:17 --> Helper loaded: url_helper
INFO - 2025-11-12 14:11:17 --> Helper loaded: file_helper
INFO - 2025-11-12 14:11:17 --> Helper loaded: main_helper
INFO - 2025-11-12 14:11:17 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:11:17 --> Database Driver Class Initialized
INFO - 2025-11-12 14:11:17 --> Email Class Initialized
DEBUG - 2025-11-12 14:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:11:17 --> Controller Class Initialized
INFO - 2025-11-12 14:11:17 --> Model "User_model" initialized
INFO - 2025-11-12 14:11:17 --> Model "Project_model" initialized
INFO - 2025-11-12 14:11:17 --> Helper loaded: form_helper
INFO - 2025-11-12 14:11:17 --> Form Validation Class Initialized
INFO - 2025-11-12 14:11:17 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:11:17 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:11:17 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:11:17 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:11:17 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:11:17 --> Model "Topk_service_model" initialized
ERROR - 2025-11-12 14:11:22 --> Gemini API request error: Server error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `503 Service Unavailable` response:
{
  "error": {
    "code": 503,
    "message": "The model is overloaded. Please try again later.",
    "status": "UNAVAI (truncated...)

ERROR - 2025-11-12 14:11:23 --> Gemini API request error: Server error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `503 Service Unavailable` response:
{
  "error": {
    "code": 503,
    "message": "The model is overloaded. Please try again later.",
    "status": "UNAVAI (truncated...)

ERROR - 2025-11-12 14:11:23 --> strategies error: AI tidak mengembalikan data strategi (respons kosong atau format tidak sesuai).
INFO - 2025-11-12 14:11:23 --> Final output sent to browser
INFO - 2025-11-12 14:11:23 --> Total execution time: 5.7073
INFO - 2025-11-12 14:11:56 --> Config Class Initialized
INFO - 2025-11-12 14:11:56 --> Hooks Class Initialized
INFO - 2025-11-12 14:11:56 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:11:56 --> Utf8 Class Initialized
INFO - 2025-11-12 14:11:56 --> URI Class Initialized
INFO - 2025-11-12 14:11:56 --> Router Class Initialized
INFO - 2025-11-12 14:11:56 --> Output Class Initialized
INFO - 2025-11-12 14:11:56 --> Security Class Initialized
INFO - 2025-11-12 14:11:56 --> Input Class Initialized
INFO - 2025-11-12 14:11:56 --> Language Class Initialized
INFO - 2025-11-12 14:11:56 --> Loader Class Initialized
INFO - 2025-11-12 14:11:56 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:11:56 --> Helper loaded: url_helper
INFO - 2025-11-12 14:11:56 --> Helper loaded: file_helper
INFO - 2025-11-12 14:11:56 --> Helper loaded: main_helper
INFO - 2025-11-12 14:11:56 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:11:56 --> Database Driver Class Initialized
INFO - 2025-11-12 14:11:56 --> Email Class Initialized
DEBUG - 2025-11-12 14:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:11:56 --> Controller Class Initialized
INFO - 2025-11-12 14:11:56 --> Model "User_model" initialized
INFO - 2025-11-12 14:11:56 --> Model "Project_model" initialized
INFO - 2025-11-12 14:11:56 --> Helper loaded: form_helper
INFO - 2025-11-12 14:11:56 --> Form Validation Class Initialized
INFO - 2025-11-12 14:11:56 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:11:56 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:11:56 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:11:56 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:11:56 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:11:56 --> Model "Topk_service_model" initialized
ERROR - 2025-11-12 14:11:59 --> Gemini API request error: Server error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `503 Service Unavailable` response:
{
  "error": {
    "code": 503,
    "message": "The model is overloaded. Please try again later.",
    "status": "UNAVAI (truncated...)

ERROR - 2025-11-12 14:12:11 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 303,
    "totalTokenCount": 1802,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 303
      }
    ],
    "thoughtsTokenCount": 1499
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "u5UUab_wB-HXjuMPv7nOgQY"
}

ERROR - 2025-11-12 14:12:13 --> Gemini API request error: Server error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `503 Service Unavailable` response:
{
  "error": {
    "code": 503,
    "message": "The model is overloaded. Please try again later.",
    "status": "UNAVAI (truncated...)

ERROR - 2025-11-12 14:12:14 --> Gemini API request error: Server error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `503 Service Unavailable` response:
{
  "error": {
    "code": 503,
    "message": "The model is overloaded. Please try again later.",
    "status": "UNAVAI (truncated...)

ERROR - 2025-11-12 14:12:14 --> strategies error: AI tidak mengembalikan data strategi (respons kosong atau format tidak sesuai).
INFO - 2025-11-12 14:12:14 --> Final output sent to browser
INFO - 2025-11-12 14:12:14 --> Total execution time: 18.8287
INFO - 2025-11-12 14:15:19 --> Config Class Initialized
INFO - 2025-11-12 14:15:19 --> Hooks Class Initialized
INFO - 2025-11-12 14:15:19 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:15:19 --> Utf8 Class Initialized
INFO - 2025-11-12 14:15:19 --> URI Class Initialized
INFO - 2025-11-12 14:15:19 --> Router Class Initialized
INFO - 2025-11-12 14:15:19 --> Output Class Initialized
INFO - 2025-11-12 14:15:19 --> Security Class Initialized
INFO - 2025-11-12 14:15:19 --> Input Class Initialized
INFO - 2025-11-12 14:15:19 --> Language Class Initialized
INFO - 2025-11-12 14:15:19 --> Loader Class Initialized
INFO - 2025-11-12 14:15:19 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:15:19 --> Helper loaded: url_helper
INFO - 2025-11-12 14:15:19 --> Helper loaded: file_helper
INFO - 2025-11-12 14:15:19 --> Helper loaded: main_helper
INFO - 2025-11-12 14:15:19 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:15:19 --> Database Driver Class Initialized
INFO - 2025-11-12 14:15:19 --> Email Class Initialized
DEBUG - 2025-11-12 14:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:15:19 --> Controller Class Initialized
INFO - 2025-11-12 14:15:19 --> Model "User_model" initialized
INFO - 2025-11-12 14:15:19 --> Model "Project_model" initialized
INFO - 2025-11-12 14:15:19 --> Helper loaded: form_helper
INFO - 2025-11-12 14:15:19 --> Form Validation Class Initialized
INFO - 2025-11-12 14:15:19 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:15:19 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:15:19 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:15:19 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:15:19 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:15:19 --> Model "Topk_service_model" initialized
ERROR - 2025-11-12 14:15:21 --> Gemini API request error: Server error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `503 Service Unavailable` response:
{
  "error": {
    "code": 503,
    "message": "The model is overloaded. Please try again later.",
    "status": "UNAVAI (truncated...)

ERROR - 2025-11-12 14:15:36 --> Gemini returned invalid JSON after retry: {"strategies":[{"code":"
ERROR - 2025-11-12 14:15:36 --> strategies error: AI tidak mengembalikan data strategi (respons kosong atau format tidak sesuai).
INFO - 2025-11-12 14:15:36 --> Final output sent to browser
INFO - 2025-11-12 14:15:36 --> Total execution time: 16.7625
INFO - 2025-11-12 14:16:59 --> Config Class Initialized
INFO - 2025-11-12 14:16:59 --> Hooks Class Initialized
INFO - 2025-11-12 14:16:59 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:16:59 --> Utf8 Class Initialized
INFO - 2025-11-12 14:16:59 --> URI Class Initialized
INFO - 2025-11-12 14:16:59 --> Router Class Initialized
INFO - 2025-11-12 14:16:59 --> Output Class Initialized
INFO - 2025-11-12 14:16:59 --> Security Class Initialized
INFO - 2025-11-12 14:16:59 --> Input Class Initialized
INFO - 2025-11-12 14:16:59 --> Language Class Initialized
INFO - 2025-11-12 14:16:59 --> Loader Class Initialized
INFO - 2025-11-12 14:16:59 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:16:59 --> Helper loaded: url_helper
INFO - 2025-11-12 14:16:59 --> Helper loaded: file_helper
INFO - 2025-11-12 14:16:59 --> Helper loaded: main_helper
INFO - 2025-11-12 14:16:59 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:16:59 --> Database Driver Class Initialized
INFO - 2025-11-12 14:16:59 --> Email Class Initialized
DEBUG - 2025-11-12 14:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:16:59 --> Controller Class Initialized
INFO - 2025-11-12 14:16:59 --> Model "User_model" initialized
INFO - 2025-11-12 14:16:59 --> Model "Project_model" initialized
INFO - 2025-11-12 14:16:59 --> Helper loaded: form_helper
INFO - 2025-11-12 14:16:59 --> Form Validation Class Initialized
INFO - 2025-11-12 14:16:59 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:16:59 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:16:59 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:16:59 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:16:59 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:16:59 --> Model "Topk_service_model" initialized
ERROR - 2025-11-12 14:17:08 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 303,
    "totalTokenCount": 1802,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 303
      }
    ],
    "thoughtsTokenCount": 1499
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "5JYUaZjoGvjKqfkP387gwAo"
}

ERROR - 2025-11-12 14:17:24 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 320,
    "totalTokenCount": 1369,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 320
      }
    ],
    "thoughtsTokenCount": 1049
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "9JYUaee6HJHFjuMPvb6c4QQ"
}

ERROR - 2025-11-12 14:17:32 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 321,
    "totalTokenCount": 1020,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 321
      }
    ],
    "thoughtsTokenCount": 699
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "_JYUaYuRJbi44-EPrtzG0AQ"
}

ERROR - 2025-11-12 14:17:34 --> Gemini API request error: Server error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `503 Service Unavailable` response:
{
  "error": {
    "code": 503,
    "message": "The model is overloaded. Please try again later.",
    "status": "UNAVAI (truncated...)

ERROR - 2025-11-12 14:17:34 --> strategies error: AI tidak mengembalikan data strategi (respons kosong atau format tidak sesuai).
INFO - 2025-11-12 14:17:34 --> Final output sent to browser
INFO - 2025-11-12 14:17:34 --> Total execution time: 35.2806
INFO - 2025-11-12 14:20:47 --> Config Class Initialized
INFO - 2025-11-12 14:20:47 --> Hooks Class Initialized
INFO - 2025-11-12 14:20:47 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:20:47 --> Utf8 Class Initialized
INFO - 2025-11-12 14:20:47 --> URI Class Initialized
INFO - 2025-11-12 14:20:47 --> Router Class Initialized
INFO - 2025-11-12 14:20:47 --> Output Class Initialized
INFO - 2025-11-12 14:20:47 --> Security Class Initialized
INFO - 2025-11-12 14:20:47 --> Input Class Initialized
INFO - 2025-11-12 14:20:47 --> Language Class Initialized
INFO - 2025-11-12 14:20:47 --> Loader Class Initialized
INFO - 2025-11-12 14:20:47 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:20:47 --> Helper loaded: url_helper
INFO - 2025-11-12 14:20:47 --> Helper loaded: file_helper
INFO - 2025-11-12 14:20:47 --> Helper loaded: main_helper
INFO - 2025-11-12 14:20:47 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:20:47 --> Database Driver Class Initialized
INFO - 2025-11-12 14:20:47 --> Email Class Initialized
DEBUG - 2025-11-12 14:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:20:48 --> Controller Class Initialized
INFO - 2025-11-12 14:20:48 --> Model "User_model" initialized
INFO - 2025-11-12 14:20:48 --> Model "Project_model" initialized
INFO - 2025-11-12 14:20:48 --> Helper loaded: form_helper
INFO - 2025-11-12 14:20:48 --> Form Validation Class Initialized
INFO - 2025-11-12 14:20:48 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:20:48 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:20:48 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:20:48 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:20:48 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:20:48 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:20:59 --> Final output sent to browser
INFO - 2025-11-12 14:20:59 --> Total execution time: 11.5855
INFO - 2025-11-12 14:21:22 --> Config Class Initialized
INFO - 2025-11-12 14:21:22 --> Hooks Class Initialized
INFO - 2025-11-12 14:21:22 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:21:22 --> Utf8 Class Initialized
INFO - 2025-11-12 14:21:22 --> URI Class Initialized
INFO - 2025-11-12 14:21:22 --> Router Class Initialized
INFO - 2025-11-12 14:21:22 --> Output Class Initialized
INFO - 2025-11-12 14:21:22 --> Security Class Initialized
INFO - 2025-11-12 14:21:22 --> Input Class Initialized
INFO - 2025-11-12 14:21:22 --> Language Class Initialized
INFO - 2025-11-12 14:21:22 --> Loader Class Initialized
INFO - 2025-11-12 14:21:22 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:21:22 --> Helper loaded: url_helper
INFO - 2025-11-12 14:21:22 --> Helper loaded: file_helper
INFO - 2025-11-12 14:21:22 --> Helper loaded: main_helper
INFO - 2025-11-12 14:21:22 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:21:22 --> Database Driver Class Initialized
INFO - 2025-11-12 14:21:22 --> Email Class Initialized
DEBUG - 2025-11-12 14:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:21:22 --> Controller Class Initialized
INFO - 2025-11-12 14:21:22 --> Model "Subscription_model" initialized
INFO - 2025-11-12 14:21:22 --> Model "User_model" initialized
INFO - 2025-11-12 14:21:22 --> Model "Auth_model" initialized
INFO - 2025-11-12 14:21:22 --> Model "Project_model" initialized
INFO - 2025-11-12 14:21:22 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-12 14:21:22 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-12 14:21:22 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-12 14:21:22 --> File loaded: D:\laragon\www\acumena\application\views\projects/profile.php
INFO - 2025-11-12 14:21:22 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-12 14:21:22 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-12 14:21:22 --> Final output sent to browser
INFO - 2025-11-12 14:21:22 --> Total execution time: 0.0923
INFO - 2025-11-12 14:21:22 --> Config Class Initialized
INFO - 2025-11-12 14:21:22 --> Hooks Class Initialized
INFO - 2025-11-12 14:21:22 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:21:22 --> Utf8 Class Initialized
INFO - 2025-11-12 14:21:22 --> URI Class Initialized
INFO - 2025-11-12 14:21:22 --> Router Class Initialized
INFO - 2025-11-12 14:21:22 --> Output Class Initialized
INFO - 2025-11-12 14:21:22 --> Security Class Initialized
INFO - 2025-11-12 14:21:22 --> Input Class Initialized
INFO - 2025-11-12 14:21:22 --> Language Class Initialized
INFO - 2025-11-12 14:21:22 --> Loader Class Initialized
INFO - 2025-11-12 14:21:22 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:21:22 --> Helper loaded: url_helper
INFO - 2025-11-12 14:21:22 --> Helper loaded: file_helper
INFO - 2025-11-12 14:21:22 --> Helper loaded: main_helper
INFO - 2025-11-12 14:21:22 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:21:22 --> Database Driver Class Initialized
INFO - 2025-11-12 14:21:22 --> Email Class Initialized
DEBUG - 2025-11-12 14:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:21:22 --> Controller Class Initialized
INFO - 2025-11-12 14:21:22 --> Model "User_model" initialized
INFO - 2025-11-12 14:21:22 --> Model "Project_model" initialized
INFO - 2025-11-12 14:21:22 --> Helper loaded: form_helper
INFO - 2025-11-12 14:21:22 --> Form Validation Class Initialized
INFO - 2025-11-12 14:21:22 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:21:22 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:21:22 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:21:22 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:21:22 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:21:22 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:21:22 --> Final output sent to browser
INFO - 2025-11-12 14:21:22 --> Total execution time: 0.0748
INFO - 2025-11-12 14:21:24 --> Config Class Initialized
INFO - 2025-11-12 14:21:24 --> Hooks Class Initialized
INFO - 2025-11-12 14:21:24 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:21:24 --> Utf8 Class Initialized
INFO - 2025-11-12 14:21:24 --> URI Class Initialized
INFO - 2025-11-12 14:21:24 --> Router Class Initialized
INFO - 2025-11-12 14:21:24 --> Output Class Initialized
INFO - 2025-11-12 14:21:24 --> Security Class Initialized
INFO - 2025-11-12 14:21:24 --> Input Class Initialized
INFO - 2025-11-12 14:21:24 --> Language Class Initialized
INFO - 2025-11-12 14:21:24 --> Loader Class Initialized
INFO - 2025-11-12 14:21:24 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:21:24 --> Helper loaded: url_helper
INFO - 2025-11-12 14:21:24 --> Helper loaded: file_helper
INFO - 2025-11-12 14:21:24 --> Helper loaded: main_helper
INFO - 2025-11-12 14:21:24 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:21:24 --> Database Driver Class Initialized
INFO - 2025-11-12 14:21:24 --> Email Class Initialized
DEBUG - 2025-11-12 14:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:21:24 --> Controller Class Initialized
INFO - 2025-11-12 14:21:24 --> Model "User_model" initialized
INFO - 2025-11-12 14:21:24 --> Model "Project_model" initialized
INFO - 2025-11-12 14:21:24 --> Helper loaded: form_helper
INFO - 2025-11-12 14:21:24 --> Form Validation Class Initialized
INFO - 2025-11-12 14:21:24 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:21:24 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:21:24 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:21:24 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:21:24 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:21:24 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:21:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-11-12 14:21:24 --> Final output sent to browser
INFO - 2025-11-12 14:21:24 --> Total execution time: 0.0972
INFO - 2025-11-12 14:21:24 --> Config Class Initialized
INFO - 2025-11-12 14:21:24 --> Hooks Class Initialized
INFO - 2025-11-12 14:21:24 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:21:24 --> Utf8 Class Initialized
INFO - 2025-11-12 14:21:24 --> URI Class Initialized
INFO - 2025-11-12 14:21:24 --> Router Class Initialized
INFO - 2025-11-12 14:21:24 --> Output Class Initialized
INFO - 2025-11-12 14:21:24 --> Security Class Initialized
INFO - 2025-11-12 14:21:24 --> Input Class Initialized
INFO - 2025-11-12 14:21:24 --> Language Class Initialized
INFO - 2025-11-12 14:21:24 --> Loader Class Initialized
INFO - 2025-11-12 14:21:24 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:21:24 --> Helper loaded: url_helper
INFO - 2025-11-12 14:21:24 --> Helper loaded: file_helper
INFO - 2025-11-12 14:21:24 --> Helper loaded: main_helper
INFO - 2025-11-12 14:21:24 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:21:24 --> Database Driver Class Initialized
INFO - 2025-11-12 14:21:24 --> Email Class Initialized
DEBUG - 2025-11-12 14:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:21:24 --> Controller Class Initialized
INFO - 2025-11-12 14:21:24 --> Model "Subscription_model" initialized
INFO - 2025-11-12 14:21:24 --> Model "User_model" initialized
INFO - 2025-11-12 14:21:24 --> Model "Auth_model" initialized
INFO - 2025-11-12 14:21:24 --> Model "Project_model" initialized
INFO - 2025-11-12 14:21:24 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-12 14:21:24 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-12 14:21:24 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-12 14:21:24 --> File loaded: D:\laragon\www\acumena\application\views\projects/swot.php
INFO - 2025-11-12 14:21:24 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-12 14:21:24 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-12 14:21:24 --> Final output sent to browser
INFO - 2025-11-12 14:21:24 --> Total execution time: 0.0802
INFO - 2025-11-12 14:21:24 --> Config Class Initialized
INFO - 2025-11-12 14:21:24 --> Hooks Class Initialized
INFO - 2025-11-12 14:21:24 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:21:24 --> Utf8 Class Initialized
INFO - 2025-11-12 14:21:24 --> URI Class Initialized
INFO - 2025-11-12 14:21:24 --> Router Class Initialized
INFO - 2025-11-12 14:21:24 --> Output Class Initialized
INFO - 2025-11-12 14:21:24 --> Security Class Initialized
INFO - 2025-11-12 14:21:24 --> Input Class Initialized
INFO - 2025-11-12 14:21:24 --> Language Class Initialized
INFO - 2025-11-12 14:21:24 --> Loader Class Initialized
INFO - 2025-11-12 14:21:24 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:21:24 --> Helper loaded: url_helper
INFO - 2025-11-12 14:21:24 --> Helper loaded: file_helper
INFO - 2025-11-12 14:21:24 --> Helper loaded: main_helper
INFO - 2025-11-12 14:21:24 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:21:24 --> Database Driver Class Initialized
INFO - 2025-11-12 14:21:24 --> Email Class Initialized
DEBUG - 2025-11-12 14:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:21:24 --> Controller Class Initialized
INFO - 2025-11-12 14:21:24 --> Model "User_model" initialized
INFO - 2025-11-12 14:21:24 --> Model "Project_model" initialized
INFO - 2025-11-12 14:21:24 --> Helper loaded: form_helper
INFO - 2025-11-12 14:21:24 --> Form Validation Class Initialized
INFO - 2025-11-12 14:21:24 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:21:24 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:21:24 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:21:24 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:21:24 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:21:24 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:21:24 --> Final output sent to browser
INFO - 2025-11-12 14:21:24 --> Total execution time: 0.0872
INFO - 2025-11-12 14:21:32 --> Config Class Initialized
INFO - 2025-11-12 14:21:32 --> Hooks Class Initialized
INFO - 2025-11-12 14:21:32 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:21:32 --> Utf8 Class Initialized
INFO - 2025-11-12 14:21:32 --> URI Class Initialized
INFO - 2025-11-12 14:21:32 --> Router Class Initialized
INFO - 2025-11-12 14:21:32 --> Output Class Initialized
INFO - 2025-11-12 14:21:32 --> Security Class Initialized
INFO - 2025-11-12 14:21:32 --> Input Class Initialized
INFO - 2025-11-12 14:21:32 --> Language Class Initialized
INFO - 2025-11-12 14:21:32 --> Loader Class Initialized
INFO - 2025-11-12 14:21:32 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:21:32 --> Helper loaded: url_helper
INFO - 2025-11-12 14:21:32 --> Helper loaded: file_helper
INFO - 2025-11-12 14:21:32 --> Helper loaded: main_helper
INFO - 2025-11-12 14:21:32 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:21:32 --> Database Driver Class Initialized
INFO - 2025-11-12 14:21:32 --> Email Class Initialized
DEBUG - 2025-11-12 14:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:21:32 --> Controller Class Initialized
INFO - 2025-11-12 14:21:32 --> Model "User_model" initialized
INFO - 2025-11-12 14:21:32 --> Model "Project_model" initialized
INFO - 2025-11-12 14:21:32 --> Helper loaded: form_helper
INFO - 2025-11-12 14:21:32 --> Form Validation Class Initialized
INFO - 2025-11-12 14:21:32 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:21:32 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:21:32 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:21:32 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:21:32 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:21:32 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:21:32 --> Final output sent to browser
INFO - 2025-11-12 14:21:32 --> Total execution time: 0.0833
INFO - 2025-11-12 14:21:32 --> Config Class Initialized
INFO - 2025-11-12 14:21:32 --> Hooks Class Initialized
INFO - 2025-11-12 14:21:32 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:21:32 --> Utf8 Class Initialized
INFO - 2025-11-12 14:21:32 --> URI Class Initialized
INFO - 2025-11-12 14:21:32 --> Router Class Initialized
INFO - 2025-11-12 14:21:32 --> Output Class Initialized
INFO - 2025-11-12 14:21:32 --> Security Class Initialized
INFO - 2025-11-12 14:21:32 --> Input Class Initialized
INFO - 2025-11-12 14:21:32 --> Language Class Initialized
INFO - 2025-11-12 14:21:32 --> Loader Class Initialized
INFO - 2025-11-12 14:21:32 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:21:32 --> Helper loaded: url_helper
INFO - 2025-11-12 14:21:32 --> Helper loaded: file_helper
INFO - 2025-11-12 14:21:32 --> Helper loaded: main_helper
INFO - 2025-11-12 14:21:32 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:21:32 --> Database Driver Class Initialized
INFO - 2025-11-12 14:21:32 --> Email Class Initialized
DEBUG - 2025-11-12 14:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:21:32 --> Controller Class Initialized
INFO - 2025-11-12 14:21:32 --> Model "Subscription_model" initialized
INFO - 2025-11-12 14:21:32 --> Model "User_model" initialized
INFO - 2025-11-12 14:21:32 --> Model "Auth_model" initialized
INFO - 2025-11-12 14:21:32 --> Model "Project_model" initialized
INFO - 2025-11-12 14:21:32 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-12 14:21:32 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-12 14:21:32 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-12 14:21:32 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ife.php
INFO - 2025-11-12 14:21:32 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-12 14:21:32 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-12 14:21:32 --> Final output sent to browser
INFO - 2025-11-12 14:21:32 --> Total execution time: 0.0975
INFO - 2025-11-12 14:21:32 --> Config Class Initialized
INFO - 2025-11-12 14:21:32 --> Hooks Class Initialized
INFO - 2025-11-12 14:21:32 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:21:32 --> Utf8 Class Initialized
INFO - 2025-11-12 14:21:32 --> URI Class Initialized
INFO - 2025-11-12 14:21:32 --> Router Class Initialized
INFO - 2025-11-12 14:21:32 --> Output Class Initialized
INFO - 2025-11-12 14:21:32 --> Security Class Initialized
INFO - 2025-11-12 14:21:32 --> Input Class Initialized
INFO - 2025-11-12 14:21:32 --> Language Class Initialized
INFO - 2025-11-12 14:21:32 --> Loader Class Initialized
INFO - 2025-11-12 14:21:32 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:21:32 --> Helper loaded: url_helper
INFO - 2025-11-12 14:21:32 --> Helper loaded: file_helper
INFO - 2025-11-12 14:21:32 --> Helper loaded: main_helper
INFO - 2025-11-12 14:21:32 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:21:32 --> Database Driver Class Initialized
INFO - 2025-11-12 14:21:32 --> Email Class Initialized
DEBUG - 2025-11-12 14:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:21:32 --> Controller Class Initialized
INFO - 2025-11-12 14:21:32 --> Model "User_model" initialized
INFO - 2025-11-12 14:21:32 --> Model "Project_model" initialized
INFO - 2025-11-12 14:21:32 --> Helper loaded: form_helper
INFO - 2025-11-12 14:21:32 --> Form Validation Class Initialized
INFO - 2025-11-12 14:21:32 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:21:32 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:21:32 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:21:32 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:21:32 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:21:32 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:21:32 --> Final output sent to browser
INFO - 2025-11-12 14:21:32 --> Total execution time: 0.1024
INFO - 2025-11-12 14:21:36 --> Config Class Initialized
INFO - 2025-11-12 14:21:36 --> Hooks Class Initialized
INFO - 2025-11-12 14:21:36 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:21:36 --> Utf8 Class Initialized
INFO - 2025-11-12 14:21:36 --> URI Class Initialized
INFO - 2025-11-12 14:21:36 --> Router Class Initialized
INFO - 2025-11-12 14:21:36 --> Output Class Initialized
INFO - 2025-11-12 14:21:36 --> Security Class Initialized
INFO - 2025-11-12 14:21:36 --> Input Class Initialized
INFO - 2025-11-12 14:21:36 --> Language Class Initialized
INFO - 2025-11-12 14:21:36 --> Loader Class Initialized
INFO - 2025-11-12 14:21:36 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:21:36 --> Helper loaded: url_helper
INFO - 2025-11-12 14:21:36 --> Helper loaded: file_helper
INFO - 2025-11-12 14:21:36 --> Helper loaded: main_helper
INFO - 2025-11-12 14:21:36 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:21:36 --> Database Driver Class Initialized
INFO - 2025-11-12 14:21:36 --> Email Class Initialized
DEBUG - 2025-11-12 14:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:21:36 --> Controller Class Initialized
INFO - 2025-11-12 14:21:36 --> Model "User_model" initialized
INFO - 2025-11-12 14:21:36 --> Model "Project_model" initialized
INFO - 2025-11-12 14:21:36 --> Helper loaded: form_helper
INFO - 2025-11-12 14:21:36 --> Form Validation Class Initialized
INFO - 2025-11-12 14:21:36 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:21:36 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:21:36 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:21:36 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:21:36 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:21:36 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:21:36 --> Final output sent to browser
INFO - 2025-11-12 14:21:36 --> Total execution time: 0.1251
INFO - 2025-11-12 14:21:36 --> Config Class Initialized
INFO - 2025-11-12 14:21:36 --> Hooks Class Initialized
INFO - 2025-11-12 14:21:36 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:21:36 --> Utf8 Class Initialized
INFO - 2025-11-12 14:21:36 --> URI Class Initialized
INFO - 2025-11-12 14:21:36 --> Router Class Initialized
INFO - 2025-11-12 14:21:36 --> Output Class Initialized
INFO - 2025-11-12 14:21:36 --> Security Class Initialized
INFO - 2025-11-12 14:21:36 --> Input Class Initialized
INFO - 2025-11-12 14:21:36 --> Language Class Initialized
INFO - 2025-11-12 14:21:36 --> Loader Class Initialized
INFO - 2025-11-12 14:21:36 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:21:36 --> Helper loaded: url_helper
INFO - 2025-11-12 14:21:36 --> Helper loaded: file_helper
INFO - 2025-11-12 14:21:36 --> Helper loaded: main_helper
INFO - 2025-11-12 14:21:36 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:21:36 --> Database Driver Class Initialized
INFO - 2025-11-12 14:21:36 --> Email Class Initialized
DEBUG - 2025-11-12 14:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:21:37 --> Controller Class Initialized
INFO - 2025-11-12 14:21:37 --> Model "Subscription_model" initialized
INFO - 2025-11-12 14:21:37 --> Model "User_model" initialized
INFO - 2025-11-12 14:21:37 --> Model "Auth_model" initialized
INFO - 2025-11-12 14:21:37 --> Model "Project_model" initialized
INFO - 2025-11-12 14:21:37 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-12 14:21:37 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-12 14:21:37 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-12 14:21:37 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-efe.php
INFO - 2025-11-12 14:21:37 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-12 14:21:37 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-12 14:21:37 --> Final output sent to browser
INFO - 2025-11-12 14:21:37 --> Total execution time: 0.0779
INFO - 2025-11-12 14:21:37 --> Config Class Initialized
INFO - 2025-11-12 14:21:37 --> Hooks Class Initialized
INFO - 2025-11-12 14:21:37 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:21:37 --> Utf8 Class Initialized
INFO - 2025-11-12 14:21:37 --> URI Class Initialized
INFO - 2025-11-12 14:21:37 --> Router Class Initialized
INFO - 2025-11-12 14:21:37 --> Output Class Initialized
INFO - 2025-11-12 14:21:37 --> Security Class Initialized
INFO - 2025-11-12 14:21:37 --> Input Class Initialized
INFO - 2025-11-12 14:21:37 --> Language Class Initialized
INFO - 2025-11-12 14:21:37 --> Loader Class Initialized
INFO - 2025-11-12 14:21:37 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:21:37 --> Helper loaded: url_helper
INFO - 2025-11-12 14:21:37 --> Helper loaded: file_helper
INFO - 2025-11-12 14:21:37 --> Helper loaded: main_helper
INFO - 2025-11-12 14:21:37 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:21:37 --> Database Driver Class Initialized
INFO - 2025-11-12 14:21:37 --> Email Class Initialized
DEBUG - 2025-11-12 14:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:21:37 --> Controller Class Initialized
INFO - 2025-11-12 14:21:37 --> Model "User_model" initialized
INFO - 2025-11-12 14:21:37 --> Model "Project_model" initialized
INFO - 2025-11-12 14:21:37 --> Helper loaded: form_helper
INFO - 2025-11-12 14:21:37 --> Form Validation Class Initialized
INFO - 2025-11-12 14:21:37 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:21:37 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:21:37 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:21:37 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:21:37 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:21:37 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:21:37 --> Final output sent to browser
INFO - 2025-11-12 14:21:37 --> Total execution time: 0.0922
INFO - 2025-11-12 14:21:41 --> Config Class Initialized
INFO - 2025-11-12 14:21:41 --> Hooks Class Initialized
INFO - 2025-11-12 14:21:41 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:21:41 --> Utf8 Class Initialized
INFO - 2025-11-12 14:21:41 --> URI Class Initialized
INFO - 2025-11-12 14:21:41 --> Router Class Initialized
INFO - 2025-11-12 14:21:41 --> Output Class Initialized
INFO - 2025-11-12 14:21:41 --> Security Class Initialized
INFO - 2025-11-12 14:21:41 --> Input Class Initialized
INFO - 2025-11-12 14:21:41 --> Language Class Initialized
INFO - 2025-11-12 14:21:41 --> Loader Class Initialized
INFO - 2025-11-12 14:21:41 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:21:41 --> Helper loaded: url_helper
INFO - 2025-11-12 14:21:41 --> Helper loaded: file_helper
INFO - 2025-11-12 14:21:41 --> Helper loaded: main_helper
INFO - 2025-11-12 14:21:41 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:21:41 --> Database Driver Class Initialized
INFO - 2025-11-12 14:21:41 --> Email Class Initialized
DEBUG - 2025-11-12 14:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:21:41 --> Controller Class Initialized
INFO - 2025-11-12 14:21:41 --> Model "User_model" initialized
INFO - 2025-11-12 14:21:41 --> Model "Project_model" initialized
INFO - 2025-11-12 14:21:41 --> Helper loaded: form_helper
INFO - 2025-11-12 14:21:41 --> Form Validation Class Initialized
INFO - 2025-11-12 14:21:41 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:21:41 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:21:41 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:21:41 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:21:41 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:21:41 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:21:41 --> Final output sent to browser
INFO - 2025-11-12 14:21:41 --> Total execution time: 0.1055
INFO - 2025-11-12 14:21:41 --> Config Class Initialized
INFO - 2025-11-12 14:21:41 --> Hooks Class Initialized
INFO - 2025-11-12 14:21:41 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:21:41 --> Utf8 Class Initialized
INFO - 2025-11-12 14:21:41 --> URI Class Initialized
INFO - 2025-11-12 14:21:41 --> Router Class Initialized
INFO - 2025-11-12 14:21:41 --> Output Class Initialized
INFO - 2025-11-12 14:21:41 --> Security Class Initialized
INFO - 2025-11-12 14:21:41 --> Input Class Initialized
INFO - 2025-11-12 14:21:41 --> Language Class Initialized
INFO - 2025-11-12 14:21:41 --> Loader Class Initialized
INFO - 2025-11-12 14:21:41 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:21:41 --> Helper loaded: url_helper
INFO - 2025-11-12 14:21:41 --> Helper loaded: file_helper
INFO - 2025-11-12 14:21:41 --> Helper loaded: main_helper
INFO - 2025-11-12 14:21:41 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:21:41 --> Database Driver Class Initialized
INFO - 2025-11-12 14:21:41 --> Email Class Initialized
DEBUG - 2025-11-12 14:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:21:41 --> Controller Class Initialized
INFO - 2025-11-12 14:21:41 --> Model "Subscription_model" initialized
INFO - 2025-11-12 14:21:41 --> Model "User_model" initialized
INFO - 2025-11-12 14:21:41 --> Model "Auth_model" initialized
INFO - 2025-11-12 14:21:41 --> Model "Project_model" initialized
INFO - 2025-11-12 14:21:41 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-12 14:21:41 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-12 14:21:41 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-12 14:21:41 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ie.php
INFO - 2025-11-12 14:21:41 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-12 14:21:41 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-12 14:21:41 --> Final output sent to browser
INFO - 2025-11-12 14:21:41 --> Total execution time: 0.0844
INFO - 2025-11-12 14:21:41 --> Config Class Initialized
INFO - 2025-11-12 14:21:41 --> Config Class Initialized
INFO - 2025-11-12 14:21:41 --> Hooks Class Initialized
INFO - 2025-11-12 14:21:41 --> Hooks Class Initialized
INFO - 2025-11-12 14:21:41 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:21:41 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:21:41 --> Utf8 Class Initialized
INFO - 2025-11-12 14:21:41 --> Utf8 Class Initialized
INFO - 2025-11-12 14:21:41 --> URI Class Initialized
INFO - 2025-11-12 14:21:41 --> URI Class Initialized
INFO - 2025-11-12 14:21:41 --> Router Class Initialized
INFO - 2025-11-12 14:21:41 --> Router Class Initialized
INFO - 2025-11-12 14:21:41 --> Output Class Initialized
INFO - 2025-11-12 14:21:41 --> Output Class Initialized
INFO - 2025-11-12 14:21:41 --> Security Class Initialized
INFO - 2025-11-12 14:21:41 --> Security Class Initialized
INFO - 2025-11-12 14:21:41 --> Input Class Initialized
INFO - 2025-11-12 14:21:41 --> Input Class Initialized
INFO - 2025-11-12 14:21:41 --> Language Class Initialized
INFO - 2025-11-12 14:21:41 --> Language Class Initialized
INFO - 2025-11-12 14:21:41 --> Loader Class Initialized
INFO - 2025-11-12 14:21:41 --> Loader Class Initialized
INFO - 2025-11-12 14:21:41 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:21:41 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:21:41 --> Helper loaded: url_helper
INFO - 2025-11-12 14:21:41 --> Helper loaded: url_helper
INFO - 2025-11-12 14:21:41 --> Helper loaded: file_helper
INFO - 2025-11-12 14:21:41 --> Helper loaded: file_helper
INFO - 2025-11-12 14:21:41 --> Helper loaded: main_helper
INFO - 2025-11-12 14:21:41 --> Helper loaded: main_helper
INFO - 2025-11-12 14:21:41 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:21:41 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:21:41 --> Database Driver Class Initialized
INFO - 2025-11-12 14:21:41 --> Database Driver Class Initialized
INFO - 2025-11-12 14:21:41 --> Email Class Initialized
INFO - 2025-11-12 14:21:41 --> Email Class Initialized
DEBUG - 2025-11-12 14:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-11-12 14:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:21:41 --> Controller Class Initialized
INFO - 2025-11-12 14:21:41 --> Model "User_model" initialized
INFO - 2025-11-12 14:21:41 --> Model "Project_model" initialized
INFO - 2025-11-12 14:21:41 --> Helper loaded: form_helper
INFO - 2025-11-12 14:21:41 --> Form Validation Class Initialized
INFO - 2025-11-12 14:21:41 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:21:41 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:21:41 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:21:41 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:21:41 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:21:41 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:21:41 --> Final output sent to browser
INFO - 2025-11-12 14:21:41 --> Total execution time: 0.0778
INFO - 2025-11-12 14:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:21:41 --> Controller Class Initialized
INFO - 2025-11-12 14:21:41 --> Model "User_model" initialized
INFO - 2025-11-12 14:21:41 --> Model "Project_model" initialized
INFO - 2025-11-12 14:21:41 --> Helper loaded: form_helper
INFO - 2025-11-12 14:21:41 --> Form Validation Class Initialized
INFO - 2025-11-12 14:21:41 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:21:41 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:21:41 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:21:41 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:21:41 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:21:41 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:21:41 --> Final output sent to browser
INFO - 2025-11-12 14:21:41 --> Total execution time: 0.0930
INFO - 2025-11-12 14:21:42 --> Config Class Initialized
INFO - 2025-11-12 14:21:42 --> Hooks Class Initialized
INFO - 2025-11-12 14:21:42 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:21:42 --> Utf8 Class Initialized
INFO - 2025-11-12 14:21:42 --> URI Class Initialized
INFO - 2025-11-12 14:21:42 --> Router Class Initialized
INFO - 2025-11-12 14:21:42 --> Output Class Initialized
INFO - 2025-11-12 14:21:42 --> Security Class Initialized
INFO - 2025-11-12 14:21:42 --> Input Class Initialized
INFO - 2025-11-12 14:21:42 --> Language Class Initialized
INFO - 2025-11-12 14:21:42 --> Loader Class Initialized
INFO - 2025-11-12 14:21:42 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:21:42 --> Helper loaded: url_helper
INFO - 2025-11-12 14:21:42 --> Helper loaded: file_helper
INFO - 2025-11-12 14:21:42 --> Helper loaded: main_helper
INFO - 2025-11-12 14:21:42 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:21:42 --> Database Driver Class Initialized
INFO - 2025-11-12 14:21:42 --> Email Class Initialized
DEBUG - 2025-11-12 14:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:21:42 --> Controller Class Initialized
INFO - 2025-11-12 14:21:42 --> Model "User_model" initialized
INFO - 2025-11-12 14:21:42 --> Model "Project_model" initialized
INFO - 2025-11-12 14:21:42 --> Helper loaded: form_helper
INFO - 2025-11-12 14:21:42 --> Form Validation Class Initialized
INFO - 2025-11-12 14:21:42 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:21:42 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:21:42 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:21:42 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:21:42 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:21:42 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:21:42 --> Final output sent to browser
INFO - 2025-11-12 14:21:42 --> Total execution time: 0.1042
INFO - 2025-11-12 14:21:42 --> Config Class Initialized
INFO - 2025-11-12 14:21:42 --> Hooks Class Initialized
INFO - 2025-11-12 14:21:42 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:21:42 --> Utf8 Class Initialized
INFO - 2025-11-12 14:21:42 --> URI Class Initialized
INFO - 2025-11-12 14:21:42 --> Router Class Initialized
INFO - 2025-11-12 14:21:42 --> Output Class Initialized
INFO - 2025-11-12 14:21:42 --> Security Class Initialized
INFO - 2025-11-12 14:21:42 --> Input Class Initialized
INFO - 2025-11-12 14:21:42 --> Language Class Initialized
INFO - 2025-11-12 14:21:42 --> Loader Class Initialized
INFO - 2025-11-12 14:21:42 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:21:42 --> Helper loaded: url_helper
INFO - 2025-11-12 14:21:42 --> Helper loaded: file_helper
INFO - 2025-11-12 14:21:42 --> Helper loaded: main_helper
INFO - 2025-11-12 14:21:42 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:21:42 --> Database Driver Class Initialized
INFO - 2025-11-12 14:21:42 --> Email Class Initialized
DEBUG - 2025-11-12 14:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:21:42 --> Controller Class Initialized
INFO - 2025-11-12 14:21:42 --> Model "User_model" initialized
INFO - 2025-11-12 14:21:42 --> Model "Project_model" initialized
INFO - 2025-11-12 14:21:42 --> Helper loaded: form_helper
INFO - 2025-11-12 14:21:42 --> Form Validation Class Initialized
INFO - 2025-11-12 14:21:42 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:21:42 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:21:42 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:21:42 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:21:42 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:21:42 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:21:42 --> Final output sent to browser
INFO - 2025-11-12 14:21:42 --> Total execution time: 0.0801
INFO - 2025-11-12 14:21:44 --> Config Class Initialized
INFO - 2025-11-12 14:21:44 --> Hooks Class Initialized
INFO - 2025-11-12 14:21:44 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:21:44 --> Utf8 Class Initialized
INFO - 2025-11-12 14:21:44 --> URI Class Initialized
INFO - 2025-11-12 14:21:44 --> Router Class Initialized
INFO - 2025-11-12 14:21:44 --> Output Class Initialized
INFO - 2025-11-12 14:21:44 --> Security Class Initialized
INFO - 2025-11-12 14:21:44 --> Input Class Initialized
INFO - 2025-11-12 14:21:44 --> Language Class Initialized
INFO - 2025-11-12 14:21:44 --> Loader Class Initialized
INFO - 2025-11-12 14:21:44 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:21:44 --> Helper loaded: url_helper
INFO - 2025-11-12 14:21:44 --> Helper loaded: file_helper
INFO - 2025-11-12 14:21:44 --> Helper loaded: main_helper
INFO - 2025-11-12 14:21:44 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:21:44 --> Database Driver Class Initialized
INFO - 2025-11-12 14:21:45 --> Email Class Initialized
DEBUG - 2025-11-12 14:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:21:45 --> Controller Class Initialized
INFO - 2025-11-12 14:21:45 --> Model "Subscription_model" initialized
INFO - 2025-11-12 14:21:45 --> Model "User_model" initialized
INFO - 2025-11-12 14:21:45 --> Model "Auth_model" initialized
INFO - 2025-11-12 14:21:45 --> Model "Project_model" initialized
INFO - 2025-11-12 14:21:45 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-12 14:21:45 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-12 14:21:45 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-12 14:21:45 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ai.php
INFO - 2025-11-12 14:21:45 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-12 14:21:45 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-12 14:21:45 --> Final output sent to browser
INFO - 2025-11-12 14:21:45 --> Total execution time: 0.0886
INFO - 2025-11-12 14:25:21 --> Config Class Initialized
INFO - 2025-11-12 14:25:21 --> Hooks Class Initialized
INFO - 2025-11-12 14:25:21 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:25:21 --> Utf8 Class Initialized
INFO - 2025-11-12 14:25:21 --> URI Class Initialized
INFO - 2025-11-12 14:25:21 --> Router Class Initialized
INFO - 2025-11-12 14:25:21 --> Output Class Initialized
INFO - 2025-11-12 14:25:21 --> Security Class Initialized
INFO - 2025-11-12 14:25:21 --> Input Class Initialized
INFO - 2025-11-12 14:25:21 --> Language Class Initialized
INFO - 2025-11-12 14:25:21 --> Loader Class Initialized
INFO - 2025-11-12 14:25:21 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:25:21 --> Helper loaded: url_helper
INFO - 2025-11-12 14:25:21 --> Helper loaded: file_helper
INFO - 2025-11-12 14:25:21 --> Helper loaded: main_helper
INFO - 2025-11-12 14:25:21 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:25:21 --> Database Driver Class Initialized
INFO - 2025-11-12 14:25:21 --> Email Class Initialized
DEBUG - 2025-11-12 14:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:25:21 --> Controller Class Initialized
INFO - 2025-11-12 14:25:21 --> Model "Subscription_model" initialized
INFO - 2025-11-12 14:25:21 --> Model "User_model" initialized
INFO - 2025-11-12 14:25:21 --> Model "Auth_model" initialized
INFO - 2025-11-12 14:25:21 --> Model "Project_model" initialized
INFO - 2025-11-12 14:25:21 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-12 14:25:21 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-12 14:25:21 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-12 14:25:21 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ai.php
INFO - 2025-11-12 14:25:21 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-12 14:25:21 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-12 14:25:21 --> Final output sent to browser
INFO - 2025-11-12 14:25:21 --> Total execution time: 0.1320
INFO - 2025-11-12 14:31:48 --> Config Class Initialized
INFO - 2025-11-12 14:31:48 --> Hooks Class Initialized
INFO - 2025-11-12 14:31:48 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:31:48 --> Utf8 Class Initialized
INFO - 2025-11-12 14:31:48 --> URI Class Initialized
DEBUG - 2025-11-12 14:31:48 --> No URI present. Default controller set.
INFO - 2025-11-12 14:31:48 --> Router Class Initialized
INFO - 2025-11-12 14:31:48 --> Output Class Initialized
INFO - 2025-11-12 14:31:48 --> Security Class Initialized
INFO - 2025-11-12 14:31:48 --> Input Class Initialized
INFO - 2025-11-12 14:31:48 --> Language Class Initialized
INFO - 2025-11-12 14:31:48 --> Loader Class Initialized
INFO - 2025-11-12 14:31:48 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:31:48 --> Helper loaded: url_helper
INFO - 2025-11-12 14:31:48 --> Helper loaded: file_helper
INFO - 2025-11-12 14:31:48 --> Helper loaded: main_helper
INFO - 2025-11-12 14:31:48 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:31:48 --> Database Driver Class Initialized
INFO - 2025-11-12 14:31:48 --> Email Class Initialized
DEBUG - 2025-11-12 14:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:31:48 --> Controller Class Initialized
INFO - 2025-11-12 14:31:48 --> Config Class Initialized
INFO - 2025-11-12 14:31:48 --> Hooks Class Initialized
INFO - 2025-11-12 14:31:48 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:31:48 --> Utf8 Class Initialized
INFO - 2025-11-12 14:31:48 --> URI Class Initialized
INFO - 2025-11-12 14:31:48 --> Router Class Initialized
INFO - 2025-11-12 14:31:48 --> Output Class Initialized
INFO - 2025-11-12 14:31:48 --> Security Class Initialized
INFO - 2025-11-12 14:31:48 --> Input Class Initialized
INFO - 2025-11-12 14:31:48 --> Language Class Initialized
INFO - 2025-11-12 14:31:48 --> Loader Class Initialized
INFO - 2025-11-12 14:31:48 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:31:48 --> Helper loaded: url_helper
INFO - 2025-11-12 14:31:48 --> Helper loaded: file_helper
INFO - 2025-11-12 14:31:48 --> Helper loaded: main_helper
INFO - 2025-11-12 14:31:48 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:31:48 --> Database Driver Class Initialized
INFO - 2025-11-12 14:31:48 --> Email Class Initialized
DEBUG - 2025-11-12 14:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:31:48 --> Controller Class Initialized
INFO - 2025-11-12 14:31:48 --> Model "Subscription_model" initialized
INFO - 2025-11-12 14:31:48 --> Model "User_model" initialized
INFO - 2025-11-12 14:31:48 --> Model "Auth_model" initialized
INFO - 2025-11-12 14:31:48 --> Config Class Initialized
INFO - 2025-11-12 14:31:48 --> Hooks Class Initialized
INFO - 2025-11-12 14:31:48 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:31:48 --> Utf8 Class Initialized
INFO - 2025-11-12 14:31:48 --> URI Class Initialized
INFO - 2025-11-12 14:31:48 --> Router Class Initialized
INFO - 2025-11-12 14:31:48 --> Output Class Initialized
INFO - 2025-11-12 14:31:48 --> Security Class Initialized
INFO - 2025-11-12 14:31:48 --> Input Class Initialized
INFO - 2025-11-12 14:31:48 --> Language Class Initialized
INFO - 2025-11-12 14:31:48 --> Loader Class Initialized
INFO - 2025-11-12 14:31:48 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:31:48 --> Helper loaded: url_helper
INFO - 2025-11-12 14:31:48 --> Helper loaded: file_helper
INFO - 2025-11-12 14:31:48 --> Helper loaded: main_helper
INFO - 2025-11-12 14:31:48 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:31:48 --> Database Driver Class Initialized
INFO - 2025-11-12 14:31:48 --> Email Class Initialized
DEBUG - 2025-11-12 14:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:31:48 --> Controller Class Initialized
INFO - 2025-11-12 14:31:48 --> Config Class Initialized
INFO - 2025-11-12 14:31:48 --> Hooks Class Initialized
INFO - 2025-11-12 14:31:48 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:31:48 --> Utf8 Class Initialized
INFO - 2025-11-12 14:31:48 --> URI Class Initialized
INFO - 2025-11-12 14:31:48 --> Router Class Initialized
INFO - 2025-11-12 14:31:48 --> Output Class Initialized
INFO - 2025-11-12 14:31:48 --> Security Class Initialized
INFO - 2025-11-12 14:31:48 --> Input Class Initialized
INFO - 2025-11-12 14:31:48 --> Language Class Initialized
INFO - 2025-11-12 14:31:48 --> Loader Class Initialized
INFO - 2025-11-12 14:31:48 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:31:48 --> Helper loaded: url_helper
INFO - 2025-11-12 14:31:48 --> Helper loaded: file_helper
INFO - 2025-11-12 14:31:48 --> Helper loaded: main_helper
INFO - 2025-11-12 14:31:48 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:31:48 --> Database Driver Class Initialized
INFO - 2025-11-12 14:31:48 --> Email Class Initialized
DEBUG - 2025-11-12 14:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:31:48 --> Controller Class Initialized
INFO - 2025-11-12 14:31:48 --> Model "Subscription_model" initialized
INFO - 2025-11-12 14:31:48 --> Model "User_model" initialized
INFO - 2025-11-12 14:31:48 --> Model "Auth_model" initialized
INFO - 2025-11-12 14:31:48 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-12 14:31:48 --> Final output sent to browser
INFO - 2025-11-12 14:31:48 --> Total execution time: 0.0762
INFO - 2025-11-12 14:31:49 --> Config Class Initialized
INFO - 2025-11-12 14:31:49 --> Hooks Class Initialized
INFO - 2025-11-12 14:31:49 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:31:49 --> Utf8 Class Initialized
INFO - 2025-11-12 14:31:54 --> Config Class Initialized
INFO - 2025-11-12 14:31:54 --> Hooks Class Initialized
INFO - 2025-11-12 14:31:54 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:31:54 --> Utf8 Class Initialized
INFO - 2025-11-12 14:31:54 --> URI Class Initialized
INFO - 2025-11-12 14:31:54 --> Router Class Initialized
INFO - 2025-11-12 14:31:54 --> Output Class Initialized
INFO - 2025-11-12 14:31:54 --> Security Class Initialized
INFO - 2025-11-12 14:31:54 --> Input Class Initialized
INFO - 2025-11-12 14:31:54 --> Language Class Initialized
INFO - 2025-11-12 14:31:54 --> Loader Class Initialized
INFO - 2025-11-12 14:31:54 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:31:54 --> Helper loaded: url_helper
INFO - 2025-11-12 14:31:54 --> Helper loaded: file_helper
INFO - 2025-11-12 14:31:54 --> Helper loaded: main_helper
INFO - 2025-11-12 14:31:54 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:31:54 --> Database Driver Class Initialized
INFO - 2025-11-12 14:31:54 --> Email Class Initialized
DEBUG - 2025-11-12 14:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:31:54 --> Controller Class Initialized
INFO - 2025-11-12 14:31:54 --> Model "Subscription_model" initialized
INFO - 2025-11-12 14:31:54 --> Model "User_model" initialized
INFO - 2025-11-12 14:31:54 --> Model "Auth_model" initialized
INFO - 2025-11-12 14:31:54 --> Model "Project_model" initialized
INFO - 2025-11-12 14:31:54 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-12 14:31:54 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-12 14:31:54 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-12 14:31:54 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ai.php
INFO - 2025-11-12 14:31:54 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-12 14:31:54 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-12 14:31:54 --> Final output sent to browser
INFO - 2025-11-12 14:31:54 --> Total execution time: 0.1196
INFO - 2025-11-12 14:31:58 --> Config Class Initialized
INFO - 2025-11-12 14:31:58 --> Hooks Class Initialized
INFO - 2025-11-12 14:31:58 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:31:58 --> Utf8 Class Initialized
INFO - 2025-11-12 14:31:58 --> URI Class Initialized
INFO - 2025-11-12 14:31:58 --> Router Class Initialized
INFO - 2025-11-12 14:31:58 --> Output Class Initialized
INFO - 2025-11-12 14:31:58 --> Security Class Initialized
INFO - 2025-11-12 14:31:58 --> Input Class Initialized
INFO - 2025-11-12 14:31:58 --> Language Class Initialized
INFO - 2025-11-12 14:31:58 --> Loader Class Initialized
INFO - 2025-11-12 14:31:58 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:31:58 --> Helper loaded: url_helper
INFO - 2025-11-12 14:31:58 --> Helper loaded: file_helper
INFO - 2025-11-12 14:31:58 --> Helper loaded: main_helper
INFO - 2025-11-12 14:31:58 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:31:58 --> Database Driver Class Initialized
INFO - 2025-11-12 14:31:58 --> Email Class Initialized
DEBUG - 2025-11-12 14:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:31:58 --> Controller Class Initialized
INFO - 2025-11-12 14:31:58 --> Model "User_model" initialized
INFO - 2025-11-12 14:31:58 --> Model "Project_model" initialized
INFO - 2025-11-12 14:31:58 --> Helper loaded: form_helper
INFO - 2025-11-12 14:31:58 --> Form Validation Class Initialized
INFO - 2025-11-12 14:31:58 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:31:58 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:31:58 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:31:58 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:31:58 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:31:58 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:31:58 --> Final output sent to browser
INFO - 2025-11-12 14:31:58 --> Total execution time: 0.1059
INFO - 2025-11-12 14:31:58 --> Config Class Initialized
INFO - 2025-11-12 14:31:58 --> Hooks Class Initialized
INFO - 2025-11-12 14:31:58 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:31:58 --> Utf8 Class Initialized
INFO - 2025-11-12 14:31:58 --> URI Class Initialized
INFO - 2025-11-12 14:31:58 --> Router Class Initialized
INFO - 2025-11-12 14:31:58 --> Output Class Initialized
INFO - 2025-11-12 14:31:58 --> Security Class Initialized
INFO - 2025-11-12 14:31:58 --> Input Class Initialized
INFO - 2025-11-12 14:31:58 --> Language Class Initialized
INFO - 2025-11-12 14:31:58 --> Loader Class Initialized
INFO - 2025-11-12 14:31:58 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:31:58 --> Helper loaded: url_helper
INFO - 2025-11-12 14:31:58 --> Helper loaded: file_helper
INFO - 2025-11-12 14:31:58 --> Helper loaded: main_helper
INFO - 2025-11-12 14:31:58 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:31:58 --> Database Driver Class Initialized
INFO - 2025-11-12 14:31:58 --> Email Class Initialized
DEBUG - 2025-11-12 14:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:31:58 --> Controller Class Initialized
INFO - 2025-11-12 14:31:58 --> Model "User_model" initialized
INFO - 2025-11-12 14:31:58 --> Model "Project_model" initialized
INFO - 2025-11-12 14:31:58 --> Helper loaded: form_helper
INFO - 2025-11-12 14:31:58 --> Form Validation Class Initialized
INFO - 2025-11-12 14:31:58 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:31:58 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:31:58 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:31:58 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:31:58 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:31:58 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:31:58 --> Final output sent to browser
INFO - 2025-11-12 14:31:58 --> Total execution time: 0.0861
INFO - 2025-11-12 14:31:58 --> Config Class Initialized
INFO - 2025-11-12 14:31:58 --> Hooks Class Initialized
INFO - 2025-11-12 14:31:58 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:31:58 --> Utf8 Class Initialized
INFO - 2025-11-12 14:31:58 --> URI Class Initialized
INFO - 2025-11-12 14:31:58 --> Router Class Initialized
INFO - 2025-11-12 14:31:58 --> Output Class Initialized
INFO - 2025-11-12 14:31:58 --> Security Class Initialized
INFO - 2025-11-12 14:31:58 --> Input Class Initialized
INFO - 2025-11-12 14:31:58 --> Language Class Initialized
INFO - 2025-11-12 14:31:58 --> Loader Class Initialized
INFO - 2025-11-12 14:31:58 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:31:58 --> Helper loaded: url_helper
INFO - 2025-11-12 14:31:58 --> Helper loaded: file_helper
INFO - 2025-11-12 14:31:58 --> Helper loaded: main_helper
INFO - 2025-11-12 14:31:58 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:31:58 --> Database Driver Class Initialized
INFO - 2025-11-12 14:31:58 --> Email Class Initialized
DEBUG - 2025-11-12 14:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:31:58 --> Controller Class Initialized
INFO - 2025-11-12 14:31:58 --> Model "User_model" initialized
INFO - 2025-11-12 14:31:58 --> Model "Project_model" initialized
INFO - 2025-11-12 14:31:58 --> Helper loaded: form_helper
INFO - 2025-11-12 14:31:58 --> Form Validation Class Initialized
INFO - 2025-11-12 14:31:58 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:31:58 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:31:58 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:31:58 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:31:58 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:31:58 --> Model "Topk_service_model" initialized
ERROR - 2025-11-12 14:32:01 --> Gemini API request error: Server error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `503 Service Unavailable` response:
{
  "error": {
    "code": 503,
    "message": "The model is overloaded. Please try again later.",
    "status": "UNAVAI (truncated...)

ERROR - 2025-11-12 14:32:11 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 267,
    "totalTokenCount": 1066,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 267
      }
    ],
    "thoughtsTokenCount": 799
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "a5oUacPwGrjUjuMP_ZLMsQo"
}

INFO - 2025-11-12 14:32:11 --> Final output sent to browser
INFO - 2025-11-12 14:32:11 --> Total execution time: 13.3312
INFO - 2025-11-12 14:32:11 --> Config Class Initialized
INFO - 2025-11-12 14:32:11 --> Hooks Class Initialized
INFO - 2025-11-12 14:32:11 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:32:11 --> Utf8 Class Initialized
INFO - 2025-11-12 14:32:11 --> URI Class Initialized
INFO - 2025-11-12 14:32:11 --> Router Class Initialized
INFO - 2025-11-12 14:32:11 --> Output Class Initialized
INFO - 2025-11-12 14:32:11 --> Security Class Initialized
INFO - 2025-11-12 14:32:11 --> Input Class Initialized
INFO - 2025-11-12 14:32:11 --> Language Class Initialized
INFO - 2025-11-12 14:32:11 --> Loader Class Initialized
INFO - 2025-11-12 14:32:11 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:32:11 --> Helper loaded: url_helper
INFO - 2025-11-12 14:32:11 --> Helper loaded: file_helper
INFO - 2025-11-12 14:32:11 --> Helper loaded: main_helper
INFO - 2025-11-12 14:32:11 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:32:11 --> Database Driver Class Initialized
INFO - 2025-11-12 14:32:11 --> Email Class Initialized
DEBUG - 2025-11-12 14:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:32:11 --> Controller Class Initialized
INFO - 2025-11-12 14:32:11 --> Model "User_model" initialized
INFO - 2025-11-12 14:32:11 --> Model "Project_model" initialized
INFO - 2025-11-12 14:32:11 --> Helper loaded: form_helper
INFO - 2025-11-12 14:32:11 --> Form Validation Class Initialized
INFO - 2025-11-12 14:32:11 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:32:11 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:32:11 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:32:11 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:32:11 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:32:11 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:32:41 --> Final output sent to browser
INFO - 2025-11-12 14:32:41 --> Total execution time: 29.4567
INFO - 2025-11-12 14:35:02 --> Config Class Initialized
INFO - 2025-11-12 14:35:02 --> Hooks Class Initialized
INFO - 2025-11-12 14:35:02 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:35:02 --> Utf8 Class Initialized
INFO - 2025-11-12 14:35:02 --> URI Class Initialized
INFO - 2025-11-12 14:35:02 --> Router Class Initialized
INFO - 2025-11-12 14:35:02 --> Output Class Initialized
INFO - 2025-11-12 14:35:02 --> Security Class Initialized
INFO - 2025-11-12 14:35:02 --> Input Class Initialized
INFO - 2025-11-12 14:35:02 --> Language Class Initialized
INFO - 2025-11-12 14:35:02 --> Loader Class Initialized
INFO - 2025-11-12 14:35:02 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:35:02 --> Helper loaded: url_helper
INFO - 2025-11-12 14:35:02 --> Helper loaded: file_helper
INFO - 2025-11-12 14:35:02 --> Helper loaded: main_helper
INFO - 2025-11-12 14:35:02 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:35:02 --> Database Driver Class Initialized
INFO - 2025-11-12 14:35:02 --> Email Class Initialized
DEBUG - 2025-11-12 14:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:35:02 --> Controller Class Initialized
INFO - 2025-11-12 14:35:02 --> Model "Subscription_model" initialized
INFO - 2025-11-12 14:35:02 --> Model "User_model" initialized
INFO - 2025-11-12 14:35:02 --> Model "Auth_model" initialized
INFO - 2025-11-12 14:35:02 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-12 14:35:02 --> Final output sent to browser
INFO - 2025-11-12 14:35:02 --> Total execution time: 0.1064
INFO - 2025-11-12 14:35:03 --> Config Class Initialized
INFO - 2025-11-12 14:35:03 --> Hooks Class Initialized
INFO - 2025-11-12 14:35:03 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:35:03 --> Utf8 Class Initialized
INFO - 2025-11-12 14:35:45 --> Config Class Initialized
INFO - 2025-11-12 14:35:45 --> Hooks Class Initialized
INFO - 2025-11-12 14:35:45 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:35:45 --> Utf8 Class Initialized
INFO - 2025-11-12 14:35:45 --> URI Class Initialized
INFO - 2025-11-12 14:35:45 --> Router Class Initialized
INFO - 2025-11-12 14:35:45 --> Output Class Initialized
INFO - 2025-11-12 14:35:45 --> Security Class Initialized
INFO - 2025-11-12 14:35:45 --> Input Class Initialized
INFO - 2025-11-12 14:35:45 --> Language Class Initialized
INFO - 2025-11-12 14:35:45 --> Loader Class Initialized
INFO - 2025-11-12 14:35:45 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:35:45 --> Helper loaded: url_helper
INFO - 2025-11-12 14:35:45 --> Helper loaded: file_helper
INFO - 2025-11-12 14:35:45 --> Helper loaded: main_helper
INFO - 2025-11-12 14:35:45 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:35:45 --> Database Driver Class Initialized
INFO - 2025-11-12 14:35:45 --> Email Class Initialized
DEBUG - 2025-11-12 14:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:35:45 --> Controller Class Initialized
INFO - 2025-11-12 14:35:45 --> Model "Subscription_model" initialized
INFO - 2025-11-12 14:35:45 --> Model "User_model" initialized
INFO - 2025-11-12 14:35:45 --> Model "Auth_model" initialized
INFO - 2025-11-12 14:35:45 --> Model "Project_model" initialized
INFO - 2025-11-12 14:35:45 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-12 14:35:45 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-12 14:35:45 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-12 14:35:45 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ai.php
INFO - 2025-11-12 14:35:45 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-12 14:35:45 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-12 14:35:45 --> Final output sent to browser
INFO - 2025-11-12 14:35:45 --> Total execution time: 0.1115
INFO - 2025-11-12 14:35:56 --> Config Class Initialized
INFO - 2025-11-12 14:35:56 --> Hooks Class Initialized
INFO - 2025-11-12 14:35:56 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:35:56 --> Utf8 Class Initialized
INFO - 2025-11-12 14:35:56 --> URI Class Initialized
INFO - 2025-11-12 14:35:56 --> Router Class Initialized
INFO - 2025-11-12 14:35:56 --> Output Class Initialized
INFO - 2025-11-12 14:35:56 --> Security Class Initialized
INFO - 2025-11-12 14:35:56 --> Input Class Initialized
INFO - 2025-11-12 14:35:56 --> Language Class Initialized
INFO - 2025-11-12 14:35:56 --> Loader Class Initialized
INFO - 2025-11-12 14:35:56 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:35:56 --> Helper loaded: url_helper
INFO - 2025-11-12 14:35:56 --> Helper loaded: file_helper
INFO - 2025-11-12 14:35:56 --> Helper loaded: main_helper
INFO - 2025-11-12 14:35:56 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:35:56 --> Database Driver Class Initialized
INFO - 2025-11-12 14:35:56 --> Email Class Initialized
DEBUG - 2025-11-12 14:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:35:56 --> Controller Class Initialized
INFO - 2025-11-12 14:35:56 --> Model "User_model" initialized
INFO - 2025-11-12 14:35:56 --> Model "Project_model" initialized
INFO - 2025-11-12 14:35:56 --> Helper loaded: form_helper
INFO - 2025-11-12 14:35:56 --> Form Validation Class Initialized
INFO - 2025-11-12 14:35:56 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:35:56 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:35:56 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:35:56 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:35:56 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:35:56 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:35:56 --> Final output sent to browser
INFO - 2025-11-12 14:35:56 --> Total execution time: 0.1131
INFO - 2025-11-12 14:35:56 --> Config Class Initialized
INFO - 2025-11-12 14:35:56 --> Hooks Class Initialized
INFO - 2025-11-12 14:35:56 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:35:56 --> Utf8 Class Initialized
INFO - 2025-11-12 14:35:56 --> URI Class Initialized
INFO - 2025-11-12 14:35:56 --> Router Class Initialized
INFO - 2025-11-12 14:35:56 --> Output Class Initialized
INFO - 2025-11-12 14:35:56 --> Security Class Initialized
INFO - 2025-11-12 14:35:56 --> Input Class Initialized
INFO - 2025-11-12 14:35:56 --> Language Class Initialized
INFO - 2025-11-12 14:35:56 --> Loader Class Initialized
INFO - 2025-11-12 14:35:56 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:35:56 --> Helper loaded: url_helper
INFO - 2025-11-12 14:35:56 --> Helper loaded: file_helper
INFO - 2025-11-12 14:35:56 --> Helper loaded: main_helper
INFO - 2025-11-12 14:35:56 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:35:56 --> Database Driver Class Initialized
INFO - 2025-11-12 14:35:56 --> Email Class Initialized
DEBUG - 2025-11-12 14:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:35:56 --> Controller Class Initialized
INFO - 2025-11-12 14:35:56 --> Model "User_model" initialized
INFO - 2025-11-12 14:35:56 --> Model "Project_model" initialized
INFO - 2025-11-12 14:35:56 --> Helper loaded: form_helper
INFO - 2025-11-12 14:35:56 --> Form Validation Class Initialized
INFO - 2025-11-12 14:35:56 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:35:56 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:35:56 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:35:56 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:35:56 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:35:56 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:35:56 --> Final output sent to browser
INFO - 2025-11-12 14:35:56 --> Total execution time: 0.0716
INFO - 2025-11-12 14:35:56 --> Config Class Initialized
INFO - 2025-11-12 14:35:56 --> Hooks Class Initialized
INFO - 2025-11-12 14:35:56 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:35:56 --> Utf8 Class Initialized
INFO - 2025-11-12 14:35:56 --> URI Class Initialized
INFO - 2025-11-12 14:35:56 --> Router Class Initialized
INFO - 2025-11-12 14:35:56 --> Output Class Initialized
INFO - 2025-11-12 14:35:56 --> Security Class Initialized
INFO - 2025-11-12 14:35:56 --> Input Class Initialized
INFO - 2025-11-12 14:35:56 --> Language Class Initialized
INFO - 2025-11-12 14:35:56 --> Loader Class Initialized
INFO - 2025-11-12 14:35:56 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:35:56 --> Helper loaded: url_helper
INFO - 2025-11-12 14:35:56 --> Helper loaded: file_helper
INFO - 2025-11-12 14:35:56 --> Helper loaded: main_helper
INFO - 2025-11-12 14:35:56 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:35:56 --> Database Driver Class Initialized
INFO - 2025-11-12 14:35:56 --> Email Class Initialized
DEBUG - 2025-11-12 14:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:35:56 --> Controller Class Initialized
INFO - 2025-11-12 14:35:56 --> Model "User_model" initialized
INFO - 2025-11-12 14:35:56 --> Model "Project_model" initialized
INFO - 2025-11-12 14:35:56 --> Helper loaded: form_helper
INFO - 2025-11-12 14:35:56 --> Form Validation Class Initialized
INFO - 2025-11-12 14:35:56 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:35:56 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:35:56 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:35:56 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:35:56 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:35:56 --> Model "Topk_service_model" initialized
ERROR - 2025-11-12 14:35:59 --> Gemini API request error: Server error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `503 Service Unavailable` response:
{
  "error": {
    "code": 503,
    "message": "The model is overloaded. Please try again later.",
    "status": "UNAVAI (truncated...)

ERROR - 2025-11-12 14:36:04 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 267,
    "totalTokenCount": 1066,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 267
      }
    ],
    "thoughtsTokenCount": 799
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "VJsUacWlCqjSqfkP5-3ZiQ4"
}

INFO - 2025-11-12 14:36:04 --> Final output sent to browser
INFO - 2025-11-12 14:36:04 --> Total execution time: 7.8685
INFO - 2025-11-12 14:36:04 --> Config Class Initialized
INFO - 2025-11-12 14:36:04 --> Hooks Class Initialized
INFO - 2025-11-12 14:36:04 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:36:04 --> Utf8 Class Initialized
INFO - 2025-11-12 14:36:04 --> URI Class Initialized
INFO - 2025-11-12 14:36:04 --> Router Class Initialized
INFO - 2025-11-12 14:36:04 --> Output Class Initialized
INFO - 2025-11-12 14:36:04 --> Security Class Initialized
INFO - 2025-11-12 14:36:04 --> Input Class Initialized
INFO - 2025-11-12 14:36:04 --> Language Class Initialized
INFO - 2025-11-12 14:36:04 --> Loader Class Initialized
INFO - 2025-11-12 14:36:04 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:36:04 --> Helper loaded: url_helper
INFO - 2025-11-12 14:36:04 --> Helper loaded: file_helper
INFO - 2025-11-12 14:36:04 --> Helper loaded: main_helper
INFO - 2025-11-12 14:36:04 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:36:04 --> Database Driver Class Initialized
INFO - 2025-11-12 14:36:04 --> Email Class Initialized
DEBUG - 2025-11-12 14:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:36:04 --> Controller Class Initialized
INFO - 2025-11-12 14:36:04 --> Model "User_model" initialized
INFO - 2025-11-12 14:36:04 --> Model "Project_model" initialized
INFO - 2025-11-12 14:36:04 --> Helper loaded: form_helper
INFO - 2025-11-12 14:36:04 --> Form Validation Class Initialized
INFO - 2025-11-12 14:36:04 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:36:04 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:36:04 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:36:04 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:36:04 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:36:04 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:36:15 --> Final output sent to browser
INFO - 2025-11-12 14:36:15 --> Total execution time: 10.6068
INFO - 2025-11-12 14:36:27 --> Config Class Initialized
INFO - 2025-11-12 14:36:27 --> Hooks Class Initialized
INFO - 2025-11-12 14:36:27 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:36:27 --> Utf8 Class Initialized
INFO - 2025-11-12 14:36:27 --> URI Class Initialized
INFO - 2025-11-12 14:36:27 --> Router Class Initialized
INFO - 2025-11-12 14:36:27 --> Output Class Initialized
INFO - 2025-11-12 14:36:27 --> Security Class Initialized
INFO - 2025-11-12 14:36:27 --> Input Class Initialized
INFO - 2025-11-12 14:36:27 --> Language Class Initialized
INFO - 2025-11-12 14:36:27 --> Loader Class Initialized
INFO - 2025-11-12 14:36:27 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:36:27 --> Helper loaded: url_helper
INFO - 2025-11-12 14:36:27 --> Helper loaded: file_helper
INFO - 2025-11-12 14:36:27 --> Helper loaded: main_helper
INFO - 2025-11-12 14:36:27 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:36:27 --> Database Driver Class Initialized
INFO - 2025-11-12 14:36:27 --> Email Class Initialized
DEBUG - 2025-11-12 14:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:36:27 --> Controller Class Initialized
INFO - 2025-11-12 14:36:27 --> Model "User_model" initialized
INFO - 2025-11-12 14:36:27 --> Model "Project_model" initialized
INFO - 2025-11-12 14:36:27 --> Helper loaded: form_helper
INFO - 2025-11-12 14:36:27 --> Form Validation Class Initialized
INFO - 2025-11-12 14:36:27 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:36:27 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:36:27 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:36:27 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:36:27 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:36:27 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:36:27 --> Final output sent to browser
INFO - 2025-11-12 14:36:27 --> Total execution time: 0.1016
INFO - 2025-11-12 14:36:27 --> Config Class Initialized
INFO - 2025-11-12 14:36:27 --> Hooks Class Initialized
INFO - 2025-11-12 14:36:27 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:36:27 --> Utf8 Class Initialized
INFO - 2025-11-12 14:36:27 --> URI Class Initialized
INFO - 2025-11-12 14:36:27 --> Router Class Initialized
INFO - 2025-11-12 14:36:27 --> Output Class Initialized
INFO - 2025-11-12 14:36:27 --> Security Class Initialized
INFO - 2025-11-12 14:36:27 --> Input Class Initialized
INFO - 2025-11-12 14:36:27 --> Language Class Initialized
INFO - 2025-11-12 14:36:27 --> Loader Class Initialized
INFO - 2025-11-12 14:36:27 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:36:27 --> Helper loaded: url_helper
INFO - 2025-11-12 14:36:27 --> Helper loaded: file_helper
INFO - 2025-11-12 14:36:27 --> Helper loaded: main_helper
INFO - 2025-11-12 14:36:27 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:36:27 --> Database Driver Class Initialized
INFO - 2025-11-12 14:36:27 --> Email Class Initialized
DEBUG - 2025-11-12 14:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:36:27 --> Controller Class Initialized
INFO - 2025-11-12 14:36:27 --> Model "User_model" initialized
INFO - 2025-11-12 14:36:27 --> Model "Project_model" initialized
INFO - 2025-11-12 14:36:27 --> Helper loaded: form_helper
INFO - 2025-11-12 14:36:27 --> Form Validation Class Initialized
INFO - 2025-11-12 14:36:27 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:36:27 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:36:27 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:36:27 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:36:27 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:36:27 --> Model "Topk_service_model" initialized
ERROR - 2025-11-12 14:36:33 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 324,
    "totalTokenCount": 1123,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 324
      }
    ],
    "thoughtsTokenCount": 799
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "cZsUaZX-D6aKqfkP67jZ8AQ"
}

ERROR - 2025-11-12 14:36:34 --> Gemini API request error: Server error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `503 Service Unavailable` response:
{
  "error": {
    "code": 503,
    "message": "The model is overloaded. Please try again later.",
    "status": "UNAVAI (truncated...)

INFO - 2025-11-12 14:36:34 --> Final output sent to browser
INFO - 2025-11-12 14:36:34 --> Total execution time: 7.2888
INFO - 2025-11-12 14:36:34 --> Config Class Initialized
INFO - 2025-11-12 14:36:34 --> Hooks Class Initialized
INFO - 2025-11-12 14:36:34 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:36:34 --> Utf8 Class Initialized
INFO - 2025-11-12 14:36:34 --> URI Class Initialized
INFO - 2025-11-12 14:36:34 --> Router Class Initialized
INFO - 2025-11-12 14:36:34 --> Output Class Initialized
INFO - 2025-11-12 14:36:34 --> Security Class Initialized
INFO - 2025-11-12 14:36:34 --> Input Class Initialized
INFO - 2025-11-12 14:36:34 --> Language Class Initialized
INFO - 2025-11-12 14:36:34 --> Loader Class Initialized
INFO - 2025-11-12 14:36:34 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:36:34 --> Helper loaded: url_helper
INFO - 2025-11-12 14:36:34 --> Helper loaded: file_helper
INFO - 2025-11-12 14:36:34 --> Helper loaded: main_helper
INFO - 2025-11-12 14:36:34 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:36:34 --> Database Driver Class Initialized
INFO - 2025-11-12 14:36:34 --> Email Class Initialized
DEBUG - 2025-11-12 14:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:36:34 --> Controller Class Initialized
INFO - 2025-11-12 14:36:34 --> Model "User_model" initialized
INFO - 2025-11-12 14:36:34 --> Model "Project_model" initialized
INFO - 2025-11-12 14:36:34 --> Helper loaded: form_helper
INFO - 2025-11-12 14:36:34 --> Form Validation Class Initialized
INFO - 2025-11-12 14:36:34 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:36:34 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:36:34 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:36:34 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:36:34 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:36:34 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:36:41 --> Final output sent to browser
INFO - 2025-11-12 14:36:41 --> Total execution time: 6.4923
INFO - 2025-11-12 14:37:44 --> Config Class Initialized
INFO - 2025-11-12 14:37:44 --> Hooks Class Initialized
INFO - 2025-11-12 14:37:44 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:37:44 --> Utf8 Class Initialized
INFO - 2025-11-12 14:37:44 --> URI Class Initialized
INFO - 2025-11-12 14:37:44 --> Router Class Initialized
INFO - 2025-11-12 14:37:44 --> Output Class Initialized
INFO - 2025-11-12 14:37:44 --> Security Class Initialized
INFO - 2025-11-12 14:37:44 --> Input Class Initialized
INFO - 2025-11-12 14:37:44 --> Language Class Initialized
INFO - 2025-11-12 14:37:44 --> Loader Class Initialized
INFO - 2025-11-12 14:37:44 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:37:44 --> Helper loaded: url_helper
INFO - 2025-11-12 14:37:44 --> Helper loaded: file_helper
INFO - 2025-11-12 14:37:44 --> Helper loaded: main_helper
INFO - 2025-11-12 14:37:44 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:37:44 --> Database Driver Class Initialized
INFO - 2025-11-12 14:37:44 --> Email Class Initialized
DEBUG - 2025-11-12 14:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:37:44 --> Controller Class Initialized
INFO - 2025-11-12 14:37:44 --> Model "User_model" initialized
INFO - 2025-11-12 14:37:44 --> Model "Project_model" initialized
INFO - 2025-11-12 14:37:44 --> Helper loaded: form_helper
INFO - 2025-11-12 14:37:44 --> Form Validation Class Initialized
INFO - 2025-11-12 14:37:44 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:37:44 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:37:44 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:37:44 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:37:44 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:37:44 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:37:44 --> Final output sent to browser
INFO - 2025-11-12 14:37:44 --> Total execution time: 0.0988
INFO - 2025-11-12 14:37:44 --> Config Class Initialized
INFO - 2025-11-12 14:37:44 --> Hooks Class Initialized
INFO - 2025-11-12 14:37:44 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:37:44 --> Utf8 Class Initialized
INFO - 2025-11-12 14:37:44 --> URI Class Initialized
INFO - 2025-11-12 14:37:44 --> Router Class Initialized
INFO - 2025-11-12 14:37:44 --> Output Class Initialized
INFO - 2025-11-12 14:37:44 --> Security Class Initialized
INFO - 2025-11-12 14:37:44 --> Input Class Initialized
INFO - 2025-11-12 14:37:44 --> Language Class Initialized
INFO - 2025-11-12 14:37:44 --> Loader Class Initialized
INFO - 2025-11-12 14:37:44 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:37:44 --> Helper loaded: url_helper
INFO - 2025-11-12 14:37:44 --> Helper loaded: file_helper
INFO - 2025-11-12 14:37:44 --> Helper loaded: main_helper
INFO - 2025-11-12 14:37:44 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:37:44 --> Database Driver Class Initialized
INFO - 2025-11-12 14:37:44 --> Email Class Initialized
DEBUG - 2025-11-12 14:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:37:44 --> Controller Class Initialized
INFO - 2025-11-12 14:37:44 --> Model "User_model" initialized
INFO - 2025-11-12 14:37:44 --> Model "Project_model" initialized
INFO - 2025-11-12 14:37:44 --> Helper loaded: form_helper
INFO - 2025-11-12 14:37:44 --> Form Validation Class Initialized
INFO - 2025-11-12 14:37:44 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:37:44 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:37:44 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:37:44 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:37:44 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:37:44 --> Model "Topk_service_model" initialized
ERROR - 2025-11-12 14:37:46 --> Gemini API request error: Server error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `503 Service Unavailable` response:
{
  "error": {
    "code": 503,
    "message": "The model is overloaded. Please try again later.",
    "status": "UNAVAI (truncated...)

ERROR - 2025-11-12 14:37:51 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 311,
    "totalTokenCount": 1110,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 311
      }
    ],
    "thoughtsTokenCount": 799
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "v5sUaa-FHIjKqfkPzLTl8Qk"
}

INFO - 2025-11-12 14:37:51 --> Final output sent to browser
INFO - 2025-11-12 14:37:51 --> Total execution time: 7.4338
INFO - 2025-11-12 14:37:51 --> Config Class Initialized
INFO - 2025-11-12 14:37:51 --> Hooks Class Initialized
INFO - 2025-11-12 14:37:51 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:37:51 --> Utf8 Class Initialized
INFO - 2025-11-12 14:37:51 --> URI Class Initialized
INFO - 2025-11-12 14:37:51 --> Router Class Initialized
INFO - 2025-11-12 14:37:51 --> Output Class Initialized
INFO - 2025-11-12 14:37:51 --> Security Class Initialized
INFO - 2025-11-12 14:37:51 --> Input Class Initialized
INFO - 2025-11-12 14:37:51 --> Language Class Initialized
INFO - 2025-11-12 14:37:51 --> Loader Class Initialized
INFO - 2025-11-12 14:37:51 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:37:51 --> Helper loaded: url_helper
INFO - 2025-11-12 14:37:51 --> Helper loaded: file_helper
INFO - 2025-11-12 14:37:51 --> Helper loaded: main_helper
INFO - 2025-11-12 14:37:51 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:37:51 --> Database Driver Class Initialized
INFO - 2025-11-12 14:37:51 --> Email Class Initialized
DEBUG - 2025-11-12 14:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:37:51 --> Controller Class Initialized
INFO - 2025-11-12 14:37:51 --> Model "User_model" initialized
INFO - 2025-11-12 14:37:51 --> Model "Project_model" initialized
INFO - 2025-11-12 14:37:51 --> Helper loaded: form_helper
INFO - 2025-11-12 14:37:51 --> Form Validation Class Initialized
INFO - 2025-11-12 14:37:51 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:37:51 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:37:51 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:37:51 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:37:51 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:37:51 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:37:59 --> Final output sent to browser
INFO - 2025-11-12 14:37:59 --> Total execution time: 7.8815
INFO - 2025-11-12 14:38:32 --> Config Class Initialized
INFO - 2025-11-12 14:38:32 --> Hooks Class Initialized
INFO - 2025-11-12 14:38:32 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:38:32 --> Utf8 Class Initialized
INFO - 2025-11-12 14:38:32 --> URI Class Initialized
INFO - 2025-11-12 14:38:32 --> Router Class Initialized
INFO - 2025-11-12 14:38:32 --> Output Class Initialized
INFO - 2025-11-12 14:38:32 --> Security Class Initialized
INFO - 2025-11-12 14:38:32 --> Input Class Initialized
INFO - 2025-11-12 14:38:32 --> Language Class Initialized
INFO - 2025-11-12 14:38:32 --> Loader Class Initialized
INFO - 2025-11-12 14:38:32 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:38:32 --> Helper loaded: url_helper
INFO - 2025-11-12 14:38:32 --> Helper loaded: file_helper
INFO - 2025-11-12 14:38:32 --> Helper loaded: main_helper
INFO - 2025-11-12 14:38:32 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:38:32 --> Database Driver Class Initialized
INFO - 2025-11-12 14:38:32 --> Email Class Initialized
DEBUG - 2025-11-12 14:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:38:32 --> Controller Class Initialized
INFO - 2025-11-12 14:38:32 --> Model "User_model" initialized
INFO - 2025-11-12 14:38:32 --> Model "Project_model" initialized
INFO - 2025-11-12 14:38:32 --> Helper loaded: form_helper
INFO - 2025-11-12 14:38:32 --> Form Validation Class Initialized
INFO - 2025-11-12 14:38:32 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:38:32 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:38:32 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:38:32 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:38:32 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:38:32 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:38:32 --> Final output sent to browser
INFO - 2025-11-12 14:38:32 --> Total execution time: 0.1302
INFO - 2025-11-12 14:38:32 --> Config Class Initialized
INFO - 2025-11-12 14:38:32 --> Hooks Class Initialized
INFO - 2025-11-12 14:38:32 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:38:32 --> Utf8 Class Initialized
INFO - 2025-11-12 14:38:32 --> URI Class Initialized
INFO - 2025-11-12 14:38:32 --> Router Class Initialized
INFO - 2025-11-12 14:38:32 --> Output Class Initialized
INFO - 2025-11-12 14:38:32 --> Security Class Initialized
INFO - 2025-11-12 14:38:32 --> Input Class Initialized
INFO - 2025-11-12 14:38:32 --> Language Class Initialized
INFO - 2025-11-12 14:38:32 --> Loader Class Initialized
INFO - 2025-11-12 14:38:32 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:38:32 --> Helper loaded: url_helper
INFO - 2025-11-12 14:38:32 --> Helper loaded: file_helper
INFO - 2025-11-12 14:38:32 --> Helper loaded: main_helper
INFO - 2025-11-12 14:38:32 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:38:32 --> Database Driver Class Initialized
INFO - 2025-11-12 14:38:32 --> Email Class Initialized
DEBUG - 2025-11-12 14:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:38:32 --> Controller Class Initialized
INFO - 2025-11-12 14:38:32 --> Model "User_model" initialized
INFO - 2025-11-12 14:38:32 --> Model "Project_model" initialized
INFO - 2025-11-12 14:38:32 --> Helper loaded: form_helper
INFO - 2025-11-12 14:38:32 --> Form Validation Class Initialized
INFO - 2025-11-12 14:38:32 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:38:32 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:38:32 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:38:32 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:38:32 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:38:32 --> Model "Topk_service_model" initialized
ERROR - 2025-11-12 14:38:38 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 383,
    "totalTokenCount": 1182,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 383
      }
    ],
    "thoughtsTokenCount": 799
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "7psUaavsAv-KqfkP2Nfu6AQ"
}

ERROR - 2025-11-12 14:38:40 --> Gemini API request error: Server error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `503 Service Unavailable` response:
{
  "error": {
    "code": 503,
    "message": "The model is overloaded. Please try again later.",
    "status": "UNAVAI (truncated...)

INFO - 2025-11-12 14:38:40 --> Final output sent to browser
INFO - 2025-11-12 14:38:40 --> Total execution time: 8.2033
INFO - 2025-11-12 14:38:40 --> Config Class Initialized
INFO - 2025-11-12 14:38:40 --> Hooks Class Initialized
INFO - 2025-11-12 14:38:40 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:38:40 --> Utf8 Class Initialized
INFO - 2025-11-12 14:38:40 --> URI Class Initialized
INFO - 2025-11-12 14:38:40 --> Router Class Initialized
INFO - 2025-11-12 14:38:40 --> Output Class Initialized
INFO - 2025-11-12 14:38:40 --> Security Class Initialized
INFO - 2025-11-12 14:38:40 --> Input Class Initialized
INFO - 2025-11-12 14:38:40 --> Language Class Initialized
INFO - 2025-11-12 14:38:40 --> Loader Class Initialized
INFO - 2025-11-12 14:38:40 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:38:40 --> Helper loaded: url_helper
INFO - 2025-11-12 14:38:40 --> Helper loaded: file_helper
INFO - 2025-11-12 14:38:40 --> Helper loaded: main_helper
INFO - 2025-11-12 14:38:40 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:38:40 --> Database Driver Class Initialized
INFO - 2025-11-12 14:38:40 --> Email Class Initialized
DEBUG - 2025-11-12 14:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:38:40 --> Controller Class Initialized
INFO - 2025-11-12 14:38:40 --> Model "User_model" initialized
INFO - 2025-11-12 14:38:40 --> Model "Project_model" initialized
INFO - 2025-11-12 14:38:40 --> Helper loaded: form_helper
INFO - 2025-11-12 14:38:40 --> Form Validation Class Initialized
INFO - 2025-11-12 14:38:40 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:38:40 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:38:40 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:38:40 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:38:40 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:38:40 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:38:48 --> Final output sent to browser
INFO - 2025-11-12 14:38:48 --> Total execution time: 7.9509
INFO - 2025-11-12 14:40:33 --> Config Class Initialized
INFO - 2025-11-12 14:40:33 --> Hooks Class Initialized
INFO - 2025-11-12 14:40:33 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:40:33 --> Utf8 Class Initialized
INFO - 2025-11-12 14:40:33 --> URI Class Initialized
INFO - 2025-11-12 14:40:33 --> Router Class Initialized
INFO - 2025-11-12 14:40:33 --> Output Class Initialized
INFO - 2025-11-12 14:40:33 --> Security Class Initialized
INFO - 2025-11-12 14:40:33 --> Input Class Initialized
INFO - 2025-11-12 14:40:33 --> Language Class Initialized
INFO - 2025-11-12 14:40:33 --> Loader Class Initialized
INFO - 2025-11-12 14:40:33 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:40:33 --> Helper loaded: url_helper
INFO - 2025-11-12 14:40:33 --> Helper loaded: file_helper
INFO - 2025-11-12 14:40:33 --> Helper loaded: main_helper
INFO - 2025-11-12 14:40:33 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:40:33 --> Database Driver Class Initialized
INFO - 2025-11-12 14:40:33 --> Email Class Initialized
DEBUG - 2025-11-12 14:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:40:33 --> Controller Class Initialized
INFO - 2025-11-12 14:40:33 --> Model "User_model" initialized
INFO - 2025-11-12 14:40:33 --> Model "Project_model" initialized
INFO - 2025-11-12 14:40:33 --> Helper loaded: form_helper
INFO - 2025-11-12 14:40:33 --> Form Validation Class Initialized
INFO - 2025-11-12 14:40:33 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:40:33 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:40:33 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:40:33 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:40:33 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:40:33 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:40:33 --> Final output sent to browser
INFO - 2025-11-12 14:40:33 --> Total execution time: 0.1113
INFO - 2025-11-12 14:40:33 --> Config Class Initialized
INFO - 2025-11-12 14:40:33 --> Hooks Class Initialized
INFO - 2025-11-12 14:40:33 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:40:33 --> Utf8 Class Initialized
INFO - 2025-11-12 14:40:33 --> URI Class Initialized
INFO - 2025-11-12 14:40:33 --> Router Class Initialized
INFO - 2025-11-12 14:40:33 --> Output Class Initialized
INFO - 2025-11-12 14:40:33 --> Security Class Initialized
INFO - 2025-11-12 14:40:33 --> Input Class Initialized
INFO - 2025-11-12 14:40:33 --> Language Class Initialized
INFO - 2025-11-12 14:40:33 --> Loader Class Initialized
INFO - 2025-11-12 14:40:33 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:40:33 --> Helper loaded: url_helper
INFO - 2025-11-12 14:40:33 --> Helper loaded: file_helper
INFO - 2025-11-12 14:40:33 --> Helper loaded: main_helper
INFO - 2025-11-12 14:40:33 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:40:33 --> Database Driver Class Initialized
INFO - 2025-11-12 14:40:33 --> Email Class Initialized
DEBUG - 2025-11-12 14:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:40:33 --> Controller Class Initialized
INFO - 2025-11-12 14:40:33 --> Model "User_model" initialized
INFO - 2025-11-12 14:40:33 --> Model "Project_model" initialized
INFO - 2025-11-12 14:40:33 --> Helper loaded: form_helper
INFO - 2025-11-12 14:40:33 --> Form Validation Class Initialized
INFO - 2025-11-12 14:40:33 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:40:33 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:40:33 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:40:33 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:40:33 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:40:33 --> Model "Topk_service_model" initialized
ERROR - 2025-11-12 14:40:45 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 383,
    "totalTokenCount": 1182,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 383
      }
    ],
    "thoughtsTokenCount": 799
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "bZwUacs5pqaO4w_vp6-ABQ"
}

ERROR - 2025-11-12 14:40:49 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 400,
    "totalTokenCount": 959,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 400
      }
    ],
    "thoughtsTokenCount": 559
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "cZwUad6cIK-p4-EPqdn-gAU"
}

INFO - 2025-11-12 14:40:49 --> Final output sent to browser
INFO - 2025-11-12 14:40:49 --> Total execution time: 16.6239
INFO - 2025-11-12 14:40:49 --> Config Class Initialized
INFO - 2025-11-12 14:40:49 --> Hooks Class Initialized
INFO - 2025-11-12 14:40:49 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:40:49 --> Utf8 Class Initialized
INFO - 2025-11-12 14:40:49 --> URI Class Initialized
INFO - 2025-11-12 14:40:49 --> Router Class Initialized
INFO - 2025-11-12 14:40:49 --> Output Class Initialized
INFO - 2025-11-12 14:40:49 --> Security Class Initialized
INFO - 2025-11-12 14:40:49 --> Input Class Initialized
INFO - 2025-11-12 14:40:49 --> Language Class Initialized
INFO - 2025-11-12 14:40:49 --> Loader Class Initialized
INFO - 2025-11-12 14:40:49 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:40:49 --> Helper loaded: url_helper
INFO - 2025-11-12 14:40:49 --> Helper loaded: file_helper
INFO - 2025-11-12 14:40:49 --> Helper loaded: main_helper
INFO - 2025-11-12 14:40:49 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:40:49 --> Database Driver Class Initialized
INFO - 2025-11-12 14:40:49 --> Email Class Initialized
DEBUG - 2025-11-12 14:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:40:49 --> Controller Class Initialized
INFO - 2025-11-12 14:40:49 --> Model "User_model" initialized
INFO - 2025-11-12 14:40:49 --> Model "Project_model" initialized
INFO - 2025-11-12 14:40:49 --> Helper loaded: form_helper
INFO - 2025-11-12 14:40:49 --> Form Validation Class Initialized
INFO - 2025-11-12 14:40:49 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:40:49 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:40:49 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:40:49 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:40:49 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:40:49 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:40:57 --> Final output sent to browser
INFO - 2025-11-12 14:40:57 --> Total execution time: 7.9514
INFO - 2025-11-12 14:49:39 --> Config Class Initialized
INFO - 2025-11-12 14:49:39 --> Hooks Class Initialized
INFO - 2025-11-12 14:49:39 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:49:39 --> Utf8 Class Initialized
INFO - 2025-11-12 14:50:15 --> Config Class Initialized
INFO - 2025-11-12 14:50:15 --> Hooks Class Initialized
INFO - 2025-11-12 14:50:15 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:50:15 --> Utf8 Class Initialized
INFO - 2025-11-12 14:50:15 --> URI Class Initialized
INFO - 2025-11-12 14:50:15 --> Router Class Initialized
INFO - 2025-11-12 14:50:15 --> Output Class Initialized
INFO - 2025-11-12 14:50:15 --> Security Class Initialized
INFO - 2025-11-12 14:50:15 --> Input Class Initialized
INFO - 2025-11-12 14:50:15 --> Language Class Initialized
INFO - 2025-11-12 14:50:15 --> Loader Class Initialized
INFO - 2025-11-12 14:50:15 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:50:15 --> Helper loaded: url_helper
INFO - 2025-11-12 14:50:15 --> Helper loaded: file_helper
INFO - 2025-11-12 14:50:15 --> Helper loaded: main_helper
INFO - 2025-11-12 14:50:15 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:50:15 --> Database Driver Class Initialized
INFO - 2025-11-12 14:50:15 --> Email Class Initialized
DEBUG - 2025-11-12 14:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:50:15 --> Controller Class Initialized
INFO - 2025-11-12 14:50:15 --> Model "Subscription_model" initialized
INFO - 2025-11-12 14:50:15 --> Model "User_model" initialized
INFO - 2025-11-12 14:50:15 --> Model "Auth_model" initialized
INFO - 2025-11-12 14:50:15 --> Model "Project_model" initialized
INFO - 2025-11-12 14:50:15 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-12 14:50:15 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-12 14:50:15 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-12 14:50:16 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ai.php
INFO - 2025-11-12 14:50:16 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-12 14:50:16 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-12 14:50:16 --> Final output sent to browser
INFO - 2025-11-12 14:50:16 --> Total execution time: 0.1048
INFO - 2025-11-12 14:50:24 --> Config Class Initialized
INFO - 2025-11-12 14:50:24 --> Hooks Class Initialized
INFO - 2025-11-12 14:50:24 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:50:24 --> Utf8 Class Initialized
INFO - 2025-11-12 14:50:24 --> URI Class Initialized
INFO - 2025-11-12 14:50:24 --> Router Class Initialized
INFO - 2025-11-12 14:50:24 --> Output Class Initialized
INFO - 2025-11-12 14:50:24 --> Security Class Initialized
INFO - 2025-11-12 14:50:24 --> Input Class Initialized
INFO - 2025-11-12 14:50:24 --> Language Class Initialized
INFO - 2025-11-12 14:50:24 --> Loader Class Initialized
INFO - 2025-11-12 14:50:24 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:50:24 --> Helper loaded: url_helper
INFO - 2025-11-12 14:50:24 --> Helper loaded: file_helper
INFO - 2025-11-12 14:50:24 --> Helper loaded: main_helper
INFO - 2025-11-12 14:50:24 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:50:24 --> Database Driver Class Initialized
INFO - 2025-11-12 14:50:24 --> Email Class Initialized
DEBUG - 2025-11-12 14:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:50:24 --> Controller Class Initialized
INFO - 2025-11-12 14:50:24 --> Model "User_model" initialized
INFO - 2025-11-12 14:50:24 --> Model "Project_model" initialized
INFO - 2025-11-12 14:50:24 --> Helper loaded: form_helper
INFO - 2025-11-12 14:50:24 --> Form Validation Class Initialized
INFO - 2025-11-12 14:50:24 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:50:24 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:50:24 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:50:24 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:50:24 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:50:24 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:50:24 --> Final output sent to browser
INFO - 2025-11-12 14:50:24 --> Total execution time: 0.0810
INFO - 2025-11-12 14:50:24 --> Config Class Initialized
INFO - 2025-11-12 14:50:24 --> Hooks Class Initialized
INFO - 2025-11-12 14:50:24 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:50:24 --> Utf8 Class Initialized
INFO - 2025-11-12 14:50:24 --> URI Class Initialized
INFO - 2025-11-12 14:50:24 --> Router Class Initialized
INFO - 2025-11-12 14:50:24 --> Output Class Initialized
INFO - 2025-11-12 14:50:24 --> Security Class Initialized
INFO - 2025-11-12 14:50:24 --> Input Class Initialized
INFO - 2025-11-12 14:50:24 --> Language Class Initialized
INFO - 2025-11-12 14:50:24 --> Loader Class Initialized
INFO - 2025-11-12 14:50:24 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:50:24 --> Helper loaded: url_helper
INFO - 2025-11-12 14:50:24 --> Helper loaded: file_helper
INFO - 2025-11-12 14:50:24 --> Helper loaded: main_helper
INFO - 2025-11-12 14:50:24 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:50:24 --> Database Driver Class Initialized
INFO - 2025-11-12 14:50:24 --> Email Class Initialized
DEBUG - 2025-11-12 14:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:50:24 --> Controller Class Initialized
INFO - 2025-11-12 14:50:24 --> Model "User_model" initialized
INFO - 2025-11-12 14:50:24 --> Model "Project_model" initialized
INFO - 2025-11-12 14:50:24 --> Helper loaded: form_helper
INFO - 2025-11-12 14:50:24 --> Form Validation Class Initialized
INFO - 2025-11-12 14:50:25 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:50:25 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:50:25 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:50:25 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:50:25 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:50:25 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:50:25 --> Final output sent to browser
INFO - 2025-11-12 14:50:25 --> Total execution time: 0.0665
INFO - 2025-11-12 14:50:25 --> Config Class Initialized
INFO - 2025-11-12 14:50:25 --> Hooks Class Initialized
INFO - 2025-11-12 14:50:25 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:50:25 --> Utf8 Class Initialized
INFO - 2025-11-12 14:50:25 --> URI Class Initialized
INFO - 2025-11-12 14:50:25 --> Router Class Initialized
INFO - 2025-11-12 14:50:25 --> Output Class Initialized
INFO - 2025-11-12 14:50:25 --> Security Class Initialized
INFO - 2025-11-12 14:50:25 --> Input Class Initialized
INFO - 2025-11-12 14:50:25 --> Language Class Initialized
INFO - 2025-11-12 14:50:25 --> Loader Class Initialized
INFO - 2025-11-12 14:50:25 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:50:25 --> Helper loaded: url_helper
INFO - 2025-11-12 14:50:25 --> Helper loaded: file_helper
INFO - 2025-11-12 14:50:25 --> Helper loaded: main_helper
INFO - 2025-11-12 14:50:25 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:50:25 --> Database Driver Class Initialized
INFO - 2025-11-12 14:50:25 --> Email Class Initialized
DEBUG - 2025-11-12 14:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:50:25 --> Controller Class Initialized
INFO - 2025-11-12 14:50:25 --> Model "User_model" initialized
INFO - 2025-11-12 14:50:25 --> Model "Project_model" initialized
INFO - 2025-11-12 14:50:25 --> Helper loaded: form_helper
INFO - 2025-11-12 14:50:25 --> Form Validation Class Initialized
INFO - 2025-11-12 14:50:25 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:50:25 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:50:25 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:50:25 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:50:25 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:50:25 --> Model "Topk_service_model" initialized
ERROR - 2025-11-12 14:50:30 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 324,
    "totalTokenCount": 1123,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 324
      }
    ],
    "thoughtsTokenCount": 799
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "tp4UacvgHZeEg8UPz6a0wAU"
}

ERROR - 2025-11-12 14:50:32 --> Gemini API request error: Server error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `503 Service Unavailable` response:
{
  "error": {
    "code": 503,
    "message": "The model is overloaded. Please try again later.",
    "status": "UNAVAI (truncated...)

INFO - 2025-11-12 14:50:32 --> Final output sent to browser
INFO - 2025-11-12 14:50:32 --> Total execution time: 7.1732
INFO - 2025-11-12 14:50:32 --> Config Class Initialized
INFO - 2025-11-12 14:50:32 --> Hooks Class Initialized
INFO - 2025-11-12 14:50:32 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:50:32 --> Utf8 Class Initialized
INFO - 2025-11-12 14:50:32 --> URI Class Initialized
INFO - 2025-11-12 14:50:32 --> Router Class Initialized
INFO - 2025-11-12 14:50:32 --> Output Class Initialized
INFO - 2025-11-12 14:50:32 --> Security Class Initialized
INFO - 2025-11-12 14:50:32 --> Input Class Initialized
INFO - 2025-11-12 14:50:32 --> Language Class Initialized
INFO - 2025-11-12 14:50:32 --> Loader Class Initialized
INFO - 2025-11-12 14:50:32 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:50:32 --> Helper loaded: url_helper
INFO - 2025-11-12 14:50:32 --> Helper loaded: file_helper
INFO - 2025-11-12 14:50:32 --> Helper loaded: main_helper
INFO - 2025-11-12 14:50:32 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:50:32 --> Database Driver Class Initialized
INFO - 2025-11-12 14:50:32 --> Email Class Initialized
DEBUG - 2025-11-12 14:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:50:32 --> Controller Class Initialized
INFO - 2025-11-12 14:50:32 --> Model "User_model" initialized
INFO - 2025-11-12 14:50:32 --> Model "Project_model" initialized
INFO - 2025-11-12 14:50:32 --> Helper loaded: form_helper
INFO - 2025-11-12 14:50:32 --> Form Validation Class Initialized
INFO - 2025-11-12 14:50:32 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:50:32 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:50:32 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:50:32 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:50:32 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:50:32 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:50:40 --> Final output sent to browser
INFO - 2025-11-12 14:50:40 --> Total execution time: 8.0932
INFO - 2025-11-12 14:54:06 --> Config Class Initialized
INFO - 2025-11-12 14:54:06 --> Hooks Class Initialized
INFO - 2025-11-12 14:54:06 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:54:06 --> Utf8 Class Initialized
INFO - 2025-11-12 14:54:07 --> Config Class Initialized
INFO - 2025-11-12 14:54:07 --> Hooks Class Initialized
INFO - 2025-11-12 14:54:07 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:54:07 --> Utf8 Class Initialized
INFO - 2025-11-12 14:54:07 --> URI Class Initialized
INFO - 2025-11-12 14:54:07 --> Router Class Initialized
INFO - 2025-11-12 14:54:07 --> Output Class Initialized
INFO - 2025-11-12 14:54:07 --> Security Class Initialized
INFO - 2025-11-12 14:54:07 --> Input Class Initialized
INFO - 2025-11-12 14:54:07 --> Language Class Initialized
INFO - 2025-11-12 14:54:07 --> Loader Class Initialized
INFO - 2025-11-12 14:54:07 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:54:07 --> Helper loaded: url_helper
INFO - 2025-11-12 14:54:07 --> Helper loaded: file_helper
INFO - 2025-11-12 14:54:07 --> Helper loaded: main_helper
INFO - 2025-11-12 14:54:07 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:54:07 --> Database Driver Class Initialized
INFO - 2025-11-12 14:54:07 --> Email Class Initialized
DEBUG - 2025-11-12 14:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:54:07 --> Controller Class Initialized
INFO - 2025-11-12 14:54:07 --> Model "Subscription_model" initialized
INFO - 2025-11-12 14:54:07 --> Model "User_model" initialized
INFO - 2025-11-12 14:54:07 --> Model "Auth_model" initialized
INFO - 2025-11-12 14:54:07 --> Model "Project_model" initialized
INFO - 2025-11-12 14:54:07 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-12 14:54:07 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-12 14:54:07 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-12 14:54:07 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ai.php
INFO - 2025-11-12 14:54:07 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-12 14:54:07 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-12 14:54:07 --> Final output sent to browser
INFO - 2025-11-12 14:54:07 --> Total execution time: 0.0805
INFO - 2025-11-12 14:54:07 --> Config Class Initialized
INFO - 2025-11-12 14:54:07 --> Hooks Class Initialized
INFO - 2025-11-12 14:54:07 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:54:07 --> Utf8 Class Initialized
INFO - 2025-11-12 14:54:07 --> URI Class Initialized
INFO - 2025-11-12 14:54:07 --> Router Class Initialized
INFO - 2025-11-12 14:54:07 --> Output Class Initialized
INFO - 2025-11-12 14:54:07 --> Security Class Initialized
INFO - 2025-11-12 14:54:07 --> Input Class Initialized
INFO - 2025-11-12 14:54:07 --> Language Class Initialized
INFO - 2025-11-12 14:54:07 --> Loader Class Initialized
INFO - 2025-11-12 14:54:07 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:54:07 --> Helper loaded: url_helper
INFO - 2025-11-12 14:54:07 --> Helper loaded: file_helper
INFO - 2025-11-12 14:54:07 --> Helper loaded: main_helper
INFO - 2025-11-12 14:54:07 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:54:07 --> Database Driver Class Initialized
INFO - 2025-11-12 14:54:07 --> Email Class Initialized
DEBUG - 2025-11-12 14:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:54:07 --> Controller Class Initialized
INFO - 2025-11-12 14:54:07 --> Model "User_model" initialized
INFO - 2025-11-12 14:54:07 --> Model "Project_model" initialized
INFO - 2025-11-12 14:54:07 --> Helper loaded: form_helper
INFO - 2025-11-12 14:54:07 --> Form Validation Class Initialized
INFO - 2025-11-12 14:54:07 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:54:07 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:54:07 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:54:07 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:54:07 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:54:07 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:54:07 --> Final output sent to browser
INFO - 2025-11-12 14:54:07 --> Total execution time: 0.0925
INFO - 2025-11-12 14:54:07 --> Config Class Initialized
INFO - 2025-11-12 14:54:07 --> Hooks Class Initialized
INFO - 2025-11-12 14:54:07 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:54:07 --> Utf8 Class Initialized
INFO - 2025-11-12 14:54:07 --> Config Class Initialized
INFO - 2025-11-12 14:54:07 --> Hooks Class Initialized
INFO - 2025-11-12 14:54:07 --> URI Class Initialized
INFO - 2025-11-12 14:54:07 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:54:07 --> Utf8 Class Initialized
INFO - 2025-11-12 14:54:07 --> URI Class Initialized
INFO - 2025-11-12 14:54:07 --> Router Class Initialized
INFO - 2025-11-12 14:54:07 --> Router Class Initialized
INFO - 2025-11-12 14:54:07 --> Output Class Initialized
INFO - 2025-11-12 14:54:07 --> Output Class Initialized
INFO - 2025-11-12 14:54:07 --> Security Class Initialized
INFO - 2025-11-12 14:54:07 --> Security Class Initialized
INFO - 2025-11-12 14:54:07 --> Input Class Initialized
INFO - 2025-11-12 14:54:07 --> Input Class Initialized
INFO - 2025-11-12 14:54:07 --> Language Class Initialized
INFO - 2025-11-12 14:54:07 --> Language Class Initialized
INFO - 2025-11-12 14:54:07 --> Loader Class Initialized
INFO - 2025-11-12 14:54:07 --> Loader Class Initialized
INFO - 2025-11-12 14:54:07 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:54:07 --> Helper loaded: url_helper
INFO - 2025-11-12 14:54:07 --> Helper loaded: file_helper
INFO - 2025-11-12 14:54:07 --> Helper loaded: main_helper
INFO - 2025-11-12 14:54:07 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:54:07 --> Helper loaded: url_helper
INFO - 2025-11-12 14:54:07 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:54:07 --> Helper loaded: file_helper
INFO - 2025-11-12 14:54:07 --> Helper loaded: main_helper
INFO - 2025-11-12 14:54:07 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:54:07 --> Database Driver Class Initialized
INFO - 2025-11-12 14:54:07 --> Email Class Initialized
INFO - 2025-11-12 14:54:07 --> Database Driver Class Initialized
INFO - 2025-11-12 14:54:07 --> Email Class Initialized
DEBUG - 2025-11-12 14:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-11-12 14:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:54:07 --> Controller Class Initialized
INFO - 2025-11-12 14:54:07 --> Model "User_model" initialized
INFO - 2025-11-12 14:54:07 --> Model "Project_model" initialized
INFO - 2025-11-12 14:54:07 --> Helper loaded: form_helper
INFO - 2025-11-12 14:54:07 --> Form Validation Class Initialized
INFO - 2025-11-12 14:54:07 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:54:07 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:54:07 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:54:07 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:54:07 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:54:07 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:54:07 --> Final output sent to browser
INFO - 2025-11-12 14:54:07 --> Total execution time: 0.1486
INFO - 2025-11-12 14:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:54:07 --> Controller Class Initialized
INFO - 2025-11-12 14:54:07 --> Model "User_model" initialized
INFO - 2025-11-12 14:54:07 --> Model "Project_model" initialized
INFO - 2025-11-12 14:54:07 --> Helper loaded: form_helper
INFO - 2025-11-12 14:54:07 --> Form Validation Class Initialized
INFO - 2025-11-12 14:54:07 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:54:07 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:54:07 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:54:07 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:54:07 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:54:07 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:54:07 --> Final output sent to browser
INFO - 2025-11-12 14:54:07 --> Total execution time: 0.1633
INFO - 2025-11-12 14:54:08 --> Config Class Initialized
INFO - 2025-11-12 14:54:08 --> Hooks Class Initialized
INFO - 2025-11-12 14:54:08 --> Config Class Initialized
INFO - 2025-11-12 14:54:08 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:54:08 --> Hooks Class Initialized
INFO - 2025-11-12 14:54:08 --> Utf8 Class Initialized
INFO - 2025-11-12 14:54:08 --> URI Class Initialized
INFO - 2025-11-12 14:54:08 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:54:08 --> Utf8 Class Initialized
INFO - 2025-11-12 14:54:08 --> Router Class Initialized
INFO - 2025-11-12 14:54:08 --> URI Class Initialized
INFO - 2025-11-12 14:54:08 --> Router Class Initialized
INFO - 2025-11-12 14:54:08 --> Output Class Initialized
INFO - 2025-11-12 14:54:08 --> Security Class Initialized
INFO - 2025-11-12 14:54:08 --> Output Class Initialized
INFO - 2025-11-12 14:54:08 --> Input Class Initialized
INFO - 2025-11-12 14:54:08 --> Language Class Initialized
INFO - 2025-11-12 14:54:08 --> Security Class Initialized
INFO - 2025-11-12 14:54:08 --> Input Class Initialized
INFO - 2025-11-12 14:54:08 --> Language Class Initialized
INFO - 2025-11-12 14:54:08 --> Loader Class Initialized
INFO - 2025-11-12 14:54:08 --> Loader Class Initialized
INFO - 2025-11-12 14:54:08 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:54:08 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:54:08 --> Helper loaded: url_helper
INFO - 2025-11-12 14:54:08 --> Helper loaded: url_helper
INFO - 2025-11-12 14:54:08 --> Helper loaded: file_helper
INFO - 2025-11-12 14:54:08 --> Helper loaded: main_helper
INFO - 2025-11-12 14:54:08 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:54:08 --> Helper loaded: file_helper
INFO - 2025-11-12 14:54:08 --> Helper loaded: main_helper
INFO - 2025-11-12 14:54:08 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:54:08 --> Database Driver Class Initialized
INFO - 2025-11-12 14:54:08 --> Database Driver Class Initialized
INFO - 2025-11-12 14:54:08 --> Email Class Initialized
INFO - 2025-11-12 14:54:08 --> Email Class Initialized
DEBUG - 2025-11-12 14:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:54:08 --> Controller Class Initialized
INFO - 2025-11-12 14:54:08 --> Model "User_model" initialized
INFO - 2025-11-12 14:54:08 --> Model "Project_model" initialized
DEBUG - 2025-11-12 14:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:54:08 --> Helper loaded: form_helper
INFO - 2025-11-12 14:54:08 --> Form Validation Class Initialized
INFO - 2025-11-12 14:54:08 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:54:08 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:54:08 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:54:08 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:54:08 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:54:08 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:54:08 --> Final output sent to browser
INFO - 2025-11-12 14:54:08 --> Total execution time: 0.1921
INFO - 2025-11-12 14:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:54:08 --> Controller Class Initialized
INFO - 2025-11-12 14:54:08 --> Model "User_model" initialized
INFO - 2025-11-12 14:54:08 --> Model "Project_model" initialized
INFO - 2025-11-12 14:54:08 --> Helper loaded: form_helper
INFO - 2025-11-12 14:54:08 --> Form Validation Class Initialized
INFO - 2025-11-12 14:54:08 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:54:08 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:54:08 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:54:08 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:54:08 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:54:08 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:54:08 --> Final output sent to browser
INFO - 2025-11-12 14:54:08 --> Total execution time: 0.2333
INFO - 2025-11-12 14:55:54 --> Config Class Initialized
INFO - 2025-11-12 14:55:54 --> Hooks Class Initialized
INFO - 2025-11-12 14:55:54 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:55:54 --> Utf8 Class Initialized
INFO - 2025-11-12 14:55:59 --> Config Class Initialized
INFO - 2025-11-12 14:55:59 --> Hooks Class Initialized
INFO - 2025-11-12 14:55:59 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:55:59 --> Utf8 Class Initialized
INFO - 2025-11-12 14:55:59 --> URI Class Initialized
INFO - 2025-11-12 14:55:59 --> Router Class Initialized
INFO - 2025-11-12 14:55:59 --> Output Class Initialized
INFO - 2025-11-12 14:55:59 --> Security Class Initialized
INFO - 2025-11-12 14:55:59 --> Input Class Initialized
INFO - 2025-11-12 14:55:59 --> Language Class Initialized
INFO - 2025-11-12 14:55:59 --> Loader Class Initialized
INFO - 2025-11-12 14:55:59 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:55:59 --> Helper loaded: url_helper
INFO - 2025-11-12 14:55:59 --> Helper loaded: file_helper
INFO - 2025-11-12 14:55:59 --> Helper loaded: main_helper
INFO - 2025-11-12 14:55:59 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:55:59 --> Database Driver Class Initialized
INFO - 2025-11-12 14:55:59 --> Email Class Initialized
DEBUG - 2025-11-12 14:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:55:59 --> Controller Class Initialized
INFO - 2025-11-12 14:55:59 --> Model "Subscription_model" initialized
INFO - 2025-11-12 14:55:59 --> Model "User_model" initialized
INFO - 2025-11-12 14:55:59 --> Model "Auth_model" initialized
INFO - 2025-11-12 14:55:59 --> Model "Project_model" initialized
INFO - 2025-11-12 14:55:59 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-12 14:55:59 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-12 14:55:59 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-12 14:55:59 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ai.php
INFO - 2025-11-12 14:55:59 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-12 14:55:59 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-12 14:55:59 --> Final output sent to browser
INFO - 2025-11-12 14:55:59 --> Total execution time: 0.0846
INFO - 2025-11-12 14:55:59 --> Config Class Initialized
INFO - 2025-11-12 14:55:59 --> Hooks Class Initialized
INFO - 2025-11-12 14:55:59 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:55:59 --> Utf8 Class Initialized
INFO - 2025-11-12 14:55:59 --> URI Class Initialized
INFO - 2025-11-12 14:55:59 --> Router Class Initialized
INFO - 2025-11-12 14:55:59 --> Output Class Initialized
INFO - 2025-11-12 14:55:59 --> Security Class Initialized
INFO - 2025-11-12 14:55:59 --> Input Class Initialized
INFO - 2025-11-12 14:55:59 --> Language Class Initialized
INFO - 2025-11-12 14:55:59 --> Loader Class Initialized
INFO - 2025-11-12 14:55:59 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:55:59 --> Helper loaded: url_helper
INFO - 2025-11-12 14:55:59 --> Helper loaded: file_helper
INFO - 2025-11-12 14:55:59 --> Helper loaded: main_helper
INFO - 2025-11-12 14:55:59 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:55:59 --> Database Driver Class Initialized
INFO - 2025-11-12 14:55:59 --> Email Class Initialized
DEBUG - 2025-11-12 14:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:55:59 --> Controller Class Initialized
INFO - 2025-11-12 14:55:59 --> Model "User_model" initialized
INFO - 2025-11-12 14:55:59 --> Model "Project_model" initialized
INFO - 2025-11-12 14:55:59 --> Helper loaded: form_helper
INFO - 2025-11-12 14:55:59 --> Form Validation Class Initialized
INFO - 2025-11-12 14:55:59 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:55:59 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:55:59 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:55:59 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:55:59 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:55:59 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:55:59 --> Final output sent to browser
INFO - 2025-11-12 14:55:59 --> Total execution time: 0.0754
INFO - 2025-11-12 14:55:59 --> Config Class Initialized
INFO - 2025-11-12 14:55:59 --> Config Class Initialized
INFO - 2025-11-12 14:55:59 --> Hooks Class Initialized
INFO - 2025-11-12 14:55:59 --> Hooks Class Initialized
INFO - 2025-11-12 14:55:59 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:55:59 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:55:59 --> Utf8 Class Initialized
INFO - 2025-11-12 14:55:59 --> Utf8 Class Initialized
INFO - 2025-11-12 14:55:59 --> URI Class Initialized
INFO - 2025-11-12 14:55:59 --> URI Class Initialized
INFO - 2025-11-12 14:55:59 --> Router Class Initialized
INFO - 2025-11-12 14:55:59 --> Router Class Initialized
INFO - 2025-11-12 14:55:59 --> Output Class Initialized
INFO - 2025-11-12 14:55:59 --> Output Class Initialized
INFO - 2025-11-12 14:55:59 --> Security Class Initialized
INFO - 2025-11-12 14:55:59 --> Security Class Initialized
INFO - 2025-11-12 14:55:59 --> Input Class Initialized
INFO - 2025-11-12 14:55:59 --> Input Class Initialized
INFO - 2025-11-12 14:55:59 --> Language Class Initialized
INFO - 2025-11-12 14:55:59 --> Language Class Initialized
INFO - 2025-11-12 14:55:59 --> Loader Class Initialized
INFO - 2025-11-12 14:55:59 --> Loader Class Initialized
INFO - 2025-11-12 14:55:59 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:55:59 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:55:59 --> Helper loaded: url_helper
INFO - 2025-11-12 14:55:59 --> Helper loaded: url_helper
INFO - 2025-11-12 14:55:59 --> Helper loaded: file_helper
INFO - 2025-11-12 14:55:59 --> Helper loaded: file_helper
INFO - 2025-11-12 14:55:59 --> Helper loaded: main_helper
INFO - 2025-11-12 14:55:59 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:55:59 --> Helper loaded: main_helper
INFO - 2025-11-12 14:55:59 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:55:59 --> Database Driver Class Initialized
INFO - 2025-11-12 14:55:59 --> Database Driver Class Initialized
INFO - 2025-11-12 14:55:59 --> Email Class Initialized
INFO - 2025-11-12 14:55:59 --> Email Class Initialized
DEBUG - 2025-11-12 14:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-11-12 14:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:55:59 --> Controller Class Initialized
INFO - 2025-11-12 14:55:59 --> Model "User_model" initialized
INFO - 2025-11-12 14:55:59 --> Model "Project_model" initialized
INFO - 2025-11-12 14:55:59 --> Helper loaded: form_helper
INFO - 2025-11-12 14:55:59 --> Form Validation Class Initialized
INFO - 2025-11-12 14:55:59 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:55:59 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:55:59 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:55:59 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:55:59 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:55:59 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:55:59 --> Final output sent to browser
INFO - 2025-11-12 14:55:59 --> Total execution time: 0.0966
INFO - 2025-11-12 14:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:55:59 --> Controller Class Initialized
INFO - 2025-11-12 14:55:59 --> Model "User_model" initialized
INFO - 2025-11-12 14:55:59 --> Model "Project_model" initialized
INFO - 2025-11-12 14:55:59 --> Helper loaded: form_helper
INFO - 2025-11-12 14:55:59 --> Form Validation Class Initialized
INFO - 2025-11-12 14:55:59 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:55:59 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:55:59 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:55:59 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:55:59 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:55:59 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:55:59 --> Final output sent to browser
INFO - 2025-11-12 14:55:59 --> Total execution time: 0.1158
INFO - 2025-11-12 14:56:00 --> Config Class Initialized
INFO - 2025-11-12 14:56:00 --> Config Class Initialized
INFO - 2025-11-12 14:56:00 --> Hooks Class Initialized
INFO - 2025-11-12 14:56:00 --> Hooks Class Initialized
INFO - 2025-11-12 14:56:00 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:56:00 --> Utf8 Class Initialized
INFO - 2025-11-12 14:56:00 --> UTF-8 Support Enabled
INFO - 2025-11-12 14:56:00 --> Utf8 Class Initialized
INFO - 2025-11-12 14:56:00 --> URI Class Initialized
INFO - 2025-11-12 14:56:00 --> URI Class Initialized
INFO - 2025-11-12 14:56:00 --> Router Class Initialized
INFO - 2025-11-12 14:56:00 --> Router Class Initialized
INFO - 2025-11-12 14:56:00 --> Output Class Initialized
INFO - 2025-11-12 14:56:00 --> Output Class Initialized
INFO - 2025-11-12 14:56:00 --> Security Class Initialized
INFO - 2025-11-12 14:56:00 --> Security Class Initialized
INFO - 2025-11-12 14:56:00 --> Input Class Initialized
INFO - 2025-11-12 14:56:00 --> Input Class Initialized
INFO - 2025-11-12 14:56:00 --> Language Class Initialized
INFO - 2025-11-12 14:56:00 --> Language Class Initialized
INFO - 2025-11-12 14:56:00 --> Loader Class Initialized
INFO - 2025-11-12 14:56:00 --> Loader Class Initialized
INFO - 2025-11-12 14:56:00 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:56:00 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-12 14:56:00 --> Helper loaded: url_helper
INFO - 2025-11-12 14:56:00 --> Helper loaded: url_helper
INFO - 2025-11-12 14:56:00 --> Helper loaded: file_helper
INFO - 2025-11-12 14:56:00 --> Helper loaded: file_helper
INFO - 2025-11-12 14:56:00 --> Helper loaded: main_helper
INFO - 2025-11-12 14:56:00 --> Helper loaded: main_helper
INFO - 2025-11-12 14:56:00 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:56:00 --> Helper loaded: sendgrid_helper
INFO - 2025-11-12 14:56:00 --> Database Driver Class Initialized
INFO - 2025-11-12 14:56:00 --> Database Driver Class Initialized
INFO - 2025-11-12 14:56:00 --> Email Class Initialized
INFO - 2025-11-12 14:56:00 --> Email Class Initialized
DEBUG - 2025-11-12 14:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-11-12 14:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-12 14:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:56:00 --> Controller Class Initialized
INFO - 2025-11-12 14:56:00 --> Model "User_model" initialized
INFO - 2025-11-12 14:56:00 --> Model "Project_model" initialized
INFO - 2025-11-12 14:56:00 --> Helper loaded: form_helper
INFO - 2025-11-12 14:56:00 --> Form Validation Class Initialized
INFO - 2025-11-12 14:56:00 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:56:00 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:56:00 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:56:00 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:56:00 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:56:00 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:56:00 --> Final output sent to browser
INFO - 2025-11-12 14:56:00 --> Total execution time: 0.1095
INFO - 2025-11-12 14:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-12 14:56:00 --> Controller Class Initialized
INFO - 2025-11-12 14:56:00 --> Model "User_model" initialized
INFO - 2025-11-12 14:56:00 --> Model "Project_model" initialized
INFO - 2025-11-12 14:56:00 --> Helper loaded: form_helper
INFO - 2025-11-12 14:56:00 --> Form Validation Class Initialized
INFO - 2025-11-12 14:56:00 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-12 14:56:00 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-12 14:56:00 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-12 14:56:00 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:56:00 --> Model "Swot_model" initialized
INFO - 2025-11-12 14:56:00 --> Model "Topk_service_model" initialized
INFO - 2025-11-12 14:56:00 --> Final output sent to browser
INFO - 2025-11-12 14:56:00 --> Total execution time: 0.1271
