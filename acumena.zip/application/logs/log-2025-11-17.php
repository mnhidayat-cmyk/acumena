<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-11-17 08:25:09 --> Config Class Initialized
INFO - 2025-11-17 08:25:09 --> Hooks Class Initialized
INFO - 2025-11-17 08:25:09 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:25:09 --> Utf8 Class Initialized
INFO - 2025-11-17 08:25:09 --> URI Class Initialized
DEBUG - 2025-11-17 08:25:09 --> No URI present. Default controller set.
INFO - 2025-11-17 08:25:09 --> Router Class Initialized
INFO - 2025-11-17 08:25:09 --> Output Class Initialized
INFO - 2025-11-17 08:25:09 --> Security Class Initialized
INFO - 2025-11-17 08:25:09 --> Input Class Initialized
INFO - 2025-11-17 08:25:09 --> Language Class Initialized
INFO - 2025-11-17 08:25:09 --> Loader Class Initialized
INFO - 2025-11-17 08:25:09 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:25:09 --> Helper loaded: url_helper
INFO - 2025-11-17 08:25:09 --> Helper loaded: file_helper
INFO - 2025-11-17 08:25:09 --> Helper loaded: main_helper
INFO - 2025-11-17 08:25:09 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:25:09 --> Database Driver Class Initialized
INFO - 2025-11-17 08:25:09 --> Config Class Initialized
INFO - 2025-11-17 08:25:09 --> Hooks Class Initialized
INFO - 2025-11-17 08:25:09 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:25:09 --> Utf8 Class Initialized
INFO - 2025-11-17 08:25:09 --> URI Class Initialized
DEBUG - 2025-11-17 08:25:09 --> No URI present. Default controller set.
INFO - 2025-11-17 08:25:09 --> Router Class Initialized
INFO - 2025-11-17 08:25:09 --> Output Class Initialized
INFO - 2025-11-17 08:25:09 --> Security Class Initialized
INFO - 2025-11-17 08:25:09 --> Input Class Initialized
INFO - 2025-11-17 08:25:09 --> Language Class Initialized
INFO - 2025-11-17 08:25:09 --> Loader Class Initialized
INFO - 2025-11-17 08:25:09 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:25:09 --> Helper loaded: url_helper
INFO - 2025-11-17 08:25:09 --> Helper loaded: file_helper
INFO - 2025-11-17 08:25:09 --> Helper loaded: main_helper
INFO - 2025-11-17 08:25:09 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:25:09 --> Database Driver Class Initialized
INFO - 2025-11-17 08:25:12 --> Email Class Initialized
DEBUG - 2025-11-17 08:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:25:12 --> Controller Class Initialized
INFO - 2025-11-17 08:25:12 --> Email Class Initialized
DEBUG - 2025-11-17 08:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:25:12 --> Controller Class Initialized
INFO - 2025-11-17 08:25:12 --> Config Class Initialized
INFO - 2025-11-17 08:25:12 --> Hooks Class Initialized
INFO - 2025-11-17 08:25:12 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:25:12 --> Utf8 Class Initialized
INFO - 2025-11-17 08:25:12 --> URI Class Initialized
INFO - 2025-11-17 08:25:12 --> Router Class Initialized
INFO - 2025-11-17 08:25:12 --> Output Class Initialized
INFO - 2025-11-17 08:25:12 --> Security Class Initialized
INFO - 2025-11-17 08:25:12 --> Input Class Initialized
INFO - 2025-11-17 08:25:12 --> Language Class Initialized
INFO - 2025-11-17 08:25:12 --> Loader Class Initialized
INFO - 2025-11-17 08:25:12 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:25:12 --> Helper loaded: url_helper
INFO - 2025-11-17 08:25:12 --> Helper loaded: file_helper
INFO - 2025-11-17 08:25:12 --> Helper loaded: main_helper
INFO - 2025-11-17 08:25:12 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:25:12 --> Database Driver Class Initialized
INFO - 2025-11-17 08:25:12 --> Email Class Initialized
DEBUG - 2025-11-17 08:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:25:12 --> Controller Class Initialized
INFO - 2025-11-17 08:25:12 --> Model "Subscription_model" initialized
INFO - 2025-11-17 08:25:12 --> Model "User_model" initialized
INFO - 2025-11-17 08:25:12 --> Model "Auth_model" initialized
INFO - 2025-11-17 08:25:12 --> Config Class Initialized
INFO - 2025-11-17 08:25:12 --> Hooks Class Initialized
INFO - 2025-11-17 08:25:12 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:25:12 --> Utf8 Class Initialized
INFO - 2025-11-17 08:25:12 --> URI Class Initialized
INFO - 2025-11-17 08:25:12 --> Router Class Initialized
INFO - 2025-11-17 08:25:12 --> Output Class Initialized
INFO - 2025-11-17 08:25:12 --> Security Class Initialized
INFO - 2025-11-17 08:25:12 --> Input Class Initialized
INFO - 2025-11-17 08:25:12 --> Language Class Initialized
INFO - 2025-11-17 08:25:12 --> Loader Class Initialized
INFO - 2025-11-17 08:25:12 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:25:12 --> Helper loaded: url_helper
INFO - 2025-11-17 08:25:12 --> Helper loaded: file_helper
INFO - 2025-11-17 08:25:12 --> Helper loaded: main_helper
INFO - 2025-11-17 08:25:12 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:25:12 --> Database Driver Class Initialized
INFO - 2025-11-17 08:25:12 --> Email Class Initialized
DEBUG - 2025-11-17 08:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:25:12 --> Controller Class Initialized
INFO - 2025-11-17 08:25:12 --> Config Class Initialized
INFO - 2025-11-17 08:25:12 --> Hooks Class Initialized
INFO - 2025-11-17 08:25:12 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:25:12 --> Utf8 Class Initialized
INFO - 2025-11-17 08:25:12 --> URI Class Initialized
INFO - 2025-11-17 08:25:12 --> Router Class Initialized
INFO - 2025-11-17 08:25:12 --> Output Class Initialized
INFO - 2025-11-17 08:25:12 --> Security Class Initialized
INFO - 2025-11-17 08:25:12 --> Input Class Initialized
INFO - 2025-11-17 08:25:12 --> Language Class Initialized
INFO - 2025-11-17 08:25:12 --> Loader Class Initialized
INFO - 2025-11-17 08:25:12 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:25:12 --> Helper loaded: url_helper
INFO - 2025-11-17 08:25:12 --> Helper loaded: file_helper
INFO - 2025-11-17 08:25:12 --> Helper loaded: main_helper
INFO - 2025-11-17 08:25:12 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:25:12 --> Database Driver Class Initialized
INFO - 2025-11-17 08:25:12 --> Email Class Initialized
DEBUG - 2025-11-17 08:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:25:12 --> Controller Class Initialized
INFO - 2025-11-17 08:25:12 --> Model "Subscription_model" initialized
INFO - 2025-11-17 08:25:12 --> Model "User_model" initialized
INFO - 2025-11-17 08:25:12 --> Model "Auth_model" initialized
INFO - 2025-11-17 08:25:12 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-17 08:25:12 --> Final output sent to browser
INFO - 2025-11-17 08:25:12 --> Total execution time: 0.0656
INFO - 2025-11-17 08:25:22 --> Config Class Initialized
INFO - 2025-11-17 08:25:22 --> Hooks Class Initialized
INFO - 2025-11-17 08:25:22 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:25:22 --> Utf8 Class Initialized
INFO - 2025-11-17 08:25:22 --> URI Class Initialized
INFO - 2025-11-17 08:25:22 --> Router Class Initialized
INFO - 2025-11-17 08:25:22 --> Output Class Initialized
INFO - 2025-11-17 08:25:22 --> Security Class Initialized
INFO - 2025-11-17 08:25:22 --> Input Class Initialized
INFO - 2025-11-17 08:25:22 --> Language Class Initialized
INFO - 2025-11-17 08:25:22 --> Loader Class Initialized
INFO - 2025-11-17 08:25:22 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:25:22 --> Helper loaded: url_helper
INFO - 2025-11-17 08:25:22 --> Helper loaded: file_helper
INFO - 2025-11-17 08:25:22 --> Helper loaded: main_helper
INFO - 2025-11-17 08:25:22 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:25:22 --> Database Driver Class Initialized
INFO - 2025-11-17 08:25:22 --> Email Class Initialized
DEBUG - 2025-11-17 08:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:25:22 --> Controller Class Initialized
INFO - 2025-11-17 08:25:22 --> Model "Subscription_model" initialized
INFO - 2025-11-17 08:25:22 --> Model "User_model" initialized
INFO - 2025-11-17 08:25:22 --> Model "Auth_model" initialized
INFO - 2025-11-17 08:25:22 --> Final output sent to browser
INFO - 2025-11-17 08:25:22 --> Total execution time: 0.2787
INFO - 2025-11-17 08:25:24 --> Config Class Initialized
INFO - 2025-11-17 08:25:24 --> Hooks Class Initialized
INFO - 2025-11-17 08:25:24 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:25:24 --> Utf8 Class Initialized
INFO - 2025-11-17 08:25:24 --> URI Class Initialized
INFO - 2025-11-17 08:25:24 --> Router Class Initialized
INFO - 2025-11-17 08:25:24 --> Output Class Initialized
INFO - 2025-11-17 08:25:24 --> Security Class Initialized
INFO - 2025-11-17 08:25:24 --> Input Class Initialized
INFO - 2025-11-17 08:25:24 --> Language Class Initialized
INFO - 2025-11-17 08:25:24 --> Loader Class Initialized
INFO - 2025-11-17 08:25:24 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:25:24 --> Helper loaded: url_helper
INFO - 2025-11-17 08:25:24 --> Helper loaded: file_helper
INFO - 2025-11-17 08:25:24 --> Helper loaded: main_helper
INFO - 2025-11-17 08:25:24 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:25:24 --> Database Driver Class Initialized
INFO - 2025-11-17 08:25:24 --> Email Class Initialized
DEBUG - 2025-11-17 08:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:25:24 --> Controller Class Initialized
INFO - 2025-11-17 08:25:24 --> Model "Subscription_model" initialized
INFO - 2025-11-17 08:25:24 --> Model "User_model" initialized
INFO - 2025-11-17 08:25:24 --> Model "Auth_model" initialized
INFO - 2025-11-17 08:25:24 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 08:25:24 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 08:25:24 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 08:25:24 --> File loaded: D:\laragon\www\acumena\application\views\dashboard.php
INFO - 2025-11-17 08:25:24 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 08:25:24 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 08:25:24 --> Final output sent to browser
INFO - 2025-11-17 08:25:24 --> Total execution time: 0.0915
INFO - 2025-11-17 08:25:24 --> Config Class Initialized
INFO - 2025-11-17 08:25:24 --> Hooks Class Initialized
INFO - 2025-11-17 08:25:24 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:25:24 --> Utf8 Class Initialized
INFO - 2025-11-17 08:25:24 --> URI Class Initialized
INFO - 2025-11-17 08:25:24 --> Router Class Initialized
INFO - 2025-11-17 08:25:24 --> Output Class Initialized
INFO - 2025-11-17 08:25:24 --> Security Class Initialized
INFO - 2025-11-17 08:25:24 --> Input Class Initialized
INFO - 2025-11-17 08:25:24 --> Language Class Initialized
INFO - 2025-11-17 08:25:24 --> Loader Class Initialized
INFO - 2025-11-17 08:25:24 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:25:24 --> Helper loaded: url_helper
INFO - 2025-11-17 08:25:24 --> Helper loaded: file_helper
INFO - 2025-11-17 08:25:24 --> Helper loaded: main_helper
INFO - 2025-11-17 08:25:24 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:25:24 --> Database Driver Class Initialized
INFO - 2025-11-17 08:25:24 --> Email Class Initialized
DEBUG - 2025-11-17 08:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:25:24 --> Controller Class Initialized
INFO - 2025-11-17 08:25:24 --> Model "User_model" initialized
INFO - 2025-11-17 08:25:24 --> Model "Project_model" initialized
INFO - 2025-11-17 08:25:24 --> Helper loaded: form_helper
INFO - 2025-11-17 08:25:24 --> Form Validation Class Initialized
INFO - 2025-11-17 08:25:24 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 08:25:24 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 08:25:24 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 08:25:24 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:25:24 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:25:24 --> Model "Topk_service_model" initialized
INFO - 2025-11-17 08:25:24 --> Final output sent to browser
INFO - 2025-11-17 08:25:24 --> Total execution time: 0.0727
INFO - 2025-11-17 08:25:27 --> Config Class Initialized
INFO - 2025-11-17 08:25:27 --> Hooks Class Initialized
INFO - 2025-11-17 08:25:27 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:25:27 --> Utf8 Class Initialized
INFO - 2025-11-17 08:25:27 --> URI Class Initialized
INFO - 2025-11-17 08:25:27 --> Router Class Initialized
INFO - 2025-11-17 08:25:27 --> Output Class Initialized
INFO - 2025-11-17 08:25:27 --> Security Class Initialized
INFO - 2025-11-17 08:25:27 --> Input Class Initialized
INFO - 2025-11-17 08:25:27 --> Language Class Initialized
INFO - 2025-11-17 08:25:27 --> Loader Class Initialized
INFO - 2025-11-17 08:25:27 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:25:27 --> Helper loaded: url_helper
INFO - 2025-11-17 08:25:27 --> Helper loaded: file_helper
INFO - 2025-11-17 08:25:27 --> Helper loaded: main_helper
INFO - 2025-11-17 08:25:27 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:25:27 --> Database Driver Class Initialized
INFO - 2025-11-17 08:25:27 --> Email Class Initialized
DEBUG - 2025-11-17 08:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:25:27 --> Controller Class Initialized
INFO - 2025-11-17 08:25:27 --> Model "Subscription_model" initialized
INFO - 2025-11-17 08:25:27 --> Model "User_model" initialized
INFO - 2025-11-17 08:25:27 --> Model "Auth_model" initialized
INFO - 2025-11-17 08:25:28 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 08:25:28 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 08:25:28 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 08:25:28 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 08:25:28 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 08:25:28 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 08:25:28 --> Final output sent to browser
INFO - 2025-11-17 08:25:28 --> Total execution time: 0.1316
INFO - 2025-11-17 08:27:59 --> Config Class Initialized
INFO - 2025-11-17 08:27:59 --> Hooks Class Initialized
INFO - 2025-11-17 08:27:59 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:27:59 --> Utf8 Class Initialized
INFO - 2025-11-17 08:27:59 --> URI Class Initialized
INFO - 2025-11-17 08:27:59 --> Router Class Initialized
INFO - 2025-11-17 08:27:59 --> Output Class Initialized
INFO - 2025-11-17 08:27:59 --> Security Class Initialized
INFO - 2025-11-17 08:27:59 --> Input Class Initialized
INFO - 2025-11-17 08:27:59 --> Language Class Initialized
INFO - 2025-11-17 08:27:59 --> Loader Class Initialized
INFO - 2025-11-17 08:27:59 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:27:59 --> Helper loaded: url_helper
INFO - 2025-11-17 08:27:59 --> Helper loaded: file_helper
INFO - 2025-11-17 08:27:59 --> Helper loaded: main_helper
INFO - 2025-11-17 08:27:59 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:27:59 --> Database Driver Class Initialized
INFO - 2025-11-17 08:27:59 --> Email Class Initialized
DEBUG - 2025-11-17 08:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:27:59 --> Controller Class Initialized
INFO - 2025-11-17 08:27:59 --> Model "Subscription_model" initialized
INFO - 2025-11-17 08:27:59 --> Model "User_model" initialized
INFO - 2025-11-17 08:27:59 --> Model "Auth_model" initialized
INFO - 2025-11-17 08:27:59 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 08:27:59 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 08:27:59 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 08:27:59 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 08:27:59 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 08:27:59 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 08:27:59 --> Final output sent to browser
INFO - 2025-11-17 08:27:59 --> Total execution time: 0.0799
INFO - 2025-11-17 08:28:48 --> Config Class Initialized
INFO - 2025-11-17 08:28:48 --> Hooks Class Initialized
INFO - 2025-11-17 08:28:48 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:28:48 --> Utf8 Class Initialized
INFO - 2025-11-17 08:28:48 --> URI Class Initialized
INFO - 2025-11-17 08:28:48 --> Router Class Initialized
INFO - 2025-11-17 08:28:48 --> Output Class Initialized
INFO - 2025-11-17 08:28:48 --> Security Class Initialized
INFO - 2025-11-17 08:28:48 --> Input Class Initialized
INFO - 2025-11-17 08:28:48 --> Language Class Initialized
INFO - 2025-11-17 08:28:48 --> Loader Class Initialized
INFO - 2025-11-17 08:28:48 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:28:48 --> Helper loaded: url_helper
INFO - 2025-11-17 08:28:48 --> Helper loaded: file_helper
INFO - 2025-11-17 08:28:48 --> Helper loaded: main_helper
INFO - 2025-11-17 08:28:48 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:28:48 --> Database Driver Class Initialized
INFO - 2025-11-17 08:28:48 --> Email Class Initialized
DEBUG - 2025-11-17 08:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:28:48 --> Controller Class Initialized
INFO - 2025-11-17 08:28:48 --> Model "Subscription_model" initialized
INFO - 2025-11-17 08:28:48 --> Model "User_model" initialized
INFO - 2025-11-17 08:28:48 --> Model "Auth_model" initialized
INFO - 2025-11-17 08:28:48 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 08:28:48 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 08:28:48 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 08:28:48 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 08:28:48 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 08:28:48 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 08:28:48 --> Final output sent to browser
INFO - 2025-11-17 08:28:48 --> Total execution time: 0.0647
INFO - 2025-11-17 08:29:16 --> Config Class Initialized
INFO - 2025-11-17 08:29:16 --> Hooks Class Initialized
INFO - 2025-11-17 08:29:16 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:29:16 --> Utf8 Class Initialized
INFO - 2025-11-17 08:29:16 --> URI Class Initialized
INFO - 2025-11-17 08:29:16 --> Router Class Initialized
INFO - 2025-11-17 08:29:16 --> Output Class Initialized
INFO - 2025-11-17 08:29:16 --> Security Class Initialized
INFO - 2025-11-17 08:29:16 --> Input Class Initialized
INFO - 2025-11-17 08:29:16 --> Language Class Initialized
INFO - 2025-11-17 08:29:16 --> Loader Class Initialized
INFO - 2025-11-17 08:29:16 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:29:16 --> Helper loaded: url_helper
INFO - 2025-11-17 08:29:16 --> Helper loaded: file_helper
INFO - 2025-11-17 08:29:16 --> Helper loaded: main_helper
INFO - 2025-11-17 08:29:16 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:29:16 --> Database Driver Class Initialized
INFO - 2025-11-17 08:29:16 --> Email Class Initialized
DEBUG - 2025-11-17 08:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:29:16 --> Controller Class Initialized
INFO - 2025-11-17 08:29:16 --> Model "Subscription_model" initialized
INFO - 2025-11-17 08:29:16 --> Model "User_model" initialized
INFO - 2025-11-17 08:29:16 --> Model "Auth_model" initialized
INFO - 2025-11-17 08:29:16 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 08:29:16 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 08:29:16 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
ERROR - 2025-11-17 08:29:16 --> Severity: Warning --> Undefined property: stdClass::$date_paid D:\laragon\www\acumena\application\views\subscriptions\index.php 56
ERROR - 2025-11-17 08:29:16 --> Severity: Deprecated Notice --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated D:\laragon\www\acumena\application\views\subscriptions\index.php 56
INFO - 2025-11-17 08:29:16 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 08:29:16 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 08:29:16 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 08:29:16 --> Final output sent to browser
INFO - 2025-11-17 08:29:16 --> Total execution time: 0.0793
INFO - 2025-11-17 08:29:25 --> Config Class Initialized
INFO - 2025-11-17 08:29:25 --> Hooks Class Initialized
INFO - 2025-11-17 08:29:25 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:29:25 --> Utf8 Class Initialized
INFO - 2025-11-17 08:29:25 --> URI Class Initialized
INFO - 2025-11-17 08:29:25 --> Router Class Initialized
INFO - 2025-11-17 08:29:25 --> Output Class Initialized
INFO - 2025-11-17 08:29:25 --> Security Class Initialized
INFO - 2025-11-17 08:29:25 --> Input Class Initialized
INFO - 2025-11-17 08:29:25 --> Language Class Initialized
INFO - 2025-11-17 08:29:25 --> Loader Class Initialized
INFO - 2025-11-17 08:29:25 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:29:25 --> Helper loaded: url_helper
INFO - 2025-11-17 08:29:25 --> Helper loaded: file_helper
INFO - 2025-11-17 08:29:25 --> Helper loaded: main_helper
INFO - 2025-11-17 08:29:25 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:29:25 --> Database Driver Class Initialized
INFO - 2025-11-17 08:29:25 --> Email Class Initialized
DEBUG - 2025-11-17 08:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:29:25 --> Controller Class Initialized
INFO - 2025-11-17 08:29:25 --> Model "Subscription_model" initialized
INFO - 2025-11-17 08:29:25 --> Model "User_model" initialized
INFO - 2025-11-17 08:29:25 --> Model "Auth_model" initialized
INFO - 2025-11-17 08:29:25 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 08:29:25 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 08:29:25 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 08:29:25 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 08:29:25 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 08:29:25 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 08:29:25 --> Final output sent to browser
INFO - 2025-11-17 08:29:25 --> Total execution time: 0.1049
INFO - 2025-11-17 08:29:46 --> Config Class Initialized
INFO - 2025-11-17 08:29:46 --> Hooks Class Initialized
INFO - 2025-11-17 08:29:46 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:29:46 --> Utf8 Class Initialized
INFO - 2025-11-17 08:29:46 --> URI Class Initialized
INFO - 2025-11-17 08:29:46 --> Router Class Initialized
INFO - 2025-11-17 08:29:46 --> Output Class Initialized
INFO - 2025-11-17 08:29:46 --> Security Class Initialized
INFO - 2025-11-17 08:29:46 --> Input Class Initialized
INFO - 2025-11-17 08:29:46 --> Language Class Initialized
INFO - 2025-11-17 08:29:47 --> Loader Class Initialized
INFO - 2025-11-17 08:29:47 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:29:47 --> Helper loaded: url_helper
INFO - 2025-11-17 08:29:47 --> Helper loaded: file_helper
INFO - 2025-11-17 08:29:47 --> Helper loaded: main_helper
INFO - 2025-11-17 08:29:47 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:29:47 --> Database Driver Class Initialized
INFO - 2025-11-17 08:29:47 --> Email Class Initialized
DEBUG - 2025-11-17 08:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:29:47 --> Controller Class Initialized
INFO - 2025-11-17 08:29:47 --> Model "Subscription_model" initialized
INFO - 2025-11-17 08:29:47 --> Model "User_model" initialized
INFO - 2025-11-17 08:29:47 --> Model "Auth_model" initialized
INFO - 2025-11-17 08:29:47 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 08:29:47 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 08:29:47 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 08:29:47 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 08:29:47 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 08:29:47 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 08:29:47 --> Final output sent to browser
INFO - 2025-11-17 08:29:47 --> Total execution time: 0.1076
INFO - 2025-11-17 08:30:45 --> Config Class Initialized
INFO - 2025-11-17 08:30:45 --> Hooks Class Initialized
INFO - 2025-11-17 08:30:45 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:30:45 --> Utf8 Class Initialized
INFO - 2025-11-17 08:30:45 --> URI Class Initialized
INFO - 2025-11-17 08:30:45 --> Router Class Initialized
INFO - 2025-11-17 08:30:45 --> Output Class Initialized
INFO - 2025-11-17 08:30:45 --> Security Class Initialized
INFO - 2025-11-17 08:30:45 --> Input Class Initialized
INFO - 2025-11-17 08:30:45 --> Language Class Initialized
INFO - 2025-11-17 08:30:45 --> Loader Class Initialized
INFO - 2025-11-17 08:30:45 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:30:45 --> Helper loaded: url_helper
INFO - 2025-11-17 08:30:45 --> Helper loaded: file_helper
INFO - 2025-11-17 08:30:45 --> Helper loaded: main_helper
INFO - 2025-11-17 08:30:45 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:30:45 --> Database Driver Class Initialized
INFO - 2025-11-17 08:30:45 --> Email Class Initialized
DEBUG - 2025-11-17 08:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:30:45 --> Controller Class Initialized
INFO - 2025-11-17 08:30:45 --> Model "Subscription_model" initialized
INFO - 2025-11-17 08:30:45 --> Model "User_model" initialized
INFO - 2025-11-17 08:30:45 --> Model "Auth_model" initialized
INFO - 2025-11-17 08:30:45 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 08:30:45 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 08:30:45 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
ERROR - 2025-11-17 08:30:45 --> Severity: Warning --> Undefined property: stdClass::$total_price D:\laragon\www\acumena\application\views\subscriptions\index.php 59
ERROR - 2025-11-17 08:30:45 --> Severity: Deprecated Notice --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated D:\laragon\www\acumena\application\views\subscriptions\index.php 59
INFO - 2025-11-17 08:30:45 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 08:30:45 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 08:30:45 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 08:30:45 --> Final output sent to browser
INFO - 2025-11-17 08:30:45 --> Total execution time: 0.1353
INFO - 2025-11-17 08:31:19 --> Config Class Initialized
INFO - 2025-11-17 08:31:19 --> Hooks Class Initialized
INFO - 2025-11-17 08:31:19 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:31:19 --> Utf8 Class Initialized
INFO - 2025-11-17 08:31:19 --> URI Class Initialized
INFO - 2025-11-17 08:31:19 --> Router Class Initialized
INFO - 2025-11-17 08:31:19 --> Output Class Initialized
INFO - 2025-11-17 08:31:19 --> Security Class Initialized
INFO - 2025-11-17 08:31:19 --> Input Class Initialized
INFO - 2025-11-17 08:31:19 --> Language Class Initialized
INFO - 2025-11-17 08:31:19 --> Loader Class Initialized
INFO - 2025-11-17 08:31:19 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:31:19 --> Helper loaded: url_helper
INFO - 2025-11-17 08:31:19 --> Helper loaded: file_helper
INFO - 2025-11-17 08:31:19 --> Helper loaded: main_helper
INFO - 2025-11-17 08:31:19 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:31:19 --> Database Driver Class Initialized
INFO - 2025-11-17 08:31:19 --> Email Class Initialized
DEBUG - 2025-11-17 08:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:31:19 --> Controller Class Initialized
INFO - 2025-11-17 08:31:19 --> Model "Subscription_model" initialized
INFO - 2025-11-17 08:31:19 --> Model "User_model" initialized
INFO - 2025-11-17 08:31:19 --> Model "Auth_model" initialized
INFO - 2025-11-17 08:31:19 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 08:31:19 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 08:31:19 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 08:31:19 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 08:31:19 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 08:31:19 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 08:31:19 --> Final output sent to browser
INFO - 2025-11-17 08:31:19 --> Total execution time: 0.0947
INFO - 2025-11-17 08:41:54 --> Config Class Initialized
INFO - 2025-11-17 08:41:54 --> Hooks Class Initialized
INFO - 2025-11-17 08:41:55 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:41:55 --> Utf8 Class Initialized
INFO - 2025-11-17 08:41:55 --> URI Class Initialized
INFO - 2025-11-17 08:41:55 --> Router Class Initialized
INFO - 2025-11-17 08:41:55 --> Output Class Initialized
INFO - 2025-11-17 08:41:55 --> Security Class Initialized
INFO - 2025-11-17 08:41:55 --> Input Class Initialized
INFO - 2025-11-17 08:41:55 --> Language Class Initialized
INFO - 2025-11-17 08:41:55 --> Loader Class Initialized
INFO - 2025-11-17 08:41:55 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:41:56 --> Helper loaded: url_helper
INFO - 2025-11-17 08:41:56 --> Helper loaded: file_helper
INFO - 2025-11-17 08:41:56 --> Helper loaded: main_helper
INFO - 2025-11-17 08:41:56 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:41:56 --> Database Driver Class Initialized
INFO - 2025-11-17 08:41:56 --> Email Class Initialized
DEBUG - 2025-11-17 08:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:41:56 --> Controller Class Initialized
INFO - 2025-11-17 08:41:57 --> Model "Subscription_model" initialized
INFO - 2025-11-17 08:41:57 --> Model "User_model" initialized
INFO - 2025-11-17 08:41:57 --> Model "Auth_model" initialized
INFO - 2025-11-17 08:41:57 --> Model "Project_model" initialized
INFO - 2025-11-17 08:41:57 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 08:41:57 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 08:41:57 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 08:41:57 --> File loaded: D:\laragon\www\acumena\application\views\projects/index.php
INFO - 2025-11-17 08:41:57 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 08:41:57 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 08:41:57 --> Final output sent to browser
INFO - 2025-11-17 08:41:57 --> Total execution time: 2.9713
INFO - 2025-11-17 08:41:57 --> Config Class Initialized
INFO - 2025-11-17 08:41:57 --> Hooks Class Initialized
INFO - 2025-11-17 08:41:57 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:41:57 --> Utf8 Class Initialized
INFO - 2025-11-17 08:41:57 --> URI Class Initialized
INFO - 2025-11-17 08:41:57 --> Router Class Initialized
INFO - 2025-11-17 08:41:57 --> Output Class Initialized
INFO - 2025-11-17 08:41:57 --> Security Class Initialized
INFO - 2025-11-17 08:41:57 --> Input Class Initialized
INFO - 2025-11-17 08:41:57 --> Language Class Initialized
INFO - 2025-11-17 08:41:57 --> Loader Class Initialized
INFO - 2025-11-17 08:41:57 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:41:57 --> Helper loaded: url_helper
INFO - 2025-11-17 08:41:57 --> Helper loaded: file_helper
INFO - 2025-11-17 08:41:57 --> Helper loaded: main_helper
INFO - 2025-11-17 08:41:57 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:41:57 --> Database Driver Class Initialized
INFO - 2025-11-17 08:41:57 --> Email Class Initialized
DEBUG - 2025-11-17 08:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:41:57 --> Controller Class Initialized
INFO - 2025-11-17 08:41:57 --> Model "User_model" initialized
INFO - 2025-11-17 08:41:57 --> Model "Project_model" initialized
INFO - 2025-11-17 08:41:57 --> Helper loaded: form_helper
INFO - 2025-11-17 08:41:57 --> Form Validation Class Initialized
INFO - 2025-11-17 08:41:58 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 08:41:58 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 08:41:58 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 08:41:58 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:41:58 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:41:58 --> Model "Topk_service_model" initialized
INFO - 2025-11-17 08:41:58 --> Final output sent to browser
INFO - 2025-11-17 08:41:58 --> Total execution time: 0.4897
INFO - 2025-11-17 08:42:01 --> Config Class Initialized
INFO - 2025-11-17 08:42:01 --> Hooks Class Initialized
INFO - 2025-11-17 08:42:01 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:42:01 --> Utf8 Class Initialized
INFO - 2025-11-17 08:42:01 --> URI Class Initialized
INFO - 2025-11-17 08:42:01 --> Router Class Initialized
INFO - 2025-11-17 08:42:01 --> Output Class Initialized
INFO - 2025-11-17 08:42:01 --> Security Class Initialized
INFO - 2025-11-17 08:42:01 --> Input Class Initialized
INFO - 2025-11-17 08:42:01 --> Language Class Initialized
INFO - 2025-11-17 08:42:01 --> Loader Class Initialized
INFO - 2025-11-17 08:42:01 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:42:01 --> Helper loaded: url_helper
INFO - 2025-11-17 08:42:01 --> Helper loaded: file_helper
INFO - 2025-11-17 08:42:01 --> Helper loaded: main_helper
INFO - 2025-11-17 08:42:01 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:42:01 --> Database Driver Class Initialized
INFO - 2025-11-17 08:42:01 --> Email Class Initialized
DEBUG - 2025-11-17 08:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:42:01 --> Controller Class Initialized
INFO - 2025-11-17 08:42:01 --> Model "Subscription_model" initialized
INFO - 2025-11-17 08:42:01 --> Model "User_model" initialized
INFO - 2025-11-17 08:42:01 --> Model "Auth_model" initialized
INFO - 2025-11-17 08:42:01 --> Model "Project_model" initialized
INFO - 2025-11-17 08:42:01 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 08:42:01 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 08:42:01 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 08:42:02 --> File loaded: D:\laragon\www\acumena\application\views\projects/profile.php
INFO - 2025-11-17 08:42:02 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 08:42:02 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 08:42:02 --> Final output sent to browser
INFO - 2025-11-17 08:42:02 --> Total execution time: 0.1434
INFO - 2025-11-17 08:42:02 --> Config Class Initialized
INFO - 2025-11-17 08:42:02 --> Hooks Class Initialized
INFO - 2025-11-17 08:42:02 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:42:02 --> Utf8 Class Initialized
INFO - 2025-11-17 08:42:02 --> URI Class Initialized
INFO - 2025-11-17 08:42:02 --> Router Class Initialized
INFO - 2025-11-17 08:42:02 --> Output Class Initialized
INFO - 2025-11-17 08:42:02 --> Security Class Initialized
INFO - 2025-11-17 08:42:02 --> Input Class Initialized
INFO - 2025-11-17 08:42:02 --> Language Class Initialized
INFO - 2025-11-17 08:42:02 --> Loader Class Initialized
INFO - 2025-11-17 08:42:02 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:42:02 --> Helper loaded: url_helper
INFO - 2025-11-17 08:42:02 --> Helper loaded: file_helper
INFO - 2025-11-17 08:42:02 --> Helper loaded: main_helper
INFO - 2025-11-17 08:42:02 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:42:02 --> Database Driver Class Initialized
INFO - 2025-11-17 08:42:02 --> Email Class Initialized
DEBUG - 2025-11-17 08:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:42:02 --> Controller Class Initialized
INFO - 2025-11-17 08:42:02 --> Model "User_model" initialized
INFO - 2025-11-17 08:42:02 --> Model "Project_model" initialized
INFO - 2025-11-17 08:42:02 --> Helper loaded: form_helper
INFO - 2025-11-17 08:42:02 --> Form Validation Class Initialized
INFO - 2025-11-17 08:42:02 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 08:42:02 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 08:42:02 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 08:42:02 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:42:02 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:42:02 --> Model "Topk_service_model" initialized
INFO - 2025-11-17 08:42:02 --> Final output sent to browser
INFO - 2025-11-17 08:42:02 --> Total execution time: 0.0840
INFO - 2025-11-17 08:42:43 --> Config Class Initialized
INFO - 2025-11-17 08:42:43 --> Hooks Class Initialized
INFO - 2025-11-17 08:42:43 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:42:43 --> Utf8 Class Initialized
INFO - 2025-11-17 08:42:43 --> URI Class Initialized
INFO - 2025-11-17 08:42:43 --> Router Class Initialized
INFO - 2025-11-17 08:42:43 --> Output Class Initialized
INFO - 2025-11-17 08:42:43 --> Security Class Initialized
INFO - 2025-11-17 08:42:43 --> Input Class Initialized
INFO - 2025-11-17 08:42:43 --> Language Class Initialized
INFO - 2025-11-17 08:42:43 --> Loader Class Initialized
INFO - 2025-11-17 08:42:43 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:42:43 --> Helper loaded: url_helper
INFO - 2025-11-17 08:42:43 --> Helper loaded: file_helper
INFO - 2025-11-17 08:42:43 --> Helper loaded: main_helper
INFO - 2025-11-17 08:42:43 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:42:43 --> Database Driver Class Initialized
INFO - 2025-11-17 08:42:43 --> Email Class Initialized
DEBUG - 2025-11-17 08:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:42:43 --> Controller Class Initialized
INFO - 2025-11-17 08:42:43 --> Model "User_model" initialized
INFO - 2025-11-17 08:42:43 --> Model "Project_model" initialized
INFO - 2025-11-17 08:42:43 --> Helper loaded: form_helper
INFO - 2025-11-17 08:42:43 --> Form Validation Class Initialized
INFO - 2025-11-17 08:42:43 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 08:42:43 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 08:42:43 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 08:42:43 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:42:43 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:42:43 --> Model "Topk_service_model" initialized
INFO - 2025-11-17 08:42:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-11-17 08:42:43 --> Final output sent to browser
INFO - 2025-11-17 08:42:43 --> Total execution time: 0.1378
INFO - 2025-11-17 08:42:43 --> Config Class Initialized
INFO - 2025-11-17 08:42:43 --> Hooks Class Initialized
INFO - 2025-11-17 08:42:43 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:42:43 --> Utf8 Class Initialized
INFO - 2025-11-17 08:42:43 --> URI Class Initialized
INFO - 2025-11-17 08:42:43 --> Router Class Initialized
INFO - 2025-11-17 08:42:43 --> Output Class Initialized
INFO - 2025-11-17 08:42:43 --> Security Class Initialized
INFO - 2025-11-17 08:42:43 --> Input Class Initialized
INFO - 2025-11-17 08:42:43 --> Language Class Initialized
INFO - 2025-11-17 08:42:43 --> Loader Class Initialized
INFO - 2025-11-17 08:42:43 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:42:43 --> Helper loaded: url_helper
INFO - 2025-11-17 08:42:43 --> Helper loaded: file_helper
INFO - 2025-11-17 08:42:43 --> Helper loaded: main_helper
INFO - 2025-11-17 08:42:43 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:42:43 --> Database Driver Class Initialized
INFO - 2025-11-17 08:42:43 --> Email Class Initialized
DEBUG - 2025-11-17 08:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:42:43 --> Controller Class Initialized
INFO - 2025-11-17 08:42:43 --> Model "Subscription_model" initialized
INFO - 2025-11-17 08:42:43 --> Model "User_model" initialized
INFO - 2025-11-17 08:42:43 --> Model "Auth_model" initialized
INFO - 2025-11-17 08:42:43 --> Model "Project_model" initialized
INFO - 2025-11-17 08:42:43 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 08:42:43 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 08:42:43 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 08:42:43 --> File loaded: D:\laragon\www\acumena\application\views\projects/swot.php
INFO - 2025-11-17 08:42:43 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 08:42:43 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 08:42:43 --> Final output sent to browser
INFO - 2025-11-17 08:42:43 --> Total execution time: 0.1628
INFO - 2025-11-17 08:42:43 --> Config Class Initialized
INFO - 2025-11-17 08:42:43 --> Hooks Class Initialized
INFO - 2025-11-17 08:42:43 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:42:43 --> Utf8 Class Initialized
INFO - 2025-11-17 08:42:43 --> URI Class Initialized
INFO - 2025-11-17 08:42:43 --> Router Class Initialized
INFO - 2025-11-17 08:42:43 --> Output Class Initialized
INFO - 2025-11-17 08:42:43 --> Security Class Initialized
INFO - 2025-11-17 08:42:43 --> Input Class Initialized
INFO - 2025-11-17 08:42:43 --> Language Class Initialized
INFO - 2025-11-17 08:42:43 --> Loader Class Initialized
INFO - 2025-11-17 08:42:43 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:42:43 --> Helper loaded: url_helper
INFO - 2025-11-17 08:42:43 --> Helper loaded: file_helper
INFO - 2025-11-17 08:42:43 --> Helper loaded: main_helper
INFO - 2025-11-17 08:42:43 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:42:43 --> Database Driver Class Initialized
INFO - 2025-11-17 08:42:43 --> Email Class Initialized
DEBUG - 2025-11-17 08:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:42:43 --> Controller Class Initialized
INFO - 2025-11-17 08:42:43 --> Model "User_model" initialized
INFO - 2025-11-17 08:42:43 --> Model "Project_model" initialized
INFO - 2025-11-17 08:42:43 --> Helper loaded: form_helper
INFO - 2025-11-17 08:42:43 --> Form Validation Class Initialized
INFO - 2025-11-17 08:42:43 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 08:42:43 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 08:42:43 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 08:42:43 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:42:43 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:42:43 --> Model "Topk_service_model" initialized
INFO - 2025-11-17 08:42:43 --> Final output sent to browser
INFO - 2025-11-17 08:42:43 --> Total execution time: 0.0699
INFO - 2025-11-17 08:42:48 --> Config Class Initialized
INFO - 2025-11-17 08:42:48 --> Hooks Class Initialized
INFO - 2025-11-17 08:42:48 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:42:48 --> Utf8 Class Initialized
INFO - 2025-11-17 08:42:48 --> URI Class Initialized
INFO - 2025-11-17 08:42:48 --> Router Class Initialized
INFO - 2025-11-17 08:42:48 --> Output Class Initialized
INFO - 2025-11-17 08:42:48 --> Security Class Initialized
INFO - 2025-11-17 08:42:48 --> Input Class Initialized
INFO - 2025-11-17 08:42:48 --> Language Class Initialized
INFO - 2025-11-17 08:42:48 --> Loader Class Initialized
INFO - 2025-11-17 08:42:48 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:42:48 --> Helper loaded: url_helper
INFO - 2025-11-17 08:42:48 --> Helper loaded: file_helper
INFO - 2025-11-17 08:42:48 --> Helper loaded: main_helper
INFO - 2025-11-17 08:42:48 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:42:48 --> Database Driver Class Initialized
INFO - 2025-11-17 08:42:48 --> Email Class Initialized
DEBUG - 2025-11-17 08:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:42:48 --> Controller Class Initialized
INFO - 2025-11-17 08:42:48 --> Model "User_model" initialized
INFO - 2025-11-17 08:42:48 --> Model "Project_model" initialized
INFO - 2025-11-17 08:42:48 --> Helper loaded: form_helper
INFO - 2025-11-17 08:42:48 --> Form Validation Class Initialized
INFO - 2025-11-17 08:42:48 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 08:42:48 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 08:42:48 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 08:42:48 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:42:48 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:42:48 --> Model "Topk_service_model" initialized
INFO - 2025-11-17 08:42:48 --> Final output sent to browser
INFO - 2025-11-17 08:42:48 --> Total execution time: 0.1127
INFO - 2025-11-17 08:42:48 --> Config Class Initialized
INFO - 2025-11-17 08:42:48 --> Hooks Class Initialized
INFO - 2025-11-17 08:42:48 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:42:48 --> Utf8 Class Initialized
INFO - 2025-11-17 08:42:48 --> URI Class Initialized
INFO - 2025-11-17 08:42:48 --> Router Class Initialized
INFO - 2025-11-17 08:42:48 --> Output Class Initialized
INFO - 2025-11-17 08:42:48 --> Security Class Initialized
INFO - 2025-11-17 08:42:48 --> Input Class Initialized
INFO - 2025-11-17 08:42:48 --> Language Class Initialized
INFO - 2025-11-17 08:42:48 --> Loader Class Initialized
INFO - 2025-11-17 08:42:48 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:42:48 --> Helper loaded: url_helper
INFO - 2025-11-17 08:42:48 --> Helper loaded: file_helper
INFO - 2025-11-17 08:42:48 --> Helper loaded: main_helper
INFO - 2025-11-17 08:42:48 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:42:48 --> Database Driver Class Initialized
INFO - 2025-11-17 08:42:48 --> Email Class Initialized
DEBUG - 2025-11-17 08:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:42:48 --> Controller Class Initialized
INFO - 2025-11-17 08:42:48 --> Model "Subscription_model" initialized
INFO - 2025-11-17 08:42:48 --> Model "User_model" initialized
INFO - 2025-11-17 08:42:48 --> Model "Auth_model" initialized
INFO - 2025-11-17 08:42:48 --> Model "Project_model" initialized
INFO - 2025-11-17 08:42:48 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 08:42:48 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 08:42:48 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 08:42:48 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ife.php
INFO - 2025-11-17 08:42:48 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 08:42:48 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 08:42:48 --> Final output sent to browser
INFO - 2025-11-17 08:42:48 --> Total execution time: 0.1768
INFO - 2025-11-17 08:42:48 --> Config Class Initialized
INFO - 2025-11-17 08:42:48 --> Hooks Class Initialized
INFO - 2025-11-17 08:42:48 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:42:48 --> Utf8 Class Initialized
INFO - 2025-11-17 08:42:48 --> URI Class Initialized
INFO - 2025-11-17 08:42:48 --> Router Class Initialized
INFO - 2025-11-17 08:42:48 --> Output Class Initialized
INFO - 2025-11-17 08:42:48 --> Security Class Initialized
INFO - 2025-11-17 08:42:48 --> Input Class Initialized
INFO - 2025-11-17 08:42:48 --> Language Class Initialized
INFO - 2025-11-17 08:42:48 --> Loader Class Initialized
INFO - 2025-11-17 08:42:48 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:42:48 --> Helper loaded: url_helper
INFO - 2025-11-17 08:42:48 --> Helper loaded: file_helper
INFO - 2025-11-17 08:42:48 --> Helper loaded: main_helper
INFO - 2025-11-17 08:42:48 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:42:48 --> Database Driver Class Initialized
INFO - 2025-11-17 08:42:48 --> Email Class Initialized
DEBUG - 2025-11-17 08:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:42:48 --> Controller Class Initialized
INFO - 2025-11-17 08:42:48 --> Model "User_model" initialized
INFO - 2025-11-17 08:42:48 --> Model "Project_model" initialized
INFO - 2025-11-17 08:42:48 --> Helper loaded: form_helper
INFO - 2025-11-17 08:42:48 --> Form Validation Class Initialized
INFO - 2025-11-17 08:42:48 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 08:42:48 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 08:42:48 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 08:42:48 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:42:48 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:42:48 --> Model "Topk_service_model" initialized
INFO - 2025-11-17 08:42:48 --> Final output sent to browser
INFO - 2025-11-17 08:42:48 --> Total execution time: 0.2431
INFO - 2025-11-17 08:43:02 --> Config Class Initialized
INFO - 2025-11-17 08:43:02 --> Hooks Class Initialized
INFO - 2025-11-17 08:43:02 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:43:02 --> Utf8 Class Initialized
INFO - 2025-11-17 08:43:02 --> URI Class Initialized
INFO - 2025-11-17 08:43:02 --> Router Class Initialized
INFO - 2025-11-17 08:43:02 --> Output Class Initialized
INFO - 2025-11-17 08:43:03 --> Security Class Initialized
INFO - 2025-11-17 08:43:03 --> Input Class Initialized
INFO - 2025-11-17 08:43:03 --> Language Class Initialized
INFO - 2025-11-17 08:43:03 --> Loader Class Initialized
INFO - 2025-11-17 08:43:03 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:43:03 --> Helper loaded: url_helper
INFO - 2025-11-17 08:43:03 --> Helper loaded: file_helper
INFO - 2025-11-17 08:43:03 --> Helper loaded: main_helper
INFO - 2025-11-17 08:43:03 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:43:03 --> Database Driver Class Initialized
INFO - 2025-11-17 08:43:03 --> Email Class Initialized
DEBUG - 2025-11-17 08:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:43:03 --> Controller Class Initialized
INFO - 2025-11-17 08:43:03 --> Model "User_model" initialized
INFO - 2025-11-17 08:43:03 --> Model "Project_model" initialized
INFO - 2025-11-17 08:43:03 --> Helper loaded: form_helper
INFO - 2025-11-17 08:43:03 --> Form Validation Class Initialized
INFO - 2025-11-17 08:43:03 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 08:43:03 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 08:43:03 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 08:43:03 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:43:03 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:43:03 --> Model "Topk_service_model" initialized
INFO - 2025-11-17 08:43:03 --> Final output sent to browser
INFO - 2025-11-17 08:43:03 --> Total execution time: 0.1089
INFO - 2025-11-17 08:43:03 --> Config Class Initialized
INFO - 2025-11-17 08:43:03 --> Hooks Class Initialized
INFO - 2025-11-17 08:43:03 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:43:03 --> Utf8 Class Initialized
INFO - 2025-11-17 08:43:03 --> URI Class Initialized
INFO - 2025-11-17 08:43:03 --> Router Class Initialized
INFO - 2025-11-17 08:43:03 --> Output Class Initialized
INFO - 2025-11-17 08:43:03 --> Security Class Initialized
INFO - 2025-11-17 08:43:03 --> Input Class Initialized
INFO - 2025-11-17 08:43:03 --> Language Class Initialized
INFO - 2025-11-17 08:43:03 --> Loader Class Initialized
INFO - 2025-11-17 08:43:03 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:43:03 --> Helper loaded: url_helper
INFO - 2025-11-17 08:43:03 --> Helper loaded: file_helper
INFO - 2025-11-17 08:43:03 --> Helper loaded: main_helper
INFO - 2025-11-17 08:43:03 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:43:03 --> Database Driver Class Initialized
INFO - 2025-11-17 08:43:03 --> Email Class Initialized
DEBUG - 2025-11-17 08:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:43:03 --> Controller Class Initialized
INFO - 2025-11-17 08:43:03 --> Model "Subscription_model" initialized
INFO - 2025-11-17 08:43:03 --> Model "User_model" initialized
INFO - 2025-11-17 08:43:03 --> Model "Auth_model" initialized
INFO - 2025-11-17 08:43:03 --> Model "Project_model" initialized
INFO - 2025-11-17 08:43:03 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 08:43:03 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 08:43:03 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 08:43:03 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-efe.php
INFO - 2025-11-17 08:43:03 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 08:43:03 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 08:43:03 --> Final output sent to browser
INFO - 2025-11-17 08:43:03 --> Total execution time: 0.2066
INFO - 2025-11-17 08:43:03 --> Config Class Initialized
INFO - 2025-11-17 08:43:03 --> Hooks Class Initialized
INFO - 2025-11-17 08:43:03 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:43:03 --> Utf8 Class Initialized
INFO - 2025-11-17 08:43:03 --> URI Class Initialized
INFO - 2025-11-17 08:43:03 --> Router Class Initialized
INFO - 2025-11-17 08:43:03 --> Output Class Initialized
INFO - 2025-11-17 08:43:03 --> Security Class Initialized
INFO - 2025-11-17 08:43:03 --> Input Class Initialized
INFO - 2025-11-17 08:43:03 --> Language Class Initialized
INFO - 2025-11-17 08:43:03 --> Loader Class Initialized
INFO - 2025-11-17 08:43:03 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:43:03 --> Helper loaded: url_helper
INFO - 2025-11-17 08:43:03 --> Helper loaded: file_helper
INFO - 2025-11-17 08:43:03 --> Helper loaded: main_helper
INFO - 2025-11-17 08:43:03 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:43:03 --> Database Driver Class Initialized
INFO - 2025-11-17 08:43:03 --> Email Class Initialized
DEBUG - 2025-11-17 08:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:43:03 --> Controller Class Initialized
INFO - 2025-11-17 08:43:03 --> Model "User_model" initialized
INFO - 2025-11-17 08:43:03 --> Model "Project_model" initialized
INFO - 2025-11-17 08:43:03 --> Helper loaded: form_helper
INFO - 2025-11-17 08:43:03 --> Form Validation Class Initialized
INFO - 2025-11-17 08:43:03 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 08:43:03 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 08:43:03 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 08:43:03 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:43:03 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:43:03 --> Model "Topk_service_model" initialized
INFO - 2025-11-17 08:43:03 --> Final output sent to browser
INFO - 2025-11-17 08:43:03 --> Total execution time: 0.1021
INFO - 2025-11-17 08:43:09 --> Config Class Initialized
INFO - 2025-11-17 08:43:09 --> Hooks Class Initialized
INFO - 2025-11-17 08:43:09 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:43:09 --> Utf8 Class Initialized
INFO - 2025-11-17 08:43:09 --> URI Class Initialized
INFO - 2025-11-17 08:43:09 --> Router Class Initialized
INFO - 2025-11-17 08:43:09 --> Output Class Initialized
INFO - 2025-11-17 08:43:09 --> Security Class Initialized
INFO - 2025-11-17 08:43:09 --> Input Class Initialized
INFO - 2025-11-17 08:43:09 --> Language Class Initialized
INFO - 2025-11-17 08:43:09 --> Loader Class Initialized
INFO - 2025-11-17 08:43:09 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:43:09 --> Helper loaded: url_helper
INFO - 2025-11-17 08:43:09 --> Helper loaded: file_helper
INFO - 2025-11-17 08:43:09 --> Helper loaded: main_helper
INFO - 2025-11-17 08:43:09 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:43:09 --> Database Driver Class Initialized
INFO - 2025-11-17 08:43:09 --> Email Class Initialized
DEBUG - 2025-11-17 08:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:43:09 --> Controller Class Initialized
INFO - 2025-11-17 08:43:09 --> Model "Subscription_model" initialized
INFO - 2025-11-17 08:43:09 --> Model "User_model" initialized
INFO - 2025-11-17 08:43:09 --> Model "Auth_model" initialized
INFO - 2025-11-17 08:43:09 --> Model "Project_model" initialized
INFO - 2025-11-17 08:43:09 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 08:43:09 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 08:43:09 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 08:43:09 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ai.php
INFO - 2025-11-17 08:43:09 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 08:43:09 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 08:43:09 --> Final output sent to browser
INFO - 2025-11-17 08:43:09 --> Total execution time: 0.1681
INFO - 2025-11-17 08:43:09 --> Config Class Initialized
INFO - 2025-11-17 08:43:09 --> Hooks Class Initialized
INFO - 2025-11-17 08:43:09 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:43:09 --> Utf8 Class Initialized
INFO - 2025-11-17 08:43:09 --> URI Class Initialized
INFO - 2025-11-17 08:43:09 --> Router Class Initialized
INFO - 2025-11-17 08:43:09 --> Output Class Initialized
INFO - 2025-11-17 08:43:09 --> Security Class Initialized
INFO - 2025-11-17 08:43:09 --> Input Class Initialized
INFO - 2025-11-17 08:43:09 --> Language Class Initialized
INFO - 2025-11-17 08:43:09 --> Loader Class Initialized
INFO - 2025-11-17 08:43:09 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:43:09 --> Helper loaded: url_helper
INFO - 2025-11-17 08:43:09 --> Helper loaded: file_helper
INFO - 2025-11-17 08:43:09 --> Helper loaded: main_helper
INFO - 2025-11-17 08:43:09 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:43:09 --> Database Driver Class Initialized
INFO - 2025-11-17 08:43:09 --> Email Class Initialized
DEBUG - 2025-11-17 08:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:43:09 --> Controller Class Initialized
INFO - 2025-11-17 08:43:09 --> Model "User_model" initialized
INFO - 2025-11-17 08:43:09 --> Model "Project_model" initialized
INFO - 2025-11-17 08:43:09 --> Helper loaded: form_helper
INFO - 2025-11-17 08:43:09 --> Form Validation Class Initialized
INFO - 2025-11-17 08:43:09 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 08:43:09 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 08:43:09 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 08:43:09 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:43:09 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:43:09 --> Model "Topk_service_model" initialized
INFO - 2025-11-17 08:43:09 --> Final output sent to browser
INFO - 2025-11-17 08:43:09 --> Total execution time: 0.0809
INFO - 2025-11-17 08:43:09 --> Config Class Initialized
INFO - 2025-11-17 08:43:09 --> Hooks Class Initialized
INFO - 2025-11-17 08:43:09 --> Config Class Initialized
INFO - 2025-11-17 08:43:09 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:43:09 --> Hooks Class Initialized
INFO - 2025-11-17 08:43:09 --> Utf8 Class Initialized
INFO - 2025-11-17 08:43:09 --> URI Class Initialized
INFO - 2025-11-17 08:43:09 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:43:09 --> Utf8 Class Initialized
INFO - 2025-11-17 08:43:09 --> Router Class Initialized
INFO - 2025-11-17 08:43:09 --> URI Class Initialized
INFO - 2025-11-17 08:43:09 --> Output Class Initialized
INFO - 2025-11-17 08:43:09 --> Router Class Initialized
INFO - 2025-11-17 08:43:09 --> Security Class Initialized
INFO - 2025-11-17 08:43:09 --> Output Class Initialized
INFO - 2025-11-17 08:43:09 --> Input Class Initialized
INFO - 2025-11-17 08:43:09 --> Language Class Initialized
INFO - 2025-11-17 08:43:09 --> Security Class Initialized
INFO - 2025-11-17 08:43:09 --> Input Class Initialized
INFO - 2025-11-17 08:43:09 --> Language Class Initialized
INFO - 2025-11-17 08:43:09 --> Loader Class Initialized
INFO - 2025-11-17 08:43:09 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:43:09 --> Loader Class Initialized
INFO - 2025-11-17 08:43:09 --> Helper loaded: url_helper
INFO - 2025-11-17 08:43:09 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:43:09 --> Helper loaded: file_helper
INFO - 2025-11-17 08:43:09 --> Helper loaded: url_helper
INFO - 2025-11-17 08:43:09 --> Helper loaded: main_helper
INFO - 2025-11-17 08:43:09 --> Helper loaded: file_helper
INFO - 2025-11-17 08:43:09 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:43:09 --> Helper loaded: main_helper
INFO - 2025-11-17 08:43:09 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:43:09 --> Database Driver Class Initialized
INFO - 2025-11-17 08:43:09 --> Database Driver Class Initialized
INFO - 2025-11-17 08:43:09 --> Email Class Initialized
DEBUG - 2025-11-17 08:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:43:09 --> Controller Class Initialized
INFO - 2025-11-17 08:43:09 --> Model "User_model" initialized
INFO - 2025-11-17 08:43:09 --> Model "Project_model" initialized
INFO - 2025-11-17 08:43:09 --> Helper loaded: form_helper
INFO - 2025-11-17 08:43:09 --> Form Validation Class Initialized
INFO - 2025-11-17 08:43:09 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 08:43:09 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 08:43:09 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 08:43:09 --> Email Class Initialized
INFO - 2025-11-17 08:43:09 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:43:09 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:43:09 --> Model "Topk_service_model" initialized
DEBUG - 2025-11-17 08:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:43:09 --> Final output sent to browser
INFO - 2025-11-17 08:43:09 --> Total execution time: 0.0682
INFO - 2025-11-17 08:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:43:09 --> Controller Class Initialized
INFO - 2025-11-17 08:43:09 --> Model "User_model" initialized
INFO - 2025-11-17 08:43:09 --> Model "Project_model" initialized
INFO - 2025-11-17 08:43:09 --> Helper loaded: form_helper
INFO - 2025-11-17 08:43:09 --> Form Validation Class Initialized
INFO - 2025-11-17 08:43:09 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 08:43:09 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 08:43:09 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 08:43:09 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:43:09 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:43:09 --> Model "Topk_service_model" initialized
INFO - 2025-11-17 08:43:09 --> Final output sent to browser
INFO - 2025-11-17 08:43:09 --> Total execution time: 0.0779
INFO - 2025-11-17 08:43:10 --> Config Class Initialized
INFO - 2025-11-17 08:43:10 --> Config Class Initialized
INFO - 2025-11-17 08:43:10 --> Hooks Class Initialized
INFO - 2025-11-17 08:43:10 --> Hooks Class Initialized
INFO - 2025-11-17 08:43:10 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:43:10 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:43:10 --> Utf8 Class Initialized
INFO - 2025-11-17 08:43:10 --> Utf8 Class Initialized
INFO - 2025-11-17 08:43:10 --> URI Class Initialized
INFO - 2025-11-17 08:43:10 --> URI Class Initialized
INFO - 2025-11-17 08:43:10 --> Router Class Initialized
INFO - 2025-11-17 08:43:10 --> Router Class Initialized
INFO - 2025-11-17 08:43:10 --> Output Class Initialized
INFO - 2025-11-17 08:43:10 --> Output Class Initialized
INFO - 2025-11-17 08:43:10 --> Security Class Initialized
INFO - 2025-11-17 08:43:10 --> Security Class Initialized
INFO - 2025-11-17 08:43:10 --> Input Class Initialized
INFO - 2025-11-17 08:43:10 --> Input Class Initialized
INFO - 2025-11-17 08:43:10 --> Language Class Initialized
INFO - 2025-11-17 08:43:10 --> Language Class Initialized
INFO - 2025-11-17 08:43:10 --> Loader Class Initialized
INFO - 2025-11-17 08:43:10 --> Loader Class Initialized
INFO - 2025-11-17 08:43:10 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:43:10 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:43:10 --> Helper loaded: url_helper
INFO - 2025-11-17 08:43:10 --> Helper loaded: url_helper
INFO - 2025-11-17 08:43:10 --> Helper loaded: file_helper
INFO - 2025-11-17 08:43:10 --> Helper loaded: file_helper
INFO - 2025-11-17 08:43:10 --> Helper loaded: main_helper
INFO - 2025-11-17 08:43:10 --> Helper loaded: main_helper
INFO - 2025-11-17 08:43:10 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:43:10 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:43:10 --> Database Driver Class Initialized
INFO - 2025-11-17 08:43:10 --> Database Driver Class Initialized
INFO - 2025-11-17 08:43:10 --> Email Class Initialized
INFO - 2025-11-17 08:43:10 --> Email Class Initialized
DEBUG - 2025-11-17 08:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-11-17 08:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:43:11 --> Controller Class Initialized
INFO - 2025-11-17 08:43:11 --> Model "User_model" initialized
INFO - 2025-11-17 08:43:11 --> Model "Project_model" initialized
INFO - 2025-11-17 08:43:11 --> Helper loaded: form_helper
INFO - 2025-11-17 08:43:11 --> Form Validation Class Initialized
INFO - 2025-11-17 08:43:11 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 08:43:11 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 08:43:11 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 08:43:11 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:43:11 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:43:11 --> Model "Topk_service_model" initialized
INFO - 2025-11-17 08:43:11 --> Final output sent to browser
INFO - 2025-11-17 08:43:11 --> Total execution time: 0.1060
INFO - 2025-11-17 08:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:43:11 --> Controller Class Initialized
INFO - 2025-11-17 08:43:11 --> Model "User_model" initialized
INFO - 2025-11-17 08:43:11 --> Model "Project_model" initialized
INFO - 2025-11-17 08:43:11 --> Helper loaded: form_helper
INFO - 2025-11-17 08:43:11 --> Form Validation Class Initialized
INFO - 2025-11-17 08:43:11 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 08:43:11 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 08:43:11 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 08:43:11 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:43:11 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:43:11 --> Model "Topk_service_model" initialized
INFO - 2025-11-17 08:43:11 --> Final output sent to browser
INFO - 2025-11-17 08:43:11 --> Total execution time: 0.1241
INFO - 2025-11-17 08:43:22 --> Config Class Initialized
INFO - 2025-11-17 08:43:22 --> Hooks Class Initialized
INFO - 2025-11-17 08:43:22 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:43:22 --> Utf8 Class Initialized
INFO - 2025-11-17 08:43:22 --> URI Class Initialized
INFO - 2025-11-17 08:43:22 --> Router Class Initialized
INFO - 2025-11-17 08:43:22 --> Output Class Initialized
INFO - 2025-11-17 08:43:22 --> Security Class Initialized
INFO - 2025-11-17 08:43:22 --> Input Class Initialized
INFO - 2025-11-17 08:43:22 --> Language Class Initialized
INFO - 2025-11-17 08:43:22 --> Loader Class Initialized
INFO - 2025-11-17 08:43:22 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:43:22 --> Helper loaded: url_helper
INFO - 2025-11-17 08:43:22 --> Helper loaded: file_helper
INFO - 2025-11-17 08:43:22 --> Helper loaded: main_helper
INFO - 2025-11-17 08:43:22 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:43:22 --> Database Driver Class Initialized
INFO - 2025-11-17 08:43:22 --> Email Class Initialized
DEBUG - 2025-11-17 08:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:43:22 --> Controller Class Initialized
INFO - 2025-11-17 08:43:22 --> Model "User_model" initialized
INFO - 2025-11-17 08:43:22 --> Model "Project_model" initialized
INFO - 2025-11-17 08:43:22 --> Helper loaded: form_helper
INFO - 2025-11-17 08:43:22 --> Form Validation Class Initialized
INFO - 2025-11-17 08:43:22 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 08:43:22 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 08:43:22 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 08:43:22 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:43:22 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:43:22 --> Model "Topk_service_model" initialized
INFO - 2025-11-17 08:43:22 --> Final output sent to browser
INFO - 2025-11-17 08:43:22 --> Total execution time: 0.0993
INFO - 2025-11-17 08:43:22 --> Config Class Initialized
INFO - 2025-11-17 08:43:22 --> Hooks Class Initialized
INFO - 2025-11-17 08:43:22 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:43:22 --> Utf8 Class Initialized
INFO - 2025-11-17 08:43:22 --> URI Class Initialized
INFO - 2025-11-17 08:43:22 --> Router Class Initialized
INFO - 2025-11-17 08:43:22 --> Output Class Initialized
INFO - 2025-11-17 08:43:22 --> Security Class Initialized
INFO - 2025-11-17 08:43:22 --> Input Class Initialized
INFO - 2025-11-17 08:43:22 --> Language Class Initialized
INFO - 2025-11-17 08:43:22 --> Loader Class Initialized
INFO - 2025-11-17 08:43:22 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:43:22 --> Helper loaded: url_helper
INFO - 2025-11-17 08:43:22 --> Helper loaded: file_helper
INFO - 2025-11-17 08:43:22 --> Helper loaded: main_helper
INFO - 2025-11-17 08:43:22 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:43:22 --> Database Driver Class Initialized
INFO - 2025-11-17 08:43:22 --> Email Class Initialized
DEBUG - 2025-11-17 08:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:43:22 --> Controller Class Initialized
INFO - 2025-11-17 08:43:22 --> Model "User_model" initialized
INFO - 2025-11-17 08:43:22 --> Model "Project_model" initialized
INFO - 2025-11-17 08:43:22 --> Helper loaded: form_helper
INFO - 2025-11-17 08:43:22 --> Form Validation Class Initialized
INFO - 2025-11-17 08:43:22 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 08:43:22 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 08:43:22 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 08:43:22 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:43:22 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:43:22 --> Model "Topk_service_model" initialized
ERROR - 2025-11-17 08:43:30 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 267,
    "totalTokenCount": 1066,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 267
      }
    ],
    "thoughtsTokenCount": 799
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "MOAaaYr2JpPLg8UPi_nByAo"
}

ERROR - 2025-11-17 08:43:34 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 284,
    "totalTokenCount": 843,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 284
      }
    ],
    "thoughtsTokenCount": 559
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "NeAaaZj5EbutjuMP0_3L0QQ"
}

INFO - 2025-11-17 08:43:34 --> Final output sent to browser
INFO - 2025-11-17 08:43:34 --> Total execution time: 11.6575
INFO - 2025-11-17 08:43:34 --> Config Class Initialized
INFO - 2025-11-17 08:43:34 --> Hooks Class Initialized
INFO - 2025-11-17 08:43:34 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:43:34 --> Utf8 Class Initialized
INFO - 2025-11-17 08:43:34 --> URI Class Initialized
INFO - 2025-11-17 08:43:34 --> Router Class Initialized
INFO - 2025-11-17 08:43:34 --> Output Class Initialized
INFO - 2025-11-17 08:43:34 --> Security Class Initialized
INFO - 2025-11-17 08:43:34 --> Input Class Initialized
INFO - 2025-11-17 08:43:34 --> Language Class Initialized
INFO - 2025-11-17 08:43:34 --> Loader Class Initialized
INFO - 2025-11-17 08:43:34 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:43:34 --> Helper loaded: url_helper
INFO - 2025-11-17 08:43:34 --> Helper loaded: file_helper
INFO - 2025-11-17 08:43:34 --> Helper loaded: main_helper
INFO - 2025-11-17 08:43:34 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:43:34 --> Database Driver Class Initialized
INFO - 2025-11-17 08:43:34 --> Email Class Initialized
DEBUG - 2025-11-17 08:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:43:34 --> Controller Class Initialized
INFO - 2025-11-17 08:43:34 --> Model "User_model" initialized
INFO - 2025-11-17 08:43:34 --> Model "Project_model" initialized
INFO - 2025-11-17 08:43:34 --> Helper loaded: form_helper
INFO - 2025-11-17 08:43:34 --> Form Validation Class Initialized
INFO - 2025-11-17 08:43:34 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 08:43:34 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 08:43:34 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 08:43:34 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:43:34 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:43:34 --> Model "Topk_service_model" initialized
ERROR - 2025-11-17 08:43:39 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 350,
    "totalTokenCount": 1049,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 350
      }
    ],
    "thoughtsTokenCount": 699
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "OuAaaZX0GYTKjuMPxPKT8Q4"
}

ERROR - 2025-11-17 08:43:43 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 367,
    "totalTokenCount": 855,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 367
      }
    ],
    "thoughtsTokenCount": 488
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "PeAaacn9NfiYjuMPyqup4Qs"
}

ERROR - 2025-11-17 08:43:43 --> strategies error: AI tidak mengembalikan data strategi (respons kosong atau format tidak sesuai).
INFO - 2025-11-17 08:43:43 --> Final output sent to browser
INFO - 2025-11-17 08:43:43 --> Total execution time: 8.5873
INFO - 2025-11-17 08:43:59 --> Config Class Initialized
INFO - 2025-11-17 08:43:59 --> Hooks Class Initialized
INFO - 2025-11-17 08:43:59 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:43:59 --> Utf8 Class Initialized
INFO - 2025-11-17 08:43:59 --> URI Class Initialized
INFO - 2025-11-17 08:43:59 --> Router Class Initialized
INFO - 2025-11-17 08:43:59 --> Output Class Initialized
INFO - 2025-11-17 08:43:59 --> Security Class Initialized
INFO - 2025-11-17 08:43:59 --> Input Class Initialized
INFO - 2025-11-17 08:43:59 --> Language Class Initialized
INFO - 2025-11-17 08:43:59 --> Loader Class Initialized
INFO - 2025-11-17 08:43:59 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:43:59 --> Helper loaded: url_helper
INFO - 2025-11-17 08:43:59 --> Helper loaded: file_helper
INFO - 2025-11-17 08:43:59 --> Helper loaded: main_helper
INFO - 2025-11-17 08:43:59 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:43:59 --> Database Driver Class Initialized
INFO - 2025-11-17 08:43:59 --> Email Class Initialized
DEBUG - 2025-11-17 08:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:43:59 --> Controller Class Initialized
INFO - 2025-11-17 08:43:59 --> Model "User_model" initialized
INFO - 2025-11-17 08:43:59 --> Model "Project_model" initialized
INFO - 2025-11-17 08:43:59 --> Helper loaded: form_helper
INFO - 2025-11-17 08:43:59 --> Form Validation Class Initialized
INFO - 2025-11-17 08:43:59 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 08:43:59 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 08:43:59 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 08:43:59 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:43:59 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:43:59 --> Model "Topk_service_model" initialized
INFO - 2025-11-17 08:43:59 --> Final output sent to browser
INFO - 2025-11-17 08:43:59 --> Total execution time: 0.1182
INFO - 2025-11-17 08:43:59 --> Config Class Initialized
INFO - 2025-11-17 08:43:59 --> Hooks Class Initialized
INFO - 2025-11-17 08:43:59 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:43:59 --> Utf8 Class Initialized
INFO - 2025-11-17 08:43:59 --> URI Class Initialized
INFO - 2025-11-17 08:43:59 --> Router Class Initialized
INFO - 2025-11-17 08:43:59 --> Output Class Initialized
INFO - 2025-11-17 08:43:59 --> Security Class Initialized
INFO - 2025-11-17 08:43:59 --> Input Class Initialized
INFO - 2025-11-17 08:43:59 --> Language Class Initialized
INFO - 2025-11-17 08:43:59 --> Loader Class Initialized
INFO - 2025-11-17 08:43:59 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:43:59 --> Helper loaded: url_helper
INFO - 2025-11-17 08:43:59 --> Helper loaded: file_helper
INFO - 2025-11-17 08:43:59 --> Helper loaded: main_helper
INFO - 2025-11-17 08:43:59 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:43:59 --> Database Driver Class Initialized
INFO - 2025-11-17 08:43:59 --> Email Class Initialized
DEBUG - 2025-11-17 08:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:43:59 --> Controller Class Initialized
INFO - 2025-11-17 08:43:59 --> Model "User_model" initialized
INFO - 2025-11-17 08:43:59 --> Model "Project_model" initialized
INFO - 2025-11-17 08:43:59 --> Helper loaded: form_helper
INFO - 2025-11-17 08:43:59 --> Form Validation Class Initialized
INFO - 2025-11-17 08:43:59 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 08:43:59 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 08:43:59 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 08:43:59 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:43:59 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:43:59 --> Model "Topk_service_model" initialized
INFO - 2025-11-17 08:44:05 --> Final output sent to browser
INFO - 2025-11-17 08:44:05 --> Total execution time: 5.8707
INFO - 2025-11-17 08:44:05 --> Config Class Initialized
INFO - 2025-11-17 08:44:05 --> Hooks Class Initialized
INFO - 2025-11-17 08:44:05 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:44:05 --> Utf8 Class Initialized
INFO - 2025-11-17 08:44:05 --> URI Class Initialized
INFO - 2025-11-17 08:44:05 --> Router Class Initialized
INFO - 2025-11-17 08:44:05 --> Output Class Initialized
INFO - 2025-11-17 08:44:05 --> Security Class Initialized
INFO - 2025-11-17 08:44:05 --> Input Class Initialized
INFO - 2025-11-17 08:44:05 --> Language Class Initialized
INFO - 2025-11-17 08:44:05 --> Loader Class Initialized
INFO - 2025-11-17 08:44:05 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:44:05 --> Helper loaded: url_helper
INFO - 2025-11-17 08:44:05 --> Helper loaded: file_helper
INFO - 2025-11-17 08:44:05 --> Helper loaded: main_helper
INFO - 2025-11-17 08:44:05 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:44:05 --> Database Driver Class Initialized
INFO - 2025-11-17 08:44:05 --> Email Class Initialized
DEBUG - 2025-11-17 08:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:44:05 --> Controller Class Initialized
INFO - 2025-11-17 08:44:05 --> Model "User_model" initialized
INFO - 2025-11-17 08:44:05 --> Model "Project_model" initialized
INFO - 2025-11-17 08:44:05 --> Helper loaded: form_helper
INFO - 2025-11-17 08:44:05 --> Form Validation Class Initialized
INFO - 2025-11-17 08:44:05 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 08:44:05 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 08:44:05 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 08:44:05 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:44:05 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:44:05 --> Model "Topk_service_model" initialized
ERROR - 2025-11-17 08:44:11 --> Gemini API request error: Server error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `503 Service Unavailable` response:
{
  "error": {
    "code": 503,
    "message": "The model is overloaded. Please try again later.",
    "status": "UNAVAI (truncated...)

ERROR - 2025-11-17 08:44:15 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 352,
    "totalTokenCount": 1051,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 352
      }
    ],
    "thoughtsTokenCount": 699
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "XuAaafaeIKGAg8UPhoTokQ8"
}

ERROR - 2025-11-17 08:44:15 --> strategies error: AI tidak mengembalikan data strategi (respons kosong atau format tidak sesuai).
INFO - 2025-11-17 08:44:15 --> Final output sent to browser
INFO - 2025-11-17 08:44:15 --> Total execution time: 10.2550
INFO - 2025-11-17 08:44:35 --> Config Class Initialized
INFO - 2025-11-17 08:44:35 --> Hooks Class Initialized
INFO - 2025-11-17 08:44:35 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:44:35 --> Utf8 Class Initialized
INFO - 2025-11-17 08:44:35 --> URI Class Initialized
INFO - 2025-11-17 08:44:35 --> Router Class Initialized
INFO - 2025-11-17 08:44:35 --> Output Class Initialized
INFO - 2025-11-17 08:44:35 --> Security Class Initialized
INFO - 2025-11-17 08:44:35 --> Input Class Initialized
INFO - 2025-11-17 08:44:35 --> Language Class Initialized
INFO - 2025-11-17 08:44:35 --> Loader Class Initialized
INFO - 2025-11-17 08:44:35 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:44:35 --> Helper loaded: url_helper
INFO - 2025-11-17 08:44:35 --> Helper loaded: file_helper
INFO - 2025-11-17 08:44:35 --> Helper loaded: main_helper
INFO - 2025-11-17 08:44:35 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:44:35 --> Database Driver Class Initialized
INFO - 2025-11-17 08:44:35 --> Email Class Initialized
DEBUG - 2025-11-17 08:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:44:35 --> Controller Class Initialized
INFO - 2025-11-17 08:44:35 --> Model "Subscription_model" initialized
INFO - 2025-11-17 08:44:35 --> Model "User_model" initialized
INFO - 2025-11-17 08:44:35 --> Model "Auth_model" initialized
INFO - 2025-11-17 08:44:35 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 08:44:36 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 08:44:36 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 08:44:36 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 08:44:36 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 08:44:36 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 08:44:36 --> Final output sent to browser
INFO - 2025-11-17 08:44:36 --> Total execution time: 0.1016
INFO - 2025-11-17 08:44:46 --> Config Class Initialized
INFO - 2025-11-17 08:44:46 --> Hooks Class Initialized
INFO - 2025-11-17 08:44:46 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:44:46 --> Utf8 Class Initialized
INFO - 2025-11-17 08:44:46 --> URI Class Initialized
INFO - 2025-11-17 08:44:46 --> Router Class Initialized
INFO - 2025-11-17 08:44:46 --> Output Class Initialized
INFO - 2025-11-17 08:44:46 --> Security Class Initialized
INFO - 2025-11-17 08:44:46 --> Input Class Initialized
INFO - 2025-11-17 08:44:46 --> Language Class Initialized
INFO - 2025-11-17 08:44:46 --> Loader Class Initialized
INFO - 2025-11-17 08:44:46 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:44:46 --> Helper loaded: url_helper
INFO - 2025-11-17 08:44:46 --> Helper loaded: file_helper
INFO - 2025-11-17 08:44:46 --> Helper loaded: main_helper
INFO - 2025-11-17 08:44:46 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:44:46 --> Database Driver Class Initialized
INFO - 2025-11-17 08:44:46 --> Email Class Initialized
DEBUG - 2025-11-17 08:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:44:46 --> Controller Class Initialized
INFO - 2025-11-17 08:44:46 --> Model "Subscription_model" initialized
INFO - 2025-11-17 08:44:46 --> Model "User_model" initialized
INFO - 2025-11-17 08:44:46 --> Model "Auth_model" initialized
INFO - 2025-11-17 08:44:46 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 08:44:46 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 08:44:46 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 08:44:46 --> File loaded: D:\laragon\www\acumena\application\views\dashboard.php
INFO - 2025-11-17 08:44:46 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 08:44:46 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 08:44:46 --> Final output sent to browser
INFO - 2025-11-17 08:44:46 --> Total execution time: 0.1795
INFO - 2025-11-17 08:44:46 --> Config Class Initialized
INFO - 2025-11-17 08:44:46 --> Hooks Class Initialized
INFO - 2025-11-17 08:44:46 --> UTF-8 Support Enabled
INFO - 2025-11-17 08:44:46 --> Utf8 Class Initialized
INFO - 2025-11-17 08:44:46 --> URI Class Initialized
INFO - 2025-11-17 08:44:46 --> Router Class Initialized
INFO - 2025-11-17 08:44:46 --> Output Class Initialized
INFO - 2025-11-17 08:44:46 --> Security Class Initialized
INFO - 2025-11-17 08:44:46 --> Input Class Initialized
INFO - 2025-11-17 08:44:46 --> Language Class Initialized
INFO - 2025-11-17 08:44:46 --> Loader Class Initialized
INFO - 2025-11-17 08:44:46 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 08:44:46 --> Helper loaded: url_helper
INFO - 2025-11-17 08:44:46 --> Helper loaded: file_helper
INFO - 2025-11-17 08:44:46 --> Helper loaded: main_helper
INFO - 2025-11-17 08:44:46 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 08:44:46 --> Database Driver Class Initialized
INFO - 2025-11-17 08:44:46 --> Email Class Initialized
DEBUG - 2025-11-17 08:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 08:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 08:44:46 --> Controller Class Initialized
INFO - 2025-11-17 08:44:46 --> Model "User_model" initialized
INFO - 2025-11-17 08:44:46 --> Model "Project_model" initialized
INFO - 2025-11-17 08:44:46 --> Helper loaded: form_helper
INFO - 2025-11-17 08:44:46 --> Form Validation Class Initialized
INFO - 2025-11-17 08:44:46 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 08:44:46 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 08:44:46 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 08:44:46 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:44:46 --> Model "Swot_model" initialized
INFO - 2025-11-17 08:44:46 --> Model "Topk_service_model" initialized
INFO - 2025-11-17 08:44:46 --> Final output sent to browser
INFO - 2025-11-17 08:44:46 --> Total execution time: 0.0703
INFO - 2025-11-17 11:34:48 --> Config Class Initialized
INFO - 2025-11-17 11:34:48 --> Hooks Class Initialized
INFO - 2025-11-17 11:34:48 --> UTF-8 Support Enabled
INFO - 2025-11-17 11:34:48 --> Utf8 Class Initialized
INFO - 2025-11-17 11:34:48 --> URI Class Initialized
DEBUG - 2025-11-17 11:34:48 --> No URI present. Default controller set.
INFO - 2025-11-17 11:34:48 --> Router Class Initialized
INFO - 2025-11-17 11:34:48 --> Output Class Initialized
INFO - 2025-11-17 11:34:48 --> Security Class Initialized
INFO - 2025-11-17 11:34:48 --> Input Class Initialized
INFO - 2025-11-17 11:34:48 --> Language Class Initialized
INFO - 2025-11-17 11:34:49 --> Loader Class Initialized
INFO - 2025-11-17 11:34:49 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 11:34:49 --> Helper loaded: url_helper
INFO - 2025-11-17 11:34:49 --> Helper loaded: file_helper
INFO - 2025-11-17 11:34:49 --> Helper loaded: main_helper
INFO - 2025-11-17 11:34:49 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 11:34:49 --> Database Driver Class Initialized
INFO - 2025-11-17 11:34:49 --> Email Class Initialized
DEBUG - 2025-11-17 11:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 11:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 11:34:49 --> Controller Class Initialized
INFO - 2025-11-17 11:34:49 --> Config Class Initialized
INFO - 2025-11-17 11:34:49 --> Hooks Class Initialized
INFO - 2025-11-17 11:34:49 --> UTF-8 Support Enabled
INFO - 2025-11-17 11:34:49 --> Utf8 Class Initialized
INFO - 2025-11-17 11:34:49 --> URI Class Initialized
INFO - 2025-11-17 11:34:49 --> Router Class Initialized
INFO - 2025-11-17 11:34:49 --> Output Class Initialized
INFO - 2025-11-17 11:34:49 --> Security Class Initialized
INFO - 2025-11-17 11:34:49 --> Input Class Initialized
INFO - 2025-11-17 11:34:49 --> Language Class Initialized
INFO - 2025-11-17 11:34:49 --> Loader Class Initialized
INFO - 2025-11-17 11:34:49 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 11:34:49 --> Helper loaded: url_helper
INFO - 2025-11-17 11:34:49 --> Helper loaded: file_helper
INFO - 2025-11-17 11:34:49 --> Helper loaded: main_helper
INFO - 2025-11-17 11:34:49 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 11:34:49 --> Database Driver Class Initialized
INFO - 2025-11-17 11:34:49 --> Email Class Initialized
DEBUG - 2025-11-17 11:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 11:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 11:34:49 --> Controller Class Initialized
INFO - 2025-11-17 11:34:49 --> Model "Subscription_model" initialized
INFO - 2025-11-17 11:34:49 --> Model "User_model" initialized
INFO - 2025-11-17 11:34:49 --> Model "Auth_model" initialized
INFO - 2025-11-17 11:34:49 --> Config Class Initialized
INFO - 2025-11-17 11:34:49 --> Hooks Class Initialized
INFO - 2025-11-17 11:34:49 --> UTF-8 Support Enabled
INFO - 2025-11-17 11:34:49 --> Utf8 Class Initialized
INFO - 2025-11-17 11:34:49 --> URI Class Initialized
INFO - 2025-11-17 11:34:49 --> Router Class Initialized
INFO - 2025-11-17 11:34:49 --> Output Class Initialized
INFO - 2025-11-17 11:34:49 --> Security Class Initialized
INFO - 2025-11-17 11:34:49 --> Input Class Initialized
INFO - 2025-11-17 11:34:49 --> Language Class Initialized
INFO - 2025-11-17 11:34:49 --> Loader Class Initialized
INFO - 2025-11-17 11:34:49 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 11:34:49 --> Helper loaded: url_helper
INFO - 2025-11-17 11:34:49 --> Helper loaded: file_helper
INFO - 2025-11-17 11:34:49 --> Helper loaded: main_helper
INFO - 2025-11-17 11:34:49 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 11:34:49 --> Database Driver Class Initialized
INFO - 2025-11-17 11:34:49 --> Email Class Initialized
DEBUG - 2025-11-17 11:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 11:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 11:34:49 --> Controller Class Initialized
INFO - 2025-11-17 11:34:49 --> Config Class Initialized
INFO - 2025-11-17 11:34:49 --> Hooks Class Initialized
INFO - 2025-11-17 11:34:49 --> UTF-8 Support Enabled
INFO - 2025-11-17 11:34:49 --> Utf8 Class Initialized
INFO - 2025-11-17 11:34:49 --> URI Class Initialized
INFO - 2025-11-17 11:34:49 --> Router Class Initialized
INFO - 2025-11-17 11:34:49 --> Output Class Initialized
INFO - 2025-11-17 11:34:49 --> Security Class Initialized
INFO - 2025-11-17 11:34:49 --> Input Class Initialized
INFO - 2025-11-17 11:34:49 --> Language Class Initialized
INFO - 2025-11-17 11:34:49 --> Loader Class Initialized
INFO - 2025-11-17 11:34:49 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 11:34:49 --> Helper loaded: url_helper
INFO - 2025-11-17 11:34:49 --> Helper loaded: file_helper
INFO - 2025-11-17 11:34:49 --> Helper loaded: main_helper
INFO - 2025-11-17 11:34:49 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 11:34:49 --> Database Driver Class Initialized
INFO - 2025-11-17 11:34:49 --> Email Class Initialized
DEBUG - 2025-11-17 11:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 11:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 11:34:49 --> Controller Class Initialized
INFO - 2025-11-17 11:34:49 --> Model "Subscription_model" initialized
INFO - 2025-11-17 11:34:49 --> Model "User_model" initialized
INFO - 2025-11-17 11:34:49 --> Model "Auth_model" initialized
INFO - 2025-11-17 11:34:49 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-17 11:34:49 --> Final output sent to browser
INFO - 2025-11-17 11:34:49 --> Total execution time: 0.0701
INFO - 2025-11-17 11:51:13 --> Config Class Initialized
INFO - 2025-11-17 11:51:13 --> Hooks Class Initialized
INFO - 2025-11-17 11:51:13 --> UTF-8 Support Enabled
INFO - 2025-11-17 11:51:13 --> Utf8 Class Initialized
INFO - 2025-11-17 11:51:13 --> URI Class Initialized
INFO - 2025-11-17 11:51:13 --> Router Class Initialized
INFO - 2025-11-17 11:51:13 --> Output Class Initialized
INFO - 2025-11-17 11:51:13 --> Security Class Initialized
INFO - 2025-11-17 11:51:13 --> Input Class Initialized
INFO - 2025-11-17 11:51:13 --> Language Class Initialized
INFO - 2025-11-17 11:51:13 --> Loader Class Initialized
INFO - 2025-11-17 11:51:13 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 11:51:13 --> Helper loaded: url_helper
INFO - 2025-11-17 11:51:13 --> Helper loaded: file_helper
INFO - 2025-11-17 11:51:13 --> Helper loaded: main_helper
INFO - 2025-11-17 11:51:13 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 11:51:13 --> Database Driver Class Initialized
INFO - 2025-11-17 11:51:13 --> Email Class Initialized
DEBUG - 2025-11-17 11:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 11:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 11:51:13 --> Controller Class Initialized
INFO - 2025-11-17 11:51:13 --> Model "Subscription_model" initialized
INFO - 2025-11-17 11:51:13 --> Model "User_model" initialized
INFO - 2025-11-17 11:51:13 --> Model "Auth_model" initialized
INFO - 2025-11-17 11:51:13 --> Final output sent to browser
INFO - 2025-11-17 11:51:13 --> Total execution time: 0.3912
INFO - 2025-11-17 11:51:14 --> Config Class Initialized
INFO - 2025-11-17 11:51:14 --> Hooks Class Initialized
INFO - 2025-11-17 11:51:14 --> UTF-8 Support Enabled
INFO - 2025-11-17 11:51:14 --> Utf8 Class Initialized
INFO - 2025-11-17 11:51:14 --> URI Class Initialized
INFO - 2025-11-17 11:51:15 --> Router Class Initialized
INFO - 2025-11-17 11:51:15 --> Output Class Initialized
INFO - 2025-11-17 11:51:15 --> Security Class Initialized
INFO - 2025-11-17 11:51:15 --> Input Class Initialized
INFO - 2025-11-17 11:51:15 --> Language Class Initialized
INFO - 2025-11-17 11:51:15 --> Loader Class Initialized
INFO - 2025-11-17 11:51:15 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 11:51:15 --> Helper loaded: url_helper
INFO - 2025-11-17 11:51:15 --> Helper loaded: file_helper
INFO - 2025-11-17 11:51:15 --> Helper loaded: main_helper
INFO - 2025-11-17 11:51:15 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 11:51:15 --> Database Driver Class Initialized
INFO - 2025-11-17 11:51:15 --> Email Class Initialized
DEBUG - 2025-11-17 11:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 11:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 11:51:15 --> Controller Class Initialized
INFO - 2025-11-17 11:51:15 --> Model "Subscription_model" initialized
INFO - 2025-11-17 11:51:15 --> Model "User_model" initialized
INFO - 2025-11-17 11:51:15 --> Model "Auth_model" initialized
INFO - 2025-11-17 11:51:15 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 11:51:15 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 11:51:15 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 11:51:15 --> File loaded: D:\laragon\www\acumena\application\views\dashboard.php
INFO - 2025-11-17 11:51:15 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 11:51:15 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 11:51:15 --> Final output sent to browser
INFO - 2025-11-17 11:51:15 --> Total execution time: 0.1049
INFO - 2025-11-17 11:51:15 --> Config Class Initialized
INFO - 2025-11-17 11:51:15 --> Hooks Class Initialized
INFO - 2025-11-17 11:51:15 --> UTF-8 Support Enabled
INFO - 2025-11-17 11:51:15 --> Utf8 Class Initialized
INFO - 2025-11-17 11:51:15 --> URI Class Initialized
INFO - 2025-11-17 11:51:15 --> Router Class Initialized
INFO - 2025-11-17 11:51:15 --> Output Class Initialized
INFO - 2025-11-17 11:51:15 --> Security Class Initialized
INFO - 2025-11-17 11:51:15 --> Input Class Initialized
INFO - 2025-11-17 11:51:15 --> Language Class Initialized
INFO - 2025-11-17 11:51:15 --> Loader Class Initialized
INFO - 2025-11-17 11:51:15 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 11:51:15 --> Helper loaded: url_helper
INFO - 2025-11-17 11:51:15 --> Helper loaded: file_helper
INFO - 2025-11-17 11:51:15 --> Helper loaded: main_helper
INFO - 2025-11-17 11:51:15 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 11:51:15 --> Database Driver Class Initialized
INFO - 2025-11-17 11:51:15 --> Email Class Initialized
DEBUG - 2025-11-17 11:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 11:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 11:51:15 --> Controller Class Initialized
INFO - 2025-11-17 11:51:15 --> Model "User_model" initialized
INFO - 2025-11-17 11:51:15 --> Model "Project_model" initialized
INFO - 2025-11-17 11:51:15 --> Helper loaded: form_helper
INFO - 2025-11-17 11:51:15 --> Form Validation Class Initialized
INFO - 2025-11-17 11:51:15 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 11:51:15 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 11:51:15 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 11:51:15 --> Model "Swot_model" initialized
INFO - 2025-11-17 11:51:15 --> Model "Swot_model" initialized
INFO - 2025-11-17 11:51:15 --> Model "Topk_service_model" initialized
INFO - 2025-11-17 11:51:15 --> Final output sent to browser
INFO - 2025-11-17 11:51:15 --> Total execution time: 0.1147
INFO - 2025-11-17 11:51:19 --> Config Class Initialized
INFO - 2025-11-17 11:51:19 --> Hooks Class Initialized
INFO - 2025-11-17 11:51:19 --> UTF-8 Support Enabled
INFO - 2025-11-17 11:51:19 --> Utf8 Class Initialized
INFO - 2025-11-17 11:51:19 --> URI Class Initialized
INFO - 2025-11-17 11:51:19 --> Router Class Initialized
INFO - 2025-11-17 11:51:19 --> Output Class Initialized
INFO - 2025-11-17 11:51:19 --> Security Class Initialized
INFO - 2025-11-17 11:51:19 --> Input Class Initialized
INFO - 2025-11-17 11:51:19 --> Language Class Initialized
INFO - 2025-11-17 11:51:19 --> Loader Class Initialized
INFO - 2025-11-17 11:51:19 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 11:51:19 --> Helper loaded: url_helper
INFO - 2025-11-17 11:51:19 --> Helper loaded: file_helper
INFO - 2025-11-17 11:51:19 --> Helper loaded: main_helper
INFO - 2025-11-17 11:51:19 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 11:51:19 --> Database Driver Class Initialized
INFO - 2025-11-17 11:51:19 --> Email Class Initialized
DEBUG - 2025-11-17 11:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 11:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 11:51:19 --> Controller Class Initialized
INFO - 2025-11-17 11:51:19 --> Model "Subscription_model" initialized
INFO - 2025-11-17 11:51:19 --> Model "User_model" initialized
INFO - 2025-11-17 11:51:19 --> Model "Auth_model" initialized
INFO - 2025-11-17 11:51:19 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 11:51:19 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 11:51:19 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 11:51:19 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 11:51:19 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 11:51:19 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 11:51:19 --> Final output sent to browser
INFO - 2025-11-17 11:51:19 --> Total execution time: 0.1213
INFO - 2025-11-17 11:51:38 --> Config Class Initialized
INFO - 2025-11-17 11:51:38 --> Hooks Class Initialized
INFO - 2025-11-17 11:51:38 --> UTF-8 Support Enabled
INFO - 2025-11-17 11:51:38 --> Utf8 Class Initialized
INFO - 2025-11-17 11:51:38 --> URI Class Initialized
INFO - 2025-11-17 11:51:38 --> Router Class Initialized
INFO - 2025-11-17 11:51:38 --> Output Class Initialized
INFO - 2025-11-17 11:51:38 --> Security Class Initialized
INFO - 2025-11-17 11:51:38 --> Input Class Initialized
INFO - 2025-11-17 11:51:38 --> Language Class Initialized
INFO - 2025-11-17 11:51:38 --> Loader Class Initialized
INFO - 2025-11-17 11:51:38 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 11:51:38 --> Helper loaded: url_helper
INFO - 2025-11-17 11:51:38 --> Helper loaded: file_helper
INFO - 2025-11-17 11:51:38 --> Helper loaded: main_helper
INFO - 2025-11-17 11:51:38 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 11:51:38 --> Database Driver Class Initialized
INFO - 2025-11-17 11:51:38 --> Email Class Initialized
DEBUG - 2025-11-17 11:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 11:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 11:51:38 --> Controller Class Initialized
INFO - 2025-11-17 11:51:38 --> Model "Subscription_model" initialized
INFO - 2025-11-17 11:51:38 --> Model "User_model" initialized
INFO - 2025-11-17 11:51:38 --> Model "Auth_model" initialized
INFO - 2025-11-17 11:51:38 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 11:51:38 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 11:51:38 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 11:51:38 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 11:51:38 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 11:51:38 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 11:51:38 --> Final output sent to browser
INFO - 2025-11-17 11:51:38 --> Total execution time: 0.1340
INFO - 2025-11-17 11:51:41 --> Config Class Initialized
INFO - 2025-11-17 11:51:41 --> Hooks Class Initialized
INFO - 2025-11-17 11:51:41 --> UTF-8 Support Enabled
INFO - 2025-11-17 11:51:41 --> Utf8 Class Initialized
INFO - 2025-11-17 11:51:41 --> URI Class Initialized
INFO - 2025-11-17 11:51:41 --> Router Class Initialized
INFO - 2025-11-17 11:51:41 --> Output Class Initialized
INFO - 2025-11-17 11:51:41 --> Security Class Initialized
INFO - 2025-11-17 11:51:41 --> Input Class Initialized
INFO - 2025-11-17 11:51:41 --> Language Class Initialized
INFO - 2025-11-17 11:51:41 --> Loader Class Initialized
INFO - 2025-11-17 11:51:41 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 11:51:41 --> Helper loaded: url_helper
INFO - 2025-11-17 11:51:41 --> Helper loaded: file_helper
INFO - 2025-11-17 11:51:41 --> Helper loaded: main_helper
INFO - 2025-11-17 11:51:41 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 11:51:41 --> Database Driver Class Initialized
INFO - 2025-11-17 11:51:41 --> Email Class Initialized
DEBUG - 2025-11-17 11:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 11:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 11:51:41 --> Controller Class Initialized
INFO - 2025-11-17 11:51:41 --> Model "Subscription_model" initialized
INFO - 2025-11-17 11:51:41 --> Model "User_model" initialized
INFO - 2025-11-17 11:51:41 --> Model "Auth_model" initialized
INFO - 2025-11-17 11:51:41 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 11:51:41 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 11:51:41 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 11:51:41 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 11:51:41 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 11:51:41 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 11:51:41 --> Final output sent to browser
INFO - 2025-11-17 11:51:41 --> Total execution time: 0.1043
INFO - 2025-11-17 11:53:02 --> Config Class Initialized
INFO - 2025-11-17 11:53:02 --> Hooks Class Initialized
INFO - 2025-11-17 11:53:02 --> UTF-8 Support Enabled
INFO - 2025-11-17 11:53:02 --> Utf8 Class Initialized
INFO - 2025-11-17 11:53:02 --> URI Class Initialized
INFO - 2025-11-17 11:53:02 --> Router Class Initialized
INFO - 2025-11-17 11:53:02 --> Output Class Initialized
INFO - 2025-11-17 11:53:02 --> Security Class Initialized
INFO - 2025-11-17 11:53:02 --> Input Class Initialized
INFO - 2025-11-17 11:53:02 --> Language Class Initialized
INFO - 2025-11-17 11:53:02 --> Loader Class Initialized
INFO - 2025-11-17 11:53:02 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 11:53:02 --> Helper loaded: url_helper
INFO - 2025-11-17 11:53:02 --> Helper loaded: file_helper
INFO - 2025-11-17 11:53:02 --> Helper loaded: main_helper
INFO - 2025-11-17 11:53:02 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 11:53:02 --> Database Driver Class Initialized
INFO - 2025-11-17 11:53:02 --> Email Class Initialized
DEBUG - 2025-11-17 11:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 11:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 11:53:02 --> Controller Class Initialized
INFO - 2025-11-17 11:53:02 --> Model "Subscription_model" initialized
INFO - 2025-11-17 11:53:02 --> Model "User_model" initialized
INFO - 2025-11-17 11:53:02 --> Model "Auth_model" initialized
INFO - 2025-11-17 11:53:02 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 11:53:02 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 11:53:02 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 11:53:02 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 11:53:02 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 11:53:02 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 11:53:02 --> Final output sent to browser
INFO - 2025-11-17 11:53:02 --> Total execution time: 0.0978
INFO - 2025-11-17 11:53:11 --> Config Class Initialized
INFO - 2025-11-17 11:53:11 --> Hooks Class Initialized
INFO - 2025-11-17 11:53:11 --> UTF-8 Support Enabled
INFO - 2025-11-17 11:53:11 --> Utf8 Class Initialized
INFO - 2025-11-17 11:53:11 --> URI Class Initialized
INFO - 2025-11-17 11:53:11 --> Router Class Initialized
INFO - 2025-11-17 11:53:11 --> Output Class Initialized
INFO - 2025-11-17 11:53:11 --> Security Class Initialized
INFO - 2025-11-17 11:53:11 --> Input Class Initialized
INFO - 2025-11-17 11:53:11 --> Language Class Initialized
INFO - 2025-11-17 11:53:11 --> Loader Class Initialized
INFO - 2025-11-17 11:53:11 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 11:53:11 --> Helper loaded: url_helper
INFO - 2025-11-17 11:53:11 --> Helper loaded: file_helper
INFO - 2025-11-17 11:53:11 --> Helper loaded: main_helper
INFO - 2025-11-17 11:53:11 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 11:53:11 --> Database Driver Class Initialized
INFO - 2025-11-17 11:53:11 --> Email Class Initialized
DEBUG - 2025-11-17 11:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 11:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 11:53:11 --> Controller Class Initialized
INFO - 2025-11-17 11:53:11 --> Model "Subscription_model" initialized
INFO - 2025-11-17 11:53:11 --> Model "User_model" initialized
INFO - 2025-11-17 11:53:11 --> Model "Auth_model" initialized
INFO - 2025-11-17 11:53:11 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 11:53:11 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 11:53:11 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 11:53:11 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 11:53:11 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 11:53:11 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 11:53:11 --> Final output sent to browser
INFO - 2025-11-17 11:53:11 --> Total execution time: 0.1161
INFO - 2025-11-17 11:53:18 --> Config Class Initialized
INFO - 2025-11-17 11:53:18 --> Hooks Class Initialized
INFO - 2025-11-17 11:53:18 --> UTF-8 Support Enabled
INFO - 2025-11-17 11:53:18 --> Utf8 Class Initialized
INFO - 2025-11-17 11:53:18 --> URI Class Initialized
INFO - 2025-11-17 11:53:18 --> Router Class Initialized
INFO - 2025-11-17 11:53:18 --> Output Class Initialized
INFO - 2025-11-17 11:53:18 --> Security Class Initialized
INFO - 2025-11-17 11:53:18 --> Input Class Initialized
INFO - 2025-11-17 11:53:18 --> Language Class Initialized
INFO - 2025-11-17 11:53:18 --> Loader Class Initialized
INFO - 2025-11-17 11:53:18 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 11:53:18 --> Helper loaded: url_helper
INFO - 2025-11-17 11:53:18 --> Helper loaded: file_helper
INFO - 2025-11-17 11:53:18 --> Helper loaded: main_helper
INFO - 2025-11-17 11:53:18 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 11:53:18 --> Database Driver Class Initialized
INFO - 2025-11-17 11:53:18 --> Email Class Initialized
DEBUG - 2025-11-17 11:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 11:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 11:53:18 --> Controller Class Initialized
INFO - 2025-11-17 11:53:18 --> Model "Subscription_model" initialized
INFO - 2025-11-17 11:53:18 --> Model "User_model" initialized
INFO - 2025-11-17 11:53:18 --> Model "Auth_model" initialized
INFO - 2025-11-17 11:53:18 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 11:53:18 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 11:53:18 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 11:53:18 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 11:53:18 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 11:53:18 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 11:53:18 --> Final output sent to browser
INFO - 2025-11-17 11:53:18 --> Total execution time: 0.0966
INFO - 2025-11-17 11:53:53 --> Config Class Initialized
INFO - 2025-11-17 11:53:53 --> Hooks Class Initialized
INFO - 2025-11-17 11:53:53 --> UTF-8 Support Enabled
INFO - 2025-11-17 11:53:53 --> Utf8 Class Initialized
INFO - 2025-11-17 11:53:53 --> URI Class Initialized
INFO - 2025-11-17 11:53:53 --> Router Class Initialized
INFO - 2025-11-17 11:53:53 --> Output Class Initialized
INFO - 2025-11-17 11:53:53 --> Security Class Initialized
INFO - 2025-11-17 11:53:53 --> Input Class Initialized
INFO - 2025-11-17 11:53:53 --> Language Class Initialized
INFO - 2025-11-17 11:53:53 --> Loader Class Initialized
INFO - 2025-11-17 11:53:53 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 11:53:53 --> Helper loaded: url_helper
INFO - 2025-11-17 11:53:53 --> Helper loaded: file_helper
INFO - 2025-11-17 11:53:53 --> Helper loaded: main_helper
INFO - 2025-11-17 11:53:53 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 11:53:53 --> Database Driver Class Initialized
INFO - 2025-11-17 11:53:53 --> Email Class Initialized
DEBUG - 2025-11-17 11:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 11:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 11:53:53 --> Controller Class Initialized
INFO - 2025-11-17 11:53:53 --> Model "Subscription_model" initialized
INFO - 2025-11-17 11:53:53 --> Model "User_model" initialized
INFO - 2025-11-17 11:53:53 --> Model "Auth_model" initialized
INFO - 2025-11-17 11:53:53 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 11:53:53 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 11:53:53 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 11:53:53 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 11:53:53 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 11:53:53 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 11:53:53 --> Final output sent to browser
INFO - 2025-11-17 11:53:53 --> Total execution time: 0.1260
INFO - 2025-11-17 12:12:08 --> Config Class Initialized
INFO - 2025-11-17 12:12:08 --> Hooks Class Initialized
INFO - 2025-11-17 12:12:08 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:12:08 --> Utf8 Class Initialized
INFO - 2025-11-17 12:12:08 --> URI Class Initialized
INFO - 2025-11-17 12:12:08 --> Router Class Initialized
INFO - 2025-11-17 12:12:08 --> Output Class Initialized
INFO - 2025-11-17 12:12:08 --> Security Class Initialized
INFO - 2025-11-17 12:12:08 --> Input Class Initialized
INFO - 2025-11-17 12:12:08 --> Language Class Initialized
INFO - 2025-11-17 12:12:08 --> Loader Class Initialized
INFO - 2025-11-17 12:12:08 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:12:08 --> Helper loaded: url_helper
INFO - 2025-11-17 12:12:08 --> Helper loaded: file_helper
INFO - 2025-11-17 12:12:08 --> Helper loaded: main_helper
INFO - 2025-11-17 12:12:08 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:12:08 --> Database Driver Class Initialized
INFO - 2025-11-17 12:12:08 --> Email Class Initialized
DEBUG - 2025-11-17 12:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:12:08 --> Controller Class Initialized
INFO - 2025-11-17 12:12:08 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:12:08 --> Model "User_model" initialized
INFO - 2025-11-17 12:12:08 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:12:08 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 12:12:08 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 12:12:08 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 12:12:08 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 12:12:08 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 12:12:08 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 12:12:08 --> Final output sent to browser
INFO - 2025-11-17 12:12:08 --> Total execution time: 0.1247
INFO - 2025-11-17 12:12:14 --> Config Class Initialized
INFO - 2025-11-17 12:12:14 --> Hooks Class Initialized
INFO - 2025-11-17 12:12:14 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:12:14 --> Utf8 Class Initialized
INFO - 2025-11-17 12:12:14 --> URI Class Initialized
INFO - 2025-11-17 12:12:14 --> Router Class Initialized
INFO - 2025-11-17 12:12:14 --> Output Class Initialized
INFO - 2025-11-17 12:12:14 --> Security Class Initialized
INFO - 2025-11-17 12:12:14 --> Input Class Initialized
INFO - 2025-11-17 12:12:14 --> Language Class Initialized
INFO - 2025-11-17 12:12:14 --> Loader Class Initialized
INFO - 2025-11-17 12:12:14 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:12:14 --> Helper loaded: url_helper
INFO - 2025-11-17 12:12:14 --> Helper loaded: file_helper
INFO - 2025-11-17 12:12:14 --> Helper loaded: main_helper
INFO - 2025-11-17 12:12:14 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:12:14 --> Database Driver Class Initialized
INFO - 2025-11-17 12:12:14 --> Email Class Initialized
DEBUG - 2025-11-17 12:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:12:14 --> Controller Class Initialized
INFO - 2025-11-17 12:12:14 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:12:14 --> Model "User_model" initialized
INFO - 2025-11-17 12:12:14 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:12:14 --> Final output sent to browser
INFO - 2025-11-17 12:12:14 --> Total execution time: 0.0819
INFO - 2025-11-17 12:12:14 --> Config Class Initialized
INFO - 2025-11-17 12:12:14 --> Hooks Class Initialized
INFO - 2025-11-17 12:12:14 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:12:14 --> Utf8 Class Initialized
INFO - 2025-11-17 12:12:14 --> URI Class Initialized
INFO - 2025-11-17 12:12:14 --> Router Class Initialized
INFO - 2025-11-17 12:12:14 --> Output Class Initialized
INFO - 2025-11-17 12:12:14 --> Security Class Initialized
INFO - 2025-11-17 12:12:14 --> Input Class Initialized
INFO - 2025-11-17 12:12:14 --> Language Class Initialized
ERROR - 2025-11-17 12:12:14 --> 404 Page Not Found: Faviconico/index
INFO - 2025-11-17 12:12:58 --> Config Class Initialized
INFO - 2025-11-17 12:12:58 --> Hooks Class Initialized
INFO - 2025-11-17 12:12:58 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:12:58 --> Utf8 Class Initialized
INFO - 2025-11-17 12:12:58 --> URI Class Initialized
INFO - 2025-11-17 12:12:58 --> Router Class Initialized
INFO - 2025-11-17 12:12:58 --> Output Class Initialized
INFO - 2025-11-17 12:12:58 --> Security Class Initialized
INFO - 2025-11-17 12:12:58 --> Input Class Initialized
INFO - 2025-11-17 12:12:58 --> Language Class Initialized
INFO - 2025-11-17 12:12:58 --> Loader Class Initialized
INFO - 2025-11-17 12:12:58 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:12:58 --> Helper loaded: url_helper
INFO - 2025-11-17 12:12:58 --> Helper loaded: file_helper
INFO - 2025-11-17 12:12:58 --> Helper loaded: main_helper
INFO - 2025-11-17 12:12:58 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:12:58 --> Database Driver Class Initialized
INFO - 2025-11-17 12:12:58 --> Email Class Initialized
DEBUG - 2025-11-17 12:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:12:58 --> Controller Class Initialized
INFO - 2025-11-17 12:12:58 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:12:58 --> Model "User_model" initialized
INFO - 2025-11-17 12:12:58 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:12:58 --> Final output sent to browser
INFO - 2025-11-17 12:12:58 --> Total execution time: 0.1016
INFO - 2025-11-17 12:13:23 --> Config Class Initialized
INFO - 2025-11-17 12:13:23 --> Hooks Class Initialized
INFO - 2025-11-17 12:13:23 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:13:23 --> Utf8 Class Initialized
INFO - 2025-11-17 12:13:23 --> URI Class Initialized
INFO - 2025-11-17 12:13:23 --> Router Class Initialized
INFO - 2025-11-17 12:13:23 --> Output Class Initialized
INFO - 2025-11-17 12:13:23 --> Security Class Initialized
INFO - 2025-11-17 12:13:23 --> Input Class Initialized
INFO - 2025-11-17 12:13:23 --> Language Class Initialized
INFO - 2025-11-17 12:13:23 --> Loader Class Initialized
INFO - 2025-11-17 12:13:23 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:13:23 --> Helper loaded: url_helper
INFO - 2025-11-17 12:13:23 --> Helper loaded: file_helper
INFO - 2025-11-17 12:13:23 --> Helper loaded: main_helper
INFO - 2025-11-17 12:13:23 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:13:23 --> Database Driver Class Initialized
INFO - 2025-11-17 12:13:23 --> Email Class Initialized
DEBUG - 2025-11-17 12:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:13:23 --> Controller Class Initialized
INFO - 2025-11-17 12:13:23 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:13:23 --> Model "User_model" initialized
INFO - 2025-11-17 12:13:23 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:13:23 --> Final output sent to browser
INFO - 2025-11-17 12:13:23 --> Total execution time: 0.0983
INFO - 2025-11-17 12:13:35 --> Config Class Initialized
INFO - 2025-11-17 12:13:35 --> Hooks Class Initialized
INFO - 2025-11-17 12:13:35 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:13:35 --> Utf8 Class Initialized
INFO - 2025-11-17 12:13:35 --> URI Class Initialized
INFO - 2025-11-17 12:13:35 --> Router Class Initialized
INFO - 2025-11-17 12:13:35 --> Output Class Initialized
INFO - 2025-11-17 12:13:35 --> Security Class Initialized
INFO - 2025-11-17 12:13:35 --> Input Class Initialized
INFO - 2025-11-17 12:13:35 --> Language Class Initialized
ERROR - 2025-11-17 12:13:35 --> 404 Page Not Found: Subscription/generate_uuid
INFO - 2025-11-17 12:14:16 --> Config Class Initialized
INFO - 2025-11-17 12:14:16 --> Hooks Class Initialized
INFO - 2025-11-17 12:14:16 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:14:16 --> Utf8 Class Initialized
INFO - 2025-11-17 12:14:16 --> URI Class Initialized
INFO - 2025-11-17 12:14:16 --> Router Class Initialized
INFO - 2025-11-17 12:14:16 --> Output Class Initialized
INFO - 2025-11-17 12:14:16 --> Security Class Initialized
INFO - 2025-11-17 12:14:16 --> Input Class Initialized
INFO - 2025-11-17 12:14:16 --> Language Class Initialized
INFO - 2025-11-17 12:14:16 --> Loader Class Initialized
INFO - 2025-11-17 12:14:16 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:14:16 --> Helper loaded: url_helper
INFO - 2025-11-17 12:14:16 --> Helper loaded: file_helper
INFO - 2025-11-17 12:14:16 --> Helper loaded: main_helper
INFO - 2025-11-17 12:14:16 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:14:16 --> Database Driver Class Initialized
INFO - 2025-11-17 12:14:16 --> Email Class Initialized
DEBUG - 2025-11-17 12:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:14:16 --> Controller Class Initialized
INFO - 2025-11-17 12:14:16 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:14:16 --> Model "User_model" initialized
INFO - 2025-11-17 12:14:16 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:14:16 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 12:14:16 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 12:14:16 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 12:14:16 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 12:14:16 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 12:14:16 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 12:14:16 --> Final output sent to browser
INFO - 2025-11-17 12:14:16 --> Total execution time: 0.0950
INFO - 2025-11-17 12:15:20 --> Config Class Initialized
INFO - 2025-11-17 12:15:20 --> Hooks Class Initialized
INFO - 2025-11-17 12:15:20 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:15:20 --> Utf8 Class Initialized
INFO - 2025-11-17 12:15:20 --> URI Class Initialized
INFO - 2025-11-17 12:15:20 --> Router Class Initialized
INFO - 2025-11-17 12:15:20 --> Output Class Initialized
INFO - 2025-11-17 12:15:20 --> Security Class Initialized
INFO - 2025-11-17 12:15:20 --> Input Class Initialized
INFO - 2025-11-17 12:15:20 --> Language Class Initialized
INFO - 2025-11-17 12:15:20 --> Loader Class Initialized
INFO - 2025-11-17 12:15:20 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:15:20 --> Helper loaded: url_helper
INFO - 2025-11-17 12:15:20 --> Helper loaded: file_helper
INFO - 2025-11-17 12:15:20 --> Helper loaded: main_helper
INFO - 2025-11-17 12:15:20 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:15:20 --> Database Driver Class Initialized
INFO - 2025-11-17 12:15:20 --> Email Class Initialized
DEBUG - 2025-11-17 12:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:15:20 --> Controller Class Initialized
INFO - 2025-11-17 12:15:20 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:15:20 --> Model "User_model" initialized
INFO - 2025-11-17 12:15:20 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:15:20 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 12:15:20 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 12:15:20 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 12:15:20 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 12:15:20 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 12:15:20 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 12:15:20 --> Final output sent to browser
INFO - 2025-11-17 12:15:20 --> Total execution time: 0.1269
INFO - 2025-11-17 12:15:21 --> Config Class Initialized
INFO - 2025-11-17 12:15:21 --> Hooks Class Initialized
INFO - 2025-11-17 12:15:21 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:15:21 --> Utf8 Class Initialized
INFO - 2025-11-17 12:15:21 --> URI Class Initialized
INFO - 2025-11-17 12:15:21 --> Router Class Initialized
INFO - 2025-11-17 12:15:21 --> Output Class Initialized
INFO - 2025-11-17 12:15:21 --> Security Class Initialized
INFO - 2025-11-17 12:15:21 --> Input Class Initialized
INFO - 2025-11-17 12:15:21 --> Language Class Initialized
INFO - 2025-11-17 12:15:21 --> Loader Class Initialized
INFO - 2025-11-17 12:15:21 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:15:21 --> Helper loaded: url_helper
INFO - 2025-11-17 12:15:21 --> Helper loaded: file_helper
INFO - 2025-11-17 12:15:21 --> Helper loaded: main_helper
INFO - 2025-11-17 12:15:21 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:15:21 --> Database Driver Class Initialized
INFO - 2025-11-17 12:15:21 --> Email Class Initialized
DEBUG - 2025-11-17 12:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:15:21 --> Controller Class Initialized
INFO - 2025-11-17 12:15:21 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:15:21 --> Model "User_model" initialized
INFO - 2025-11-17 12:15:21 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:15:21 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:15:21 --> Final output sent to browser
INFO - 2025-11-17 12:15:21 --> Total execution time: 0.0871
INFO - 2025-11-17 12:15:28 --> Config Class Initialized
INFO - 2025-11-17 12:15:28 --> Hooks Class Initialized
INFO - 2025-11-17 12:15:28 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:15:28 --> Utf8 Class Initialized
INFO - 2025-11-17 12:15:28 --> URI Class Initialized
INFO - 2025-11-17 12:15:28 --> Router Class Initialized
INFO - 2025-11-17 12:15:28 --> Output Class Initialized
INFO - 2025-11-17 12:15:28 --> Security Class Initialized
INFO - 2025-11-17 12:15:28 --> Input Class Initialized
INFO - 2025-11-17 12:15:28 --> Language Class Initialized
INFO - 2025-11-17 12:15:28 --> Loader Class Initialized
INFO - 2025-11-17 12:15:28 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:15:28 --> Helper loaded: url_helper
INFO - 2025-11-17 12:15:28 --> Helper loaded: file_helper
INFO - 2025-11-17 12:15:28 --> Helper loaded: main_helper
INFO - 2025-11-17 12:15:28 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:15:28 --> Database Driver Class Initialized
INFO - 2025-11-17 12:15:28 --> Email Class Initialized
DEBUG - 2025-11-17 12:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:15:28 --> Controller Class Initialized
INFO - 2025-11-17 12:15:28 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:15:28 --> Model "User_model" initialized
INFO - 2025-11-17 12:15:28 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:15:28 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 12:15:28 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 12:15:28 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 12:15:28 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 12:15:28 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 12:15:28 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 12:15:28 --> Final output sent to browser
INFO - 2025-11-17 12:15:28 --> Total execution time: 0.1186
INFO - 2025-11-17 12:15:30 --> Config Class Initialized
INFO - 2025-11-17 12:15:30 --> Hooks Class Initialized
INFO - 2025-11-17 12:15:30 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:15:30 --> Utf8 Class Initialized
INFO - 2025-11-17 12:15:30 --> URI Class Initialized
INFO - 2025-11-17 12:15:30 --> Router Class Initialized
INFO - 2025-11-17 12:15:30 --> Output Class Initialized
INFO - 2025-11-17 12:15:30 --> Security Class Initialized
INFO - 2025-11-17 12:15:30 --> Input Class Initialized
INFO - 2025-11-17 12:15:30 --> Language Class Initialized
INFO - 2025-11-17 12:15:30 --> Loader Class Initialized
INFO - 2025-11-17 12:15:30 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:15:30 --> Helper loaded: url_helper
INFO - 2025-11-17 12:15:30 --> Helper loaded: file_helper
INFO - 2025-11-17 12:15:30 --> Helper loaded: main_helper
INFO - 2025-11-17 12:15:30 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:15:30 --> Database Driver Class Initialized
INFO - 2025-11-17 12:15:30 --> Email Class Initialized
DEBUG - 2025-11-17 12:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:15:30 --> Controller Class Initialized
INFO - 2025-11-17 12:15:30 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:15:30 --> Model "User_model" initialized
INFO - 2025-11-17 12:15:30 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:15:30 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:15:30 --> Final output sent to browser
INFO - 2025-11-17 12:15:30 --> Total execution time: 0.0865
INFO - 2025-11-17 12:18:15 --> Config Class Initialized
INFO - 2025-11-17 12:18:15 --> Hooks Class Initialized
INFO - 2025-11-17 12:18:15 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:18:15 --> Utf8 Class Initialized
INFO - 2025-11-17 12:18:15 --> URI Class Initialized
INFO - 2025-11-17 12:18:15 --> Router Class Initialized
INFO - 2025-11-17 12:18:15 --> Output Class Initialized
INFO - 2025-11-17 12:18:15 --> Security Class Initialized
INFO - 2025-11-17 12:18:15 --> Input Class Initialized
INFO - 2025-11-17 12:18:15 --> Language Class Initialized
INFO - 2025-11-17 12:18:15 --> Loader Class Initialized
INFO - 2025-11-17 12:18:15 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:18:15 --> Helper loaded: url_helper
INFO - 2025-11-17 12:18:15 --> Helper loaded: file_helper
INFO - 2025-11-17 12:18:15 --> Helper loaded: main_helper
INFO - 2025-11-17 12:18:15 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:18:15 --> Database Driver Class Initialized
INFO - 2025-11-17 12:18:15 --> Email Class Initialized
DEBUG - 2025-11-17 12:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:18:15 --> Controller Class Initialized
INFO - 2025-11-17 12:18:15 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:18:15 --> Model "User_model" initialized
INFO - 2025-11-17 12:18:15 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:18:15 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:18:15 --> Final output sent to browser
INFO - 2025-11-17 12:18:15 --> Total execution time: 0.1025
INFO - 2025-11-17 12:19:39 --> Config Class Initialized
INFO - 2025-11-17 12:19:39 --> Hooks Class Initialized
INFO - 2025-11-17 12:19:39 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:19:39 --> Utf8 Class Initialized
INFO - 2025-11-17 12:19:39 --> URI Class Initialized
INFO - 2025-11-17 12:19:39 --> Router Class Initialized
INFO - 2025-11-17 12:19:39 --> Output Class Initialized
INFO - 2025-11-17 12:19:39 --> Security Class Initialized
INFO - 2025-11-17 12:19:39 --> Input Class Initialized
INFO - 2025-11-17 12:19:39 --> Language Class Initialized
INFO - 2025-11-17 12:19:39 --> Loader Class Initialized
INFO - 2025-11-17 12:19:39 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:19:39 --> Helper loaded: url_helper
INFO - 2025-11-17 12:19:39 --> Helper loaded: file_helper
INFO - 2025-11-17 12:19:39 --> Helper loaded: main_helper
INFO - 2025-11-17 12:19:39 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:19:39 --> Database Driver Class Initialized
INFO - 2025-11-17 12:19:39 --> Email Class Initialized
DEBUG - 2025-11-17 12:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:19:39 --> Controller Class Initialized
INFO - 2025-11-17 12:19:39 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:19:39 --> Model "User_model" initialized
INFO - 2025-11-17 12:19:39 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:19:39 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 12:19:39 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 12:19:39 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 12:19:39 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 12:19:39 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 12:19:39 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 12:19:39 --> Final output sent to browser
INFO - 2025-11-17 12:19:39 --> Total execution time: 0.0925
INFO - 2025-11-17 12:20:19 --> Config Class Initialized
INFO - 2025-11-17 12:20:19 --> Hooks Class Initialized
INFO - 2025-11-17 12:20:19 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:20:19 --> Utf8 Class Initialized
INFO - 2025-11-17 12:20:19 --> URI Class Initialized
INFO - 2025-11-17 12:20:19 --> Router Class Initialized
INFO - 2025-11-17 12:20:19 --> Output Class Initialized
INFO - 2025-11-17 12:20:19 --> Security Class Initialized
INFO - 2025-11-17 12:20:19 --> Input Class Initialized
INFO - 2025-11-17 12:20:19 --> Language Class Initialized
INFO - 2025-11-17 12:20:19 --> Loader Class Initialized
INFO - 2025-11-17 12:20:19 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:20:19 --> Helper loaded: url_helper
INFO - 2025-11-17 12:20:19 --> Helper loaded: file_helper
INFO - 2025-11-17 12:20:19 --> Helper loaded: main_helper
INFO - 2025-11-17 12:20:19 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:20:19 --> Database Driver Class Initialized
INFO - 2025-11-17 12:20:19 --> Email Class Initialized
DEBUG - 2025-11-17 12:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:20:19 --> Controller Class Initialized
INFO - 2025-11-17 12:20:19 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:20:19 --> Model "User_model" initialized
INFO - 2025-11-17 12:20:19 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:20:19 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:20:19 --> Final output sent to browser
INFO - 2025-11-17 12:20:19 --> Total execution time: 0.0852
INFO - 2025-11-17 12:22:44 --> Config Class Initialized
INFO - 2025-11-17 12:22:44 --> Hooks Class Initialized
INFO - 2025-11-17 12:22:44 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:22:44 --> Utf8 Class Initialized
INFO - 2025-11-17 12:22:44 --> URI Class Initialized
INFO - 2025-11-17 12:22:44 --> Router Class Initialized
INFO - 2025-11-17 12:22:44 --> Output Class Initialized
INFO - 2025-11-17 12:22:44 --> Security Class Initialized
INFO - 2025-11-17 12:22:44 --> Input Class Initialized
INFO - 2025-11-17 12:22:44 --> Language Class Initialized
INFO - 2025-11-17 12:22:44 --> Loader Class Initialized
INFO - 2025-11-17 12:22:44 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:22:44 --> Helper loaded: url_helper
INFO - 2025-11-17 12:22:44 --> Helper loaded: file_helper
INFO - 2025-11-17 12:22:44 --> Helper loaded: main_helper
INFO - 2025-11-17 12:22:44 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:22:44 --> Database Driver Class Initialized
INFO - 2025-11-17 12:22:44 --> Email Class Initialized
DEBUG - 2025-11-17 12:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:22:44 --> Controller Class Initialized
INFO - 2025-11-17 12:22:44 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:22:44 --> Model "User_model" initialized
INFO - 2025-11-17 12:22:44 --> Model "Auth_model" initialized
ERROR - 2025-11-17 12:22:44 --> Severity: Warning --> Trying to access array offset on value of type null D:\laragon\www\acumena\application\controllers\Subscription.php 44
ERROR - 2025-11-17 12:22:44 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\laragon\www\acumena\application\controllers\Subscription.php 44
INFO - 2025-11-17 12:22:53 --> Config Class Initialized
INFO - 2025-11-17 12:22:53 --> Hooks Class Initialized
INFO - 2025-11-17 12:22:53 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:22:53 --> Utf8 Class Initialized
INFO - 2025-11-17 12:22:53 --> URI Class Initialized
INFO - 2025-11-17 12:22:53 --> Router Class Initialized
INFO - 2025-11-17 12:22:53 --> Output Class Initialized
INFO - 2025-11-17 12:22:53 --> Security Class Initialized
INFO - 2025-11-17 12:22:53 --> Input Class Initialized
INFO - 2025-11-17 12:22:53 --> Language Class Initialized
INFO - 2025-11-17 12:22:53 --> Loader Class Initialized
INFO - 2025-11-17 12:22:53 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:22:53 --> Helper loaded: url_helper
INFO - 2025-11-17 12:22:53 --> Helper loaded: file_helper
INFO - 2025-11-17 12:22:53 --> Helper loaded: main_helper
INFO - 2025-11-17 12:22:53 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:22:53 --> Database Driver Class Initialized
INFO - 2025-11-17 12:22:53 --> Email Class Initialized
DEBUG - 2025-11-17 12:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:22:53 --> Controller Class Initialized
INFO - 2025-11-17 12:22:53 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:22:53 --> Model "User_model" initialized
INFO - 2025-11-17 12:22:53 --> Model "Auth_model" initialized
ERROR - 2025-11-17 12:22:53 --> Severity: Warning --> Trying to access array offset on value of type null D:\laragon\www\acumena\application\controllers\Subscription.php 44
ERROR - 2025-11-17 12:22:53 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\laragon\www\acumena\application\controllers\Subscription.php 44
INFO - 2025-11-17 12:23:19 --> Config Class Initialized
INFO - 2025-11-17 12:23:19 --> Hooks Class Initialized
INFO - 2025-11-17 12:23:19 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:23:19 --> Utf8 Class Initialized
INFO - 2025-11-17 12:23:19 --> URI Class Initialized
INFO - 2025-11-17 12:23:19 --> Router Class Initialized
INFO - 2025-11-17 12:23:19 --> Output Class Initialized
INFO - 2025-11-17 12:23:19 --> Security Class Initialized
INFO - 2025-11-17 12:23:19 --> Input Class Initialized
INFO - 2025-11-17 12:23:19 --> Language Class Initialized
INFO - 2025-11-17 12:23:19 --> Loader Class Initialized
INFO - 2025-11-17 12:23:19 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:23:19 --> Helper loaded: url_helper
INFO - 2025-11-17 12:23:19 --> Helper loaded: file_helper
INFO - 2025-11-17 12:23:19 --> Helper loaded: main_helper
INFO - 2025-11-17 12:23:19 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:23:19 --> Database Driver Class Initialized
INFO - 2025-11-17 12:23:19 --> Email Class Initialized
DEBUG - 2025-11-17 12:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:23:19 --> Controller Class Initialized
INFO - 2025-11-17 12:23:19 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:23:19 --> Model "User_model" initialized
INFO - 2025-11-17 12:23:19 --> Model "Auth_model" initialized
ERROR - 2025-11-17 12:23:19 --> Severity: Warning --> Attempt to read property "id" on null D:\laragon\www\acumena\application\controllers\Subscription.php 44
INFO - 2025-11-17 12:23:19 --> Config Class Initialized
INFO - 2025-11-17 12:23:19 --> Hooks Class Initialized
INFO - 2025-11-17 12:23:19 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:23:19 --> Utf8 Class Initialized
INFO - 2025-11-17 12:23:19 --> URI Class Initialized
INFO - 2025-11-17 12:23:19 --> Router Class Initialized
INFO - 2025-11-17 12:23:19 --> Output Class Initialized
INFO - 2025-11-17 12:23:19 --> Security Class Initialized
INFO - 2025-11-17 12:23:19 --> Input Class Initialized
INFO - 2025-11-17 12:23:19 --> Language Class Initialized
INFO - 2025-11-17 12:23:19 --> Loader Class Initialized
INFO - 2025-11-17 12:23:19 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:23:19 --> Helper loaded: url_helper
INFO - 2025-11-17 12:23:19 --> Helper loaded: file_helper
INFO - 2025-11-17 12:23:19 --> Helper loaded: main_helper
INFO - 2025-11-17 12:23:19 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:23:19 --> Database Driver Class Initialized
INFO - 2025-11-17 12:23:19 --> Email Class Initialized
DEBUG - 2025-11-17 12:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:23:19 --> Controller Class Initialized
INFO - 2025-11-17 12:23:19 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:23:19 --> Model "User_model" initialized
INFO - 2025-11-17 12:23:19 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:23:19 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 12:23:19 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 12:23:19 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 12:23:19 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 12:23:19 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 12:23:19 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 12:23:19 --> Final output sent to browser
INFO - 2025-11-17 12:23:19 --> Total execution time: 0.1299
INFO - 2025-11-17 12:23:21 --> Config Class Initialized
INFO - 2025-11-17 12:23:21 --> Hooks Class Initialized
INFO - 2025-11-17 12:23:21 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:23:21 --> Utf8 Class Initialized
INFO - 2025-11-17 12:23:21 --> URI Class Initialized
INFO - 2025-11-17 12:23:21 --> Router Class Initialized
INFO - 2025-11-17 12:23:21 --> Output Class Initialized
INFO - 2025-11-17 12:23:21 --> Security Class Initialized
INFO - 2025-11-17 12:23:21 --> Input Class Initialized
INFO - 2025-11-17 12:23:21 --> Language Class Initialized
INFO - 2025-11-17 12:23:21 --> Loader Class Initialized
INFO - 2025-11-17 12:23:21 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:23:21 --> Helper loaded: url_helper
INFO - 2025-11-17 12:23:21 --> Helper loaded: file_helper
INFO - 2025-11-17 12:23:21 --> Helper loaded: main_helper
INFO - 2025-11-17 12:23:21 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:23:21 --> Database Driver Class Initialized
INFO - 2025-11-17 12:23:21 --> Email Class Initialized
DEBUG - 2025-11-17 12:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:23:21 --> Controller Class Initialized
INFO - 2025-11-17 12:23:21 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:23:21 --> Model "User_model" initialized
INFO - 2025-11-17 12:23:21 --> Model "Auth_model" initialized
ERROR - 2025-11-17 12:23:21 --> Severity: Warning --> Attempt to read property "id" on null D:\laragon\www\acumena\application\controllers\Subscription.php 44
INFO - 2025-11-17 12:23:21 --> Config Class Initialized
INFO - 2025-11-17 12:23:21 --> Hooks Class Initialized
INFO - 2025-11-17 12:23:21 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:23:21 --> Utf8 Class Initialized
INFO - 2025-11-17 12:23:21 --> URI Class Initialized
INFO - 2025-11-17 12:23:21 --> Router Class Initialized
INFO - 2025-11-17 12:23:21 --> Output Class Initialized
INFO - 2025-11-17 12:23:21 --> Security Class Initialized
INFO - 2025-11-17 12:23:21 --> Input Class Initialized
INFO - 2025-11-17 12:23:21 --> Language Class Initialized
INFO - 2025-11-17 12:23:21 --> Loader Class Initialized
INFO - 2025-11-17 12:23:21 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:23:21 --> Helper loaded: url_helper
INFO - 2025-11-17 12:23:21 --> Helper loaded: file_helper
INFO - 2025-11-17 12:23:21 --> Helper loaded: main_helper
INFO - 2025-11-17 12:23:21 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:23:21 --> Database Driver Class Initialized
INFO - 2025-11-17 12:23:21 --> Email Class Initialized
DEBUG - 2025-11-17 12:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:23:21 --> Controller Class Initialized
INFO - 2025-11-17 12:23:21 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:23:21 --> Model "User_model" initialized
INFO - 2025-11-17 12:23:21 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:23:21 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 12:23:21 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 12:23:21 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 12:23:21 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 12:23:21 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 12:23:21 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 12:23:21 --> Final output sent to browser
INFO - 2025-11-17 12:23:21 --> Total execution time: 0.1072
INFO - 2025-11-17 12:23:24 --> Config Class Initialized
INFO - 2025-11-17 12:23:24 --> Hooks Class Initialized
INFO - 2025-11-17 12:23:24 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:23:24 --> Utf8 Class Initialized
INFO - 2025-11-17 12:23:24 --> URI Class Initialized
INFO - 2025-11-17 12:23:24 --> Router Class Initialized
INFO - 2025-11-17 12:23:24 --> Output Class Initialized
INFO - 2025-11-17 12:23:24 --> Security Class Initialized
INFO - 2025-11-17 12:23:24 --> Input Class Initialized
INFO - 2025-11-17 12:23:24 --> Language Class Initialized
INFO - 2025-11-17 12:23:24 --> Loader Class Initialized
INFO - 2025-11-17 12:23:24 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:23:24 --> Helper loaded: url_helper
INFO - 2025-11-17 12:23:24 --> Helper loaded: file_helper
INFO - 2025-11-17 12:23:24 --> Helper loaded: main_helper
INFO - 2025-11-17 12:23:24 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:23:24 --> Database Driver Class Initialized
INFO - 2025-11-17 12:23:24 --> Email Class Initialized
DEBUG - 2025-11-17 12:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:23:24 --> Controller Class Initialized
INFO - 2025-11-17 12:23:24 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:23:24 --> Model "User_model" initialized
INFO - 2025-11-17 12:23:24 --> Model "Auth_model" initialized
ERROR - 2025-11-17 12:23:24 --> Severity: Warning --> Attempt to read property "id" on null D:\laragon\www\acumena\application\controllers\Subscription.php 44
INFO - 2025-11-17 12:23:24 --> Config Class Initialized
INFO - 2025-11-17 12:23:24 --> Hooks Class Initialized
INFO - 2025-11-17 12:23:24 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:23:24 --> Utf8 Class Initialized
INFO - 2025-11-17 12:23:24 --> URI Class Initialized
INFO - 2025-11-17 12:23:24 --> Router Class Initialized
INFO - 2025-11-17 12:23:24 --> Output Class Initialized
INFO - 2025-11-17 12:23:24 --> Security Class Initialized
INFO - 2025-11-17 12:23:24 --> Input Class Initialized
INFO - 2025-11-17 12:23:24 --> Language Class Initialized
INFO - 2025-11-17 12:23:24 --> Loader Class Initialized
INFO - 2025-11-17 12:23:24 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:23:24 --> Helper loaded: url_helper
INFO - 2025-11-17 12:23:24 --> Helper loaded: file_helper
INFO - 2025-11-17 12:23:24 --> Helper loaded: main_helper
INFO - 2025-11-17 12:23:24 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:23:24 --> Database Driver Class Initialized
INFO - 2025-11-17 12:23:24 --> Email Class Initialized
DEBUG - 2025-11-17 12:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:23:24 --> Controller Class Initialized
INFO - 2025-11-17 12:23:24 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:23:24 --> Model "User_model" initialized
INFO - 2025-11-17 12:23:24 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:23:24 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 12:23:24 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 12:23:24 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 12:23:24 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 12:23:24 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 12:23:24 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 12:23:24 --> Final output sent to browser
INFO - 2025-11-17 12:23:24 --> Total execution time: 0.0870
INFO - 2025-11-17 12:23:39 --> Config Class Initialized
INFO - 2025-11-17 12:23:39 --> Hooks Class Initialized
INFO - 2025-11-17 12:23:39 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:23:39 --> Utf8 Class Initialized
INFO - 2025-11-17 12:23:39 --> URI Class Initialized
INFO - 2025-11-17 12:23:39 --> Router Class Initialized
INFO - 2025-11-17 12:23:39 --> Output Class Initialized
INFO - 2025-11-17 12:23:39 --> Security Class Initialized
INFO - 2025-11-17 12:23:39 --> Input Class Initialized
INFO - 2025-11-17 12:23:39 --> Language Class Initialized
INFO - 2025-11-17 12:23:39 --> Loader Class Initialized
INFO - 2025-11-17 12:23:39 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:23:39 --> Helper loaded: url_helper
INFO - 2025-11-17 12:23:39 --> Helper loaded: file_helper
INFO - 2025-11-17 12:23:39 --> Helper loaded: main_helper
INFO - 2025-11-17 12:23:39 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:23:40 --> Database Driver Class Initialized
INFO - 2025-11-17 12:23:40 --> Email Class Initialized
DEBUG - 2025-11-17 12:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:23:40 --> Controller Class Initialized
INFO - 2025-11-17 12:23:40 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:23:40 --> Model "User_model" initialized
INFO - 2025-11-17 12:23:40 --> Model "Auth_model" initialized
ERROR - 2025-11-17 12:23:40 --> Severity: Warning --> Attempt to read property "id" on null D:\laragon\www\acumena\application\controllers\Subscription.php 44
INFO - 2025-11-17 12:23:40 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:23:40 --> Final output sent to browser
INFO - 2025-11-17 12:23:40 --> Total execution time: 0.1100
INFO - 2025-11-17 12:24:00 --> Config Class Initialized
INFO - 2025-11-17 12:24:00 --> Hooks Class Initialized
INFO - 2025-11-17 12:24:00 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:24:00 --> Utf8 Class Initialized
INFO - 2025-11-17 12:24:00 --> URI Class Initialized
INFO - 2025-11-17 12:24:00 --> Router Class Initialized
INFO - 2025-11-17 12:24:00 --> Output Class Initialized
INFO - 2025-11-17 12:24:00 --> Security Class Initialized
INFO - 2025-11-17 12:24:00 --> Input Class Initialized
INFO - 2025-11-17 12:24:00 --> Language Class Initialized
INFO - 2025-11-17 12:24:00 --> Loader Class Initialized
INFO - 2025-11-17 12:24:00 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:24:00 --> Helper loaded: url_helper
INFO - 2025-11-17 12:24:00 --> Helper loaded: file_helper
INFO - 2025-11-17 12:24:00 --> Helper loaded: main_helper
INFO - 2025-11-17 12:24:00 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:24:00 --> Database Driver Class Initialized
INFO - 2025-11-17 12:24:00 --> Email Class Initialized
DEBUG - 2025-11-17 12:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:24:00 --> Controller Class Initialized
INFO - 2025-11-17 12:24:00 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:24:00 --> Model "User_model" initialized
INFO - 2025-11-17 12:24:00 --> Model "Auth_model" initialized
ERROR - 2025-11-17 12:24:00 --> Severity: Warning --> Attempt to read property "id" on null D:\laragon\www\acumena\application\controllers\Subscription.php 44
INFO - 2025-11-17 12:24:00 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:24:00 --> Final output sent to browser
INFO - 2025-11-17 12:24:00 --> Total execution time: 0.1203
INFO - 2025-11-17 12:24:16 --> Config Class Initialized
INFO - 2025-11-17 12:24:16 --> Hooks Class Initialized
INFO - 2025-11-17 12:24:16 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:24:16 --> Utf8 Class Initialized
INFO - 2025-11-17 12:24:16 --> URI Class Initialized
INFO - 2025-11-17 12:24:16 --> Router Class Initialized
INFO - 2025-11-17 12:24:16 --> Output Class Initialized
INFO - 2025-11-17 12:24:16 --> Security Class Initialized
INFO - 2025-11-17 12:24:16 --> Input Class Initialized
INFO - 2025-11-17 12:24:16 --> Language Class Initialized
INFO - 2025-11-17 12:24:16 --> Loader Class Initialized
INFO - 2025-11-17 12:24:16 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:24:16 --> Helper loaded: url_helper
INFO - 2025-11-17 12:24:16 --> Helper loaded: file_helper
INFO - 2025-11-17 12:24:16 --> Helper loaded: main_helper
INFO - 2025-11-17 12:24:16 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:24:16 --> Database Driver Class Initialized
INFO - 2025-11-17 12:24:16 --> Email Class Initialized
DEBUG - 2025-11-17 12:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:24:16 --> Controller Class Initialized
INFO - 2025-11-17 12:24:16 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:24:16 --> Model "User_model" initialized
INFO - 2025-11-17 12:24:16 --> Model "Auth_model" initialized
ERROR - 2025-11-17 12:24:16 --> Severity: Warning --> Attempt to read property "id" on null D:\laragon\www\acumena\application\controllers\Subscription.php 44
ERROR - 2025-11-17 12:24:16 --> Severity: Warning --> Attempt to read property "id" on null D:\laragon\www\acumena\application\controllers\Subscription.php 46
INFO - 2025-11-17 12:24:16 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:24:16 --> Final output sent to browser
INFO - 2025-11-17 12:24:16 --> Total execution time: 0.1290
INFO - 2025-11-17 12:29:31 --> Config Class Initialized
INFO - 2025-11-17 12:29:31 --> Hooks Class Initialized
INFO - 2025-11-17 12:29:31 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:29:31 --> Utf8 Class Initialized
INFO - 2025-11-17 12:29:31 --> URI Class Initialized
INFO - 2025-11-17 12:29:31 --> Router Class Initialized
INFO - 2025-11-17 12:29:31 --> Output Class Initialized
INFO - 2025-11-17 12:29:31 --> Security Class Initialized
INFO - 2025-11-17 12:29:31 --> Input Class Initialized
INFO - 2025-11-17 12:29:31 --> Language Class Initialized
INFO - 2025-11-17 12:29:31 --> Loader Class Initialized
INFO - 2025-11-17 12:29:31 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:29:31 --> Helper loaded: url_helper
INFO - 2025-11-17 12:29:31 --> Helper loaded: file_helper
INFO - 2025-11-17 12:29:31 --> Helper loaded: main_helper
INFO - 2025-11-17 12:29:31 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:29:31 --> Database Driver Class Initialized
INFO - 2025-11-17 12:29:31 --> Email Class Initialized
DEBUG - 2025-11-17 12:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:29:31 --> Controller Class Initialized
INFO - 2025-11-17 12:29:31 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:29:31 --> Model "User_model" initialized
INFO - 2025-11-17 12:29:31 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:29:31 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:29:31 --> Final output sent to browser
INFO - 2025-11-17 12:29:31 --> Total execution time: 0.1065
INFO - 2025-11-17 12:29:57 --> Config Class Initialized
INFO - 2025-11-17 12:29:57 --> Hooks Class Initialized
INFO - 2025-11-17 12:29:57 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:29:57 --> Utf8 Class Initialized
INFO - 2025-11-17 12:29:57 --> URI Class Initialized
INFO - 2025-11-17 12:29:57 --> Router Class Initialized
INFO - 2025-11-17 12:29:57 --> Output Class Initialized
INFO - 2025-11-17 12:29:57 --> Security Class Initialized
INFO - 2025-11-17 12:29:57 --> Input Class Initialized
INFO - 2025-11-17 12:29:57 --> Language Class Initialized
INFO - 2025-11-17 12:29:57 --> Loader Class Initialized
INFO - 2025-11-17 12:29:57 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:29:57 --> Helper loaded: url_helper
INFO - 2025-11-17 12:29:57 --> Helper loaded: file_helper
INFO - 2025-11-17 12:29:57 --> Helper loaded: main_helper
INFO - 2025-11-17 12:29:57 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:29:57 --> Database Driver Class Initialized
INFO - 2025-11-17 12:29:57 --> Email Class Initialized
DEBUG - 2025-11-17 12:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:29:57 --> Controller Class Initialized
INFO - 2025-11-17 12:29:57 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:29:57 --> Model "User_model" initialized
INFO - 2025-11-17 12:29:57 --> Model "Auth_model" initialized
ERROR - 2025-11-17 12:29:57 --> Severity: Warning --> Attempt to read property "id" on null D:\laragon\www\acumena\application\controllers\Subscription.php 44
ERROR - 2025-11-17 12:29:57 --> Severity: Warning --> Attempt to read property "id" on null D:\laragon\www\acumena\application\controllers\Subscription.php 46
INFO - 2025-11-17 12:29:57 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:29:57 --> Final output sent to browser
INFO - 2025-11-17 12:29:57 --> Total execution time: 0.1181
INFO - 2025-11-17 12:30:11 --> Config Class Initialized
INFO - 2025-11-17 12:30:11 --> Hooks Class Initialized
INFO - 2025-11-17 12:30:11 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:30:11 --> Utf8 Class Initialized
INFO - 2025-11-17 12:30:11 --> URI Class Initialized
INFO - 2025-11-17 12:30:11 --> Router Class Initialized
INFO - 2025-11-17 12:30:11 --> Output Class Initialized
INFO - 2025-11-17 12:30:11 --> Security Class Initialized
INFO - 2025-11-17 12:30:11 --> Input Class Initialized
INFO - 2025-11-17 12:30:11 --> Language Class Initialized
INFO - 2025-11-17 12:30:11 --> Loader Class Initialized
INFO - 2025-11-17 12:30:11 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:30:11 --> Helper loaded: url_helper
INFO - 2025-11-17 12:30:11 --> Helper loaded: file_helper
INFO - 2025-11-17 12:30:11 --> Helper loaded: main_helper
INFO - 2025-11-17 12:30:11 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:30:11 --> Database Driver Class Initialized
INFO - 2025-11-17 12:30:11 --> Email Class Initialized
DEBUG - 2025-11-17 12:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:30:11 --> Controller Class Initialized
INFO - 2025-11-17 12:30:11 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:30:11 --> Model "User_model" initialized
INFO - 2025-11-17 12:30:11 --> Model "Auth_model" initialized
ERROR - 2025-11-17 12:30:11 --> Severity: Warning --> Attempt to read property "id" on null D:\laragon\www\acumena\application\controllers\Subscription.php 44
ERROR - 2025-11-17 12:30:11 --> Severity: Warning --> Trying to access array offset on value of type null D:\laragon\www\acumena\application\controllers\Subscription.php 46
INFO - 2025-11-17 12:30:11 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:30:11 --> Final output sent to browser
INFO - 2025-11-17 12:30:11 --> Total execution time: 0.1274
INFO - 2025-11-17 12:30:20 --> Config Class Initialized
INFO - 2025-11-17 12:30:20 --> Hooks Class Initialized
INFO - 2025-11-17 12:30:20 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:30:20 --> Utf8 Class Initialized
INFO - 2025-11-17 12:30:20 --> URI Class Initialized
INFO - 2025-11-17 12:30:20 --> Router Class Initialized
INFO - 2025-11-17 12:30:20 --> Output Class Initialized
INFO - 2025-11-17 12:30:20 --> Security Class Initialized
INFO - 2025-11-17 12:30:20 --> Input Class Initialized
INFO - 2025-11-17 12:30:20 --> Language Class Initialized
INFO - 2025-11-17 12:30:20 --> Loader Class Initialized
INFO - 2025-11-17 12:30:20 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:30:20 --> Helper loaded: url_helper
INFO - 2025-11-17 12:30:20 --> Helper loaded: file_helper
INFO - 2025-11-17 12:30:20 --> Helper loaded: main_helper
INFO - 2025-11-17 12:30:20 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:30:20 --> Database Driver Class Initialized
INFO - 2025-11-17 12:30:20 --> Email Class Initialized
DEBUG - 2025-11-17 12:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:30:20 --> Controller Class Initialized
INFO - 2025-11-17 12:30:20 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:30:20 --> Model "User_model" initialized
INFO - 2025-11-17 12:30:20 --> Model "Auth_model" initialized
ERROR - 2025-11-17 12:30:20 --> Severity: Warning --> Attempt to read property "id" on null D:\laragon\www\acumena\application\controllers\Subscription.php 44
ERROR - 2025-11-17 12:30:20 --> Severity: Warning --> Attempt to read property "id" on null D:\laragon\www\acumena\application\controllers\Subscription.php 46
INFO - 2025-11-17 12:30:20 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:30:20 --> Final output sent to browser
INFO - 2025-11-17 12:30:20 --> Total execution time: 0.0893
INFO - 2025-11-17 12:30:35 --> Config Class Initialized
INFO - 2025-11-17 12:30:35 --> Hooks Class Initialized
INFO - 2025-11-17 12:30:35 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:30:35 --> Utf8 Class Initialized
INFO - 2025-11-17 12:30:35 --> URI Class Initialized
INFO - 2025-11-17 12:30:35 --> Router Class Initialized
INFO - 2025-11-17 12:30:35 --> Output Class Initialized
INFO - 2025-11-17 12:30:35 --> Security Class Initialized
INFO - 2025-11-17 12:30:35 --> Input Class Initialized
INFO - 2025-11-17 12:30:35 --> Language Class Initialized
INFO - 2025-11-17 12:30:35 --> Loader Class Initialized
INFO - 2025-11-17 12:30:35 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:30:35 --> Helper loaded: url_helper
INFO - 2025-11-17 12:30:35 --> Helper loaded: file_helper
INFO - 2025-11-17 12:30:35 --> Helper loaded: main_helper
INFO - 2025-11-17 12:30:36 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:30:36 --> Database Driver Class Initialized
INFO - 2025-11-17 12:30:36 --> Email Class Initialized
DEBUG - 2025-11-17 12:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:30:36 --> Controller Class Initialized
INFO - 2025-11-17 12:30:36 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:30:36 --> Model "User_model" initialized
INFO - 2025-11-17 12:30:36 --> Model "Auth_model" initialized
ERROR - 2025-11-17 12:30:36 --> Severity: Warning --> Attempt to read property "id" on null D:\laragon\www\acumena\application\controllers\Subscription.php 44
INFO - 2025-11-17 12:30:36 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:30:36 --> Final output sent to browser
INFO - 2025-11-17 12:30:36 --> Total execution time: 0.2642
INFO - 2025-11-17 12:30:50 --> Config Class Initialized
INFO - 2025-11-17 12:30:50 --> Hooks Class Initialized
INFO - 2025-11-17 12:30:50 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:30:50 --> Utf8 Class Initialized
INFO - 2025-11-17 12:30:50 --> URI Class Initialized
INFO - 2025-11-17 12:30:50 --> Router Class Initialized
INFO - 2025-11-17 12:30:50 --> Output Class Initialized
INFO - 2025-11-17 12:30:50 --> Security Class Initialized
INFO - 2025-11-17 12:30:50 --> Input Class Initialized
INFO - 2025-11-17 12:30:50 --> Language Class Initialized
INFO - 2025-11-17 12:30:50 --> Loader Class Initialized
INFO - 2025-11-17 12:30:50 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:30:50 --> Helper loaded: url_helper
INFO - 2025-11-17 12:30:50 --> Helper loaded: file_helper
INFO - 2025-11-17 12:30:50 --> Helper loaded: main_helper
INFO - 2025-11-17 12:30:50 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:30:50 --> Database Driver Class Initialized
INFO - 2025-11-17 12:30:50 --> Email Class Initialized
DEBUG - 2025-11-17 12:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:30:50 --> Controller Class Initialized
INFO - 2025-11-17 12:30:50 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:30:50 --> Model "User_model" initialized
INFO - 2025-11-17 12:30:50 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:30:50 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:30:50 --> Final output sent to browser
INFO - 2025-11-17 12:30:50 --> Total execution time: 0.1194
INFO - 2025-11-17 12:31:25 --> Config Class Initialized
INFO - 2025-11-17 12:31:25 --> Hooks Class Initialized
INFO - 2025-11-17 12:31:25 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:31:25 --> Utf8 Class Initialized
INFO - 2025-11-17 12:31:25 --> URI Class Initialized
INFO - 2025-11-17 12:31:25 --> Router Class Initialized
INFO - 2025-11-17 12:31:25 --> Output Class Initialized
INFO - 2025-11-17 12:31:25 --> Security Class Initialized
INFO - 2025-11-17 12:31:25 --> Input Class Initialized
INFO - 2025-11-17 12:31:25 --> Language Class Initialized
INFO - 2025-11-17 12:31:25 --> Loader Class Initialized
INFO - 2025-11-17 12:31:25 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:31:25 --> Helper loaded: url_helper
INFO - 2025-11-17 12:31:25 --> Helper loaded: file_helper
INFO - 2025-11-17 12:31:25 --> Helper loaded: main_helper
INFO - 2025-11-17 12:31:25 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:31:25 --> Database Driver Class Initialized
INFO - 2025-11-17 12:31:25 --> Email Class Initialized
DEBUG - 2025-11-17 12:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:31:25 --> Controller Class Initialized
INFO - 2025-11-17 12:31:25 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:31:25 --> Model "User_model" initialized
INFO - 2025-11-17 12:31:25 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:31:25 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:31:25 --> Final output sent to browser
INFO - 2025-11-17 12:31:25 --> Total execution time: 0.2423
INFO - 2025-11-17 12:31:35 --> Config Class Initialized
INFO - 2025-11-17 12:31:35 --> Hooks Class Initialized
INFO - 2025-11-17 12:31:35 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:31:35 --> Utf8 Class Initialized
INFO - 2025-11-17 12:31:35 --> URI Class Initialized
INFO - 2025-11-17 12:31:35 --> Router Class Initialized
INFO - 2025-11-17 12:31:35 --> Output Class Initialized
INFO - 2025-11-17 12:31:35 --> Security Class Initialized
INFO - 2025-11-17 12:31:35 --> Input Class Initialized
INFO - 2025-11-17 12:31:35 --> Language Class Initialized
INFO - 2025-11-17 12:31:35 --> Loader Class Initialized
INFO - 2025-11-17 12:31:35 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:31:35 --> Helper loaded: url_helper
INFO - 2025-11-17 12:31:35 --> Helper loaded: file_helper
INFO - 2025-11-17 12:31:35 --> Helper loaded: main_helper
INFO - 2025-11-17 12:31:35 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:31:35 --> Database Driver Class Initialized
INFO - 2025-11-17 12:31:35 --> Email Class Initialized
DEBUG - 2025-11-17 12:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:31:35 --> Controller Class Initialized
INFO - 2025-11-17 12:31:35 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:31:35 --> Model "User_model" initialized
INFO - 2025-11-17 12:31:35 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:31:35 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:31:35 --> Final output sent to browser
INFO - 2025-11-17 12:31:35 --> Total execution time: 0.0901
INFO - 2025-11-17 12:32:15 --> Config Class Initialized
INFO - 2025-11-17 12:32:15 --> Hooks Class Initialized
INFO - 2025-11-17 12:32:15 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:32:15 --> Utf8 Class Initialized
INFO - 2025-11-17 12:32:15 --> URI Class Initialized
INFO - 2025-11-17 12:32:15 --> Router Class Initialized
INFO - 2025-11-17 12:32:15 --> Output Class Initialized
INFO - 2025-11-17 12:32:15 --> Security Class Initialized
INFO - 2025-11-17 12:32:15 --> Input Class Initialized
INFO - 2025-11-17 12:32:15 --> Language Class Initialized
INFO - 2025-11-17 12:32:15 --> Loader Class Initialized
INFO - 2025-11-17 12:32:15 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:32:15 --> Helper loaded: url_helper
INFO - 2025-11-17 12:32:15 --> Helper loaded: file_helper
INFO - 2025-11-17 12:32:15 --> Helper loaded: main_helper
INFO - 2025-11-17 12:32:15 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:32:15 --> Database Driver Class Initialized
INFO - 2025-11-17 12:32:15 --> Email Class Initialized
DEBUG - 2025-11-17 12:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:32:15 --> Controller Class Initialized
INFO - 2025-11-17 12:32:15 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:32:15 --> Model "User_model" initialized
INFO - 2025-11-17 12:32:15 --> Model "Auth_model" initialized
ERROR - 2025-11-17 12:32:15 --> Severity: Warning --> Undefined property: stdClass::$invoice_date D:\laragon\www\acumena\application\views\subscriptions\invoice.php 32
ERROR - 2025-11-17 12:32:15 --> Severity: Warning --> Undefined property: stdClass::$due_date D:\laragon\www\acumena\application\views\subscriptions\invoice.php 33
INFO - 2025-11-17 12:32:15 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:32:15 --> Final output sent to browser
INFO - 2025-11-17 12:32:15 --> Total execution time: 0.1026
INFO - 2025-11-17 12:32:27 --> Config Class Initialized
INFO - 2025-11-17 12:32:27 --> Hooks Class Initialized
INFO - 2025-11-17 12:32:27 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:32:27 --> Utf8 Class Initialized
INFO - 2025-11-17 12:32:27 --> URI Class Initialized
INFO - 2025-11-17 12:32:27 --> Router Class Initialized
INFO - 2025-11-17 12:32:27 --> Output Class Initialized
INFO - 2025-11-17 12:32:27 --> Security Class Initialized
INFO - 2025-11-17 12:32:27 --> Input Class Initialized
INFO - 2025-11-17 12:32:27 --> Language Class Initialized
INFO - 2025-11-17 12:32:27 --> Loader Class Initialized
INFO - 2025-11-17 12:32:27 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:32:27 --> Helper loaded: url_helper
INFO - 2025-11-17 12:32:27 --> Helper loaded: file_helper
INFO - 2025-11-17 12:32:27 --> Helper loaded: main_helper
INFO - 2025-11-17 12:32:27 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:32:27 --> Database Driver Class Initialized
INFO - 2025-11-17 12:32:27 --> Email Class Initialized
DEBUG - 2025-11-17 12:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:32:27 --> Controller Class Initialized
INFO - 2025-11-17 12:32:27 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:32:27 --> Model "User_model" initialized
INFO - 2025-11-17 12:32:27 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:32:27 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:32:27 --> Final output sent to browser
INFO - 2025-11-17 12:32:27 --> Total execution time: 0.0890
INFO - 2025-11-17 12:32:45 --> Config Class Initialized
INFO - 2025-11-17 12:32:45 --> Hooks Class Initialized
INFO - 2025-11-17 12:32:45 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:32:45 --> Utf8 Class Initialized
INFO - 2025-11-17 12:32:45 --> URI Class Initialized
INFO - 2025-11-17 12:32:45 --> Router Class Initialized
INFO - 2025-11-17 12:32:45 --> Output Class Initialized
INFO - 2025-11-17 12:32:45 --> Security Class Initialized
INFO - 2025-11-17 12:32:45 --> Input Class Initialized
INFO - 2025-11-17 12:32:45 --> Language Class Initialized
INFO - 2025-11-17 12:32:45 --> Loader Class Initialized
INFO - 2025-11-17 12:32:45 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:32:45 --> Helper loaded: url_helper
INFO - 2025-11-17 12:32:45 --> Helper loaded: file_helper
INFO - 2025-11-17 12:32:45 --> Helper loaded: main_helper
INFO - 2025-11-17 12:32:45 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:32:45 --> Database Driver Class Initialized
INFO - 2025-11-17 12:32:45 --> Email Class Initialized
DEBUG - 2025-11-17 12:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:32:45 --> Controller Class Initialized
INFO - 2025-11-17 12:32:45 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:32:45 --> Model "User_model" initialized
INFO - 2025-11-17 12:32:45 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:32:45 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:32:45 --> Final output sent to browser
INFO - 2025-11-17 12:32:45 --> Total execution time: 0.1219
INFO - 2025-11-17 12:32:55 --> Config Class Initialized
INFO - 2025-11-17 12:32:55 --> Hooks Class Initialized
INFO - 2025-11-17 12:32:55 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:32:55 --> Utf8 Class Initialized
INFO - 2025-11-17 12:32:55 --> URI Class Initialized
INFO - 2025-11-17 12:32:55 --> Router Class Initialized
INFO - 2025-11-17 12:32:55 --> Output Class Initialized
INFO - 2025-11-17 12:32:55 --> Security Class Initialized
INFO - 2025-11-17 12:32:55 --> Input Class Initialized
INFO - 2025-11-17 12:32:55 --> Language Class Initialized
INFO - 2025-11-17 12:32:55 --> Loader Class Initialized
INFO - 2025-11-17 12:32:55 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:32:55 --> Helper loaded: url_helper
INFO - 2025-11-17 12:32:55 --> Helper loaded: file_helper
INFO - 2025-11-17 12:32:55 --> Helper loaded: main_helper
INFO - 2025-11-17 12:32:55 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:32:55 --> Database Driver Class Initialized
INFO - 2025-11-17 12:32:55 --> Email Class Initialized
DEBUG - 2025-11-17 12:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:32:55 --> Controller Class Initialized
INFO - 2025-11-17 12:32:55 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:32:55 --> Model "User_model" initialized
INFO - 2025-11-17 12:32:55 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:32:55 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:32:55 --> Final output sent to browser
INFO - 2025-11-17 12:32:55 --> Total execution time: 0.1368
INFO - 2025-11-17 12:33:15 --> Config Class Initialized
INFO - 2025-11-17 12:33:15 --> Hooks Class Initialized
INFO - 2025-11-17 12:33:15 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:33:15 --> Utf8 Class Initialized
INFO - 2025-11-17 12:33:15 --> URI Class Initialized
INFO - 2025-11-17 12:33:15 --> Router Class Initialized
INFO - 2025-11-17 12:33:15 --> Output Class Initialized
INFO - 2025-11-17 12:33:15 --> Security Class Initialized
INFO - 2025-11-17 12:33:15 --> Input Class Initialized
INFO - 2025-11-17 12:33:15 --> Language Class Initialized
INFO - 2025-11-17 12:33:15 --> Loader Class Initialized
INFO - 2025-11-17 12:33:15 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:33:15 --> Helper loaded: url_helper
INFO - 2025-11-17 12:33:15 --> Helper loaded: file_helper
INFO - 2025-11-17 12:33:15 --> Helper loaded: main_helper
INFO - 2025-11-17 12:33:15 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:33:15 --> Database Driver Class Initialized
INFO - 2025-11-17 12:33:15 --> Email Class Initialized
DEBUG - 2025-11-17 12:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:33:15 --> Controller Class Initialized
INFO - 2025-11-17 12:33:15 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:33:15 --> Model "User_model" initialized
INFO - 2025-11-17 12:33:15 --> Model "Auth_model" initialized
ERROR - 2025-11-17 12:33:15 --> Severity: Warning --> Undefined property: stdClass::$invoice_date D:\laragon\www\acumena\application\views\subscriptions\invoice.php 32
ERROR - 2025-11-17 12:33:15 --> Severity: Deprecated Notice --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated D:\laragon\www\acumena\application\views\subscriptions\invoice.php 32
INFO - 2025-11-17 12:33:15 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:33:15 --> Final output sent to browser
INFO - 2025-11-17 12:33:15 --> Total execution time: 0.1352
INFO - 2025-11-17 12:33:24 --> Config Class Initialized
INFO - 2025-11-17 12:33:24 --> Hooks Class Initialized
INFO - 2025-11-17 12:33:24 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:33:24 --> Utf8 Class Initialized
INFO - 2025-11-17 12:33:24 --> URI Class Initialized
INFO - 2025-11-17 12:33:24 --> Router Class Initialized
INFO - 2025-11-17 12:33:24 --> Output Class Initialized
INFO - 2025-11-17 12:33:24 --> Security Class Initialized
INFO - 2025-11-17 12:33:24 --> Input Class Initialized
INFO - 2025-11-17 12:33:24 --> Language Class Initialized
INFO - 2025-11-17 12:33:24 --> Loader Class Initialized
INFO - 2025-11-17 12:33:24 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:33:24 --> Helper loaded: url_helper
INFO - 2025-11-17 12:33:24 --> Helper loaded: file_helper
INFO - 2025-11-17 12:33:24 --> Helper loaded: main_helper
INFO - 2025-11-17 12:33:24 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:33:24 --> Database Driver Class Initialized
INFO - 2025-11-17 12:33:24 --> Email Class Initialized
DEBUG - 2025-11-17 12:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:33:24 --> Controller Class Initialized
INFO - 2025-11-17 12:33:24 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:33:24 --> Model "User_model" initialized
INFO - 2025-11-17 12:33:24 --> Model "Auth_model" initialized
ERROR - 2025-11-17 12:33:24 --> Severity: Warning --> Undefined property: stdClass::$date_create D:\laragon\www\acumena\application\views\subscriptions\invoice.php 32
ERROR - 2025-11-17 12:33:24 --> Severity: Deprecated Notice --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated D:\laragon\www\acumena\application\views\subscriptions\invoice.php 32
INFO - 2025-11-17 12:33:24 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:33:24 --> Final output sent to browser
INFO - 2025-11-17 12:33:24 --> Total execution time: 0.1275
INFO - 2025-11-17 12:33:28 --> Config Class Initialized
INFO - 2025-11-17 12:33:28 --> Hooks Class Initialized
INFO - 2025-11-17 12:33:28 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:33:28 --> Utf8 Class Initialized
INFO - 2025-11-17 12:33:28 --> URI Class Initialized
INFO - 2025-11-17 12:33:28 --> Router Class Initialized
INFO - 2025-11-17 12:33:28 --> Output Class Initialized
INFO - 2025-11-17 12:33:28 --> Security Class Initialized
INFO - 2025-11-17 12:33:28 --> Input Class Initialized
INFO - 2025-11-17 12:33:28 --> Language Class Initialized
INFO - 2025-11-17 12:33:28 --> Loader Class Initialized
INFO - 2025-11-17 12:33:28 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:33:28 --> Helper loaded: url_helper
INFO - 2025-11-17 12:33:28 --> Helper loaded: file_helper
INFO - 2025-11-17 12:33:28 --> Helper loaded: main_helper
INFO - 2025-11-17 12:33:28 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:33:28 --> Database Driver Class Initialized
INFO - 2025-11-17 12:33:28 --> Email Class Initialized
DEBUG - 2025-11-17 12:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:33:28 --> Controller Class Initialized
INFO - 2025-11-17 12:33:28 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:33:28 --> Model "User_model" initialized
INFO - 2025-11-17 12:33:28 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:33:28 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:33:28 --> Final output sent to browser
INFO - 2025-11-17 12:33:28 --> Total execution time: 0.0849
INFO - 2025-11-17 12:35:33 --> Config Class Initialized
INFO - 2025-11-17 12:35:33 --> Hooks Class Initialized
INFO - 2025-11-17 12:35:33 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:35:33 --> Utf8 Class Initialized
INFO - 2025-11-17 12:35:34 --> URI Class Initialized
INFO - 2025-11-17 12:35:34 --> Router Class Initialized
INFO - 2025-11-17 12:35:34 --> Output Class Initialized
INFO - 2025-11-17 12:35:34 --> Security Class Initialized
INFO - 2025-11-17 12:35:34 --> Input Class Initialized
INFO - 2025-11-17 12:35:34 --> Language Class Initialized
INFO - 2025-11-17 12:35:34 --> Loader Class Initialized
INFO - 2025-11-17 12:35:34 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:35:34 --> Helper loaded: url_helper
INFO - 2025-11-17 12:35:34 --> Helper loaded: file_helper
INFO - 2025-11-17 12:35:34 --> Helper loaded: main_helper
INFO - 2025-11-17 12:35:34 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:35:34 --> Database Driver Class Initialized
INFO - 2025-11-17 12:35:34 --> Email Class Initialized
DEBUG - 2025-11-17 12:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:35:34 --> Controller Class Initialized
INFO - 2025-11-17 12:35:34 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:35:34 --> Model "User_model" initialized
INFO - 2025-11-17 12:35:34 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:35:34 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:35:34 --> Final output sent to browser
INFO - 2025-11-17 12:35:34 --> Total execution time: 0.4323
INFO - 2025-11-17 12:36:17 --> Config Class Initialized
INFO - 2025-11-17 12:36:17 --> Hooks Class Initialized
INFO - 2025-11-17 12:36:17 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:36:17 --> Utf8 Class Initialized
INFO - 2025-11-17 12:36:17 --> URI Class Initialized
INFO - 2025-11-17 12:36:17 --> Router Class Initialized
INFO - 2025-11-17 12:36:17 --> Output Class Initialized
INFO - 2025-11-17 12:36:17 --> Security Class Initialized
INFO - 2025-11-17 12:36:17 --> Input Class Initialized
INFO - 2025-11-17 12:36:17 --> Language Class Initialized
INFO - 2025-11-17 12:36:18 --> Loader Class Initialized
INFO - 2025-11-17 12:36:18 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:36:18 --> Helper loaded: url_helper
INFO - 2025-11-17 12:36:18 --> Helper loaded: file_helper
INFO - 2025-11-17 12:36:18 --> Helper loaded: main_helper
INFO - 2025-11-17 12:36:18 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:36:18 --> Database Driver Class Initialized
INFO - 2025-11-17 12:36:18 --> Email Class Initialized
DEBUG - 2025-11-17 12:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:36:18 --> Controller Class Initialized
INFO - 2025-11-17 12:36:18 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:36:18 --> Model "User_model" initialized
INFO - 2025-11-17 12:36:18 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:36:18 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:36:18 --> Final output sent to browser
INFO - 2025-11-17 12:36:18 --> Total execution time: 0.0847
INFO - 2025-11-17 12:36:50 --> Config Class Initialized
INFO - 2025-11-17 12:36:50 --> Hooks Class Initialized
INFO - 2025-11-17 12:36:50 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:36:50 --> Utf8 Class Initialized
INFO - 2025-11-17 12:36:50 --> URI Class Initialized
INFO - 2025-11-17 12:36:50 --> Router Class Initialized
INFO - 2025-11-17 12:36:50 --> Output Class Initialized
INFO - 2025-11-17 12:36:50 --> Security Class Initialized
INFO - 2025-11-17 12:36:50 --> Input Class Initialized
INFO - 2025-11-17 12:36:50 --> Language Class Initialized
INFO - 2025-11-17 12:36:50 --> Loader Class Initialized
INFO - 2025-11-17 12:36:50 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:36:50 --> Helper loaded: url_helper
INFO - 2025-11-17 12:36:50 --> Helper loaded: file_helper
INFO - 2025-11-17 12:36:50 --> Helper loaded: main_helper
INFO - 2025-11-17 12:36:50 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:36:50 --> Database Driver Class Initialized
INFO - 2025-11-17 12:36:50 --> Email Class Initialized
DEBUG - 2025-11-17 12:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:36:50 --> Controller Class Initialized
INFO - 2025-11-17 12:36:50 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:36:50 --> Model "User_model" initialized
INFO - 2025-11-17 12:36:50 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:36:50 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 12:36:50 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 12:36:50 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 12:36:50 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 12:36:50 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 12:36:50 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 12:36:50 --> Final output sent to browser
INFO - 2025-11-17 12:36:50 --> Total execution time: 0.0953
INFO - 2025-11-17 12:36:52 --> Config Class Initialized
INFO - 2025-11-17 12:36:52 --> Hooks Class Initialized
INFO - 2025-11-17 12:36:52 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:36:52 --> Utf8 Class Initialized
INFO - 2025-11-17 12:36:52 --> URI Class Initialized
INFO - 2025-11-17 12:36:52 --> Router Class Initialized
INFO - 2025-11-17 12:36:52 --> Output Class Initialized
INFO - 2025-11-17 12:36:52 --> Security Class Initialized
INFO - 2025-11-17 12:36:52 --> Input Class Initialized
INFO - 2025-11-17 12:36:52 --> Language Class Initialized
INFO - 2025-11-17 12:36:52 --> Loader Class Initialized
INFO - 2025-11-17 12:36:52 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:36:52 --> Helper loaded: url_helper
INFO - 2025-11-17 12:36:52 --> Helper loaded: file_helper
INFO - 2025-11-17 12:36:52 --> Helper loaded: main_helper
INFO - 2025-11-17 12:36:52 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:36:52 --> Database Driver Class Initialized
INFO - 2025-11-17 12:36:52 --> Email Class Initialized
DEBUG - 2025-11-17 12:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:36:52 --> Controller Class Initialized
INFO - 2025-11-17 12:36:52 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:36:52 --> Model "User_model" initialized
INFO - 2025-11-17 12:36:52 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:36:52 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 12:36:52 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 12:36:52 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 12:36:52 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 12:36:52 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 12:36:52 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 12:36:52 --> Final output sent to browser
INFO - 2025-11-17 12:36:52 --> Total execution time: 0.1019
INFO - 2025-11-17 12:37:17 --> Config Class Initialized
INFO - 2025-11-17 12:37:17 --> Hooks Class Initialized
INFO - 2025-11-17 12:37:17 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:37:17 --> Utf8 Class Initialized
INFO - 2025-11-17 12:37:17 --> URI Class Initialized
INFO - 2025-11-17 12:37:17 --> Router Class Initialized
INFO - 2025-11-17 12:37:17 --> Output Class Initialized
INFO - 2025-11-17 12:37:17 --> Security Class Initialized
INFO - 2025-11-17 12:37:17 --> Input Class Initialized
INFO - 2025-11-17 12:37:17 --> Language Class Initialized
INFO - 2025-11-17 12:37:17 --> Loader Class Initialized
INFO - 2025-11-17 12:37:17 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:37:17 --> Helper loaded: url_helper
INFO - 2025-11-17 12:37:17 --> Helper loaded: file_helper
INFO - 2025-11-17 12:37:17 --> Helper loaded: main_helper
INFO - 2025-11-17 12:37:17 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:37:17 --> Database Driver Class Initialized
INFO - 2025-11-17 12:37:17 --> Email Class Initialized
DEBUG - 2025-11-17 12:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:37:17 --> Controller Class Initialized
INFO - 2025-11-17 12:37:17 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:37:17 --> Model "User_model" initialized
INFO - 2025-11-17 12:37:17 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:37:17 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:37:17 --> Final output sent to browser
INFO - 2025-11-17 12:37:17 --> Total execution time: 0.1071
INFO - 2025-11-17 12:37:47 --> Config Class Initialized
INFO - 2025-11-17 12:37:47 --> Hooks Class Initialized
INFO - 2025-11-17 12:37:47 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:37:47 --> Utf8 Class Initialized
INFO - 2025-11-17 12:37:47 --> URI Class Initialized
INFO - 2025-11-17 12:37:47 --> Router Class Initialized
INFO - 2025-11-17 12:37:47 --> Output Class Initialized
INFO - 2025-11-17 12:37:47 --> Security Class Initialized
INFO - 2025-11-17 12:37:47 --> Input Class Initialized
INFO - 2025-11-17 12:37:47 --> Language Class Initialized
INFO - 2025-11-17 12:37:47 --> Loader Class Initialized
INFO - 2025-11-17 12:37:47 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:37:47 --> Helper loaded: url_helper
INFO - 2025-11-17 12:37:47 --> Helper loaded: file_helper
INFO - 2025-11-17 12:37:47 --> Helper loaded: main_helper
INFO - 2025-11-17 12:37:47 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:37:47 --> Database Driver Class Initialized
INFO - 2025-11-17 12:37:47 --> Email Class Initialized
DEBUG - 2025-11-17 12:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:37:47 --> Controller Class Initialized
INFO - 2025-11-17 12:37:47 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:37:47 --> Model "User_model" initialized
INFO - 2025-11-17 12:37:47 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:37:47 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:37:47 --> Final output sent to browser
INFO - 2025-11-17 12:37:47 --> Total execution time: 0.0848
INFO - 2025-11-17 12:38:29 --> Config Class Initialized
INFO - 2025-11-17 12:38:29 --> Hooks Class Initialized
INFO - 2025-11-17 12:38:29 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:38:29 --> Utf8 Class Initialized
INFO - 2025-11-17 12:38:29 --> URI Class Initialized
INFO - 2025-11-17 12:38:29 --> Router Class Initialized
INFO - 2025-11-17 12:38:29 --> Output Class Initialized
INFO - 2025-11-17 12:38:29 --> Security Class Initialized
INFO - 2025-11-17 12:38:29 --> Input Class Initialized
INFO - 2025-11-17 12:38:29 --> Language Class Initialized
INFO - 2025-11-17 12:38:29 --> Loader Class Initialized
INFO - 2025-11-17 12:38:29 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:38:29 --> Helper loaded: url_helper
INFO - 2025-11-17 12:38:29 --> Helper loaded: file_helper
INFO - 2025-11-17 12:38:29 --> Helper loaded: main_helper
INFO - 2025-11-17 12:38:29 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:38:29 --> Database Driver Class Initialized
INFO - 2025-11-17 12:38:29 --> Email Class Initialized
DEBUG - 2025-11-17 12:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:38:29 --> Controller Class Initialized
INFO - 2025-11-17 12:38:29 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:38:29 --> Model "User_model" initialized
INFO - 2025-11-17 12:38:29 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:38:29 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:38:29 --> Final output sent to browser
INFO - 2025-11-17 12:38:29 --> Total execution time: 0.0848
INFO - 2025-11-17 12:38:49 --> Config Class Initialized
INFO - 2025-11-17 12:38:49 --> Hooks Class Initialized
INFO - 2025-11-17 12:38:49 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:38:49 --> Utf8 Class Initialized
INFO - 2025-11-17 12:38:49 --> URI Class Initialized
INFO - 2025-11-17 12:38:49 --> Router Class Initialized
INFO - 2025-11-17 12:38:49 --> Output Class Initialized
INFO - 2025-11-17 12:38:49 --> Security Class Initialized
INFO - 2025-11-17 12:38:49 --> Input Class Initialized
INFO - 2025-11-17 12:38:49 --> Language Class Initialized
INFO - 2025-11-17 12:38:49 --> Loader Class Initialized
INFO - 2025-11-17 12:38:49 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:38:49 --> Helper loaded: url_helper
INFO - 2025-11-17 12:38:49 --> Helper loaded: file_helper
INFO - 2025-11-17 12:38:49 --> Helper loaded: main_helper
INFO - 2025-11-17 12:38:49 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:38:49 --> Database Driver Class Initialized
INFO - 2025-11-17 12:38:49 --> Email Class Initialized
DEBUG - 2025-11-17 12:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:38:49 --> Controller Class Initialized
INFO - 2025-11-17 12:38:49 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:38:49 --> Model "User_model" initialized
INFO - 2025-11-17 12:38:49 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:38:49 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:38:49 --> Final output sent to browser
INFO - 2025-11-17 12:38:49 --> Total execution time: 0.0889
INFO - 2025-11-17 12:38:58 --> Config Class Initialized
INFO - 2025-11-17 12:38:58 --> Hooks Class Initialized
INFO - 2025-11-17 12:38:58 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:38:58 --> Utf8 Class Initialized
INFO - 2025-11-17 12:38:58 --> URI Class Initialized
INFO - 2025-11-17 12:38:58 --> Router Class Initialized
INFO - 2025-11-17 12:38:58 --> Output Class Initialized
INFO - 2025-11-17 12:38:58 --> Security Class Initialized
INFO - 2025-11-17 12:38:58 --> Input Class Initialized
INFO - 2025-11-17 12:38:58 --> Language Class Initialized
INFO - 2025-11-17 12:38:58 --> Loader Class Initialized
INFO - 2025-11-17 12:38:58 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:38:58 --> Helper loaded: url_helper
INFO - 2025-11-17 12:38:58 --> Helper loaded: file_helper
INFO - 2025-11-17 12:38:58 --> Helper loaded: main_helper
INFO - 2025-11-17 12:38:58 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:38:58 --> Database Driver Class Initialized
INFO - 2025-11-17 12:38:58 --> Email Class Initialized
DEBUG - 2025-11-17 12:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:38:58 --> Controller Class Initialized
INFO - 2025-11-17 12:38:58 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:38:58 --> Model "User_model" initialized
INFO - 2025-11-17 12:38:58 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:38:58 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:38:58 --> Final output sent to browser
INFO - 2025-11-17 12:38:58 --> Total execution time: 0.1011
INFO - 2025-11-17 12:39:51 --> Config Class Initialized
INFO - 2025-11-17 12:39:51 --> Hooks Class Initialized
INFO - 2025-11-17 12:39:51 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:39:51 --> Utf8 Class Initialized
INFO - 2025-11-17 12:39:51 --> URI Class Initialized
INFO - 2025-11-17 12:39:51 --> Router Class Initialized
INFO - 2025-11-17 12:39:51 --> Output Class Initialized
INFO - 2025-11-17 12:39:51 --> Security Class Initialized
INFO - 2025-11-17 12:39:51 --> Input Class Initialized
INFO - 2025-11-17 12:39:51 --> Language Class Initialized
INFO - 2025-11-17 12:39:51 --> Loader Class Initialized
INFO - 2025-11-17 12:39:51 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:39:51 --> Helper loaded: url_helper
INFO - 2025-11-17 12:39:51 --> Helper loaded: file_helper
INFO - 2025-11-17 12:39:51 --> Helper loaded: main_helper
INFO - 2025-11-17 12:39:51 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:39:51 --> Database Driver Class Initialized
INFO - 2025-11-17 12:39:51 --> Email Class Initialized
DEBUG - 2025-11-17 12:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:39:51 --> Controller Class Initialized
INFO - 2025-11-17 12:39:51 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:39:51 --> Model "User_model" initialized
INFO - 2025-11-17 12:39:51 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:39:51 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:39:51 --> Final output sent to browser
INFO - 2025-11-17 12:39:51 --> Total execution time: 0.0886
INFO - 2025-11-17 12:40:25 --> Config Class Initialized
INFO - 2025-11-17 12:40:25 --> Hooks Class Initialized
INFO - 2025-11-17 12:40:25 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:40:25 --> Utf8 Class Initialized
INFO - 2025-11-17 12:40:25 --> URI Class Initialized
INFO - 2025-11-17 12:40:25 --> Router Class Initialized
INFO - 2025-11-17 12:40:25 --> Output Class Initialized
INFO - 2025-11-17 12:40:25 --> Security Class Initialized
INFO - 2025-11-17 12:40:25 --> Input Class Initialized
INFO - 2025-11-17 12:40:25 --> Language Class Initialized
INFO - 2025-11-17 12:40:25 --> Loader Class Initialized
INFO - 2025-11-17 12:40:25 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:40:25 --> Helper loaded: url_helper
INFO - 2025-11-17 12:40:25 --> Helper loaded: file_helper
INFO - 2025-11-17 12:40:25 --> Helper loaded: main_helper
INFO - 2025-11-17 12:40:25 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:40:25 --> Database Driver Class Initialized
INFO - 2025-11-17 12:40:25 --> Email Class Initialized
DEBUG - 2025-11-17 12:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:40:25 --> Controller Class Initialized
INFO - 2025-11-17 12:40:25 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:40:25 --> Model "User_model" initialized
INFO - 2025-11-17 12:40:25 --> Model "Auth_model" initialized
ERROR - 2025-11-17 12:40:25 --> Severity: Warning --> Undefined property: stdClass::$plan_name D:\laragon\www\acumena\application\views\subscriptions\invoice.php 73
INFO - 2025-11-17 12:40:25 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:40:25 --> Final output sent to browser
INFO - 2025-11-17 12:40:25 --> Total execution time: 0.0995
INFO - 2025-11-17 12:40:51 --> Config Class Initialized
INFO - 2025-11-17 12:40:51 --> Hooks Class Initialized
INFO - 2025-11-17 12:40:51 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:40:51 --> Utf8 Class Initialized
INFO - 2025-11-17 12:40:51 --> URI Class Initialized
INFO - 2025-11-17 12:40:51 --> Router Class Initialized
INFO - 2025-11-17 12:40:51 --> Output Class Initialized
INFO - 2025-11-17 12:40:51 --> Security Class Initialized
INFO - 2025-11-17 12:40:51 --> Input Class Initialized
INFO - 2025-11-17 12:40:51 --> Language Class Initialized
INFO - 2025-11-17 12:40:51 --> Loader Class Initialized
INFO - 2025-11-17 12:40:51 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:40:51 --> Helper loaded: url_helper
INFO - 2025-11-17 12:40:51 --> Helper loaded: file_helper
INFO - 2025-11-17 12:40:51 --> Helper loaded: main_helper
INFO - 2025-11-17 12:40:51 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:40:51 --> Database Driver Class Initialized
INFO - 2025-11-17 12:40:51 --> Email Class Initialized
DEBUG - 2025-11-17 12:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:40:51 --> Controller Class Initialized
INFO - 2025-11-17 12:40:51 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:40:51 --> Model "User_model" initialized
INFO - 2025-11-17 12:40:51 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:40:51 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:40:51 --> Final output sent to browser
INFO - 2025-11-17 12:40:51 --> Total execution time: 0.1369
INFO - 2025-11-17 12:41:12 --> Config Class Initialized
INFO - 2025-11-17 12:41:12 --> Hooks Class Initialized
INFO - 2025-11-17 12:41:12 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:41:12 --> Utf8 Class Initialized
INFO - 2025-11-17 12:41:12 --> URI Class Initialized
INFO - 2025-11-17 12:41:12 --> Router Class Initialized
INFO - 2025-11-17 12:41:12 --> Output Class Initialized
INFO - 2025-11-17 12:41:12 --> Security Class Initialized
INFO - 2025-11-17 12:41:12 --> Input Class Initialized
INFO - 2025-11-17 12:41:12 --> Language Class Initialized
INFO - 2025-11-17 12:41:12 --> Loader Class Initialized
INFO - 2025-11-17 12:41:12 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:41:12 --> Helper loaded: url_helper
INFO - 2025-11-17 12:41:12 --> Helper loaded: file_helper
INFO - 2025-11-17 12:41:12 --> Helper loaded: main_helper
INFO - 2025-11-17 12:41:12 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:41:12 --> Database Driver Class Initialized
INFO - 2025-11-17 12:41:12 --> Email Class Initialized
DEBUG - 2025-11-17 12:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:41:12 --> Controller Class Initialized
INFO - 2025-11-17 12:41:12 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:41:12 --> Model "User_model" initialized
INFO - 2025-11-17 12:41:12 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:41:12 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:41:12 --> Final output sent to browser
INFO - 2025-11-17 12:41:12 --> Total execution time: 0.0850
INFO - 2025-11-17 12:41:30 --> Config Class Initialized
INFO - 2025-11-17 12:41:30 --> Hooks Class Initialized
INFO - 2025-11-17 12:41:30 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:41:30 --> Utf8 Class Initialized
INFO - 2025-11-17 12:41:30 --> URI Class Initialized
INFO - 2025-11-17 12:41:30 --> Router Class Initialized
INFO - 2025-11-17 12:41:30 --> Output Class Initialized
INFO - 2025-11-17 12:41:30 --> Security Class Initialized
INFO - 2025-11-17 12:41:30 --> Input Class Initialized
INFO - 2025-11-17 12:41:30 --> Language Class Initialized
INFO - 2025-11-17 12:41:30 --> Loader Class Initialized
INFO - 2025-11-17 12:41:30 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:41:30 --> Helper loaded: url_helper
INFO - 2025-11-17 12:41:30 --> Helper loaded: file_helper
INFO - 2025-11-17 12:41:30 --> Helper loaded: main_helper
INFO - 2025-11-17 12:41:30 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:41:30 --> Database Driver Class Initialized
INFO - 2025-11-17 12:41:30 --> Email Class Initialized
DEBUG - 2025-11-17 12:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:41:30 --> Controller Class Initialized
INFO - 2025-11-17 12:41:30 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:41:30 --> Model "User_model" initialized
INFO - 2025-11-17 12:41:30 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:41:30 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:41:30 --> Final output sent to browser
INFO - 2025-11-17 12:41:30 --> Total execution time: 0.1259
INFO - 2025-11-17 12:41:43 --> Config Class Initialized
INFO - 2025-11-17 12:41:43 --> Hooks Class Initialized
INFO - 2025-11-17 12:41:43 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:41:43 --> Utf8 Class Initialized
INFO - 2025-11-17 12:41:43 --> URI Class Initialized
INFO - 2025-11-17 12:41:43 --> Router Class Initialized
INFO - 2025-11-17 12:41:43 --> Output Class Initialized
INFO - 2025-11-17 12:41:43 --> Security Class Initialized
INFO - 2025-11-17 12:41:43 --> Input Class Initialized
INFO - 2025-11-17 12:41:43 --> Language Class Initialized
INFO - 2025-11-17 12:41:43 --> Loader Class Initialized
INFO - 2025-11-17 12:41:43 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:41:43 --> Helper loaded: url_helper
INFO - 2025-11-17 12:41:43 --> Helper loaded: file_helper
INFO - 2025-11-17 12:41:43 --> Helper loaded: main_helper
INFO - 2025-11-17 12:41:43 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:41:43 --> Database Driver Class Initialized
INFO - 2025-11-17 12:41:43 --> Email Class Initialized
DEBUG - 2025-11-17 12:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:41:43 --> Controller Class Initialized
INFO - 2025-11-17 12:41:43 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:41:43 --> Model "User_model" initialized
INFO - 2025-11-17 12:41:43 --> Model "Auth_model" initialized
ERROR - 2025-11-17 12:41:43 --> Severity: Warning --> Undefined property: stdClass::$price_monthly D:\laragon\www\acumena\application\views\subscriptions\invoice.php 77
ERROR - 2025-11-17 12:41:43 --> Severity: Deprecated Notice --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated D:\laragon\www\acumena\application\views\subscriptions\invoice.php 77
INFO - 2025-11-17 12:41:43 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:41:43 --> Final output sent to browser
INFO - 2025-11-17 12:41:43 --> Total execution time: 0.1102
INFO - 2025-11-17 12:41:55 --> Config Class Initialized
INFO - 2025-11-17 12:41:55 --> Hooks Class Initialized
INFO - 2025-11-17 12:41:55 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:41:55 --> Utf8 Class Initialized
INFO - 2025-11-17 12:41:55 --> URI Class Initialized
INFO - 2025-11-17 12:41:55 --> Router Class Initialized
INFO - 2025-11-17 12:41:55 --> Output Class Initialized
INFO - 2025-11-17 12:41:55 --> Security Class Initialized
INFO - 2025-11-17 12:41:55 --> Input Class Initialized
INFO - 2025-11-17 12:41:55 --> Language Class Initialized
INFO - 2025-11-17 12:41:55 --> Loader Class Initialized
INFO - 2025-11-17 12:41:55 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:41:55 --> Helper loaded: url_helper
INFO - 2025-11-17 12:41:55 --> Helper loaded: file_helper
INFO - 2025-11-17 12:41:55 --> Helper loaded: main_helper
INFO - 2025-11-17 12:41:55 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:41:55 --> Database Driver Class Initialized
INFO - 2025-11-17 12:41:55 --> Email Class Initialized
DEBUG - 2025-11-17 12:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:41:55 --> Controller Class Initialized
INFO - 2025-11-17 12:41:55 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:41:55 --> Model "User_model" initialized
INFO - 2025-11-17 12:41:55 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:41:55 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:41:55 --> Final output sent to browser
INFO - 2025-11-17 12:41:55 --> Total execution time: 0.1035
INFO - 2025-11-17 12:42:20 --> Config Class Initialized
INFO - 2025-11-17 12:42:20 --> Hooks Class Initialized
INFO - 2025-11-17 12:42:20 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:42:20 --> Utf8 Class Initialized
INFO - 2025-11-17 12:42:20 --> URI Class Initialized
INFO - 2025-11-17 12:42:20 --> Router Class Initialized
INFO - 2025-11-17 12:42:20 --> Output Class Initialized
INFO - 2025-11-17 12:42:20 --> Security Class Initialized
INFO - 2025-11-17 12:42:20 --> Input Class Initialized
INFO - 2025-11-17 12:42:20 --> Language Class Initialized
INFO - 2025-11-17 12:42:20 --> Loader Class Initialized
INFO - 2025-11-17 12:42:20 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:42:20 --> Helper loaded: url_helper
INFO - 2025-11-17 12:42:20 --> Helper loaded: file_helper
INFO - 2025-11-17 12:42:20 --> Helper loaded: main_helper
INFO - 2025-11-17 12:42:20 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:42:20 --> Database Driver Class Initialized
INFO - 2025-11-17 12:42:20 --> Email Class Initialized
DEBUG - 2025-11-17 12:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:42:20 --> Controller Class Initialized
INFO - 2025-11-17 12:42:20 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:42:20 --> Model "User_model" initialized
INFO - 2025-11-17 12:42:20 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:42:20 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:42:20 --> Final output sent to browser
INFO - 2025-11-17 12:42:20 --> Total execution time: 0.1511
INFO - 2025-11-17 12:42:29 --> Config Class Initialized
INFO - 2025-11-17 12:42:29 --> Hooks Class Initialized
INFO - 2025-11-17 12:42:29 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:42:29 --> Utf8 Class Initialized
INFO - 2025-11-17 12:42:29 --> URI Class Initialized
INFO - 2025-11-17 12:42:29 --> Router Class Initialized
INFO - 2025-11-17 12:42:29 --> Output Class Initialized
INFO - 2025-11-17 12:42:29 --> Security Class Initialized
INFO - 2025-11-17 12:42:29 --> Input Class Initialized
INFO - 2025-11-17 12:42:29 --> Language Class Initialized
INFO - 2025-11-17 12:42:29 --> Loader Class Initialized
INFO - 2025-11-17 12:42:29 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:42:29 --> Helper loaded: url_helper
INFO - 2025-11-17 12:42:29 --> Helper loaded: file_helper
INFO - 2025-11-17 12:42:29 --> Helper loaded: main_helper
INFO - 2025-11-17 12:42:29 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:42:29 --> Database Driver Class Initialized
INFO - 2025-11-17 12:42:29 --> Email Class Initialized
DEBUG - 2025-11-17 12:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:42:29 --> Controller Class Initialized
INFO - 2025-11-17 12:42:29 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:42:29 --> Model "User_model" initialized
INFO - 2025-11-17 12:42:29 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:42:29 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:42:29 --> Final output sent to browser
INFO - 2025-11-17 12:42:29 --> Total execution time: 0.1043
INFO - 2025-11-17 12:42:32 --> Config Class Initialized
INFO - 2025-11-17 12:42:32 --> Hooks Class Initialized
INFO - 2025-11-17 12:42:32 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:42:32 --> Utf8 Class Initialized
INFO - 2025-11-17 12:42:32 --> URI Class Initialized
INFO - 2025-11-17 12:42:32 --> Router Class Initialized
INFO - 2025-11-17 12:42:32 --> Output Class Initialized
INFO - 2025-11-17 12:42:32 --> Security Class Initialized
INFO - 2025-11-17 12:42:32 --> Input Class Initialized
INFO - 2025-11-17 12:42:32 --> Language Class Initialized
INFO - 2025-11-17 12:42:32 --> Loader Class Initialized
INFO - 2025-11-17 12:42:32 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:42:32 --> Helper loaded: url_helper
INFO - 2025-11-17 12:42:32 --> Helper loaded: file_helper
INFO - 2025-11-17 12:42:32 --> Helper loaded: main_helper
INFO - 2025-11-17 12:42:32 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:42:32 --> Database Driver Class Initialized
INFO - 2025-11-17 12:42:32 --> Email Class Initialized
DEBUG - 2025-11-17 12:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:42:32 --> Controller Class Initialized
INFO - 2025-11-17 12:42:32 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:42:32 --> Model "User_model" initialized
INFO - 2025-11-17 12:42:32 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:42:32 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:42:32 --> Final output sent to browser
INFO - 2025-11-17 12:42:32 --> Total execution time: 0.0806
INFO - 2025-11-17 12:42:36 --> Config Class Initialized
INFO - 2025-11-17 12:42:36 --> Hooks Class Initialized
INFO - 2025-11-17 12:42:36 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:42:36 --> Utf8 Class Initialized
INFO - 2025-11-17 12:42:36 --> URI Class Initialized
INFO - 2025-11-17 12:42:36 --> Router Class Initialized
INFO - 2025-11-17 12:42:36 --> Output Class Initialized
INFO - 2025-11-17 12:42:36 --> Security Class Initialized
INFO - 2025-11-17 12:42:36 --> Input Class Initialized
INFO - 2025-11-17 12:42:36 --> Language Class Initialized
INFO - 2025-11-17 12:42:36 --> Loader Class Initialized
INFO - 2025-11-17 12:42:36 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:42:36 --> Helper loaded: url_helper
INFO - 2025-11-17 12:42:36 --> Helper loaded: file_helper
INFO - 2025-11-17 12:42:36 --> Helper loaded: main_helper
INFO - 2025-11-17 12:42:36 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:42:36 --> Database Driver Class Initialized
INFO - 2025-11-17 12:42:36 --> Email Class Initialized
DEBUG - 2025-11-17 12:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:42:36 --> Controller Class Initialized
INFO - 2025-11-17 12:42:36 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:42:36 --> Model "User_model" initialized
INFO - 2025-11-17 12:42:36 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:42:36 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:42:36 --> Final output sent to browser
INFO - 2025-11-17 12:42:36 --> Total execution time: 0.0871
INFO - 2025-11-17 12:43:28 --> Config Class Initialized
INFO - 2025-11-17 12:43:28 --> Hooks Class Initialized
INFO - 2025-11-17 12:43:28 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:43:28 --> Utf8 Class Initialized
INFO - 2025-11-17 12:43:28 --> URI Class Initialized
INFO - 2025-11-17 12:43:28 --> Router Class Initialized
INFO - 2025-11-17 12:43:28 --> Output Class Initialized
INFO - 2025-11-17 12:43:28 --> Security Class Initialized
INFO - 2025-11-17 12:43:28 --> Input Class Initialized
INFO - 2025-11-17 12:43:28 --> Language Class Initialized
INFO - 2025-11-17 12:43:28 --> Loader Class Initialized
INFO - 2025-11-17 12:43:28 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:43:28 --> Helper loaded: url_helper
INFO - 2025-11-17 12:43:28 --> Helper loaded: file_helper
INFO - 2025-11-17 12:43:28 --> Helper loaded: main_helper
INFO - 2025-11-17 12:43:28 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:43:28 --> Database Driver Class Initialized
INFO - 2025-11-17 12:43:28 --> Email Class Initialized
DEBUG - 2025-11-17 12:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:43:28 --> Controller Class Initialized
INFO - 2025-11-17 12:43:28 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:43:28 --> Model "User_model" initialized
INFO - 2025-11-17 12:43:28 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:43:28 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:43:28 --> Final output sent to browser
INFO - 2025-11-17 12:43:28 --> Total execution time: 0.0889
INFO - 2025-11-17 12:43:42 --> Config Class Initialized
INFO - 2025-11-17 12:43:42 --> Hooks Class Initialized
INFO - 2025-11-17 12:43:42 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:43:42 --> Utf8 Class Initialized
INFO - 2025-11-17 12:43:42 --> URI Class Initialized
INFO - 2025-11-17 12:43:42 --> Router Class Initialized
INFO - 2025-11-17 12:43:42 --> Output Class Initialized
INFO - 2025-11-17 12:43:42 --> Security Class Initialized
INFO - 2025-11-17 12:43:42 --> Input Class Initialized
INFO - 2025-11-17 12:43:42 --> Language Class Initialized
INFO - 2025-11-17 12:43:42 --> Loader Class Initialized
INFO - 2025-11-17 12:43:42 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:43:42 --> Helper loaded: url_helper
INFO - 2025-11-17 12:43:42 --> Helper loaded: file_helper
INFO - 2025-11-17 12:43:42 --> Helper loaded: main_helper
INFO - 2025-11-17 12:43:42 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:43:42 --> Database Driver Class Initialized
INFO - 2025-11-17 12:43:42 --> Email Class Initialized
DEBUG - 2025-11-17 12:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:43:42 --> Controller Class Initialized
INFO - 2025-11-17 12:43:42 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:43:42 --> Model "User_model" initialized
INFO - 2025-11-17 12:43:42 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:43:42 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:43:42 --> Final output sent to browser
INFO - 2025-11-17 12:43:42 --> Total execution time: 0.1497
INFO - 2025-11-17 12:44:30 --> Config Class Initialized
INFO - 2025-11-17 12:44:30 --> Hooks Class Initialized
INFO - 2025-11-17 12:44:30 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:44:30 --> Utf8 Class Initialized
INFO - 2025-11-17 12:44:30 --> URI Class Initialized
INFO - 2025-11-17 12:44:30 --> Router Class Initialized
INFO - 2025-11-17 12:44:30 --> Output Class Initialized
INFO - 2025-11-17 12:44:30 --> Security Class Initialized
INFO - 2025-11-17 12:44:30 --> Input Class Initialized
INFO - 2025-11-17 12:44:30 --> Language Class Initialized
INFO - 2025-11-17 12:44:30 --> Loader Class Initialized
INFO - 2025-11-17 12:44:30 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:44:30 --> Helper loaded: url_helper
INFO - 2025-11-17 12:44:30 --> Helper loaded: file_helper
INFO - 2025-11-17 12:44:30 --> Helper loaded: main_helper
INFO - 2025-11-17 12:44:30 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:44:30 --> Database Driver Class Initialized
INFO - 2025-11-17 12:44:30 --> Email Class Initialized
DEBUG - 2025-11-17 12:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:44:30 --> Controller Class Initialized
INFO - 2025-11-17 12:44:30 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:44:30 --> Model "User_model" initialized
INFO - 2025-11-17 12:44:30 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:44:30 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:44:30 --> Final output sent to browser
INFO - 2025-11-17 12:44:30 --> Total execution time: 0.1038
INFO - 2025-11-17 12:45:15 --> Config Class Initialized
INFO - 2025-11-17 12:45:15 --> Hooks Class Initialized
INFO - 2025-11-17 12:45:15 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:45:15 --> Utf8 Class Initialized
INFO - 2025-11-17 12:45:15 --> URI Class Initialized
INFO - 2025-11-17 12:45:15 --> Router Class Initialized
INFO - 2025-11-17 12:45:15 --> Output Class Initialized
INFO - 2025-11-17 12:45:15 --> Security Class Initialized
INFO - 2025-11-17 12:45:15 --> Input Class Initialized
INFO - 2025-11-17 12:45:15 --> Language Class Initialized
INFO - 2025-11-17 12:45:15 --> Loader Class Initialized
INFO - 2025-11-17 12:45:15 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:45:15 --> Helper loaded: url_helper
INFO - 2025-11-17 12:45:15 --> Helper loaded: file_helper
INFO - 2025-11-17 12:45:15 --> Helper loaded: main_helper
INFO - 2025-11-17 12:45:15 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:45:15 --> Database Driver Class Initialized
INFO - 2025-11-17 12:45:15 --> Email Class Initialized
DEBUG - 2025-11-17 12:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:45:15 --> Controller Class Initialized
INFO - 2025-11-17 12:45:15 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:45:15 --> Model "User_model" initialized
INFO - 2025-11-17 12:45:15 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:45:15 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:45:15 --> Final output sent to browser
INFO - 2025-11-17 12:45:15 --> Total execution time: 0.0866
INFO - 2025-11-17 12:45:44 --> Config Class Initialized
INFO - 2025-11-17 12:45:44 --> Hooks Class Initialized
INFO - 2025-11-17 12:45:44 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:45:44 --> Utf8 Class Initialized
INFO - 2025-11-17 12:45:44 --> URI Class Initialized
INFO - 2025-11-17 12:45:44 --> Router Class Initialized
INFO - 2025-11-17 12:45:44 --> Output Class Initialized
INFO - 2025-11-17 12:45:44 --> Security Class Initialized
INFO - 2025-11-17 12:45:44 --> Input Class Initialized
INFO - 2025-11-17 12:45:44 --> Language Class Initialized
INFO - 2025-11-17 12:45:44 --> Loader Class Initialized
INFO - 2025-11-17 12:45:44 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:45:44 --> Helper loaded: url_helper
INFO - 2025-11-17 12:45:44 --> Helper loaded: file_helper
INFO - 2025-11-17 12:45:44 --> Helper loaded: main_helper
INFO - 2025-11-17 12:45:44 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:45:44 --> Database Driver Class Initialized
INFO - 2025-11-17 12:45:44 --> Email Class Initialized
DEBUG - 2025-11-17 12:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:45:44 --> Controller Class Initialized
INFO - 2025-11-17 12:45:44 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:45:44 --> Model "User_model" initialized
INFO - 2025-11-17 12:45:44 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:45:44 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:45:44 --> Final output sent to browser
INFO - 2025-11-17 12:45:44 --> Total execution time: 0.0933
INFO - 2025-11-17 12:45:50 --> Config Class Initialized
INFO - 2025-11-17 12:45:50 --> Hooks Class Initialized
INFO - 2025-11-17 12:45:50 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:45:50 --> Utf8 Class Initialized
INFO - 2025-11-17 12:45:50 --> URI Class Initialized
INFO - 2025-11-17 12:45:50 --> Router Class Initialized
INFO - 2025-11-17 12:45:50 --> Output Class Initialized
INFO - 2025-11-17 12:45:50 --> Security Class Initialized
INFO - 2025-11-17 12:45:50 --> Input Class Initialized
INFO - 2025-11-17 12:45:50 --> Language Class Initialized
INFO - 2025-11-17 12:45:50 --> Loader Class Initialized
INFO - 2025-11-17 12:45:50 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:45:50 --> Helper loaded: url_helper
INFO - 2025-11-17 12:45:50 --> Helper loaded: file_helper
INFO - 2025-11-17 12:45:50 --> Helper loaded: main_helper
INFO - 2025-11-17 12:45:50 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:45:50 --> Database Driver Class Initialized
INFO - 2025-11-17 12:45:50 --> Email Class Initialized
DEBUG - 2025-11-17 12:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:45:50 --> Controller Class Initialized
INFO - 2025-11-17 12:45:50 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:45:50 --> Model "User_model" initialized
INFO - 2025-11-17 12:45:50 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:45:50 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:45:50 --> Final output sent to browser
INFO - 2025-11-17 12:45:50 --> Total execution time: 0.0838
INFO - 2025-11-17 12:46:05 --> Config Class Initialized
INFO - 2025-11-17 12:46:05 --> Hooks Class Initialized
INFO - 2025-11-17 12:46:05 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:46:05 --> Utf8 Class Initialized
INFO - 2025-11-17 12:46:05 --> URI Class Initialized
INFO - 2025-11-17 12:46:05 --> Router Class Initialized
INFO - 2025-11-17 12:46:05 --> Output Class Initialized
INFO - 2025-11-17 12:46:05 --> Security Class Initialized
INFO - 2025-11-17 12:46:05 --> Input Class Initialized
INFO - 2025-11-17 12:46:05 --> Language Class Initialized
INFO - 2025-11-17 12:46:05 --> Loader Class Initialized
INFO - 2025-11-17 12:46:05 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:46:05 --> Helper loaded: url_helper
INFO - 2025-11-17 12:46:05 --> Helper loaded: file_helper
INFO - 2025-11-17 12:46:05 --> Helper loaded: main_helper
INFO - 2025-11-17 12:46:05 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:46:05 --> Database Driver Class Initialized
INFO - 2025-11-17 12:46:05 --> Email Class Initialized
DEBUG - 2025-11-17 12:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:46:05 --> Controller Class Initialized
INFO - 2025-11-17 12:46:05 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:46:05 --> Model "User_model" initialized
INFO - 2025-11-17 12:46:05 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:46:05 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:46:05 --> Final output sent to browser
INFO - 2025-11-17 12:46:05 --> Total execution time: 0.1139
INFO - 2025-11-17 12:46:28 --> Config Class Initialized
INFO - 2025-11-17 12:46:28 --> Hooks Class Initialized
INFO - 2025-11-17 12:46:28 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:46:28 --> Utf8 Class Initialized
INFO - 2025-11-17 12:46:28 --> URI Class Initialized
INFO - 2025-11-17 12:46:28 --> Router Class Initialized
INFO - 2025-11-17 12:46:28 --> Output Class Initialized
INFO - 2025-11-17 12:46:28 --> Security Class Initialized
INFO - 2025-11-17 12:46:28 --> Input Class Initialized
INFO - 2025-11-17 12:46:28 --> Language Class Initialized
INFO - 2025-11-17 12:46:28 --> Loader Class Initialized
INFO - 2025-11-17 12:46:28 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:46:28 --> Helper loaded: url_helper
INFO - 2025-11-17 12:46:28 --> Helper loaded: file_helper
INFO - 2025-11-17 12:46:28 --> Helper loaded: main_helper
INFO - 2025-11-17 12:46:28 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:46:28 --> Database Driver Class Initialized
INFO - 2025-11-17 12:46:28 --> Email Class Initialized
DEBUG - 2025-11-17 12:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:46:28 --> Controller Class Initialized
INFO - 2025-11-17 12:46:28 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:46:28 --> Model "User_model" initialized
INFO - 2025-11-17 12:46:28 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:46:28 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 12:46:28 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 12:46:28 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 12:46:28 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 12:46:28 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 12:46:28 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 12:46:28 --> Final output sent to browser
INFO - 2025-11-17 12:46:28 --> Total execution time: 0.0987
INFO - 2025-11-17 12:46:44 --> Config Class Initialized
INFO - 2025-11-17 12:46:44 --> Hooks Class Initialized
INFO - 2025-11-17 12:46:44 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:46:44 --> Utf8 Class Initialized
INFO - 2025-11-17 12:46:44 --> URI Class Initialized
INFO - 2025-11-17 12:46:44 --> Router Class Initialized
INFO - 2025-11-17 12:46:44 --> Output Class Initialized
INFO - 2025-11-17 12:46:44 --> Security Class Initialized
INFO - 2025-11-17 12:46:44 --> Input Class Initialized
INFO - 2025-11-17 12:46:44 --> Language Class Initialized
INFO - 2025-11-17 12:46:45 --> Loader Class Initialized
INFO - 2025-11-17 12:46:45 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:46:45 --> Helper loaded: url_helper
INFO - 2025-11-17 12:46:45 --> Helper loaded: file_helper
INFO - 2025-11-17 12:46:45 --> Helper loaded: main_helper
INFO - 2025-11-17 12:46:45 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:46:45 --> Database Driver Class Initialized
INFO - 2025-11-17 12:46:45 --> Email Class Initialized
DEBUG - 2025-11-17 12:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:46:45 --> Controller Class Initialized
INFO - 2025-11-17 12:46:45 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:46:45 --> Model "User_model" initialized
INFO - 2025-11-17 12:46:45 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:46:45 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 12:46:45 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 12:46:45 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 12:46:45 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 12:46:45 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 12:46:45 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 12:46:45 --> Final output sent to browser
INFO - 2025-11-17 12:46:45 --> Total execution time: 0.1514
INFO - 2025-11-17 12:46:46 --> Config Class Initialized
INFO - 2025-11-17 12:46:46 --> Hooks Class Initialized
INFO - 2025-11-17 12:46:46 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:46:46 --> Utf8 Class Initialized
INFO - 2025-11-17 12:46:46 --> URI Class Initialized
INFO - 2025-11-17 12:46:46 --> Router Class Initialized
INFO - 2025-11-17 12:46:46 --> Output Class Initialized
INFO - 2025-11-17 12:46:46 --> Security Class Initialized
INFO - 2025-11-17 12:46:46 --> Input Class Initialized
INFO - 2025-11-17 12:46:46 --> Language Class Initialized
INFO - 2025-11-17 12:46:46 --> Loader Class Initialized
INFO - 2025-11-17 12:46:46 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:46:46 --> Helper loaded: url_helper
INFO - 2025-11-17 12:46:46 --> Helper loaded: file_helper
INFO - 2025-11-17 12:46:46 --> Helper loaded: main_helper
INFO - 2025-11-17 12:46:46 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:46:46 --> Database Driver Class Initialized
INFO - 2025-11-17 12:46:46 --> Email Class Initialized
DEBUG - 2025-11-17 12:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:46:46 --> Controller Class Initialized
INFO - 2025-11-17 12:46:46 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:46:46 --> Model "User_model" initialized
INFO - 2025-11-17 12:46:46 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:46:46 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:46:46 --> Final output sent to browser
INFO - 2025-11-17 12:46:46 --> Total execution time: 0.0890
INFO - 2025-11-17 12:47:04 --> Config Class Initialized
INFO - 2025-11-17 12:47:04 --> Hooks Class Initialized
INFO - 2025-11-17 12:47:04 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:47:04 --> Utf8 Class Initialized
INFO - 2025-11-17 12:47:04 --> URI Class Initialized
INFO - 2025-11-17 12:47:04 --> Router Class Initialized
INFO - 2025-11-17 12:47:04 --> Output Class Initialized
INFO - 2025-11-17 12:47:04 --> Security Class Initialized
INFO - 2025-11-17 12:47:04 --> Input Class Initialized
INFO - 2025-11-17 12:47:04 --> Language Class Initialized
INFO - 2025-11-17 12:47:04 --> Loader Class Initialized
INFO - 2025-11-17 12:47:04 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:47:04 --> Helper loaded: url_helper
INFO - 2025-11-17 12:47:04 --> Helper loaded: file_helper
INFO - 2025-11-17 12:47:04 --> Helper loaded: main_helper
INFO - 2025-11-17 12:47:04 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:47:04 --> Database Driver Class Initialized
INFO - 2025-11-17 12:47:04 --> Email Class Initialized
DEBUG - 2025-11-17 12:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:47:04 --> Controller Class Initialized
INFO - 2025-11-17 12:47:04 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:47:04 --> Model "User_model" initialized
INFO - 2025-11-17 12:47:04 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:47:04 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:47:04 --> Final output sent to browser
INFO - 2025-11-17 12:47:04 --> Total execution time: 0.0870
INFO - 2025-11-17 12:47:27 --> Config Class Initialized
INFO - 2025-11-17 12:47:27 --> Hooks Class Initialized
INFO - 2025-11-17 12:47:27 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:47:27 --> Utf8 Class Initialized
INFO - 2025-11-17 12:47:27 --> URI Class Initialized
INFO - 2025-11-17 12:47:27 --> Router Class Initialized
INFO - 2025-11-17 12:47:27 --> Output Class Initialized
INFO - 2025-11-17 12:47:27 --> Security Class Initialized
INFO - 2025-11-17 12:47:27 --> Input Class Initialized
INFO - 2025-11-17 12:47:27 --> Language Class Initialized
INFO - 2025-11-17 12:47:27 --> Loader Class Initialized
INFO - 2025-11-17 12:47:27 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:47:27 --> Helper loaded: url_helper
INFO - 2025-11-17 12:47:27 --> Helper loaded: file_helper
INFO - 2025-11-17 12:47:27 --> Helper loaded: main_helper
INFO - 2025-11-17 12:47:27 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:47:27 --> Database Driver Class Initialized
INFO - 2025-11-17 12:47:27 --> Email Class Initialized
DEBUG - 2025-11-17 12:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:47:27 --> Controller Class Initialized
INFO - 2025-11-17 12:47:27 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:47:27 --> Model "User_model" initialized
INFO - 2025-11-17 12:47:27 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:47:27 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:47:27 --> Final output sent to browser
INFO - 2025-11-17 12:47:27 --> Total execution time: 0.0855
INFO - 2025-11-17 12:47:43 --> Config Class Initialized
INFO - 2025-11-17 12:47:43 --> Hooks Class Initialized
INFO - 2025-11-17 12:47:43 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:47:43 --> Utf8 Class Initialized
INFO - 2025-11-17 12:47:43 --> URI Class Initialized
INFO - 2025-11-17 12:47:43 --> Router Class Initialized
INFO - 2025-11-17 12:47:43 --> Output Class Initialized
INFO - 2025-11-17 12:47:43 --> Security Class Initialized
INFO - 2025-11-17 12:47:43 --> Input Class Initialized
INFO - 2025-11-17 12:47:43 --> Language Class Initialized
INFO - 2025-11-17 12:47:43 --> Loader Class Initialized
INFO - 2025-11-17 12:47:43 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:47:43 --> Helper loaded: url_helper
INFO - 2025-11-17 12:47:43 --> Helper loaded: file_helper
INFO - 2025-11-17 12:47:43 --> Helper loaded: main_helper
INFO - 2025-11-17 12:47:43 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:47:43 --> Database Driver Class Initialized
INFO - 2025-11-17 12:47:43 --> Email Class Initialized
DEBUG - 2025-11-17 12:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:47:43 --> Controller Class Initialized
INFO - 2025-11-17 12:47:43 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:47:43 --> Model "User_model" initialized
INFO - 2025-11-17 12:47:43 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:47:43 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:47:43 --> Final output sent to browser
INFO - 2025-11-17 12:47:43 --> Total execution time: 0.0880
INFO - 2025-11-17 12:49:17 --> Config Class Initialized
INFO - 2025-11-17 12:49:17 --> Hooks Class Initialized
INFO - 2025-11-17 12:49:17 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:49:17 --> Utf8 Class Initialized
INFO - 2025-11-17 12:49:17 --> URI Class Initialized
INFO - 2025-11-17 12:49:17 --> Router Class Initialized
INFO - 2025-11-17 12:49:17 --> Output Class Initialized
INFO - 2025-11-17 12:49:17 --> Security Class Initialized
INFO - 2025-11-17 12:49:17 --> Input Class Initialized
INFO - 2025-11-17 12:49:17 --> Language Class Initialized
INFO - 2025-11-17 12:49:17 --> Loader Class Initialized
INFO - 2025-11-17 12:49:17 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:49:17 --> Helper loaded: url_helper
INFO - 2025-11-17 12:49:17 --> Helper loaded: file_helper
INFO - 2025-11-17 12:49:17 --> Helper loaded: main_helper
INFO - 2025-11-17 12:49:17 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:49:17 --> Database Driver Class Initialized
INFO - 2025-11-17 12:49:17 --> Email Class Initialized
DEBUG - 2025-11-17 12:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:49:17 --> Controller Class Initialized
INFO - 2025-11-17 12:49:17 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:49:17 --> Model "User_model" initialized
INFO - 2025-11-17 12:49:17 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:49:17 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:49:17 --> Final output sent to browser
INFO - 2025-11-17 12:49:17 --> Total execution time: 0.0977
INFO - 2025-11-17 12:54:53 --> Config Class Initialized
INFO - 2025-11-17 12:54:53 --> Hooks Class Initialized
INFO - 2025-11-17 12:54:53 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:54:53 --> Utf8 Class Initialized
INFO - 2025-11-17 12:54:53 --> URI Class Initialized
INFO - 2025-11-17 12:54:53 --> Router Class Initialized
INFO - 2025-11-17 12:54:53 --> Output Class Initialized
INFO - 2025-11-17 12:54:53 --> Security Class Initialized
INFO - 2025-11-17 12:54:53 --> Input Class Initialized
INFO - 2025-11-17 12:54:53 --> Language Class Initialized
INFO - 2025-11-17 12:54:53 --> Loader Class Initialized
INFO - 2025-11-17 12:54:53 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:54:53 --> Helper loaded: url_helper
INFO - 2025-11-17 12:54:53 --> Helper loaded: file_helper
INFO - 2025-11-17 12:54:53 --> Helper loaded: main_helper
INFO - 2025-11-17 12:54:53 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:54:53 --> Database Driver Class Initialized
INFO - 2025-11-17 12:54:53 --> Email Class Initialized
DEBUG - 2025-11-17 12:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:54:53 --> Controller Class Initialized
INFO - 2025-11-17 12:54:53 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:54:53 --> Model "User_model" initialized
INFO - 2025-11-17 12:54:53 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:54:53 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:54:53 --> Final output sent to browser
INFO - 2025-11-17 12:54:53 --> Total execution time: 0.0910
INFO - 2025-11-17 12:55:50 --> Config Class Initialized
INFO - 2025-11-17 12:55:50 --> Hooks Class Initialized
INFO - 2025-11-17 12:55:50 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:55:50 --> Utf8 Class Initialized
INFO - 2025-11-17 12:55:50 --> URI Class Initialized
INFO - 2025-11-17 12:55:50 --> Router Class Initialized
INFO - 2025-11-17 12:55:50 --> Output Class Initialized
INFO - 2025-11-17 12:55:50 --> Security Class Initialized
INFO - 2025-11-17 12:55:50 --> Input Class Initialized
INFO - 2025-11-17 12:55:50 --> Language Class Initialized
INFO - 2025-11-17 12:55:50 --> Loader Class Initialized
INFO - 2025-11-17 12:55:50 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:55:50 --> Helper loaded: url_helper
INFO - 2025-11-17 12:55:50 --> Helper loaded: file_helper
INFO - 2025-11-17 12:55:50 --> Helper loaded: main_helper
INFO - 2025-11-17 12:55:50 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:55:51 --> Database Driver Class Initialized
INFO - 2025-11-17 12:55:51 --> Email Class Initialized
DEBUG - 2025-11-17 12:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:55:51 --> Controller Class Initialized
INFO - 2025-11-17 12:55:51 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:55:51 --> Model "User_model" initialized
INFO - 2025-11-17 12:55:51 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:55:51 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:55:51 --> Final output sent to browser
INFO - 2025-11-17 12:55:51 --> Total execution time: 0.1194
INFO - 2025-11-17 12:57:42 --> Config Class Initialized
INFO - 2025-11-17 12:57:42 --> Hooks Class Initialized
INFO - 2025-11-17 12:57:42 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:57:42 --> Utf8 Class Initialized
INFO - 2025-11-17 12:57:42 --> URI Class Initialized
INFO - 2025-11-17 12:57:42 --> Router Class Initialized
INFO - 2025-11-17 12:57:42 --> Output Class Initialized
INFO - 2025-11-17 12:57:42 --> Security Class Initialized
INFO - 2025-11-17 12:57:42 --> Input Class Initialized
INFO - 2025-11-17 12:57:42 --> Language Class Initialized
INFO - 2025-11-17 12:57:42 --> Loader Class Initialized
INFO - 2025-11-17 12:57:42 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:57:42 --> Helper loaded: url_helper
INFO - 2025-11-17 12:57:42 --> Helper loaded: file_helper
INFO - 2025-11-17 12:57:42 --> Helper loaded: main_helper
INFO - 2025-11-17 12:57:42 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:57:42 --> Database Driver Class Initialized
INFO - 2025-11-17 12:57:42 --> Email Class Initialized
DEBUG - 2025-11-17 12:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:57:42 --> Controller Class Initialized
INFO - 2025-11-17 12:57:42 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:57:42 --> Model "User_model" initialized
INFO - 2025-11-17 12:57:42 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:57:42 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:57:42 --> Final output sent to browser
INFO - 2025-11-17 12:57:42 --> Total execution time: 0.0858
INFO - 2025-11-17 12:58:12 --> Config Class Initialized
INFO - 2025-11-17 12:58:12 --> Hooks Class Initialized
INFO - 2025-11-17 12:58:12 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:58:12 --> Utf8 Class Initialized
INFO - 2025-11-17 12:58:12 --> URI Class Initialized
INFO - 2025-11-17 12:58:12 --> Router Class Initialized
INFO - 2025-11-17 12:58:12 --> Output Class Initialized
INFO - 2025-11-17 12:58:12 --> Security Class Initialized
INFO - 2025-11-17 12:58:12 --> Input Class Initialized
INFO - 2025-11-17 12:58:12 --> Language Class Initialized
INFO - 2025-11-17 12:58:12 --> Loader Class Initialized
INFO - 2025-11-17 12:58:12 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:58:12 --> Helper loaded: url_helper
INFO - 2025-11-17 12:58:12 --> Helper loaded: file_helper
INFO - 2025-11-17 12:58:12 --> Helper loaded: main_helper
INFO - 2025-11-17 12:58:12 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:58:12 --> Database Driver Class Initialized
INFO - 2025-11-17 12:58:12 --> Email Class Initialized
DEBUG - 2025-11-17 12:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:58:12 --> Controller Class Initialized
INFO - 2025-11-17 12:58:12 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:58:12 --> Model "User_model" initialized
INFO - 2025-11-17 12:58:12 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:58:12 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:58:12 --> Final output sent to browser
INFO - 2025-11-17 12:58:12 --> Total execution time: 0.0998
INFO - 2025-11-17 12:59:22 --> Config Class Initialized
INFO - 2025-11-17 12:59:22 --> Hooks Class Initialized
INFO - 2025-11-17 12:59:22 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:59:22 --> Utf8 Class Initialized
INFO - 2025-11-17 12:59:22 --> URI Class Initialized
INFO - 2025-11-17 12:59:22 --> Router Class Initialized
INFO - 2025-11-17 12:59:22 --> Output Class Initialized
INFO - 2025-11-17 12:59:22 --> Security Class Initialized
INFO - 2025-11-17 12:59:22 --> Input Class Initialized
INFO - 2025-11-17 12:59:22 --> Language Class Initialized
INFO - 2025-11-17 12:59:22 --> Loader Class Initialized
INFO - 2025-11-17 12:59:22 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:59:22 --> Helper loaded: url_helper
INFO - 2025-11-17 12:59:22 --> Helper loaded: file_helper
INFO - 2025-11-17 12:59:22 --> Helper loaded: main_helper
INFO - 2025-11-17 12:59:22 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:59:22 --> Database Driver Class Initialized
INFO - 2025-11-17 12:59:22 --> Email Class Initialized
DEBUG - 2025-11-17 12:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:59:22 --> Controller Class Initialized
INFO - 2025-11-17 12:59:22 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:59:22 --> Model "User_model" initialized
INFO - 2025-11-17 12:59:22 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:59:22 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:59:22 --> Final output sent to browser
INFO - 2025-11-17 12:59:22 --> Total execution time: 0.1180
INFO - 2025-11-17 12:59:48 --> Config Class Initialized
INFO - 2025-11-17 12:59:48 --> Hooks Class Initialized
INFO - 2025-11-17 12:59:48 --> UTF-8 Support Enabled
INFO - 2025-11-17 12:59:48 --> Utf8 Class Initialized
INFO - 2025-11-17 12:59:48 --> URI Class Initialized
INFO - 2025-11-17 12:59:48 --> Router Class Initialized
INFO - 2025-11-17 12:59:48 --> Output Class Initialized
INFO - 2025-11-17 12:59:48 --> Security Class Initialized
INFO - 2025-11-17 12:59:48 --> Input Class Initialized
INFO - 2025-11-17 12:59:48 --> Language Class Initialized
INFO - 2025-11-17 12:59:48 --> Loader Class Initialized
INFO - 2025-11-17 12:59:48 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 12:59:48 --> Helper loaded: url_helper
INFO - 2025-11-17 12:59:48 --> Helper loaded: file_helper
INFO - 2025-11-17 12:59:48 --> Helper loaded: main_helper
INFO - 2025-11-17 12:59:48 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 12:59:48 --> Database Driver Class Initialized
INFO - 2025-11-17 12:59:48 --> Email Class Initialized
DEBUG - 2025-11-17 12:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 12:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 12:59:48 --> Controller Class Initialized
INFO - 2025-11-17 12:59:48 --> Model "Subscription_model" initialized
INFO - 2025-11-17 12:59:48 --> Model "User_model" initialized
INFO - 2025-11-17 12:59:48 --> Model "Auth_model" initialized
INFO - 2025-11-17 12:59:48 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 12:59:48 --> Final output sent to browser
INFO - 2025-11-17 12:59:48 --> Total execution time: 0.1224
INFO - 2025-11-17 13:00:06 --> Config Class Initialized
INFO - 2025-11-17 13:00:06 --> Hooks Class Initialized
INFO - 2025-11-17 13:00:06 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:00:06 --> Utf8 Class Initialized
INFO - 2025-11-17 13:00:06 --> URI Class Initialized
INFO - 2025-11-17 13:00:06 --> Router Class Initialized
INFO - 2025-11-17 13:00:06 --> Output Class Initialized
INFO - 2025-11-17 13:00:06 --> Security Class Initialized
INFO - 2025-11-17 13:00:06 --> Input Class Initialized
INFO - 2025-11-17 13:00:06 --> Language Class Initialized
INFO - 2025-11-17 13:00:06 --> Loader Class Initialized
INFO - 2025-11-17 13:00:06 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:00:06 --> Helper loaded: url_helper
INFO - 2025-11-17 13:00:06 --> Helper loaded: file_helper
INFO - 2025-11-17 13:00:06 --> Helper loaded: main_helper
INFO - 2025-11-17 13:00:06 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:00:07 --> Database Driver Class Initialized
INFO - 2025-11-17 13:00:07 --> Email Class Initialized
DEBUG - 2025-11-17 13:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:00:07 --> Controller Class Initialized
INFO - 2025-11-17 13:00:07 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:00:07 --> Model "User_model" initialized
INFO - 2025-11-17 13:00:07 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:00:07 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:00:07 --> Final output sent to browser
INFO - 2025-11-17 13:00:07 --> Total execution time: 0.0997
INFO - 2025-11-17 13:02:11 --> Config Class Initialized
INFO - 2025-11-17 13:02:11 --> Hooks Class Initialized
INFO - 2025-11-17 13:02:11 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:02:11 --> Utf8 Class Initialized
INFO - 2025-11-17 13:02:11 --> URI Class Initialized
INFO - 2025-11-17 13:02:11 --> Router Class Initialized
INFO - 2025-11-17 13:02:11 --> Output Class Initialized
INFO - 2025-11-17 13:02:11 --> Security Class Initialized
INFO - 2025-11-17 13:02:11 --> Input Class Initialized
INFO - 2025-11-17 13:02:11 --> Language Class Initialized
INFO - 2025-11-17 13:02:11 --> Loader Class Initialized
INFO - 2025-11-17 13:02:11 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:02:11 --> Helper loaded: url_helper
INFO - 2025-11-17 13:02:11 --> Helper loaded: file_helper
INFO - 2025-11-17 13:02:11 --> Helper loaded: main_helper
INFO - 2025-11-17 13:02:11 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:02:11 --> Database Driver Class Initialized
INFO - 2025-11-17 13:02:11 --> Email Class Initialized
DEBUG - 2025-11-17 13:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:02:11 --> Controller Class Initialized
INFO - 2025-11-17 13:02:11 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:02:11 --> Model "User_model" initialized
INFO - 2025-11-17 13:02:11 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:02:11 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:02:11 --> Final output sent to browser
INFO - 2025-11-17 13:02:11 --> Total execution time: 0.0985
INFO - 2025-11-17 13:02:14 --> Config Class Initialized
INFO - 2025-11-17 13:02:14 --> Hooks Class Initialized
INFO - 2025-11-17 13:02:14 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:02:14 --> Utf8 Class Initialized
INFO - 2025-11-17 13:02:14 --> URI Class Initialized
INFO - 2025-11-17 13:02:14 --> Router Class Initialized
INFO - 2025-11-17 13:02:14 --> Output Class Initialized
INFO - 2025-11-17 13:02:14 --> Security Class Initialized
INFO - 2025-11-17 13:02:14 --> Input Class Initialized
INFO - 2025-11-17 13:02:14 --> Language Class Initialized
INFO - 2025-11-17 13:02:14 --> Loader Class Initialized
INFO - 2025-11-17 13:02:14 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:02:14 --> Helper loaded: url_helper
INFO - 2025-11-17 13:02:14 --> Helper loaded: file_helper
INFO - 2025-11-17 13:02:14 --> Helper loaded: main_helper
INFO - 2025-11-17 13:02:14 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:02:14 --> Database Driver Class Initialized
INFO - 2025-11-17 13:02:14 --> Email Class Initialized
DEBUG - 2025-11-17 13:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:02:14 --> Controller Class Initialized
INFO - 2025-11-17 13:02:14 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:02:14 --> Model "User_model" initialized
INFO - 2025-11-17 13:02:14 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:02:14 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:02:14 --> Final output sent to browser
INFO - 2025-11-17 13:02:14 --> Total execution time: 0.0813
INFO - 2025-11-17 13:02:24 --> Config Class Initialized
INFO - 2025-11-17 13:02:24 --> Hooks Class Initialized
INFO - 2025-11-17 13:02:24 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:02:24 --> Utf8 Class Initialized
INFO - 2025-11-17 13:02:24 --> URI Class Initialized
INFO - 2025-11-17 13:02:24 --> Router Class Initialized
INFO - 2025-11-17 13:02:24 --> Output Class Initialized
INFO - 2025-11-17 13:02:24 --> Security Class Initialized
INFO - 2025-11-17 13:02:24 --> Input Class Initialized
INFO - 2025-11-17 13:02:24 --> Language Class Initialized
INFO - 2025-11-17 13:02:24 --> Loader Class Initialized
INFO - 2025-11-17 13:02:24 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:02:24 --> Helper loaded: url_helper
INFO - 2025-11-17 13:02:24 --> Helper loaded: file_helper
INFO - 2025-11-17 13:02:24 --> Helper loaded: main_helper
INFO - 2025-11-17 13:02:24 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:02:24 --> Database Driver Class Initialized
INFO - 2025-11-17 13:02:24 --> Email Class Initialized
DEBUG - 2025-11-17 13:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:02:24 --> Controller Class Initialized
INFO - 2025-11-17 13:02:24 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:02:24 --> Model "User_model" initialized
INFO - 2025-11-17 13:02:24 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:02:24 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:02:24 --> Final output sent to browser
INFO - 2025-11-17 13:02:24 --> Total execution time: 0.0960
INFO - 2025-11-17 13:02:35 --> Config Class Initialized
INFO - 2025-11-17 13:02:35 --> Hooks Class Initialized
INFO - 2025-11-17 13:02:35 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:02:35 --> Utf8 Class Initialized
INFO - 2025-11-17 13:02:35 --> URI Class Initialized
INFO - 2025-11-17 13:02:35 --> Router Class Initialized
INFO - 2025-11-17 13:02:35 --> Output Class Initialized
INFO - 2025-11-17 13:02:35 --> Security Class Initialized
INFO - 2025-11-17 13:02:35 --> Input Class Initialized
INFO - 2025-11-17 13:02:35 --> Language Class Initialized
INFO - 2025-11-17 13:02:35 --> Loader Class Initialized
INFO - 2025-11-17 13:02:35 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:02:35 --> Helper loaded: url_helper
INFO - 2025-11-17 13:02:35 --> Helper loaded: file_helper
INFO - 2025-11-17 13:02:35 --> Helper loaded: main_helper
INFO - 2025-11-17 13:02:35 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:02:36 --> Database Driver Class Initialized
INFO - 2025-11-17 13:02:36 --> Email Class Initialized
DEBUG - 2025-11-17 13:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:02:36 --> Controller Class Initialized
INFO - 2025-11-17 13:02:36 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:02:36 --> Model "User_model" initialized
INFO - 2025-11-17 13:02:36 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:02:36 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:02:36 --> Final output sent to browser
INFO - 2025-11-17 13:02:36 --> Total execution time: 0.1153
INFO - 2025-11-17 13:09:11 --> Config Class Initialized
INFO - 2025-11-17 13:09:11 --> Hooks Class Initialized
INFO - 2025-11-17 13:09:11 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:09:11 --> Utf8 Class Initialized
INFO - 2025-11-17 13:09:11 --> URI Class Initialized
INFO - 2025-11-17 13:09:11 --> Router Class Initialized
INFO - 2025-11-17 13:09:11 --> Output Class Initialized
INFO - 2025-11-17 13:09:11 --> Security Class Initialized
INFO - 2025-11-17 13:09:11 --> Input Class Initialized
INFO - 2025-11-17 13:09:11 --> Language Class Initialized
INFO - 2025-11-17 13:09:11 --> Loader Class Initialized
INFO - 2025-11-17 13:09:11 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:09:11 --> Helper loaded: url_helper
INFO - 2025-11-17 13:09:11 --> Helper loaded: file_helper
INFO - 2025-11-17 13:09:11 --> Helper loaded: main_helper
INFO - 2025-11-17 13:09:11 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:09:11 --> Database Driver Class Initialized
INFO - 2025-11-17 13:09:11 --> Email Class Initialized
DEBUG - 2025-11-17 13:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:09:11 --> Controller Class Initialized
INFO - 2025-11-17 13:09:11 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:09:11 --> Model "User_model" initialized
INFO - 2025-11-17 13:09:11 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:09:11 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:09:11 --> Final output sent to browser
INFO - 2025-11-17 13:09:11 --> Total execution time: 0.1118
INFO - 2025-11-17 13:09:30 --> Config Class Initialized
INFO - 2025-11-17 13:09:30 --> Hooks Class Initialized
INFO - 2025-11-17 13:09:30 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:09:30 --> Utf8 Class Initialized
INFO - 2025-11-17 13:09:30 --> URI Class Initialized
INFO - 2025-11-17 13:09:30 --> Router Class Initialized
INFO - 2025-11-17 13:09:30 --> Output Class Initialized
INFO - 2025-11-17 13:09:30 --> Security Class Initialized
INFO - 2025-11-17 13:09:31 --> Input Class Initialized
INFO - 2025-11-17 13:09:31 --> Language Class Initialized
INFO - 2025-11-17 13:09:31 --> Loader Class Initialized
INFO - 2025-11-17 13:09:31 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:09:31 --> Helper loaded: url_helper
INFO - 2025-11-17 13:09:31 --> Helper loaded: file_helper
INFO - 2025-11-17 13:09:31 --> Helper loaded: main_helper
INFO - 2025-11-17 13:09:31 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:09:31 --> Database Driver Class Initialized
INFO - 2025-11-17 13:09:31 --> Email Class Initialized
DEBUG - 2025-11-17 13:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:09:31 --> Controller Class Initialized
INFO - 2025-11-17 13:09:31 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:09:31 --> Model "User_model" initialized
INFO - 2025-11-17 13:09:31 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:09:31 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:09:31 --> Final output sent to browser
INFO - 2025-11-17 13:09:31 --> Total execution time: 0.0903
INFO - 2025-11-17 13:10:11 --> Config Class Initialized
INFO - 2025-11-17 13:10:11 --> Hooks Class Initialized
INFO - 2025-11-17 13:10:11 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:10:11 --> Utf8 Class Initialized
INFO - 2025-11-17 13:10:11 --> URI Class Initialized
INFO - 2025-11-17 13:10:11 --> Router Class Initialized
INFO - 2025-11-17 13:10:11 --> Output Class Initialized
INFO - 2025-11-17 13:10:11 --> Security Class Initialized
INFO - 2025-11-17 13:10:11 --> Input Class Initialized
INFO - 2025-11-17 13:10:11 --> Language Class Initialized
INFO - 2025-11-17 13:10:11 --> Loader Class Initialized
INFO - 2025-11-17 13:10:11 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:10:11 --> Helper loaded: url_helper
INFO - 2025-11-17 13:10:11 --> Helper loaded: file_helper
INFO - 2025-11-17 13:10:11 --> Helper loaded: main_helper
INFO - 2025-11-17 13:10:11 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:10:11 --> Database Driver Class Initialized
INFO - 2025-11-17 13:10:11 --> Email Class Initialized
DEBUG - 2025-11-17 13:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:10:11 --> Controller Class Initialized
INFO - 2025-11-17 13:10:11 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:10:11 --> Model "User_model" initialized
INFO - 2025-11-17 13:10:11 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:10:11 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:10:11 --> Final output sent to browser
INFO - 2025-11-17 13:10:11 --> Total execution time: 0.0837
INFO - 2025-11-17 13:10:18 --> Config Class Initialized
INFO - 2025-11-17 13:10:18 --> Hooks Class Initialized
INFO - 2025-11-17 13:10:18 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:10:18 --> Utf8 Class Initialized
INFO - 2025-11-17 13:10:18 --> URI Class Initialized
INFO - 2025-11-17 13:10:18 --> Router Class Initialized
INFO - 2025-11-17 13:10:18 --> Output Class Initialized
INFO - 2025-11-17 13:10:18 --> Security Class Initialized
INFO - 2025-11-17 13:10:18 --> Input Class Initialized
INFO - 2025-11-17 13:10:18 --> Language Class Initialized
ERROR - 2025-11-17 13:10:18 --> 404 Page Not Found: Api/subscription
INFO - 2025-11-17 13:11:22 --> Config Class Initialized
INFO - 2025-11-17 13:11:22 --> Hooks Class Initialized
INFO - 2025-11-17 13:11:22 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:11:22 --> Utf8 Class Initialized
INFO - 2025-11-17 13:11:22 --> URI Class Initialized
INFO - 2025-11-17 13:11:22 --> Router Class Initialized
INFO - 2025-11-17 13:11:22 --> Output Class Initialized
INFO - 2025-11-17 13:11:22 --> Security Class Initialized
INFO - 2025-11-17 13:11:22 --> Input Class Initialized
INFO - 2025-11-17 13:11:22 --> Language Class Initialized
INFO - 2025-11-17 13:11:22 --> Loader Class Initialized
INFO - 2025-11-17 13:11:22 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:11:22 --> Helper loaded: url_helper
INFO - 2025-11-17 13:11:22 --> Helper loaded: file_helper
INFO - 2025-11-17 13:11:22 --> Helper loaded: main_helper
INFO - 2025-11-17 13:11:22 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:11:22 --> Database Driver Class Initialized
INFO - 2025-11-17 13:11:22 --> Email Class Initialized
DEBUG - 2025-11-17 13:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:11:22 --> Controller Class Initialized
INFO - 2025-11-17 13:11:22 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:11:22 --> Model "User_model" initialized
INFO - 2025-11-17 13:11:22 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:11:22 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:11:22 --> Final output sent to browser
INFO - 2025-11-17 13:11:22 --> Total execution time: 0.0957
INFO - 2025-11-17 13:11:34 --> Config Class Initialized
INFO - 2025-11-17 13:11:34 --> Hooks Class Initialized
INFO - 2025-11-17 13:11:34 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:11:34 --> Utf8 Class Initialized
INFO - 2025-11-17 13:11:34 --> URI Class Initialized
INFO - 2025-11-17 13:11:34 --> Router Class Initialized
INFO - 2025-11-17 13:11:34 --> Output Class Initialized
INFO - 2025-11-17 13:11:34 --> Security Class Initialized
INFO - 2025-11-17 13:11:34 --> Input Class Initialized
INFO - 2025-11-17 13:11:34 --> Language Class Initialized
INFO - 2025-11-17 13:11:34 --> Loader Class Initialized
INFO - 2025-11-17 13:11:34 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:11:34 --> Helper loaded: url_helper
INFO - 2025-11-17 13:11:34 --> Helper loaded: file_helper
INFO - 2025-11-17 13:11:34 --> Helper loaded: main_helper
INFO - 2025-11-17 13:11:34 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:11:34 --> Database Driver Class Initialized
INFO - 2025-11-17 13:11:34 --> Email Class Initialized
DEBUG - 2025-11-17 13:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:11:34 --> Controller Class Initialized
INFO - 2025-11-17 13:11:34 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:11:34 --> Model "User_model" initialized
INFO - 2025-11-17 13:11:34 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:11:34 --> Upload Class Initialized
INFO - 2025-11-17 13:11:34 --> Final output sent to browser
INFO - 2025-11-17 13:11:34 --> Total execution time: 0.1401
INFO - 2025-11-17 13:11:34 --> Config Class Initialized
INFO - 2025-11-17 13:11:34 --> Hooks Class Initialized
INFO - 2025-11-17 13:11:34 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:11:34 --> Utf8 Class Initialized
INFO - 2025-11-17 13:11:34 --> URI Class Initialized
INFO - 2025-11-17 13:11:34 --> Router Class Initialized
INFO - 2025-11-17 13:11:34 --> Output Class Initialized
INFO - 2025-11-17 13:11:34 --> Security Class Initialized
INFO - 2025-11-17 13:11:34 --> Input Class Initialized
INFO - 2025-11-17 13:11:34 --> Language Class Initialized
INFO - 2025-11-17 13:11:34 --> Loader Class Initialized
INFO - 2025-11-17 13:11:34 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:11:34 --> Helper loaded: url_helper
INFO - 2025-11-17 13:11:34 --> Helper loaded: file_helper
INFO - 2025-11-17 13:11:34 --> Helper loaded: main_helper
INFO - 2025-11-17 13:11:34 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:11:34 --> Database Driver Class Initialized
INFO - 2025-11-17 13:11:34 --> Email Class Initialized
DEBUG - 2025-11-17 13:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:11:34 --> Controller Class Initialized
INFO - 2025-11-17 13:11:34 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:11:34 --> Model "User_model" initialized
INFO - 2025-11-17 13:11:34 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:11:34 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:11:34 --> Final output sent to browser
INFO - 2025-11-17 13:11:34 --> Total execution time: 0.1293
INFO - 2025-11-17 13:11:41 --> Config Class Initialized
INFO - 2025-11-17 13:11:41 --> Hooks Class Initialized
INFO - 2025-11-17 13:11:41 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:11:41 --> Utf8 Class Initialized
INFO - 2025-11-17 13:11:41 --> URI Class Initialized
INFO - 2025-11-17 13:11:41 --> Router Class Initialized
INFO - 2025-11-17 13:11:41 --> Output Class Initialized
INFO - 2025-11-17 13:11:41 --> Security Class Initialized
INFO - 2025-11-17 13:11:41 --> Input Class Initialized
INFO - 2025-11-17 13:11:41 --> Language Class Initialized
INFO - 2025-11-17 13:11:41 --> Loader Class Initialized
INFO - 2025-11-17 13:11:41 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:11:41 --> Helper loaded: url_helper
INFO - 2025-11-17 13:11:41 --> Helper loaded: file_helper
INFO - 2025-11-17 13:11:41 --> Helper loaded: main_helper
INFO - 2025-11-17 13:11:41 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:11:41 --> Database Driver Class Initialized
INFO - 2025-11-17 13:11:41 --> Email Class Initialized
DEBUG - 2025-11-17 13:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:11:41 --> Controller Class Initialized
INFO - 2025-11-17 13:11:41 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:11:41 --> Model "User_model" initialized
INFO - 2025-11-17 13:11:41 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:11:41 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:11:41 --> Final output sent to browser
INFO - 2025-11-17 13:11:41 --> Total execution time: 0.1038
INFO - 2025-11-17 13:13:56 --> Config Class Initialized
INFO - 2025-11-17 13:13:56 --> Hooks Class Initialized
INFO - 2025-11-17 13:13:56 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:13:56 --> Utf8 Class Initialized
INFO - 2025-11-17 13:13:56 --> URI Class Initialized
INFO - 2025-11-17 13:13:56 --> Router Class Initialized
INFO - 2025-11-17 13:13:56 --> Output Class Initialized
INFO - 2025-11-17 13:13:56 --> Security Class Initialized
INFO - 2025-11-17 13:13:56 --> Input Class Initialized
INFO - 2025-11-17 13:13:56 --> Language Class Initialized
INFO - 2025-11-17 13:13:56 --> Loader Class Initialized
INFO - 2025-11-17 13:13:56 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:13:56 --> Helper loaded: url_helper
INFO - 2025-11-17 13:13:56 --> Helper loaded: file_helper
INFO - 2025-11-17 13:13:56 --> Helper loaded: main_helper
INFO - 2025-11-17 13:13:56 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:13:56 --> Database Driver Class Initialized
INFO - 2025-11-17 13:13:56 --> Email Class Initialized
DEBUG - 2025-11-17 13:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:13:56 --> Controller Class Initialized
INFO - 2025-11-17 13:13:56 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:13:56 --> Model "User_model" initialized
INFO - 2025-11-17 13:13:56 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:13:56 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:13:56 --> Final output sent to browser
INFO - 2025-11-17 13:13:56 --> Total execution time: 0.0900
INFO - 2025-11-17 13:14:56 --> Config Class Initialized
INFO - 2025-11-17 13:14:56 --> Hooks Class Initialized
INFO - 2025-11-17 13:14:56 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:14:56 --> Utf8 Class Initialized
INFO - 2025-11-17 13:14:56 --> URI Class Initialized
INFO - 2025-11-17 13:14:56 --> Router Class Initialized
INFO - 2025-11-17 13:14:56 --> Output Class Initialized
INFO - 2025-11-17 13:14:56 --> Security Class Initialized
INFO - 2025-11-17 13:14:56 --> Input Class Initialized
INFO - 2025-11-17 13:14:56 --> Language Class Initialized
INFO - 2025-11-17 13:14:56 --> Loader Class Initialized
INFO - 2025-11-17 13:14:56 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:14:56 --> Helper loaded: url_helper
INFO - 2025-11-17 13:14:56 --> Helper loaded: file_helper
INFO - 2025-11-17 13:14:56 --> Helper loaded: main_helper
INFO - 2025-11-17 13:14:56 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:14:56 --> Database Driver Class Initialized
INFO - 2025-11-17 13:14:56 --> Email Class Initialized
DEBUG - 2025-11-17 13:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:14:56 --> Controller Class Initialized
INFO - 2025-11-17 13:14:56 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:14:56 --> Model "User_model" initialized
INFO - 2025-11-17 13:14:56 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:14:56 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:14:56 --> Final output sent to browser
INFO - 2025-11-17 13:14:56 --> Total execution time: 0.0896
INFO - 2025-11-17 13:15:04 --> Config Class Initialized
INFO - 2025-11-17 13:15:04 --> Hooks Class Initialized
INFO - 2025-11-17 13:15:04 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:15:04 --> Utf8 Class Initialized
INFO - 2025-11-17 13:15:04 --> URI Class Initialized
INFO - 2025-11-17 13:15:04 --> Router Class Initialized
INFO - 2025-11-17 13:15:04 --> Output Class Initialized
INFO - 2025-11-17 13:15:04 --> Security Class Initialized
INFO - 2025-11-17 13:15:04 --> Input Class Initialized
INFO - 2025-11-17 13:15:04 --> Language Class Initialized
INFO - 2025-11-17 13:15:04 --> Loader Class Initialized
INFO - 2025-11-17 13:15:04 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:15:04 --> Helper loaded: url_helper
INFO - 2025-11-17 13:15:04 --> Helper loaded: file_helper
INFO - 2025-11-17 13:15:04 --> Helper loaded: main_helper
INFO - 2025-11-17 13:15:04 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:15:04 --> Database Driver Class Initialized
INFO - 2025-11-17 13:15:04 --> Email Class Initialized
DEBUG - 2025-11-17 13:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:15:04 --> Controller Class Initialized
INFO - 2025-11-17 13:15:04 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:15:04 --> Model "User_model" initialized
INFO - 2025-11-17 13:15:04 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:15:04 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:15:04 --> Final output sent to browser
INFO - 2025-11-17 13:15:04 --> Total execution time: 0.1170
INFO - 2025-11-17 13:15:27 --> Config Class Initialized
INFO - 2025-11-17 13:15:27 --> Hooks Class Initialized
INFO - 2025-11-17 13:15:27 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:15:27 --> Utf8 Class Initialized
INFO - 2025-11-17 13:15:27 --> URI Class Initialized
INFO - 2025-11-17 13:15:27 --> Router Class Initialized
INFO - 2025-11-17 13:15:27 --> Output Class Initialized
INFO - 2025-11-17 13:15:27 --> Security Class Initialized
INFO - 2025-11-17 13:15:27 --> Input Class Initialized
INFO - 2025-11-17 13:15:27 --> Language Class Initialized
INFO - 2025-11-17 13:15:27 --> Loader Class Initialized
INFO - 2025-11-17 13:15:27 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:15:27 --> Helper loaded: url_helper
INFO - 2025-11-17 13:15:27 --> Helper loaded: file_helper
INFO - 2025-11-17 13:15:27 --> Helper loaded: main_helper
INFO - 2025-11-17 13:15:27 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:15:27 --> Database Driver Class Initialized
INFO - 2025-11-17 13:15:27 --> Email Class Initialized
DEBUG - 2025-11-17 13:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:15:27 --> Controller Class Initialized
INFO - 2025-11-17 13:15:27 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:15:27 --> Model "User_model" initialized
INFO - 2025-11-17 13:15:27 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:15:27 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:15:27 --> Final output sent to browser
INFO - 2025-11-17 13:15:27 --> Total execution time: 0.0833
INFO - 2025-11-17 13:18:03 --> Config Class Initialized
INFO - 2025-11-17 13:18:03 --> Hooks Class Initialized
INFO - 2025-11-17 13:18:03 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:18:03 --> Utf8 Class Initialized
INFO - 2025-11-17 13:18:03 --> URI Class Initialized
INFO - 2025-11-17 13:18:03 --> Router Class Initialized
INFO - 2025-11-17 13:18:03 --> Output Class Initialized
INFO - 2025-11-17 13:18:03 --> Security Class Initialized
INFO - 2025-11-17 13:18:03 --> Input Class Initialized
INFO - 2025-11-17 13:18:03 --> Language Class Initialized
INFO - 2025-11-17 13:18:03 --> Loader Class Initialized
INFO - 2025-11-17 13:18:03 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:18:03 --> Helper loaded: url_helper
INFO - 2025-11-17 13:18:03 --> Helper loaded: file_helper
INFO - 2025-11-17 13:18:03 --> Helper loaded: main_helper
INFO - 2025-11-17 13:18:03 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:18:03 --> Database Driver Class Initialized
INFO - 2025-11-17 13:18:03 --> Email Class Initialized
DEBUG - 2025-11-17 13:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:18:03 --> Controller Class Initialized
INFO - 2025-11-17 13:18:03 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:18:03 --> Model "User_model" initialized
INFO - 2025-11-17 13:18:03 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:18:03 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:18:03 --> Final output sent to browser
INFO - 2025-11-17 13:18:03 --> Total execution time: 0.1206
INFO - 2025-11-17 13:18:40 --> Config Class Initialized
INFO - 2025-11-17 13:18:40 --> Hooks Class Initialized
INFO - 2025-11-17 13:18:40 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:18:40 --> Utf8 Class Initialized
INFO - 2025-11-17 13:18:40 --> URI Class Initialized
INFO - 2025-11-17 13:18:40 --> Router Class Initialized
INFO - 2025-11-17 13:18:40 --> Output Class Initialized
INFO - 2025-11-17 13:18:40 --> Security Class Initialized
INFO - 2025-11-17 13:18:40 --> Input Class Initialized
INFO - 2025-11-17 13:18:40 --> Language Class Initialized
INFO - 2025-11-17 13:18:40 --> Loader Class Initialized
INFO - 2025-11-17 13:18:40 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:18:40 --> Helper loaded: url_helper
INFO - 2025-11-17 13:18:40 --> Helper loaded: file_helper
INFO - 2025-11-17 13:18:40 --> Helper loaded: main_helper
INFO - 2025-11-17 13:18:40 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:18:40 --> Database Driver Class Initialized
INFO - 2025-11-17 13:18:40 --> Email Class Initialized
DEBUG - 2025-11-17 13:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:18:40 --> Controller Class Initialized
INFO - 2025-11-17 13:18:40 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:18:40 --> Model "User_model" initialized
INFO - 2025-11-17 13:18:40 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:18:40 --> Upload Class Initialized
INFO - 2025-11-17 13:18:40 --> Final output sent to browser
INFO - 2025-11-17 13:18:40 --> Total execution time: 0.1176
INFO - 2025-11-17 13:18:40 --> Config Class Initialized
INFO - 2025-11-17 13:18:40 --> Hooks Class Initialized
INFO - 2025-11-17 13:18:40 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:18:40 --> Utf8 Class Initialized
INFO - 2025-11-17 13:18:40 --> URI Class Initialized
INFO - 2025-11-17 13:18:40 --> Router Class Initialized
INFO - 2025-11-17 13:18:40 --> Output Class Initialized
INFO - 2025-11-17 13:18:40 --> Security Class Initialized
INFO - 2025-11-17 13:18:40 --> Input Class Initialized
INFO - 2025-11-17 13:18:40 --> Language Class Initialized
INFO - 2025-11-17 13:18:40 --> Loader Class Initialized
INFO - 2025-11-17 13:18:40 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:18:40 --> Helper loaded: url_helper
INFO - 2025-11-17 13:18:40 --> Helper loaded: file_helper
INFO - 2025-11-17 13:18:40 --> Helper loaded: main_helper
INFO - 2025-11-17 13:18:40 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:18:40 --> Database Driver Class Initialized
INFO - 2025-11-17 13:18:40 --> Email Class Initialized
DEBUG - 2025-11-17 13:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:18:40 --> Controller Class Initialized
INFO - 2025-11-17 13:18:40 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:18:40 --> Model "User_model" initialized
INFO - 2025-11-17 13:18:40 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:18:40 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:18:40 --> Final output sent to browser
INFO - 2025-11-17 13:18:40 --> Total execution time: 0.0921
INFO - 2025-11-17 13:18:41 --> Config Class Initialized
INFO - 2025-11-17 13:18:41 --> Hooks Class Initialized
INFO - 2025-11-17 13:18:41 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:18:41 --> Utf8 Class Initialized
INFO - 2025-11-17 13:18:41 --> URI Class Initialized
INFO - 2025-11-17 13:18:41 --> Router Class Initialized
INFO - 2025-11-17 13:18:41 --> Output Class Initialized
INFO - 2025-11-17 13:18:41 --> Security Class Initialized
INFO - 2025-11-17 13:18:41 --> Input Class Initialized
INFO - 2025-11-17 13:18:41 --> Language Class Initialized
ERROR - 2025-11-17 13:18:41 --> 404 Page Not Found: Ff67549c109d3b67dedd2eb37618f6bcpng/index
INFO - 2025-11-17 13:20:49 --> Config Class Initialized
INFO - 2025-11-17 13:20:49 --> Hooks Class Initialized
INFO - 2025-11-17 13:20:49 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:20:49 --> Utf8 Class Initialized
INFO - 2025-11-17 13:20:49 --> URI Class Initialized
INFO - 2025-11-17 13:20:49 --> Router Class Initialized
INFO - 2025-11-17 13:20:49 --> Output Class Initialized
INFO - 2025-11-17 13:20:49 --> Security Class Initialized
INFO - 2025-11-17 13:20:49 --> Input Class Initialized
INFO - 2025-11-17 13:20:49 --> Language Class Initialized
INFO - 2025-11-17 13:20:49 --> Loader Class Initialized
INFO - 2025-11-17 13:20:49 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:20:49 --> Helper loaded: url_helper
INFO - 2025-11-17 13:20:49 --> Helper loaded: file_helper
INFO - 2025-11-17 13:20:49 --> Helper loaded: main_helper
INFO - 2025-11-17 13:20:49 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:20:49 --> Database Driver Class Initialized
INFO - 2025-11-17 13:20:49 --> Email Class Initialized
DEBUG - 2025-11-17 13:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:20:49 --> Controller Class Initialized
INFO - 2025-11-17 13:20:49 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:20:49 --> Model "User_model" initialized
INFO - 2025-11-17 13:20:49 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:20:49 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:20:49 --> Final output sent to browser
INFO - 2025-11-17 13:20:49 --> Total execution time: 0.1222
INFO - 2025-11-17 13:20:49 --> Config Class Initialized
INFO - 2025-11-17 13:20:49 --> Hooks Class Initialized
INFO - 2025-11-17 13:20:49 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:20:49 --> Utf8 Class Initialized
INFO - 2025-11-17 13:20:49 --> URI Class Initialized
INFO - 2025-11-17 13:20:49 --> Router Class Initialized
INFO - 2025-11-17 13:20:49 --> Output Class Initialized
INFO - 2025-11-17 13:20:49 --> Security Class Initialized
INFO - 2025-11-17 13:20:49 --> Input Class Initialized
INFO - 2025-11-17 13:20:49 --> Language Class Initialized
ERROR - 2025-11-17 13:20:49 --> 404 Page Not Found: Ff67549c109d3b67dedd2eb37618f6bcpng/index
INFO - 2025-11-17 13:22:06 --> Config Class Initialized
INFO - 2025-11-17 13:22:06 --> Hooks Class Initialized
INFO - 2025-11-17 13:22:06 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:22:06 --> Utf8 Class Initialized
INFO - 2025-11-17 13:22:06 --> URI Class Initialized
INFO - 2025-11-17 13:22:06 --> Router Class Initialized
INFO - 2025-11-17 13:22:06 --> Output Class Initialized
INFO - 2025-11-17 13:22:06 --> Security Class Initialized
INFO - 2025-11-17 13:22:06 --> Input Class Initialized
INFO - 2025-11-17 13:22:06 --> Language Class Initialized
ERROR - 2025-11-17 13:22:06 --> 404 Page Not Found: Subscription/generate_uuid
INFO - 2025-11-17 13:22:07 --> Config Class Initialized
INFO - 2025-11-17 13:22:07 --> Hooks Class Initialized
INFO - 2025-11-17 13:22:07 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:22:07 --> Utf8 Class Initialized
INFO - 2025-11-17 13:22:07 --> URI Class Initialized
INFO - 2025-11-17 13:22:07 --> Router Class Initialized
INFO - 2025-11-17 13:22:07 --> Output Class Initialized
INFO - 2025-11-17 13:22:07 --> Security Class Initialized
INFO - 2025-11-17 13:22:07 --> Input Class Initialized
INFO - 2025-11-17 13:22:07 --> Language Class Initialized
INFO - 2025-11-17 13:22:07 --> Loader Class Initialized
INFO - 2025-11-17 13:22:07 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:22:07 --> Helper loaded: url_helper
INFO - 2025-11-17 13:22:07 --> Helper loaded: file_helper
INFO - 2025-11-17 13:22:07 --> Helper loaded: main_helper
INFO - 2025-11-17 13:22:07 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:22:07 --> Database Driver Class Initialized
INFO - 2025-11-17 13:22:07 --> Email Class Initialized
DEBUG - 2025-11-17 13:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:22:07 --> Controller Class Initialized
INFO - 2025-11-17 13:22:07 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:22:07 --> Model "User_model" initialized
INFO - 2025-11-17 13:22:07 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:22:07 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:22:07 --> Final output sent to browser
INFO - 2025-11-17 13:22:07 --> Total execution time: 0.0869
INFO - 2025-11-17 13:35:05 --> Config Class Initialized
INFO - 2025-11-17 13:35:05 --> Hooks Class Initialized
INFO - 2025-11-17 13:35:05 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:35:05 --> Utf8 Class Initialized
INFO - 2025-11-17 13:35:05 --> URI Class Initialized
INFO - 2025-11-17 13:35:05 --> Router Class Initialized
INFO - 2025-11-17 13:35:05 --> Output Class Initialized
INFO - 2025-11-17 13:35:05 --> Security Class Initialized
INFO - 2025-11-17 13:35:05 --> Input Class Initialized
INFO - 2025-11-17 13:35:05 --> Language Class Initialized
INFO - 2025-11-17 13:35:05 --> Loader Class Initialized
INFO - 2025-11-17 13:35:05 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:35:05 --> Helper loaded: url_helper
INFO - 2025-11-17 13:35:05 --> Helper loaded: file_helper
INFO - 2025-11-17 13:35:05 --> Helper loaded: main_helper
INFO - 2025-11-17 13:35:05 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:35:05 --> Database Driver Class Initialized
INFO - 2025-11-17 13:35:05 --> Email Class Initialized
DEBUG - 2025-11-17 13:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:35:05 --> Controller Class Initialized
INFO - 2025-11-17 13:35:05 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:35:05 --> Model "User_model" initialized
INFO - 2025-11-17 13:35:05 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:35:05 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:35:05 --> Final output sent to browser
INFO - 2025-11-17 13:35:05 --> Total execution time: 0.0920
INFO - 2025-11-17 13:35:15 --> Config Class Initialized
INFO - 2025-11-17 13:35:15 --> Hooks Class Initialized
INFO - 2025-11-17 13:35:15 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:35:15 --> Utf8 Class Initialized
INFO - 2025-11-17 13:35:15 --> URI Class Initialized
INFO - 2025-11-17 13:35:15 --> Router Class Initialized
INFO - 2025-11-17 13:35:15 --> Output Class Initialized
INFO - 2025-11-17 13:35:15 --> Security Class Initialized
INFO - 2025-11-17 13:35:15 --> Input Class Initialized
INFO - 2025-11-17 13:35:15 --> Language Class Initialized
INFO - 2025-11-17 13:35:15 --> Loader Class Initialized
INFO - 2025-11-17 13:35:15 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:35:15 --> Helper loaded: url_helper
INFO - 2025-11-17 13:35:15 --> Helper loaded: file_helper
INFO - 2025-11-17 13:35:15 --> Helper loaded: main_helper
INFO - 2025-11-17 13:35:15 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:35:15 --> Database Driver Class Initialized
INFO - 2025-11-17 13:35:15 --> Email Class Initialized
DEBUG - 2025-11-17 13:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:35:15 --> Controller Class Initialized
INFO - 2025-11-17 13:35:15 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:35:15 --> Model "User_model" initialized
INFO - 2025-11-17 13:35:15 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:35:15 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:35:15 --> Final output sent to browser
INFO - 2025-11-17 13:35:15 --> Total execution time: 0.0894
INFO - 2025-11-17 13:35:58 --> Config Class Initialized
INFO - 2025-11-17 13:35:58 --> Hooks Class Initialized
INFO - 2025-11-17 13:35:58 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:35:58 --> Utf8 Class Initialized
INFO - 2025-11-17 13:35:58 --> URI Class Initialized
INFO - 2025-11-17 13:35:58 --> Router Class Initialized
INFO - 2025-11-17 13:35:58 --> Output Class Initialized
INFO - 2025-11-17 13:35:58 --> Security Class Initialized
INFO - 2025-11-17 13:35:58 --> Input Class Initialized
INFO - 2025-11-17 13:35:58 --> Language Class Initialized
INFO - 2025-11-17 13:35:58 --> Loader Class Initialized
INFO - 2025-11-17 13:35:58 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:35:58 --> Helper loaded: url_helper
INFO - 2025-11-17 13:35:58 --> Helper loaded: file_helper
INFO - 2025-11-17 13:35:58 --> Helper loaded: main_helper
INFO - 2025-11-17 13:35:58 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:35:58 --> Database Driver Class Initialized
INFO - 2025-11-17 13:35:58 --> Email Class Initialized
DEBUG - 2025-11-17 13:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:35:58 --> Controller Class Initialized
INFO - 2025-11-17 13:35:58 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:35:58 --> Model "User_model" initialized
INFO - 2025-11-17 13:35:58 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:35:58 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:35:58 --> Final output sent to browser
INFO - 2025-11-17 13:35:58 --> Total execution time: 0.0963
INFO - 2025-11-17 13:36:18 --> Config Class Initialized
INFO - 2025-11-17 13:36:18 --> Hooks Class Initialized
INFO - 2025-11-17 13:36:18 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:36:18 --> Utf8 Class Initialized
INFO - 2025-11-17 13:36:18 --> URI Class Initialized
INFO - 2025-11-17 13:36:18 --> Router Class Initialized
INFO - 2025-11-17 13:36:18 --> Output Class Initialized
INFO - 2025-11-17 13:36:18 --> Security Class Initialized
INFO - 2025-11-17 13:36:18 --> Input Class Initialized
INFO - 2025-11-17 13:36:18 --> Language Class Initialized
INFO - 2025-11-17 13:36:18 --> Loader Class Initialized
INFO - 2025-11-17 13:36:18 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:36:18 --> Helper loaded: url_helper
INFO - 2025-11-17 13:36:18 --> Helper loaded: file_helper
INFO - 2025-11-17 13:36:18 --> Helper loaded: main_helper
INFO - 2025-11-17 13:36:18 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:36:18 --> Database Driver Class Initialized
INFO - 2025-11-17 13:36:18 --> Email Class Initialized
DEBUG - 2025-11-17 13:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:36:18 --> Controller Class Initialized
INFO - 2025-11-17 13:36:18 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:36:18 --> Model "User_model" initialized
INFO - 2025-11-17 13:36:18 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:36:18 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:36:18 --> Final output sent to browser
INFO - 2025-11-17 13:36:18 --> Total execution time: 0.0894
INFO - 2025-11-17 13:37:33 --> Config Class Initialized
INFO - 2025-11-17 13:37:33 --> Hooks Class Initialized
INFO - 2025-11-17 13:37:33 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:37:33 --> Utf8 Class Initialized
INFO - 2025-11-17 13:37:33 --> URI Class Initialized
INFO - 2025-11-17 13:37:33 --> Router Class Initialized
INFO - 2025-11-17 13:37:33 --> Output Class Initialized
INFO - 2025-11-17 13:37:33 --> Security Class Initialized
INFO - 2025-11-17 13:37:33 --> Input Class Initialized
INFO - 2025-11-17 13:37:33 --> Language Class Initialized
INFO - 2025-11-17 13:37:33 --> Loader Class Initialized
INFO - 2025-11-17 13:37:33 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:37:33 --> Helper loaded: url_helper
INFO - 2025-11-17 13:37:33 --> Helper loaded: file_helper
INFO - 2025-11-17 13:37:33 --> Helper loaded: main_helper
INFO - 2025-11-17 13:37:33 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:37:34 --> Database Driver Class Initialized
INFO - 2025-11-17 13:37:34 --> Email Class Initialized
DEBUG - 2025-11-17 13:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:37:34 --> Controller Class Initialized
INFO - 2025-11-17 13:37:34 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:37:34 --> Model "User_model" initialized
INFO - 2025-11-17 13:37:34 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:37:34 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:37:34 --> Final output sent to browser
INFO - 2025-11-17 13:37:34 --> Total execution time: 0.0863
INFO - 2025-11-17 13:53:29 --> Config Class Initialized
INFO - 2025-11-17 13:53:29 --> Hooks Class Initialized
INFO - 2025-11-17 13:53:29 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:53:29 --> Utf8 Class Initialized
INFO - 2025-11-17 13:53:29 --> URI Class Initialized
INFO - 2025-11-17 13:53:29 --> Router Class Initialized
INFO - 2025-11-17 13:53:29 --> Output Class Initialized
INFO - 2025-11-17 13:53:29 --> Security Class Initialized
INFO - 2025-11-17 13:53:29 --> Input Class Initialized
INFO - 2025-11-17 13:53:29 --> Language Class Initialized
INFO - 2025-11-17 13:53:29 --> Loader Class Initialized
INFO - 2025-11-17 13:53:29 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:53:29 --> Helper loaded: url_helper
INFO - 2025-11-17 13:53:29 --> Helper loaded: file_helper
INFO - 2025-11-17 13:53:29 --> Helper loaded: main_helper
INFO - 2025-11-17 13:53:29 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:53:29 --> Database Driver Class Initialized
INFO - 2025-11-17 13:53:29 --> Email Class Initialized
DEBUG - 2025-11-17 13:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:53:29 --> Controller Class Initialized
INFO - 2025-11-17 13:53:29 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:53:29 --> Model "User_model" initialized
INFO - 2025-11-17 13:53:29 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:53:29 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:53:29 --> Final output sent to browser
INFO - 2025-11-17 13:53:29 --> Total execution time: 0.1026
INFO - 2025-11-17 13:54:28 --> Config Class Initialized
INFO - 2025-11-17 13:54:28 --> Hooks Class Initialized
INFO - 2025-11-17 13:54:28 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:54:28 --> Utf8 Class Initialized
INFO - 2025-11-17 13:54:28 --> URI Class Initialized
INFO - 2025-11-17 13:54:28 --> Router Class Initialized
INFO - 2025-11-17 13:54:28 --> Output Class Initialized
INFO - 2025-11-17 13:54:28 --> Security Class Initialized
INFO - 2025-11-17 13:54:28 --> Input Class Initialized
INFO - 2025-11-17 13:54:28 --> Language Class Initialized
INFO - 2025-11-17 13:54:28 --> Loader Class Initialized
INFO - 2025-11-17 13:54:28 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:54:28 --> Helper loaded: url_helper
INFO - 2025-11-17 13:54:28 --> Helper loaded: file_helper
INFO - 2025-11-17 13:54:28 --> Helper loaded: main_helper
INFO - 2025-11-17 13:54:28 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:54:28 --> Database Driver Class Initialized
INFO - 2025-11-17 13:54:28 --> Email Class Initialized
DEBUG - 2025-11-17 13:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:54:28 --> Controller Class Initialized
INFO - 2025-11-17 13:54:28 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:54:28 --> Model "User_model" initialized
INFO - 2025-11-17 13:54:28 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:54:28 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:54:28 --> Final output sent to browser
INFO - 2025-11-17 13:54:28 --> Total execution time: 0.1021
INFO - 2025-11-17 13:54:39 --> Config Class Initialized
INFO - 2025-11-17 13:54:39 --> Hooks Class Initialized
INFO - 2025-11-17 13:54:39 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:54:39 --> Utf8 Class Initialized
INFO - 2025-11-17 13:54:39 --> URI Class Initialized
INFO - 2025-11-17 13:54:39 --> Router Class Initialized
INFO - 2025-11-17 13:54:39 --> Output Class Initialized
INFO - 2025-11-17 13:54:39 --> Security Class Initialized
INFO - 2025-11-17 13:54:39 --> Input Class Initialized
INFO - 2025-11-17 13:54:39 --> Language Class Initialized
INFO - 2025-11-17 13:54:39 --> Loader Class Initialized
INFO - 2025-11-17 13:54:39 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:54:39 --> Helper loaded: url_helper
INFO - 2025-11-17 13:54:39 --> Helper loaded: file_helper
INFO - 2025-11-17 13:54:39 --> Helper loaded: main_helper
INFO - 2025-11-17 13:54:39 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:54:39 --> Database Driver Class Initialized
INFO - 2025-11-17 13:54:39 --> Email Class Initialized
DEBUG - 2025-11-17 13:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:54:39 --> Controller Class Initialized
INFO - 2025-11-17 13:54:39 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:54:39 --> Model "User_model" initialized
INFO - 2025-11-17 13:54:39 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:54:39 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:54:39 --> Final output sent to browser
INFO - 2025-11-17 13:54:39 --> Total execution time: 0.1089
INFO - 2025-11-17 13:54:42 --> Config Class Initialized
INFO - 2025-11-17 13:54:42 --> Hooks Class Initialized
INFO - 2025-11-17 13:54:42 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:54:42 --> Utf8 Class Initialized
INFO - 2025-11-17 13:54:42 --> URI Class Initialized
INFO - 2025-11-17 13:54:42 --> Router Class Initialized
INFO - 2025-11-17 13:54:42 --> Output Class Initialized
INFO - 2025-11-17 13:54:42 --> Security Class Initialized
INFO - 2025-11-17 13:54:42 --> Input Class Initialized
INFO - 2025-11-17 13:54:42 --> Language Class Initialized
INFO - 2025-11-17 13:54:42 --> Loader Class Initialized
INFO - 2025-11-17 13:54:42 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:54:42 --> Helper loaded: url_helper
INFO - 2025-11-17 13:54:42 --> Helper loaded: file_helper
INFO - 2025-11-17 13:54:42 --> Helper loaded: main_helper
INFO - 2025-11-17 13:54:42 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:54:42 --> Database Driver Class Initialized
INFO - 2025-11-17 13:54:42 --> Email Class Initialized
DEBUG - 2025-11-17 13:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:54:42 --> Controller Class Initialized
INFO - 2025-11-17 13:54:42 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:54:42 --> Model "User_model" initialized
INFO - 2025-11-17 13:54:42 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:54:42 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:54:42 --> Final output sent to browser
INFO - 2025-11-17 13:54:42 --> Total execution time: 0.1002
INFO - 2025-11-17 13:55:21 --> Config Class Initialized
INFO - 2025-11-17 13:55:21 --> Hooks Class Initialized
INFO - 2025-11-17 13:55:21 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:55:21 --> Utf8 Class Initialized
INFO - 2025-11-17 13:55:21 --> URI Class Initialized
INFO - 2025-11-17 13:55:21 --> Router Class Initialized
INFO - 2025-11-17 13:55:21 --> Output Class Initialized
INFO - 2025-11-17 13:55:21 --> Security Class Initialized
INFO - 2025-11-17 13:55:21 --> Input Class Initialized
INFO - 2025-11-17 13:55:21 --> Language Class Initialized
INFO - 2025-11-17 13:55:21 --> Loader Class Initialized
INFO - 2025-11-17 13:55:21 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:55:21 --> Helper loaded: url_helper
INFO - 2025-11-17 13:55:21 --> Helper loaded: file_helper
INFO - 2025-11-17 13:55:21 --> Helper loaded: main_helper
INFO - 2025-11-17 13:55:21 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:55:21 --> Database Driver Class Initialized
INFO - 2025-11-17 13:55:21 --> Email Class Initialized
DEBUG - 2025-11-17 13:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:55:21 --> Controller Class Initialized
INFO - 2025-11-17 13:55:21 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:55:21 --> Model "User_model" initialized
INFO - 2025-11-17 13:55:21 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:55:21 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:55:21 --> Final output sent to browser
INFO - 2025-11-17 13:55:21 --> Total execution time: 0.0977
INFO - 2025-11-17 13:55:23 --> Config Class Initialized
INFO - 2025-11-17 13:55:23 --> Hooks Class Initialized
INFO - 2025-11-17 13:55:23 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:55:23 --> Utf8 Class Initialized
INFO - 2025-11-17 13:55:23 --> URI Class Initialized
INFO - 2025-11-17 13:55:23 --> Router Class Initialized
INFO - 2025-11-17 13:55:23 --> Output Class Initialized
INFO - 2025-11-17 13:55:23 --> Security Class Initialized
INFO - 2025-11-17 13:55:23 --> Input Class Initialized
INFO - 2025-11-17 13:55:23 --> Language Class Initialized
INFO - 2025-11-17 13:55:23 --> Loader Class Initialized
INFO - 2025-11-17 13:55:23 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:55:23 --> Helper loaded: url_helper
INFO - 2025-11-17 13:55:23 --> Helper loaded: file_helper
INFO - 2025-11-17 13:55:23 --> Helper loaded: main_helper
INFO - 2025-11-17 13:55:23 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:55:23 --> Database Driver Class Initialized
INFO - 2025-11-17 13:55:23 --> Email Class Initialized
DEBUG - 2025-11-17 13:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:55:23 --> Controller Class Initialized
INFO - 2025-11-17 13:55:23 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:55:23 --> Model "User_model" initialized
INFO - 2025-11-17 13:55:23 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:55:23 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:55:23 --> Final output sent to browser
INFO - 2025-11-17 13:55:23 --> Total execution time: 0.1046
INFO - 2025-11-17 13:56:02 --> Config Class Initialized
INFO - 2025-11-17 13:56:02 --> Hooks Class Initialized
INFO - 2025-11-17 13:56:02 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:56:02 --> Utf8 Class Initialized
INFO - 2025-11-17 13:56:02 --> URI Class Initialized
INFO - 2025-11-17 13:56:02 --> Router Class Initialized
INFO - 2025-11-17 13:56:02 --> Output Class Initialized
INFO - 2025-11-17 13:56:02 --> Security Class Initialized
INFO - 2025-11-17 13:56:02 --> Input Class Initialized
INFO - 2025-11-17 13:56:02 --> Language Class Initialized
INFO - 2025-11-17 13:56:02 --> Loader Class Initialized
INFO - 2025-11-17 13:56:02 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:56:02 --> Helper loaded: url_helper
INFO - 2025-11-17 13:56:02 --> Helper loaded: file_helper
INFO - 2025-11-17 13:56:02 --> Helper loaded: main_helper
INFO - 2025-11-17 13:56:02 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:56:02 --> Database Driver Class Initialized
INFO - 2025-11-17 13:56:02 --> Email Class Initialized
DEBUG - 2025-11-17 13:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:56:02 --> Controller Class Initialized
INFO - 2025-11-17 13:56:02 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:56:02 --> Model "User_model" initialized
INFO - 2025-11-17 13:56:02 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:56:02 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:56:02 --> Final output sent to browser
INFO - 2025-11-17 13:56:02 --> Total execution time: 0.0952
INFO - 2025-11-17 13:56:46 --> Config Class Initialized
INFO - 2025-11-17 13:56:46 --> Hooks Class Initialized
INFO - 2025-11-17 13:56:46 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:56:46 --> Utf8 Class Initialized
INFO - 2025-11-17 13:56:46 --> URI Class Initialized
INFO - 2025-11-17 13:56:46 --> Router Class Initialized
INFO - 2025-11-17 13:56:46 --> Output Class Initialized
INFO - 2025-11-17 13:56:46 --> Security Class Initialized
INFO - 2025-11-17 13:56:46 --> Input Class Initialized
INFO - 2025-11-17 13:56:46 --> Language Class Initialized
INFO - 2025-11-17 13:56:46 --> Loader Class Initialized
INFO - 2025-11-17 13:56:46 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:56:46 --> Helper loaded: url_helper
INFO - 2025-11-17 13:56:46 --> Helper loaded: file_helper
INFO - 2025-11-17 13:56:46 --> Helper loaded: main_helper
INFO - 2025-11-17 13:56:46 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:56:46 --> Database Driver Class Initialized
INFO - 2025-11-17 13:56:46 --> Email Class Initialized
DEBUG - 2025-11-17 13:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:56:46 --> Controller Class Initialized
INFO - 2025-11-17 13:56:46 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:56:46 --> Model "User_model" initialized
INFO - 2025-11-17 13:56:46 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:56:46 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:56:46 --> Final output sent to browser
INFO - 2025-11-17 13:56:46 --> Total execution time: 0.1121
INFO - 2025-11-17 13:57:22 --> Config Class Initialized
INFO - 2025-11-17 13:57:22 --> Hooks Class Initialized
INFO - 2025-11-17 13:57:22 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:57:22 --> Utf8 Class Initialized
INFO - 2025-11-17 13:57:22 --> URI Class Initialized
INFO - 2025-11-17 13:57:22 --> Router Class Initialized
INFO - 2025-11-17 13:57:22 --> Output Class Initialized
INFO - 2025-11-17 13:57:22 --> Security Class Initialized
INFO - 2025-11-17 13:57:22 --> Input Class Initialized
INFO - 2025-11-17 13:57:22 --> Language Class Initialized
INFO - 2025-11-17 13:57:22 --> Loader Class Initialized
INFO - 2025-11-17 13:57:22 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:57:22 --> Helper loaded: url_helper
INFO - 2025-11-17 13:57:22 --> Helper loaded: file_helper
INFO - 2025-11-17 13:57:22 --> Helper loaded: main_helper
INFO - 2025-11-17 13:57:22 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:57:22 --> Database Driver Class Initialized
INFO - 2025-11-17 13:57:22 --> Email Class Initialized
DEBUG - 2025-11-17 13:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:57:22 --> Controller Class Initialized
INFO - 2025-11-17 13:57:22 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:57:22 --> Model "User_model" initialized
INFO - 2025-11-17 13:57:22 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:57:22 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:57:22 --> Final output sent to browser
INFO - 2025-11-17 13:57:22 --> Total execution time: 0.1210
INFO - 2025-11-17 13:57:38 --> Config Class Initialized
INFO - 2025-11-17 13:57:38 --> Hooks Class Initialized
INFO - 2025-11-17 13:57:38 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:57:38 --> Utf8 Class Initialized
INFO - 2025-11-17 13:57:38 --> URI Class Initialized
INFO - 2025-11-17 13:57:38 --> Router Class Initialized
INFO - 2025-11-17 13:57:38 --> Output Class Initialized
INFO - 2025-11-17 13:57:38 --> Security Class Initialized
INFO - 2025-11-17 13:57:38 --> Input Class Initialized
INFO - 2025-11-17 13:57:38 --> Language Class Initialized
INFO - 2025-11-17 13:57:38 --> Loader Class Initialized
INFO - 2025-11-17 13:57:38 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:57:38 --> Helper loaded: url_helper
INFO - 2025-11-17 13:57:38 --> Helper loaded: file_helper
INFO - 2025-11-17 13:57:38 --> Helper loaded: main_helper
INFO - 2025-11-17 13:57:39 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:57:39 --> Database Driver Class Initialized
INFO - 2025-11-17 13:57:39 --> Email Class Initialized
DEBUG - 2025-11-17 13:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:57:39 --> Controller Class Initialized
INFO - 2025-11-17 13:57:39 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:57:39 --> Model "User_model" initialized
INFO - 2025-11-17 13:57:39 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:57:39 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:57:39 --> Final output sent to browser
INFO - 2025-11-17 13:57:39 --> Total execution time: 0.1044
INFO - 2025-11-17 13:58:04 --> Config Class Initialized
INFO - 2025-11-17 13:58:04 --> Hooks Class Initialized
INFO - 2025-11-17 13:58:04 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:58:04 --> Utf8 Class Initialized
INFO - 2025-11-17 13:58:04 --> URI Class Initialized
INFO - 2025-11-17 13:58:04 --> Router Class Initialized
INFO - 2025-11-17 13:58:04 --> Output Class Initialized
INFO - 2025-11-17 13:58:04 --> Security Class Initialized
INFO - 2025-11-17 13:58:04 --> Input Class Initialized
INFO - 2025-11-17 13:58:04 --> Language Class Initialized
INFO - 2025-11-17 13:58:04 --> Loader Class Initialized
INFO - 2025-11-17 13:58:04 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:58:04 --> Helper loaded: url_helper
INFO - 2025-11-17 13:58:04 --> Helper loaded: file_helper
INFO - 2025-11-17 13:58:04 --> Helper loaded: main_helper
INFO - 2025-11-17 13:58:04 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:58:04 --> Database Driver Class Initialized
INFO - 2025-11-17 13:58:04 --> Email Class Initialized
DEBUG - 2025-11-17 13:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:58:04 --> Controller Class Initialized
INFO - 2025-11-17 13:58:04 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:58:04 --> Model "User_model" initialized
INFO - 2025-11-17 13:58:04 --> Model "Auth_model" initialized
ERROR - 2025-11-17 13:58:04 --> Severity: Warning --> Undefined property: stdClass::$payment_proof_size D:\laragon\www\acumena\application\views\subscriptions\invoice.php 297
INFO - 2025-11-17 13:58:04 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:58:04 --> Final output sent to browser
INFO - 2025-11-17 13:58:04 --> Total execution time: 0.1143
INFO - 2025-11-17 13:58:15 --> Config Class Initialized
INFO - 2025-11-17 13:58:15 --> Hooks Class Initialized
INFO - 2025-11-17 13:58:15 --> UTF-8 Support Enabled
INFO - 2025-11-17 13:58:15 --> Utf8 Class Initialized
INFO - 2025-11-17 13:58:15 --> URI Class Initialized
INFO - 2025-11-17 13:58:15 --> Router Class Initialized
INFO - 2025-11-17 13:58:15 --> Output Class Initialized
INFO - 2025-11-17 13:58:15 --> Security Class Initialized
INFO - 2025-11-17 13:58:15 --> Input Class Initialized
INFO - 2025-11-17 13:58:15 --> Language Class Initialized
INFO - 2025-11-17 13:58:15 --> Loader Class Initialized
INFO - 2025-11-17 13:58:15 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 13:58:15 --> Helper loaded: url_helper
INFO - 2025-11-17 13:58:15 --> Helper loaded: file_helper
INFO - 2025-11-17 13:58:15 --> Helper loaded: main_helper
INFO - 2025-11-17 13:58:15 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 13:58:15 --> Database Driver Class Initialized
INFO - 2025-11-17 13:58:15 --> Email Class Initialized
DEBUG - 2025-11-17 13:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 13:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 13:58:15 --> Controller Class Initialized
INFO - 2025-11-17 13:58:15 --> Model "Subscription_model" initialized
INFO - 2025-11-17 13:58:15 --> Model "User_model" initialized
INFO - 2025-11-17 13:58:15 --> Model "Auth_model" initialized
INFO - 2025-11-17 13:58:15 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 13:58:15 --> Final output sent to browser
INFO - 2025-11-17 13:58:15 --> Total execution time: 0.1173
INFO - 2025-11-17 22:22:50 --> Config Class Initialized
INFO - 2025-11-17 22:22:50 --> Hooks Class Initialized
INFO - 2025-11-17 22:22:50 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:22:50 --> Utf8 Class Initialized
INFO - 2025-11-17 22:22:50 --> URI Class Initialized
INFO - 2025-11-17 22:22:50 --> Router Class Initialized
INFO - 2025-11-17 22:22:50 --> Output Class Initialized
INFO - 2025-11-17 22:22:50 --> Security Class Initialized
INFO - 2025-11-17 22:22:50 --> Input Class Initialized
INFO - 2025-11-17 22:22:50 --> Language Class Initialized
INFO - 2025-11-17 22:22:50 --> Loader Class Initialized
INFO - 2025-11-17 22:22:50 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:22:50 --> Helper loaded: url_helper
INFO - 2025-11-17 22:22:50 --> Helper loaded: file_helper
INFO - 2025-11-17 22:22:50 --> Helper loaded: main_helper
INFO - 2025-11-17 22:22:50 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:22:50 --> Database Driver Class Initialized
INFO - 2025-11-17 22:22:50 --> Email Class Initialized
DEBUG - 2025-11-17 22:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:22:50 --> Controller Class Initialized
INFO - 2025-11-17 22:22:50 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:22:50 --> Model "User_model" initialized
INFO - 2025-11-17 22:22:50 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:22:50 --> Config Class Initialized
INFO - 2025-11-17 22:22:50 --> Hooks Class Initialized
INFO - 2025-11-17 22:22:50 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:22:50 --> Utf8 Class Initialized
INFO - 2025-11-17 22:22:50 --> URI Class Initialized
INFO - 2025-11-17 22:22:50 --> Router Class Initialized
INFO - 2025-11-17 22:22:50 --> Output Class Initialized
INFO - 2025-11-17 22:22:50 --> Security Class Initialized
INFO - 2025-11-17 22:22:50 --> Input Class Initialized
INFO - 2025-11-17 22:22:50 --> Language Class Initialized
INFO - 2025-11-17 22:22:50 --> Loader Class Initialized
INFO - 2025-11-17 22:22:50 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:22:50 --> Helper loaded: url_helper
INFO - 2025-11-17 22:22:50 --> Helper loaded: file_helper
INFO - 2025-11-17 22:22:50 --> Helper loaded: main_helper
INFO - 2025-11-17 22:22:50 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:22:50 --> Database Driver Class Initialized
INFO - 2025-11-17 22:22:50 --> Email Class Initialized
DEBUG - 2025-11-17 22:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:22:50 --> Controller Class Initialized
INFO - 2025-11-17 22:22:50 --> Config Class Initialized
INFO - 2025-11-17 22:22:50 --> Hooks Class Initialized
INFO - 2025-11-17 22:22:50 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:22:50 --> Utf8 Class Initialized
INFO - 2025-11-17 22:22:50 --> URI Class Initialized
INFO - 2025-11-17 22:22:50 --> Router Class Initialized
INFO - 2025-11-17 22:22:50 --> Output Class Initialized
INFO - 2025-11-17 22:22:50 --> Security Class Initialized
INFO - 2025-11-17 22:22:50 --> Input Class Initialized
INFO - 2025-11-17 22:22:50 --> Language Class Initialized
INFO - 2025-11-17 22:22:50 --> Loader Class Initialized
INFO - 2025-11-17 22:22:50 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:22:50 --> Helper loaded: url_helper
INFO - 2025-11-17 22:22:50 --> Helper loaded: file_helper
INFO - 2025-11-17 22:22:50 --> Helper loaded: main_helper
INFO - 2025-11-17 22:22:50 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:22:50 --> Database Driver Class Initialized
INFO - 2025-11-17 22:22:50 --> Email Class Initialized
DEBUG - 2025-11-17 22:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:22:50 --> Controller Class Initialized
INFO - 2025-11-17 22:22:50 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:22:50 --> Model "User_model" initialized
INFO - 2025-11-17 22:22:50 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:22:50 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-17 22:22:50 --> Final output sent to browser
INFO - 2025-11-17 22:22:50 --> Total execution time: 0.0625
INFO - 2025-11-17 22:22:53 --> Config Class Initialized
INFO - 2025-11-17 22:22:53 --> Hooks Class Initialized
INFO - 2025-11-17 22:22:53 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:22:53 --> Utf8 Class Initialized
INFO - 2025-11-17 22:22:53 --> URI Class Initialized
INFO - 2025-11-17 22:22:54 --> Router Class Initialized
INFO - 2025-11-17 22:22:54 --> Output Class Initialized
INFO - 2025-11-17 22:22:54 --> Security Class Initialized
INFO - 2025-11-17 22:22:54 --> Input Class Initialized
INFO - 2025-11-17 22:22:54 --> Language Class Initialized
INFO - 2025-11-17 22:22:54 --> Loader Class Initialized
INFO - 2025-11-17 22:22:54 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:22:54 --> Helper loaded: url_helper
INFO - 2025-11-17 22:22:54 --> Helper loaded: file_helper
INFO - 2025-11-17 22:22:54 --> Helper loaded: main_helper
INFO - 2025-11-17 22:22:54 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:22:54 --> Database Driver Class Initialized
INFO - 2025-11-17 22:22:54 --> Email Class Initialized
DEBUG - 2025-11-17 22:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:22:54 --> Controller Class Initialized
INFO - 2025-11-17 22:22:54 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:22:54 --> Model "User_model" initialized
INFO - 2025-11-17 22:22:54 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:22:54 --> Final output sent to browser
INFO - 2025-11-17 22:22:54 --> Total execution time: 0.2621
INFO - 2025-11-17 22:22:55 --> Config Class Initialized
INFO - 2025-11-17 22:22:55 --> Hooks Class Initialized
INFO - 2025-11-17 22:22:55 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:22:55 --> Utf8 Class Initialized
INFO - 2025-11-17 22:22:55 --> URI Class Initialized
INFO - 2025-11-17 22:22:55 --> Router Class Initialized
INFO - 2025-11-17 22:22:55 --> Output Class Initialized
INFO - 2025-11-17 22:22:55 --> Security Class Initialized
INFO - 2025-11-17 22:22:55 --> Input Class Initialized
INFO - 2025-11-17 22:22:55 --> Language Class Initialized
INFO - 2025-11-17 22:22:55 --> Loader Class Initialized
INFO - 2025-11-17 22:22:55 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:22:55 --> Helper loaded: url_helper
INFO - 2025-11-17 22:22:55 --> Helper loaded: file_helper
INFO - 2025-11-17 22:22:55 --> Helper loaded: main_helper
INFO - 2025-11-17 22:22:55 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:22:55 --> Database Driver Class Initialized
INFO - 2025-11-17 22:22:55 --> Email Class Initialized
DEBUG - 2025-11-17 22:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:22:55 --> Controller Class Initialized
INFO - 2025-11-17 22:22:55 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:22:55 --> Model "User_model" initialized
INFO - 2025-11-17 22:22:55 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:22:55 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:22:55 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:22:55 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:22:55 --> File loaded: D:\laragon\www\acumena\application\views\dashboard.php
INFO - 2025-11-17 22:22:55 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:22:55 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:22:55 --> Final output sent to browser
INFO - 2025-11-17 22:22:55 --> Total execution time: 0.0863
INFO - 2025-11-17 22:22:55 --> Config Class Initialized
INFO - 2025-11-17 22:22:55 --> Hooks Class Initialized
INFO - 2025-11-17 22:22:55 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:22:55 --> Utf8 Class Initialized
INFO - 2025-11-17 22:22:55 --> URI Class Initialized
INFO - 2025-11-17 22:22:55 --> Router Class Initialized
INFO - 2025-11-17 22:22:55 --> Output Class Initialized
INFO - 2025-11-17 22:22:55 --> Security Class Initialized
INFO - 2025-11-17 22:22:55 --> Input Class Initialized
INFO - 2025-11-17 22:22:55 --> Language Class Initialized
INFO - 2025-11-17 22:22:55 --> Loader Class Initialized
INFO - 2025-11-17 22:22:55 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:22:55 --> Helper loaded: url_helper
INFO - 2025-11-17 22:22:55 --> Helper loaded: file_helper
INFO - 2025-11-17 22:22:55 --> Helper loaded: main_helper
INFO - 2025-11-17 22:22:55 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:22:55 --> Database Driver Class Initialized
INFO - 2025-11-17 22:22:55 --> Email Class Initialized
DEBUG - 2025-11-17 22:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:22:55 --> Controller Class Initialized
INFO - 2025-11-17 22:22:56 --> Model "User_model" initialized
INFO - 2025-11-17 22:22:56 --> Model "Project_model" initialized
INFO - 2025-11-17 22:22:56 --> Helper loaded: form_helper
INFO - 2025-11-17 22:22:56 --> Form Validation Class Initialized
INFO - 2025-11-17 22:22:56 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 22:22:56 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 22:22:56 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 22:22:56 --> Model "Swot_model" initialized
INFO - 2025-11-17 22:22:56 --> Model "Swot_model" initialized
INFO - 2025-11-17 22:22:56 --> Model "Topk_service_model" initialized
INFO - 2025-11-17 22:22:56 --> Final output sent to browser
INFO - 2025-11-17 22:22:56 --> Total execution time: 0.0837
INFO - 2025-11-17 22:22:58 --> Config Class Initialized
INFO - 2025-11-17 22:22:58 --> Hooks Class Initialized
INFO - 2025-11-17 22:22:58 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:22:58 --> Utf8 Class Initialized
INFO - 2025-11-17 22:22:58 --> URI Class Initialized
INFO - 2025-11-17 22:22:58 --> Router Class Initialized
INFO - 2025-11-17 22:22:58 --> Output Class Initialized
INFO - 2025-11-17 22:22:58 --> Security Class Initialized
INFO - 2025-11-17 22:22:58 --> Input Class Initialized
INFO - 2025-11-17 22:22:58 --> Language Class Initialized
INFO - 2025-11-17 22:22:58 --> Loader Class Initialized
INFO - 2025-11-17 22:22:58 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:22:58 --> Helper loaded: url_helper
INFO - 2025-11-17 22:22:58 --> Helper loaded: file_helper
INFO - 2025-11-17 22:22:58 --> Helper loaded: main_helper
INFO - 2025-11-17 22:22:58 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:22:58 --> Database Driver Class Initialized
INFO - 2025-11-17 22:22:58 --> Email Class Initialized
DEBUG - 2025-11-17 22:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:22:58 --> Controller Class Initialized
INFO - 2025-11-17 22:22:58 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:22:58 --> Model "User_model" initialized
INFO - 2025-11-17 22:22:58 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:22:58 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:22:58 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:22:58 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:22:58 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 22:22:58 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:22:58 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:22:58 --> Final output sent to browser
INFO - 2025-11-17 22:22:58 --> Total execution time: 0.0792
INFO - 2025-11-17 22:22:59 --> Config Class Initialized
INFO - 2025-11-17 22:22:59 --> Hooks Class Initialized
INFO - 2025-11-17 22:22:59 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:22:59 --> Utf8 Class Initialized
INFO - 2025-11-17 22:22:59 --> URI Class Initialized
INFO - 2025-11-17 22:22:59 --> Router Class Initialized
INFO - 2025-11-17 22:22:59 --> Output Class Initialized
INFO - 2025-11-17 22:22:59 --> Security Class Initialized
INFO - 2025-11-17 22:22:59 --> Input Class Initialized
INFO - 2025-11-17 22:22:59 --> Language Class Initialized
INFO - 2025-11-17 22:22:59 --> Loader Class Initialized
INFO - 2025-11-17 22:22:59 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:22:59 --> Helper loaded: url_helper
INFO - 2025-11-17 22:22:59 --> Helper loaded: file_helper
INFO - 2025-11-17 22:22:59 --> Helper loaded: main_helper
INFO - 2025-11-17 22:22:59 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:22:59 --> Database Driver Class Initialized
INFO - 2025-11-17 22:22:59 --> Email Class Initialized
DEBUG - 2025-11-17 22:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:22:59 --> Controller Class Initialized
INFO - 2025-11-17 22:22:59 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:22:59 --> Model "User_model" initialized
INFO - 2025-11-17 22:22:59 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:22:59 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 22:22:59 --> Final output sent to browser
INFO - 2025-11-17 22:22:59 --> Total execution time: 0.0666
INFO - 2025-11-17 22:23:25 --> Config Class Initialized
INFO - 2025-11-17 22:23:25 --> Hooks Class Initialized
INFO - 2025-11-17 22:23:25 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:23:25 --> Utf8 Class Initialized
INFO - 2025-11-17 22:23:25 --> URI Class Initialized
INFO - 2025-11-17 22:23:25 --> Router Class Initialized
INFO - 2025-11-17 22:23:25 --> Output Class Initialized
INFO - 2025-11-17 22:23:25 --> Security Class Initialized
INFO - 2025-11-17 22:23:25 --> Input Class Initialized
INFO - 2025-11-17 22:23:25 --> Language Class Initialized
INFO - 2025-11-17 22:23:25 --> Loader Class Initialized
INFO - 2025-11-17 22:23:25 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:23:25 --> Helper loaded: url_helper
INFO - 2025-11-17 22:23:25 --> Helper loaded: file_helper
INFO - 2025-11-17 22:23:25 --> Helper loaded: main_helper
INFO - 2025-11-17 22:23:25 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:23:25 --> Database Driver Class Initialized
INFO - 2025-11-17 22:23:25 --> Email Class Initialized
DEBUG - 2025-11-17 22:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:23:25 --> Controller Class Initialized
INFO - 2025-11-17 22:23:25 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:23:25 --> Model "User_model" initialized
INFO - 2025-11-17 22:23:25 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:23:25 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:23:25 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:23:25 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:23:25 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 22:23:25 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:23:25 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:23:25 --> Final output sent to browser
INFO - 2025-11-17 22:23:25 --> Total execution time: 0.0891
INFO - 2025-11-17 22:23:28 --> Config Class Initialized
INFO - 2025-11-17 22:23:28 --> Hooks Class Initialized
INFO - 2025-11-17 22:23:28 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:23:28 --> Utf8 Class Initialized
INFO - 2025-11-17 22:23:28 --> URI Class Initialized
INFO - 2025-11-17 22:23:28 --> Router Class Initialized
INFO - 2025-11-17 22:23:28 --> Output Class Initialized
INFO - 2025-11-17 22:23:28 --> Security Class Initialized
INFO - 2025-11-17 22:23:28 --> Input Class Initialized
INFO - 2025-11-17 22:23:28 --> Language Class Initialized
INFO - 2025-11-17 22:23:28 --> Loader Class Initialized
INFO - 2025-11-17 22:23:28 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:23:28 --> Helper loaded: url_helper
INFO - 2025-11-17 22:23:28 --> Helper loaded: file_helper
INFO - 2025-11-17 22:23:28 --> Helper loaded: main_helper
INFO - 2025-11-17 22:23:28 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:23:28 --> Database Driver Class Initialized
INFO - 2025-11-17 22:23:28 --> Email Class Initialized
DEBUG - 2025-11-17 22:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:23:28 --> Controller Class Initialized
INFO - 2025-11-17 22:23:28 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:23:28 --> Model "User_model" initialized
INFO - 2025-11-17 22:23:28 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:23:28 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 22:23:28 --> Final output sent to browser
INFO - 2025-11-17 22:23:28 --> Total execution time: 0.0885
INFO - 2025-11-17 22:26:42 --> Config Class Initialized
INFO - 2025-11-17 22:26:42 --> Hooks Class Initialized
INFO - 2025-11-17 22:26:42 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:26:42 --> Utf8 Class Initialized
INFO - 2025-11-17 22:26:42 --> URI Class Initialized
INFO - 2025-11-17 22:26:42 --> Router Class Initialized
INFO - 2025-11-17 22:26:42 --> Output Class Initialized
INFO - 2025-11-17 22:26:42 --> Security Class Initialized
INFO - 2025-11-17 22:26:42 --> Input Class Initialized
INFO - 2025-11-17 22:26:42 --> Language Class Initialized
INFO - 2025-11-17 22:26:42 --> Loader Class Initialized
INFO - 2025-11-17 22:26:42 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:26:42 --> Helper loaded: url_helper
INFO - 2025-11-17 22:26:42 --> Helper loaded: file_helper
INFO - 2025-11-17 22:26:42 --> Helper loaded: main_helper
INFO - 2025-11-17 22:26:42 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:26:42 --> Database Driver Class Initialized
INFO - 2025-11-17 22:26:42 --> Email Class Initialized
DEBUG - 2025-11-17 22:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:26:42 --> Controller Class Initialized
INFO - 2025-11-17 22:26:42 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:26:42 --> Model "User_model" initialized
INFO - 2025-11-17 22:26:42 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:26:42 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 22:26:42 --> Final output sent to browser
INFO - 2025-11-17 22:26:42 --> Total execution time: 0.0724
INFO - 2025-11-17 22:27:11 --> Config Class Initialized
INFO - 2025-11-17 22:27:11 --> Hooks Class Initialized
INFO - 2025-11-17 22:27:11 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:27:11 --> Utf8 Class Initialized
INFO - 2025-11-17 22:27:11 --> URI Class Initialized
INFO - 2025-11-17 22:27:11 --> Router Class Initialized
INFO - 2025-11-17 22:27:11 --> Output Class Initialized
INFO - 2025-11-17 22:27:11 --> Security Class Initialized
INFO - 2025-11-17 22:27:11 --> Input Class Initialized
INFO - 2025-11-17 22:27:11 --> Language Class Initialized
INFO - 2025-11-17 22:27:11 --> Loader Class Initialized
INFO - 2025-11-17 22:27:11 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:27:11 --> Helper loaded: url_helper
INFO - 2025-11-17 22:27:11 --> Helper loaded: file_helper
INFO - 2025-11-17 22:27:11 --> Helper loaded: main_helper
INFO - 2025-11-17 22:27:11 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:27:11 --> Database Driver Class Initialized
INFO - 2025-11-17 22:27:11 --> Email Class Initialized
DEBUG - 2025-11-17 22:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:27:11 --> Controller Class Initialized
INFO - 2025-11-17 22:27:11 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:27:11 --> Model "User_model" initialized
INFO - 2025-11-17 22:27:11 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:27:11 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 22:27:11 --> Final output sent to browser
INFO - 2025-11-17 22:27:11 --> Total execution time: 0.0862
INFO - 2025-11-17 22:28:13 --> Config Class Initialized
INFO - 2025-11-17 22:28:13 --> Hooks Class Initialized
INFO - 2025-11-17 22:28:13 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:28:13 --> Utf8 Class Initialized
INFO - 2025-11-17 22:28:13 --> URI Class Initialized
INFO - 2025-11-17 22:28:13 --> Router Class Initialized
INFO - 2025-11-17 22:28:13 --> Output Class Initialized
INFO - 2025-11-17 22:28:13 --> Security Class Initialized
INFO - 2025-11-17 22:28:13 --> Input Class Initialized
INFO - 2025-11-17 22:28:13 --> Language Class Initialized
INFO - 2025-11-17 22:28:13 --> Loader Class Initialized
INFO - 2025-11-17 22:28:13 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:28:13 --> Helper loaded: url_helper
INFO - 2025-11-17 22:28:13 --> Helper loaded: file_helper
INFO - 2025-11-17 22:28:13 --> Helper loaded: main_helper
INFO - 2025-11-17 22:28:13 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:28:13 --> Database Driver Class Initialized
INFO - 2025-11-17 22:28:13 --> Email Class Initialized
DEBUG - 2025-11-17 22:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:28:13 --> Controller Class Initialized
INFO - 2025-11-17 22:28:13 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:28:13 --> Model "User_model" initialized
INFO - 2025-11-17 22:28:13 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:28:13 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 22:28:13 --> Final output sent to browser
INFO - 2025-11-17 22:28:13 --> Total execution time: 0.0921
INFO - 2025-11-17 22:30:43 --> Config Class Initialized
INFO - 2025-11-17 22:30:43 --> Hooks Class Initialized
INFO - 2025-11-17 22:30:43 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:30:43 --> Utf8 Class Initialized
INFO - 2025-11-17 22:30:43 --> URI Class Initialized
INFO - 2025-11-17 22:30:43 --> Router Class Initialized
INFO - 2025-11-17 22:30:43 --> Output Class Initialized
INFO - 2025-11-17 22:30:43 --> Security Class Initialized
INFO - 2025-11-17 22:30:43 --> Input Class Initialized
INFO - 2025-11-17 22:30:43 --> Language Class Initialized
INFO - 2025-11-17 22:30:43 --> Loader Class Initialized
INFO - 2025-11-17 22:30:43 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:30:43 --> Helper loaded: url_helper
INFO - 2025-11-17 22:30:43 --> Helper loaded: file_helper
INFO - 2025-11-17 22:30:43 --> Helper loaded: main_helper
INFO - 2025-11-17 22:30:43 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:30:43 --> Database Driver Class Initialized
INFO - 2025-11-17 22:30:43 --> Email Class Initialized
DEBUG - 2025-11-17 22:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:30:43 --> Controller Class Initialized
INFO - 2025-11-17 22:30:43 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:30:43 --> Model "User_model" initialized
INFO - 2025-11-17 22:30:43 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:30:43 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 22:30:43 --> Final output sent to browser
INFO - 2025-11-17 22:30:43 --> Total execution time: 0.0790
INFO - 2025-11-17 22:30:45 --> Config Class Initialized
INFO - 2025-11-17 22:30:45 --> Hooks Class Initialized
INFO - 2025-11-17 22:30:45 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:30:45 --> Utf8 Class Initialized
INFO - 2025-11-17 22:30:45 --> URI Class Initialized
INFO - 2025-11-17 22:30:45 --> Router Class Initialized
INFO - 2025-11-17 22:30:45 --> Output Class Initialized
INFO - 2025-11-17 22:30:45 --> Security Class Initialized
INFO - 2025-11-17 22:30:45 --> Input Class Initialized
INFO - 2025-11-17 22:30:45 --> Language Class Initialized
INFO - 2025-11-17 22:30:45 --> Loader Class Initialized
INFO - 2025-11-17 22:30:45 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:30:45 --> Helper loaded: url_helper
INFO - 2025-11-17 22:30:45 --> Helper loaded: file_helper
INFO - 2025-11-17 22:30:45 --> Helper loaded: main_helper
INFO - 2025-11-17 22:30:45 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:30:45 --> Database Driver Class Initialized
INFO - 2025-11-17 22:30:45 --> Email Class Initialized
DEBUG - 2025-11-17 22:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:30:45 --> Controller Class Initialized
INFO - 2025-11-17 22:30:45 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:30:45 --> Model "User_model" initialized
INFO - 2025-11-17 22:30:45 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:30:45 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 22:30:45 --> Final output sent to browser
INFO - 2025-11-17 22:30:45 --> Total execution time: 0.0879
INFO - 2025-11-17 22:30:52 --> Config Class Initialized
INFO - 2025-11-17 22:30:52 --> Hooks Class Initialized
INFO - 2025-11-17 22:30:52 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:30:52 --> Utf8 Class Initialized
INFO - 2025-11-17 22:30:52 --> URI Class Initialized
INFO - 2025-11-17 22:30:52 --> Router Class Initialized
INFO - 2025-11-17 22:30:52 --> Output Class Initialized
INFO - 2025-11-17 22:30:53 --> Security Class Initialized
INFO - 2025-11-17 22:30:53 --> Input Class Initialized
INFO - 2025-11-17 22:30:53 --> Language Class Initialized
INFO - 2025-11-17 22:30:53 --> Loader Class Initialized
INFO - 2025-11-17 22:30:53 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:30:53 --> Helper loaded: url_helper
INFO - 2025-11-17 22:30:53 --> Helper loaded: file_helper
INFO - 2025-11-17 22:30:53 --> Helper loaded: main_helper
INFO - 2025-11-17 22:30:53 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:30:53 --> Database Driver Class Initialized
INFO - 2025-11-17 22:30:53 --> Email Class Initialized
DEBUG - 2025-11-17 22:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:30:53 --> Controller Class Initialized
INFO - 2025-11-17 22:30:53 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:30:53 --> Model "User_model" initialized
INFO - 2025-11-17 22:30:53 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:30:53 --> Upload Class Initialized
INFO - 2025-11-17 22:30:53 --> Final output sent to browser
INFO - 2025-11-17 22:30:53 --> Total execution time: 0.1234
INFO - 2025-11-17 22:30:53 --> Config Class Initialized
INFO - 2025-11-17 22:30:53 --> Hooks Class Initialized
INFO - 2025-11-17 22:30:53 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:30:53 --> Utf8 Class Initialized
INFO - 2025-11-17 22:30:53 --> URI Class Initialized
INFO - 2025-11-17 22:30:53 --> Router Class Initialized
INFO - 2025-11-17 22:30:53 --> Output Class Initialized
INFO - 2025-11-17 22:30:53 --> Security Class Initialized
INFO - 2025-11-17 22:30:53 --> Input Class Initialized
INFO - 2025-11-17 22:30:53 --> Language Class Initialized
INFO - 2025-11-17 22:30:53 --> Loader Class Initialized
INFO - 2025-11-17 22:30:53 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:30:53 --> Helper loaded: url_helper
INFO - 2025-11-17 22:30:53 --> Helper loaded: file_helper
INFO - 2025-11-17 22:30:53 --> Helper loaded: main_helper
INFO - 2025-11-17 22:30:53 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:30:53 --> Database Driver Class Initialized
INFO - 2025-11-17 22:30:53 --> Email Class Initialized
DEBUG - 2025-11-17 22:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:30:53 --> Controller Class Initialized
INFO - 2025-11-17 22:30:53 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:30:53 --> Model "User_model" initialized
INFO - 2025-11-17 22:30:53 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:30:53 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 22:30:53 --> Final output sent to browser
INFO - 2025-11-17 22:30:53 --> Total execution time: 0.0678
INFO - 2025-11-17 22:30:53 --> Config Class Initialized
INFO - 2025-11-17 22:30:53 --> Hooks Class Initialized
INFO - 2025-11-17 22:30:53 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:30:53 --> Utf8 Class Initialized
INFO - 2025-11-17 22:30:53 --> URI Class Initialized
INFO - 2025-11-17 22:30:53 --> Router Class Initialized
INFO - 2025-11-17 22:30:53 --> Output Class Initialized
INFO - 2025-11-17 22:30:53 --> Security Class Initialized
INFO - 2025-11-17 22:30:53 --> Input Class Initialized
INFO - 2025-11-17 22:30:53 --> Language Class Initialized
ERROR - 2025-11-17 22:30:53 --> 404 Page Not Found: 2025-11-17-22-30-53-838d7d9f-b676-4b72-a527-ee3a16f52f19png/index
INFO - 2025-11-17 22:32:15 --> Config Class Initialized
INFO - 2025-11-17 22:32:15 --> Hooks Class Initialized
INFO - 2025-11-17 22:32:15 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:32:15 --> Utf8 Class Initialized
INFO - 2025-11-17 22:32:15 --> URI Class Initialized
INFO - 2025-11-17 22:32:15 --> Router Class Initialized
INFO - 2025-11-17 22:32:15 --> Output Class Initialized
INFO - 2025-11-17 22:32:15 --> Security Class Initialized
INFO - 2025-11-17 22:32:15 --> Input Class Initialized
INFO - 2025-11-17 22:32:15 --> Language Class Initialized
INFO - 2025-11-17 22:32:15 --> Loader Class Initialized
INFO - 2025-11-17 22:32:15 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:32:15 --> Helper loaded: url_helper
INFO - 2025-11-17 22:32:15 --> Helper loaded: file_helper
INFO - 2025-11-17 22:32:15 --> Helper loaded: main_helper
INFO - 2025-11-17 22:32:15 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:32:15 --> Database Driver Class Initialized
INFO - 2025-11-17 22:32:15 --> Email Class Initialized
DEBUG - 2025-11-17 22:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:32:15 --> Controller Class Initialized
INFO - 2025-11-17 22:32:15 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:32:15 --> Model "User_model" initialized
INFO - 2025-11-17 22:32:15 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:32:15 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 22:32:15 --> Final output sent to browser
INFO - 2025-11-17 22:32:15 --> Total execution time: 0.0818
INFO - 2025-11-17 22:32:33 --> Config Class Initialized
INFO - 2025-11-17 22:32:33 --> Hooks Class Initialized
INFO - 2025-11-17 22:32:33 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:32:33 --> Utf8 Class Initialized
INFO - 2025-11-17 22:32:34 --> URI Class Initialized
INFO - 2025-11-17 22:32:34 --> Router Class Initialized
INFO - 2025-11-17 22:32:34 --> Output Class Initialized
INFO - 2025-11-17 22:32:34 --> Security Class Initialized
INFO - 2025-11-17 22:32:34 --> Input Class Initialized
INFO - 2025-11-17 22:32:34 --> Language Class Initialized
INFO - 2025-11-17 22:32:34 --> Loader Class Initialized
INFO - 2025-11-17 22:32:34 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:32:34 --> Helper loaded: url_helper
INFO - 2025-11-17 22:32:34 --> Helper loaded: file_helper
INFO - 2025-11-17 22:32:34 --> Helper loaded: main_helper
INFO - 2025-11-17 22:32:34 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:32:35 --> Database Driver Class Initialized
INFO - 2025-11-17 22:32:35 --> Email Class Initialized
DEBUG - 2025-11-17 22:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:32:35 --> Controller Class Initialized
INFO - 2025-11-17 22:32:36 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:32:36 --> Model "User_model" initialized
INFO - 2025-11-17 22:32:36 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:32:36 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:32:36 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:32:36 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:32:36 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 22:32:36 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:32:36 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:32:36 --> Final output sent to browser
INFO - 2025-11-17 22:32:36 --> Total execution time: 3.1138
INFO - 2025-11-17 22:32:51 --> Config Class Initialized
INFO - 2025-11-17 22:32:51 --> Hooks Class Initialized
INFO - 2025-11-17 22:32:51 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:32:51 --> Utf8 Class Initialized
INFO - 2025-11-17 22:32:51 --> URI Class Initialized
INFO - 2025-11-17 22:32:51 --> Router Class Initialized
INFO - 2025-11-17 22:32:51 --> Output Class Initialized
INFO - 2025-11-17 22:32:51 --> Security Class Initialized
INFO - 2025-11-17 22:32:51 --> Input Class Initialized
INFO - 2025-11-17 22:32:51 --> Language Class Initialized
INFO - 2025-11-17 22:32:51 --> Loader Class Initialized
INFO - 2025-11-17 22:32:51 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:32:51 --> Helper loaded: url_helper
INFO - 2025-11-17 22:32:51 --> Helper loaded: file_helper
INFO - 2025-11-17 22:32:51 --> Helper loaded: main_helper
INFO - 2025-11-17 22:32:51 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:32:51 --> Database Driver Class Initialized
INFO - 2025-11-17 22:32:51 --> Email Class Initialized
DEBUG - 2025-11-17 22:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:32:51 --> Controller Class Initialized
INFO - 2025-11-17 22:32:51 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:32:51 --> Model "User_model" initialized
INFO - 2025-11-17 22:32:51 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:32:52 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-17 22:32:52 --> Final output sent to browser
INFO - 2025-11-17 22:32:52 --> Total execution time: 0.1417
INFO - 2025-11-17 22:34:43 --> Config Class Initialized
INFO - 2025-11-17 22:34:43 --> Hooks Class Initialized
INFO - 2025-11-17 22:34:43 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:34:43 --> Utf8 Class Initialized
INFO - 2025-11-17 22:34:43 --> URI Class Initialized
INFO - 2025-11-17 22:34:43 --> Router Class Initialized
INFO - 2025-11-17 22:34:43 --> Output Class Initialized
INFO - 2025-11-17 22:34:43 --> Security Class Initialized
INFO - 2025-11-17 22:34:43 --> Input Class Initialized
INFO - 2025-11-17 22:34:43 --> Language Class Initialized
INFO - 2025-11-17 22:34:43 --> Loader Class Initialized
INFO - 2025-11-17 22:34:43 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:34:43 --> Helper loaded: url_helper
INFO - 2025-11-17 22:34:43 --> Helper loaded: file_helper
INFO - 2025-11-17 22:34:43 --> Helper loaded: main_helper
INFO - 2025-11-17 22:34:43 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:34:43 --> Database Driver Class Initialized
INFO - 2025-11-17 22:34:43 --> Email Class Initialized
DEBUG - 2025-11-17 22:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:34:43 --> Controller Class Initialized
INFO - 2025-11-17 22:34:43 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:34:43 --> Model "User_model" initialized
INFO - 2025-11-17 22:34:43 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:34:43 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:34:43 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:34:43 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:34:43 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 22:34:43 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:34:43 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:34:43 --> Final output sent to browser
INFO - 2025-11-17 22:34:43 --> Total execution time: 0.0989
INFO - 2025-11-17 22:34:56 --> Config Class Initialized
INFO - 2025-11-17 22:34:56 --> Hooks Class Initialized
INFO - 2025-11-17 22:34:56 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:34:56 --> Utf8 Class Initialized
INFO - 2025-11-17 22:34:56 --> URI Class Initialized
INFO - 2025-11-17 22:34:56 --> Router Class Initialized
INFO - 2025-11-17 22:34:56 --> Output Class Initialized
INFO - 2025-11-17 22:34:56 --> Security Class Initialized
INFO - 2025-11-17 22:34:56 --> Input Class Initialized
INFO - 2025-11-17 22:34:56 --> Language Class Initialized
INFO - 2025-11-17 22:34:56 --> Loader Class Initialized
INFO - 2025-11-17 22:34:56 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:34:56 --> Helper loaded: url_helper
INFO - 2025-11-17 22:34:56 --> Helper loaded: file_helper
INFO - 2025-11-17 22:34:56 --> Helper loaded: main_helper
INFO - 2025-11-17 22:34:56 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:34:56 --> Database Driver Class Initialized
INFO - 2025-11-17 22:34:56 --> Email Class Initialized
DEBUG - 2025-11-17 22:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:34:56 --> Controller Class Initialized
INFO - 2025-11-17 22:34:56 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:34:56 --> Model "User_model" initialized
INFO - 2025-11-17 22:34:56 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:34:56 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:34:56 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:34:56 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:34:56 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 22:34:56 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:34:56 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:34:56 --> Final output sent to browser
INFO - 2025-11-17 22:34:56 --> Total execution time: 0.0947
INFO - 2025-11-17 22:36:03 --> Config Class Initialized
INFO - 2025-11-17 22:36:03 --> Hooks Class Initialized
INFO - 2025-11-17 22:36:03 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:36:03 --> Utf8 Class Initialized
INFO - 2025-11-17 22:36:03 --> URI Class Initialized
INFO - 2025-11-17 22:36:03 --> Router Class Initialized
INFO - 2025-11-17 22:36:03 --> Output Class Initialized
INFO - 2025-11-17 22:36:03 --> Security Class Initialized
INFO - 2025-11-17 22:36:03 --> Input Class Initialized
INFO - 2025-11-17 22:36:03 --> Language Class Initialized
INFO - 2025-11-17 22:36:03 --> Loader Class Initialized
INFO - 2025-11-17 22:36:03 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:36:03 --> Helper loaded: url_helper
INFO - 2025-11-17 22:36:03 --> Helper loaded: file_helper
INFO - 2025-11-17 22:36:03 --> Helper loaded: main_helper
INFO - 2025-11-17 22:36:03 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:36:03 --> Database Driver Class Initialized
INFO - 2025-11-17 22:36:03 --> Email Class Initialized
DEBUG - 2025-11-17 22:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:36:03 --> Controller Class Initialized
INFO - 2025-11-17 22:36:03 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:36:03 --> Model "User_model" initialized
INFO - 2025-11-17 22:36:03 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:36:03 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:36:03 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:36:03 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:36:03 --> File loaded: D:\laragon\www\acumena\application\views\dashboard.php
INFO - 2025-11-17 22:36:03 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:36:03 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:36:03 --> Final output sent to browser
INFO - 2025-11-17 22:36:03 --> Total execution time: 0.1874
INFO - 2025-11-17 22:36:03 --> Config Class Initialized
INFO - 2025-11-17 22:36:03 --> Hooks Class Initialized
INFO - 2025-11-17 22:36:03 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:36:03 --> Utf8 Class Initialized
INFO - 2025-11-17 22:36:03 --> URI Class Initialized
INFO - 2025-11-17 22:36:03 --> Router Class Initialized
INFO - 2025-11-17 22:36:03 --> Output Class Initialized
INFO - 2025-11-17 22:36:03 --> Security Class Initialized
INFO - 2025-11-17 22:36:03 --> Input Class Initialized
INFO - 2025-11-17 22:36:03 --> Language Class Initialized
INFO - 2025-11-17 22:36:03 --> Loader Class Initialized
INFO - 2025-11-17 22:36:03 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:36:03 --> Helper loaded: url_helper
INFO - 2025-11-17 22:36:03 --> Helper loaded: file_helper
INFO - 2025-11-17 22:36:03 --> Helper loaded: main_helper
INFO - 2025-11-17 22:36:03 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:36:03 --> Database Driver Class Initialized
INFO - 2025-11-17 22:36:03 --> Email Class Initialized
DEBUG - 2025-11-17 22:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:36:03 --> Controller Class Initialized
INFO - 2025-11-17 22:36:03 --> Model "User_model" initialized
INFO - 2025-11-17 22:36:03 --> Model "Project_model" initialized
INFO - 2025-11-17 22:36:03 --> Helper loaded: form_helper
INFO - 2025-11-17 22:36:03 --> Form Validation Class Initialized
INFO - 2025-11-17 22:36:03 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 22:36:03 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 22:36:03 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 22:36:03 --> Model "Swot_model" initialized
INFO - 2025-11-17 22:36:03 --> Model "Swot_model" initialized
INFO - 2025-11-17 22:36:03 --> Model "Topk_service_model" initialized
INFO - 2025-11-17 22:36:03 --> Final output sent to browser
INFO - 2025-11-17 22:36:03 --> Total execution time: 0.4945
INFO - 2025-11-17 22:36:04 --> Config Class Initialized
INFO - 2025-11-17 22:36:04 --> Hooks Class Initialized
INFO - 2025-11-17 22:36:04 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:36:04 --> Utf8 Class Initialized
INFO - 2025-11-17 22:36:04 --> URI Class Initialized
INFO - 2025-11-17 22:36:04 --> Router Class Initialized
INFO - 2025-11-17 22:36:04 --> Output Class Initialized
INFO - 2025-11-17 22:36:04 --> Security Class Initialized
INFO - 2025-11-17 22:36:04 --> Input Class Initialized
INFO - 2025-11-17 22:36:04 --> Language Class Initialized
INFO - 2025-11-17 22:36:04 --> Loader Class Initialized
INFO - 2025-11-17 22:36:04 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:36:04 --> Helper loaded: url_helper
INFO - 2025-11-17 22:36:04 --> Helper loaded: file_helper
INFO - 2025-11-17 22:36:04 --> Helper loaded: main_helper
INFO - 2025-11-17 22:36:04 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:36:04 --> Database Driver Class Initialized
INFO - 2025-11-17 22:36:04 --> Email Class Initialized
DEBUG - 2025-11-17 22:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:36:04 --> Controller Class Initialized
INFO - 2025-11-17 22:36:04 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:36:04 --> Model "User_model" initialized
INFO - 2025-11-17 22:36:04 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:36:04 --> Model "Project_model" initialized
INFO - 2025-11-17 22:36:04 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:36:04 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:36:04 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:36:04 --> File loaded: D:\laragon\www\acumena\application\views\projects/index.php
INFO - 2025-11-17 22:36:04 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:36:04 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:36:04 --> Final output sent to browser
INFO - 2025-11-17 22:36:04 --> Total execution time: 0.2116
INFO - 2025-11-17 22:36:04 --> Config Class Initialized
INFO - 2025-11-17 22:36:04 --> Hooks Class Initialized
INFO - 2025-11-17 22:36:04 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:36:04 --> Utf8 Class Initialized
INFO - 2025-11-17 22:36:04 --> URI Class Initialized
INFO - 2025-11-17 22:36:04 --> Router Class Initialized
INFO - 2025-11-17 22:36:04 --> Output Class Initialized
INFO - 2025-11-17 22:36:04 --> Security Class Initialized
INFO - 2025-11-17 22:36:04 --> Input Class Initialized
INFO - 2025-11-17 22:36:04 --> Language Class Initialized
INFO - 2025-11-17 22:36:04 --> Loader Class Initialized
INFO - 2025-11-17 22:36:04 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:36:04 --> Helper loaded: url_helper
INFO - 2025-11-17 22:36:04 --> Helper loaded: file_helper
INFO - 2025-11-17 22:36:04 --> Helper loaded: main_helper
INFO - 2025-11-17 22:36:04 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:36:04 --> Database Driver Class Initialized
INFO - 2025-11-17 22:36:04 --> Email Class Initialized
DEBUG - 2025-11-17 22:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:36:04 --> Controller Class Initialized
INFO - 2025-11-17 22:36:04 --> Model "User_model" initialized
INFO - 2025-11-17 22:36:04 --> Model "Project_model" initialized
INFO - 2025-11-17 22:36:04 --> Helper loaded: form_helper
INFO - 2025-11-17 22:36:04 --> Form Validation Class Initialized
INFO - 2025-11-17 22:36:04 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 22:36:04 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 22:36:04 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 22:36:04 --> Model "Swot_model" initialized
INFO - 2025-11-17 22:36:04 --> Model "Swot_model" initialized
INFO - 2025-11-17 22:36:04 --> Model "Topk_service_model" initialized
INFO - 2025-11-17 22:36:04 --> Final output sent to browser
INFO - 2025-11-17 22:36:04 --> Total execution time: 0.0697
INFO - 2025-11-17 22:36:10 --> Config Class Initialized
INFO - 2025-11-17 22:36:10 --> Hooks Class Initialized
INFO - 2025-11-17 22:36:10 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:36:10 --> Utf8 Class Initialized
INFO - 2025-11-17 22:36:10 --> URI Class Initialized
INFO - 2025-11-17 22:36:10 --> Router Class Initialized
INFO - 2025-11-17 22:36:10 --> Output Class Initialized
INFO - 2025-11-17 22:36:10 --> Security Class Initialized
INFO - 2025-11-17 22:36:10 --> Input Class Initialized
INFO - 2025-11-17 22:36:10 --> Language Class Initialized
INFO - 2025-11-17 22:36:10 --> Loader Class Initialized
INFO - 2025-11-17 22:36:10 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:36:10 --> Helper loaded: url_helper
INFO - 2025-11-17 22:36:10 --> Helper loaded: file_helper
INFO - 2025-11-17 22:36:10 --> Helper loaded: main_helper
INFO - 2025-11-17 22:36:10 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:36:10 --> Database Driver Class Initialized
INFO - 2025-11-17 22:36:10 --> Email Class Initialized
DEBUG - 2025-11-17 22:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:36:10 --> Controller Class Initialized
INFO - 2025-11-17 22:36:10 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:36:10 --> Model "User_model" initialized
INFO - 2025-11-17 22:36:10 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:36:10 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:36:10 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:36:10 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:36:10 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 22:36:10 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:36:10 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:36:10 --> Final output sent to browser
INFO - 2025-11-17 22:36:10 --> Total execution time: 0.0697
INFO - 2025-11-17 22:39:46 --> Config Class Initialized
INFO - 2025-11-17 22:39:46 --> Hooks Class Initialized
INFO - 2025-11-17 22:39:46 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:39:46 --> Utf8 Class Initialized
INFO - 2025-11-17 22:39:46 --> URI Class Initialized
INFO - 2025-11-17 22:39:46 --> Router Class Initialized
INFO - 2025-11-17 22:39:46 --> Output Class Initialized
INFO - 2025-11-17 22:39:46 --> Security Class Initialized
INFO - 2025-11-17 22:39:46 --> Input Class Initialized
INFO - 2025-11-17 22:39:46 --> Language Class Initialized
INFO - 2025-11-17 22:39:46 --> Loader Class Initialized
INFO - 2025-11-17 22:39:46 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:39:46 --> Helper loaded: url_helper
INFO - 2025-11-17 22:39:46 --> Helper loaded: file_helper
INFO - 2025-11-17 22:39:46 --> Helper loaded: main_helper
INFO - 2025-11-17 22:39:46 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:39:46 --> Database Driver Class Initialized
INFO - 2025-11-17 22:39:46 --> Email Class Initialized
DEBUG - 2025-11-17 22:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:39:46 --> Controller Class Initialized
INFO - 2025-11-17 22:39:46 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:39:46 --> Model "User_model" initialized
INFO - 2025-11-17 22:39:46 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:39:46 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:39:46 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:39:46 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:39:46 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 22:39:46 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:39:46 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:39:46 --> Final output sent to browser
INFO - 2025-11-17 22:39:46 --> Total execution time: 0.0727
INFO - 2025-11-17 22:39:47 --> Config Class Initialized
INFO - 2025-11-17 22:39:47 --> Hooks Class Initialized
INFO - 2025-11-17 22:39:47 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:39:47 --> Utf8 Class Initialized
INFO - 2025-11-17 22:39:47 --> URI Class Initialized
INFO - 2025-11-17 22:39:47 --> Router Class Initialized
INFO - 2025-11-17 22:39:47 --> Output Class Initialized
INFO - 2025-11-17 22:39:47 --> Security Class Initialized
INFO - 2025-11-17 22:39:47 --> Input Class Initialized
INFO - 2025-11-17 22:39:47 --> Language Class Initialized
INFO - 2025-11-17 22:39:47 --> Loader Class Initialized
INFO - 2025-11-17 22:39:47 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:39:47 --> Helper loaded: url_helper
INFO - 2025-11-17 22:39:47 --> Helper loaded: file_helper
INFO - 2025-11-17 22:39:47 --> Helper loaded: main_helper
INFO - 2025-11-17 22:39:47 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:39:47 --> Database Driver Class Initialized
INFO - 2025-11-17 22:39:47 --> Email Class Initialized
DEBUG - 2025-11-17 22:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:39:47 --> Controller Class Initialized
INFO - 2025-11-17 22:39:47 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:39:47 --> Model "User_model" initialized
INFO - 2025-11-17 22:39:47 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:39:47 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:39:47 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:39:47 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:40:01 --> Config Class Initialized
INFO - 2025-11-17 22:40:01 --> Hooks Class Initialized
INFO - 2025-11-17 22:40:01 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:40:01 --> Utf8 Class Initialized
INFO - 2025-11-17 22:40:01 --> URI Class Initialized
INFO - 2025-11-17 22:40:01 --> Router Class Initialized
INFO - 2025-11-17 22:40:01 --> Output Class Initialized
INFO - 2025-11-17 22:40:01 --> Security Class Initialized
INFO - 2025-11-17 22:40:01 --> Input Class Initialized
INFO - 2025-11-17 22:40:01 --> Language Class Initialized
INFO - 2025-11-17 22:40:01 --> Loader Class Initialized
INFO - 2025-11-17 22:40:01 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:40:01 --> Helper loaded: url_helper
INFO - 2025-11-17 22:40:01 --> Helper loaded: file_helper
INFO - 2025-11-17 22:40:01 --> Helper loaded: main_helper
INFO - 2025-11-17 22:40:01 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:40:01 --> Database Driver Class Initialized
INFO - 2025-11-17 22:40:01 --> Email Class Initialized
DEBUG - 2025-11-17 22:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:40:01 --> Controller Class Initialized
INFO - 2025-11-17 22:40:01 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:40:01 --> Model "User_model" initialized
INFO - 2025-11-17 22:40:01 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:40:01 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:40:01 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:40:01 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
ERROR - 2025-11-17 22:40:01 --> Severity: Warning --> Attempt to read property "subscription_name" on array D:\laragon\www\acumena\application\views\subscriptions\package.php 17
ERROR - 2025-11-17 22:40:01 --> Severity: Warning --> Attempt to read property "price_monthly" on array D:\laragon\www\acumena\application\views\subscriptions\package.php 20
ERROR - 2025-11-17 22:40:01 --> Severity: Warning --> Attempt to read property "date_start" on array D:\laragon\www\acumena\application\views\subscriptions\package.php 29
ERROR - 2025-11-17 22:40:01 --> Severity: Deprecated Notice --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated D:\laragon\www\acumena\application\views\subscriptions\package.php 29
ERROR - 2025-11-17 22:40:01 --> Severity: Warning --> Attempt to read property "date_end" on array D:\laragon\www\acumena\application\views\subscriptions\package.php 29
ERROR - 2025-11-17 22:40:01 --> Severity: Deprecated Notice --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated D:\laragon\www\acumena\application\views\subscriptions\package.php 29
ERROR - 2025-11-17 22:40:01 --> Severity: Warning --> Attempt to read property "subscription_id" on array D:\laragon\www\acumena\application\views\subscriptions\package.php 35
ERROR - 2025-11-17 22:40:01 --> Severity: Warning --> Undefined variable $invoice_history D:\laragon\www\acumena\application\views\subscriptions\package.php 51
ERROR - 2025-11-17 22:40:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given D:\laragon\www\acumena\application\views\subscriptions\package.php 51
INFO - 2025-11-17 22:40:01 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/package.php
INFO - 2025-11-17 22:40:01 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:40:01 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:40:01 --> Final output sent to browser
INFO - 2025-11-17 22:40:01 --> Total execution time: 0.1639
INFO - 2025-11-17 22:41:01 --> Config Class Initialized
INFO - 2025-11-17 22:41:01 --> Hooks Class Initialized
INFO - 2025-11-17 22:41:01 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:41:01 --> Utf8 Class Initialized
INFO - 2025-11-17 22:41:01 --> URI Class Initialized
INFO - 2025-11-17 22:41:01 --> Router Class Initialized
INFO - 2025-11-17 22:41:01 --> Output Class Initialized
INFO - 2025-11-17 22:41:01 --> Security Class Initialized
INFO - 2025-11-17 22:41:01 --> Input Class Initialized
INFO - 2025-11-17 22:41:01 --> Language Class Initialized
INFO - 2025-11-17 22:41:01 --> Loader Class Initialized
INFO - 2025-11-17 22:41:01 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:41:01 --> Helper loaded: url_helper
INFO - 2025-11-17 22:41:01 --> Helper loaded: file_helper
INFO - 2025-11-17 22:41:01 --> Helper loaded: main_helper
INFO - 2025-11-17 22:41:01 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:41:01 --> Database Driver Class Initialized
INFO - 2025-11-17 22:41:01 --> Email Class Initialized
DEBUG - 2025-11-17 22:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:41:01 --> Controller Class Initialized
INFO - 2025-11-17 22:41:01 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:41:01 --> Model "User_model" initialized
INFO - 2025-11-17 22:41:01 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:41:01 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:41:01 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:41:01 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
ERROR - 2025-11-17 22:41:01 --> Severity: Warning --> Attempt to read property "subscription_name" on array D:\laragon\www\acumena\application\views\subscriptions\package.php 17
ERROR - 2025-11-17 22:41:01 --> Severity: Warning --> Attempt to read property "price_monthly" on array D:\laragon\www\acumena\application\views\subscriptions\package.php 20
ERROR - 2025-11-17 22:41:01 --> Severity: Warning --> Attempt to read property "date_start" on array D:\laragon\www\acumena\application\views\subscriptions\package.php 29
ERROR - 2025-11-17 22:41:01 --> Severity: Deprecated Notice --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated D:\laragon\www\acumena\application\views\subscriptions\package.php 29
ERROR - 2025-11-17 22:41:01 --> Severity: Warning --> Attempt to read property "date_end" on array D:\laragon\www\acumena\application\views\subscriptions\package.php 29
ERROR - 2025-11-17 22:41:01 --> Severity: Deprecated Notice --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated D:\laragon\www\acumena\application\views\subscriptions\package.php 29
ERROR - 2025-11-17 22:41:01 --> Severity: Warning --> Attempt to read property "subscription_id" on array D:\laragon\www\acumena\application\views\subscriptions\package.php 35
ERROR - 2025-11-17 22:41:01 --> Severity: Warning --> Undefined variable $invoice_history D:\laragon\www\acumena\application\views\subscriptions\package.php 51
ERROR - 2025-11-17 22:41:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given D:\laragon\www\acumena\application\views\subscriptions\package.php 51
INFO - 2025-11-17 22:41:01 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/package.php
INFO - 2025-11-17 22:41:01 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:41:01 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:41:01 --> Final output sent to browser
INFO - 2025-11-17 22:41:01 --> Total execution time: 0.1202
INFO - 2025-11-17 22:41:14 --> Config Class Initialized
INFO - 2025-11-17 22:41:14 --> Hooks Class Initialized
INFO - 2025-11-17 22:41:14 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:41:14 --> Utf8 Class Initialized
INFO - 2025-11-17 22:41:14 --> URI Class Initialized
INFO - 2025-11-17 22:41:14 --> Router Class Initialized
INFO - 2025-11-17 22:41:14 --> Output Class Initialized
INFO - 2025-11-17 22:41:14 --> Security Class Initialized
INFO - 2025-11-17 22:41:14 --> Input Class Initialized
INFO - 2025-11-17 22:41:14 --> Language Class Initialized
INFO - 2025-11-17 22:41:14 --> Loader Class Initialized
INFO - 2025-11-17 22:41:14 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:41:14 --> Helper loaded: url_helper
INFO - 2025-11-17 22:41:14 --> Helper loaded: file_helper
INFO - 2025-11-17 22:41:14 --> Helper loaded: main_helper
INFO - 2025-11-17 22:41:14 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:41:14 --> Database Driver Class Initialized
INFO - 2025-11-17 22:41:14 --> Email Class Initialized
DEBUG - 2025-11-17 22:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:41:14 --> Controller Class Initialized
INFO - 2025-11-17 22:41:14 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:41:14 --> Model "User_model" initialized
INFO - 2025-11-17 22:41:14 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:41:14 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:41:14 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:41:14 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:41:14 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/package.php
INFO - 2025-11-17 22:41:14 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:41:14 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:41:14 --> Final output sent to browser
INFO - 2025-11-17 22:41:14 --> Total execution time: 0.0956
INFO - 2025-11-17 22:44:31 --> Config Class Initialized
INFO - 2025-11-17 22:44:31 --> Hooks Class Initialized
INFO - 2025-11-17 22:44:31 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:44:31 --> Utf8 Class Initialized
INFO - 2025-11-17 22:44:31 --> URI Class Initialized
INFO - 2025-11-17 22:44:31 --> Router Class Initialized
INFO - 2025-11-17 22:44:31 --> Output Class Initialized
INFO - 2025-11-17 22:44:31 --> Security Class Initialized
INFO - 2025-11-17 22:44:31 --> Input Class Initialized
INFO - 2025-11-17 22:44:31 --> Language Class Initialized
INFO - 2025-11-17 22:44:31 --> Loader Class Initialized
INFO - 2025-11-17 22:44:31 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:44:31 --> Helper loaded: url_helper
INFO - 2025-11-17 22:44:31 --> Helper loaded: file_helper
INFO - 2025-11-17 22:44:31 --> Helper loaded: main_helper
INFO - 2025-11-17 22:44:31 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:44:31 --> Database Driver Class Initialized
INFO - 2025-11-17 22:44:31 --> Email Class Initialized
DEBUG - 2025-11-17 22:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:44:31 --> Controller Class Initialized
INFO - 2025-11-17 22:44:31 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:44:31 --> Model "User_model" initialized
INFO - 2025-11-17 22:44:31 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:44:31 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:44:31 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:44:31 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:44:31 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/package.php
INFO - 2025-11-17 22:44:31 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:44:31 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:44:31 --> Final output sent to browser
INFO - 2025-11-17 22:44:31 --> Total execution time: 0.1381
INFO - 2025-11-17 22:45:52 --> Config Class Initialized
INFO - 2025-11-17 22:45:52 --> Hooks Class Initialized
INFO - 2025-11-17 22:45:52 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:45:52 --> Utf8 Class Initialized
INFO - 2025-11-17 22:45:52 --> URI Class Initialized
INFO - 2025-11-17 22:45:52 --> Router Class Initialized
INFO - 2025-11-17 22:45:52 --> Output Class Initialized
INFO - 2025-11-17 22:45:52 --> Security Class Initialized
INFO - 2025-11-17 22:45:52 --> Input Class Initialized
INFO - 2025-11-17 22:45:52 --> Language Class Initialized
INFO - 2025-11-17 22:45:52 --> Loader Class Initialized
INFO - 2025-11-17 22:45:52 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:45:52 --> Helper loaded: url_helper
INFO - 2025-11-17 22:45:52 --> Helper loaded: file_helper
INFO - 2025-11-17 22:45:52 --> Helper loaded: main_helper
INFO - 2025-11-17 22:45:52 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:45:52 --> Database Driver Class Initialized
INFO - 2025-11-17 22:45:52 --> Email Class Initialized
DEBUG - 2025-11-17 22:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:45:52 --> Controller Class Initialized
INFO - 2025-11-17 22:45:52 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:45:52 --> Model "User_model" initialized
INFO - 2025-11-17 22:45:52 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:45:52 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:45:52 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:45:52 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:45:52 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/package.php
INFO - 2025-11-17 22:45:52 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:45:52 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:45:52 --> Final output sent to browser
INFO - 2025-11-17 22:45:52 --> Total execution time: 0.0849
INFO - 2025-11-17 22:46:52 --> Config Class Initialized
INFO - 2025-11-17 22:46:52 --> Hooks Class Initialized
INFO - 2025-11-17 22:46:52 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:46:52 --> Utf8 Class Initialized
INFO - 2025-11-17 22:46:52 --> URI Class Initialized
INFO - 2025-11-17 22:46:52 --> Router Class Initialized
INFO - 2025-11-17 22:46:52 --> Output Class Initialized
INFO - 2025-11-17 22:46:52 --> Security Class Initialized
INFO - 2025-11-17 22:46:52 --> Input Class Initialized
INFO - 2025-11-17 22:46:52 --> Language Class Initialized
INFO - 2025-11-17 22:46:52 --> Loader Class Initialized
INFO - 2025-11-17 22:46:52 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:46:52 --> Helper loaded: url_helper
INFO - 2025-11-17 22:46:52 --> Helper loaded: file_helper
INFO - 2025-11-17 22:46:52 --> Helper loaded: main_helper
INFO - 2025-11-17 22:46:52 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:46:53 --> Database Driver Class Initialized
INFO - 2025-11-17 22:46:53 --> Email Class Initialized
DEBUG - 2025-11-17 22:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:46:53 --> Controller Class Initialized
INFO - 2025-11-17 22:46:53 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:46:53 --> Model "User_model" initialized
INFO - 2025-11-17 22:46:53 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:46:53 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:46:53 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:46:53 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:46:53 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/package.php
INFO - 2025-11-17 22:46:53 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:46:53 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:46:53 --> Final output sent to browser
INFO - 2025-11-17 22:46:53 --> Total execution time: 0.0706
INFO - 2025-11-17 22:47:10 --> Config Class Initialized
INFO - 2025-11-17 22:47:10 --> Hooks Class Initialized
INFO - 2025-11-17 22:47:10 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:47:10 --> Utf8 Class Initialized
INFO - 2025-11-17 22:47:10 --> URI Class Initialized
INFO - 2025-11-17 22:47:10 --> Router Class Initialized
INFO - 2025-11-17 22:47:10 --> Output Class Initialized
INFO - 2025-11-17 22:47:10 --> Security Class Initialized
INFO - 2025-11-17 22:47:10 --> Input Class Initialized
INFO - 2025-11-17 22:47:10 --> Language Class Initialized
INFO - 2025-11-17 22:47:11 --> Loader Class Initialized
INFO - 2025-11-17 22:47:11 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:47:11 --> Helper loaded: url_helper
INFO - 2025-11-17 22:47:11 --> Helper loaded: file_helper
INFO - 2025-11-17 22:47:11 --> Helper loaded: main_helper
INFO - 2025-11-17 22:47:11 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:47:11 --> Database Driver Class Initialized
INFO - 2025-11-17 22:47:11 --> Email Class Initialized
DEBUG - 2025-11-17 22:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:47:11 --> Controller Class Initialized
INFO - 2025-11-17 22:47:11 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:47:11 --> Model "User_model" initialized
INFO - 2025-11-17 22:47:11 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:47:11 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:47:11 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:47:11 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:47:11 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/package.php
INFO - 2025-11-17 22:47:11 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:47:11 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:47:11 --> Final output sent to browser
INFO - 2025-11-17 22:47:11 --> Total execution time: 0.0841
INFO - 2025-11-17 22:48:22 --> Config Class Initialized
INFO - 2025-11-17 22:48:22 --> Hooks Class Initialized
INFO - 2025-11-17 22:48:22 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:48:22 --> Utf8 Class Initialized
INFO - 2025-11-17 22:48:22 --> URI Class Initialized
INFO - 2025-11-17 22:48:22 --> Router Class Initialized
INFO - 2025-11-17 22:48:22 --> Output Class Initialized
INFO - 2025-11-17 22:48:22 --> Security Class Initialized
INFO - 2025-11-17 22:48:22 --> Input Class Initialized
INFO - 2025-11-17 22:48:22 --> Language Class Initialized
INFO - 2025-11-17 22:48:22 --> Loader Class Initialized
INFO - 2025-11-17 22:48:22 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:48:22 --> Helper loaded: url_helper
INFO - 2025-11-17 22:48:22 --> Helper loaded: file_helper
INFO - 2025-11-17 22:48:22 --> Helper loaded: main_helper
INFO - 2025-11-17 22:48:22 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:48:22 --> Database Driver Class Initialized
INFO - 2025-11-17 22:48:22 --> Email Class Initialized
DEBUG - 2025-11-17 22:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:48:22 --> Controller Class Initialized
INFO - 2025-11-17 22:48:22 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:48:22 --> Model "User_model" initialized
INFO - 2025-11-17 22:48:22 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:48:22 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:48:22 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:48:22 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:48:22 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/package.php
INFO - 2025-11-17 22:48:22 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:48:22 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:48:22 --> Final output sent to browser
INFO - 2025-11-17 22:48:22 --> Total execution time: 0.0768
INFO - 2025-11-17 22:49:06 --> Config Class Initialized
INFO - 2025-11-17 22:49:06 --> Hooks Class Initialized
INFO - 2025-11-17 22:49:06 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:49:06 --> Utf8 Class Initialized
INFO - 2025-11-17 22:49:06 --> URI Class Initialized
INFO - 2025-11-17 22:49:06 --> Router Class Initialized
INFO - 2025-11-17 22:49:06 --> Output Class Initialized
INFO - 2025-11-17 22:49:06 --> Security Class Initialized
INFO - 2025-11-17 22:49:06 --> Input Class Initialized
INFO - 2025-11-17 22:49:06 --> Language Class Initialized
INFO - 2025-11-17 22:49:06 --> Loader Class Initialized
INFO - 2025-11-17 22:49:06 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:49:06 --> Helper loaded: url_helper
INFO - 2025-11-17 22:49:06 --> Helper loaded: file_helper
INFO - 2025-11-17 22:49:06 --> Helper loaded: main_helper
INFO - 2025-11-17 22:49:06 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:49:06 --> Database Driver Class Initialized
INFO - 2025-11-17 22:49:06 --> Email Class Initialized
DEBUG - 2025-11-17 22:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:49:06 --> Controller Class Initialized
INFO - 2025-11-17 22:49:06 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:49:06 --> Model "User_model" initialized
INFO - 2025-11-17 22:49:06 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:49:06 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:49:06 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:49:06 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:49:06 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/package.php
INFO - 2025-11-17 22:49:06 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:49:06 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:49:06 --> Final output sent to browser
INFO - 2025-11-17 22:49:06 --> Total execution time: 0.0934
INFO - 2025-11-17 22:49:57 --> Config Class Initialized
INFO - 2025-11-17 22:49:57 --> Hooks Class Initialized
INFO - 2025-11-17 22:49:57 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:49:57 --> Utf8 Class Initialized
INFO - 2025-11-17 22:49:57 --> URI Class Initialized
INFO - 2025-11-17 22:49:57 --> Router Class Initialized
INFO - 2025-11-17 22:49:57 --> Output Class Initialized
INFO - 2025-11-17 22:49:57 --> Security Class Initialized
INFO - 2025-11-17 22:49:57 --> Input Class Initialized
INFO - 2025-11-17 22:49:57 --> Language Class Initialized
INFO - 2025-11-17 22:49:57 --> Loader Class Initialized
INFO - 2025-11-17 22:49:57 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:49:57 --> Helper loaded: url_helper
INFO - 2025-11-17 22:49:57 --> Helper loaded: file_helper
INFO - 2025-11-17 22:49:57 --> Helper loaded: main_helper
INFO - 2025-11-17 22:49:57 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:49:57 --> Database Driver Class Initialized
INFO - 2025-11-17 22:49:57 --> Email Class Initialized
DEBUG - 2025-11-17 22:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:49:57 --> Controller Class Initialized
INFO - 2025-11-17 22:49:57 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:49:57 --> Model "User_model" initialized
INFO - 2025-11-17 22:49:57 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:49:57 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:49:57 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:49:57 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:49:57 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/package.php
INFO - 2025-11-17 22:49:57 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:49:57 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:49:57 --> Final output sent to browser
INFO - 2025-11-17 22:49:57 --> Total execution time: 0.0785
INFO - 2025-11-17 22:50:08 --> Config Class Initialized
INFO - 2025-11-17 22:50:08 --> Hooks Class Initialized
INFO - 2025-11-17 22:50:08 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:50:08 --> Utf8 Class Initialized
INFO - 2025-11-17 22:50:08 --> URI Class Initialized
INFO - 2025-11-17 22:50:08 --> Router Class Initialized
INFO - 2025-11-17 22:50:08 --> Output Class Initialized
INFO - 2025-11-17 22:50:08 --> Security Class Initialized
INFO - 2025-11-17 22:50:08 --> Input Class Initialized
INFO - 2025-11-17 22:50:08 --> Language Class Initialized
INFO - 2025-11-17 22:50:08 --> Loader Class Initialized
INFO - 2025-11-17 22:50:08 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:50:08 --> Helper loaded: url_helper
INFO - 2025-11-17 22:50:08 --> Helper loaded: file_helper
INFO - 2025-11-17 22:50:08 --> Helper loaded: main_helper
INFO - 2025-11-17 22:50:08 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:50:08 --> Database Driver Class Initialized
INFO - 2025-11-17 22:50:08 --> Email Class Initialized
DEBUG - 2025-11-17 22:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:50:08 --> Controller Class Initialized
INFO - 2025-11-17 22:50:08 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:50:08 --> Model "User_model" initialized
INFO - 2025-11-17 22:50:08 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:50:08 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:50:08 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:50:08 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:50:08 --> File loaded: D:\laragon\www\acumena\application\views\dashboard.php
INFO - 2025-11-17 22:50:08 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:50:08 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:50:08 --> Final output sent to browser
INFO - 2025-11-17 22:50:08 --> Total execution time: 0.0660
INFO - 2025-11-17 22:50:08 --> Config Class Initialized
INFO - 2025-11-17 22:50:08 --> Hooks Class Initialized
INFO - 2025-11-17 22:50:08 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:50:08 --> Utf8 Class Initialized
INFO - 2025-11-17 22:50:08 --> URI Class Initialized
INFO - 2025-11-17 22:50:08 --> Router Class Initialized
INFO - 2025-11-17 22:50:08 --> Output Class Initialized
INFO - 2025-11-17 22:50:08 --> Security Class Initialized
INFO - 2025-11-17 22:50:08 --> Input Class Initialized
INFO - 2025-11-17 22:50:08 --> Language Class Initialized
INFO - 2025-11-17 22:50:08 --> Loader Class Initialized
INFO - 2025-11-17 22:50:08 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:50:08 --> Helper loaded: url_helper
INFO - 2025-11-17 22:50:08 --> Helper loaded: file_helper
INFO - 2025-11-17 22:50:08 --> Helper loaded: main_helper
INFO - 2025-11-17 22:50:08 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:50:08 --> Database Driver Class Initialized
INFO - 2025-11-17 22:50:08 --> Email Class Initialized
DEBUG - 2025-11-17 22:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:50:08 --> Controller Class Initialized
INFO - 2025-11-17 22:50:08 --> Model "User_model" initialized
INFO - 2025-11-17 22:50:08 --> Model "Project_model" initialized
INFO - 2025-11-17 22:50:08 --> Helper loaded: form_helper
INFO - 2025-11-17 22:50:08 --> Form Validation Class Initialized
INFO - 2025-11-17 22:50:08 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 22:50:08 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 22:50:08 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 22:50:08 --> Model "Swot_model" initialized
INFO - 2025-11-17 22:50:08 --> Model "Swot_model" initialized
INFO - 2025-11-17 22:50:08 --> Model "Topk_service_model" initialized
INFO - 2025-11-17 22:50:08 --> Final output sent to browser
INFO - 2025-11-17 22:50:08 --> Total execution time: 0.0729
INFO - 2025-11-17 22:50:35 --> Config Class Initialized
INFO - 2025-11-17 22:50:35 --> Hooks Class Initialized
INFO - 2025-11-17 22:50:35 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:50:35 --> Utf8 Class Initialized
INFO - 2025-11-17 22:50:35 --> URI Class Initialized
INFO - 2025-11-17 22:50:35 --> Router Class Initialized
INFO - 2025-11-17 22:50:35 --> Output Class Initialized
INFO - 2025-11-17 22:50:35 --> Security Class Initialized
INFO - 2025-11-17 22:50:35 --> Input Class Initialized
INFO - 2025-11-17 22:50:35 --> Language Class Initialized
INFO - 2025-11-17 22:50:35 --> Loader Class Initialized
INFO - 2025-11-17 22:50:35 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:50:35 --> Helper loaded: url_helper
INFO - 2025-11-17 22:50:35 --> Helper loaded: file_helper
INFO - 2025-11-17 22:50:35 --> Helper loaded: main_helper
INFO - 2025-11-17 22:50:35 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:50:35 --> Database Driver Class Initialized
INFO - 2025-11-17 22:50:35 --> Email Class Initialized
DEBUG - 2025-11-17 22:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:50:35 --> Controller Class Initialized
INFO - 2025-11-17 22:50:35 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:50:35 --> Model "User_model" initialized
INFO - 2025-11-17 22:50:35 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:50:35 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:50:35 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:50:35 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:50:35 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-17 22:50:35 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:50:35 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:50:35 --> Final output sent to browser
INFO - 2025-11-17 22:50:35 --> Total execution time: 0.0815
INFO - 2025-11-17 22:50:37 --> Config Class Initialized
INFO - 2025-11-17 22:50:37 --> Hooks Class Initialized
INFO - 2025-11-17 22:50:37 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:50:37 --> Utf8 Class Initialized
INFO - 2025-11-17 22:50:37 --> URI Class Initialized
INFO - 2025-11-17 22:50:37 --> Router Class Initialized
INFO - 2025-11-17 22:50:37 --> Output Class Initialized
INFO - 2025-11-17 22:50:37 --> Security Class Initialized
INFO - 2025-11-17 22:50:37 --> Input Class Initialized
INFO - 2025-11-17 22:50:37 --> Language Class Initialized
INFO - 2025-11-17 22:50:37 --> Loader Class Initialized
INFO - 2025-11-17 22:50:37 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:50:37 --> Helper loaded: url_helper
INFO - 2025-11-17 22:50:37 --> Helper loaded: file_helper
INFO - 2025-11-17 22:50:37 --> Helper loaded: main_helper
INFO - 2025-11-17 22:50:37 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:50:37 --> Database Driver Class Initialized
INFO - 2025-11-17 22:50:37 --> Email Class Initialized
DEBUG - 2025-11-17 22:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:50:37 --> Controller Class Initialized
INFO - 2025-11-17 22:50:37 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:50:37 --> Model "User_model" initialized
INFO - 2025-11-17 22:50:37 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:50:37 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:50:37 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:50:37 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:50:37 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/package.php
INFO - 2025-11-17 22:50:37 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:50:37 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:50:37 --> Final output sent to browser
INFO - 2025-11-17 22:50:37 --> Total execution time: 0.1038
INFO - 2025-11-17 22:50:51 --> Config Class Initialized
INFO - 2025-11-17 22:50:51 --> Hooks Class Initialized
INFO - 2025-11-17 22:50:51 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:50:51 --> Utf8 Class Initialized
INFO - 2025-11-17 22:50:51 --> URI Class Initialized
INFO - 2025-11-17 22:50:51 --> Router Class Initialized
INFO - 2025-11-17 22:50:51 --> Output Class Initialized
INFO - 2025-11-17 22:50:51 --> Security Class Initialized
INFO - 2025-11-17 22:50:51 --> Input Class Initialized
INFO - 2025-11-17 22:50:51 --> Language Class Initialized
INFO - 2025-11-17 22:50:51 --> Loader Class Initialized
INFO - 2025-11-17 22:50:51 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:50:51 --> Helper loaded: url_helper
INFO - 2025-11-17 22:50:51 --> Helper loaded: file_helper
INFO - 2025-11-17 22:50:51 --> Helper loaded: main_helper
INFO - 2025-11-17 22:50:51 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:50:51 --> Database Driver Class Initialized
INFO - 2025-11-17 22:50:51 --> Email Class Initialized
DEBUG - 2025-11-17 22:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:50:51 --> Controller Class Initialized
INFO - 2025-11-17 22:50:51 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:50:51 --> Model "User_model" initialized
INFO - 2025-11-17 22:50:51 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:50:51 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:50:51 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:50:51 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:50:51 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/package.php
INFO - 2025-11-17 22:50:51 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:50:51 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:50:51 --> Final output sent to browser
INFO - 2025-11-17 22:50:51 --> Total execution time: 0.1219
INFO - 2025-11-17 22:51:03 --> Config Class Initialized
INFO - 2025-11-17 22:51:03 --> Hooks Class Initialized
INFO - 2025-11-17 22:51:03 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:51:03 --> Utf8 Class Initialized
INFO - 2025-11-17 22:51:03 --> URI Class Initialized
INFO - 2025-11-17 22:51:03 --> Router Class Initialized
INFO - 2025-11-17 22:51:03 --> Output Class Initialized
INFO - 2025-11-17 22:51:03 --> Security Class Initialized
INFO - 2025-11-17 22:51:03 --> Input Class Initialized
INFO - 2025-11-17 22:51:03 --> Language Class Initialized
INFO - 2025-11-17 22:51:03 --> Loader Class Initialized
INFO - 2025-11-17 22:51:03 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:51:03 --> Helper loaded: url_helper
INFO - 2025-11-17 22:51:03 --> Helper loaded: file_helper
INFO - 2025-11-17 22:51:03 --> Helper loaded: main_helper
INFO - 2025-11-17 22:51:03 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:51:03 --> Database Driver Class Initialized
INFO - 2025-11-17 22:51:03 --> Email Class Initialized
DEBUG - 2025-11-17 22:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:51:03 --> Controller Class Initialized
INFO - 2025-11-17 22:51:03 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:51:03 --> Model "User_model" initialized
INFO - 2025-11-17 22:51:03 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:51:03 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:51:03 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:51:03 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:51:03 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/package.php
INFO - 2025-11-17 22:51:03 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:51:03 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:51:03 --> Final output sent to browser
INFO - 2025-11-17 22:51:03 --> Total execution time: 0.1052
INFO - 2025-11-17 22:51:12 --> Config Class Initialized
INFO - 2025-11-17 22:51:12 --> Hooks Class Initialized
INFO - 2025-11-17 22:51:12 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:51:12 --> Utf8 Class Initialized
INFO - 2025-11-17 22:51:12 --> URI Class Initialized
INFO - 2025-11-17 22:51:12 --> Router Class Initialized
INFO - 2025-11-17 22:51:12 --> Output Class Initialized
INFO - 2025-11-17 22:51:12 --> Security Class Initialized
INFO - 2025-11-17 22:51:12 --> Input Class Initialized
INFO - 2025-11-17 22:51:12 --> Language Class Initialized
INFO - 2025-11-17 22:51:12 --> Loader Class Initialized
INFO - 2025-11-17 22:51:12 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:51:12 --> Helper loaded: url_helper
INFO - 2025-11-17 22:51:12 --> Helper loaded: file_helper
INFO - 2025-11-17 22:51:12 --> Helper loaded: main_helper
INFO - 2025-11-17 22:51:12 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:51:12 --> Database Driver Class Initialized
INFO - 2025-11-17 22:51:12 --> Email Class Initialized
DEBUG - 2025-11-17 22:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:51:12 --> Controller Class Initialized
INFO - 2025-11-17 22:51:12 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:51:12 --> Model "User_model" initialized
INFO - 2025-11-17 22:51:12 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:51:12 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:51:12 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:51:12 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:51:12 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/package.php
INFO - 2025-11-17 22:51:12 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:51:12 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:51:12 --> Final output sent to browser
INFO - 2025-11-17 22:51:12 --> Total execution time: 0.0962
INFO - 2025-11-17 22:51:20 --> Config Class Initialized
INFO - 2025-11-17 22:51:20 --> Hooks Class Initialized
INFO - 2025-11-17 22:51:20 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:51:20 --> Utf8 Class Initialized
INFO - 2025-11-17 22:51:20 --> URI Class Initialized
INFO - 2025-11-17 22:51:20 --> Router Class Initialized
INFO - 2025-11-17 22:51:20 --> Output Class Initialized
INFO - 2025-11-17 22:51:20 --> Security Class Initialized
INFO - 2025-11-17 22:51:20 --> Input Class Initialized
INFO - 2025-11-17 22:51:20 --> Language Class Initialized
INFO - 2025-11-17 22:51:20 --> Loader Class Initialized
INFO - 2025-11-17 22:51:20 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:51:20 --> Helper loaded: url_helper
INFO - 2025-11-17 22:51:20 --> Helper loaded: file_helper
INFO - 2025-11-17 22:51:20 --> Helper loaded: main_helper
INFO - 2025-11-17 22:51:20 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:51:20 --> Database Driver Class Initialized
INFO - 2025-11-17 22:51:20 --> Email Class Initialized
DEBUG - 2025-11-17 22:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:51:20 --> Controller Class Initialized
INFO - 2025-11-17 22:51:20 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:51:20 --> Model "User_model" initialized
INFO - 2025-11-17 22:51:20 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:51:20 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:51:20 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:51:20 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:51:20 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/package.php
INFO - 2025-11-17 22:51:20 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:51:20 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:51:20 --> Final output sent to browser
INFO - 2025-11-17 22:51:20 --> Total execution time: 0.0870
INFO - 2025-11-17 22:52:42 --> Config Class Initialized
INFO - 2025-11-17 22:52:42 --> Hooks Class Initialized
INFO - 2025-11-17 22:52:42 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:52:42 --> Utf8 Class Initialized
INFO - 2025-11-17 22:52:42 --> URI Class Initialized
INFO - 2025-11-17 22:52:42 --> Router Class Initialized
INFO - 2025-11-17 22:52:42 --> Output Class Initialized
INFO - 2025-11-17 22:52:42 --> Security Class Initialized
INFO - 2025-11-17 22:52:42 --> Input Class Initialized
INFO - 2025-11-17 22:52:42 --> Language Class Initialized
INFO - 2025-11-17 22:52:42 --> Loader Class Initialized
INFO - 2025-11-17 22:52:42 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:52:42 --> Helper loaded: url_helper
INFO - 2025-11-17 22:52:42 --> Helper loaded: file_helper
INFO - 2025-11-17 22:52:42 --> Helper loaded: main_helper
INFO - 2025-11-17 22:52:42 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:52:42 --> Database Driver Class Initialized
INFO - 2025-11-17 22:52:42 --> Email Class Initialized
DEBUG - 2025-11-17 22:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:52:42 --> Controller Class Initialized
INFO - 2025-11-17 22:52:42 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:52:42 --> Model "User_model" initialized
INFO - 2025-11-17 22:52:42 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:52:42 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:52:42 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:52:42 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:52:42 --> File loaded: D:\laragon\www\acumena\application\views\dashboard.php
INFO - 2025-11-17 22:52:42 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:52:42 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:52:42 --> Final output sent to browser
INFO - 2025-11-17 22:52:42 --> Total execution time: 0.0873
INFO - 2025-11-17 22:52:42 --> Config Class Initialized
INFO - 2025-11-17 22:52:42 --> Hooks Class Initialized
INFO - 2025-11-17 22:52:42 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:52:42 --> Utf8 Class Initialized
INFO - 2025-11-17 22:52:42 --> URI Class Initialized
INFO - 2025-11-17 22:52:42 --> Router Class Initialized
INFO - 2025-11-17 22:52:42 --> Output Class Initialized
INFO - 2025-11-17 22:52:42 --> Security Class Initialized
INFO - 2025-11-17 22:52:42 --> Input Class Initialized
INFO - 2025-11-17 22:52:42 --> Language Class Initialized
INFO - 2025-11-17 22:52:42 --> Loader Class Initialized
INFO - 2025-11-17 22:52:42 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:52:42 --> Helper loaded: url_helper
INFO - 2025-11-17 22:52:42 --> Helper loaded: file_helper
INFO - 2025-11-17 22:52:42 --> Helper loaded: main_helper
INFO - 2025-11-17 22:52:42 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:52:42 --> Database Driver Class Initialized
INFO - 2025-11-17 22:52:42 --> Email Class Initialized
DEBUG - 2025-11-17 22:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:52:42 --> Controller Class Initialized
INFO - 2025-11-17 22:52:42 --> Model "User_model" initialized
INFO - 2025-11-17 22:52:42 --> Model "Project_model" initialized
INFO - 2025-11-17 22:52:42 --> Helper loaded: form_helper
INFO - 2025-11-17 22:52:42 --> Form Validation Class Initialized
INFO - 2025-11-17 22:52:42 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 22:52:42 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 22:52:42 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 22:52:42 --> Model "Swot_model" initialized
INFO - 2025-11-17 22:52:42 --> Model "Swot_model" initialized
INFO - 2025-11-17 22:52:42 --> Model "Topk_service_model" initialized
INFO - 2025-11-17 22:52:42 --> Final output sent to browser
INFO - 2025-11-17 22:52:42 --> Total execution time: 0.0671
INFO - 2025-11-17 22:52:44 --> Config Class Initialized
INFO - 2025-11-17 22:52:44 --> Hooks Class Initialized
INFO - 2025-11-17 22:52:44 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:52:44 --> Utf8 Class Initialized
INFO - 2025-11-17 22:52:44 --> URI Class Initialized
INFO - 2025-11-17 22:52:44 --> Router Class Initialized
INFO - 2025-11-17 22:52:44 --> Output Class Initialized
INFO - 2025-11-17 22:52:44 --> Security Class Initialized
INFO - 2025-11-17 22:52:44 --> Input Class Initialized
INFO - 2025-11-17 22:52:44 --> Language Class Initialized
INFO - 2025-11-17 22:52:44 --> Loader Class Initialized
INFO - 2025-11-17 22:52:44 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:52:44 --> Helper loaded: url_helper
INFO - 2025-11-17 22:52:44 --> Helper loaded: file_helper
INFO - 2025-11-17 22:52:44 --> Helper loaded: main_helper
INFO - 2025-11-17 22:52:44 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:52:44 --> Database Driver Class Initialized
INFO - 2025-11-17 22:52:44 --> Email Class Initialized
DEBUG - 2025-11-17 22:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:52:44 --> Controller Class Initialized
INFO - 2025-11-17 22:52:44 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:52:44 --> Model "User_model" initialized
INFO - 2025-11-17 22:52:44 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:52:44 --> Model "Project_model" initialized
INFO - 2025-11-17 22:52:44 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:52:44 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:52:44 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:52:44 --> File loaded: D:\laragon\www\acumena\application\views\projects/index.php
INFO - 2025-11-17 22:52:44 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:52:44 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:52:44 --> Final output sent to browser
INFO - 2025-11-17 22:52:44 --> Total execution time: 0.0766
INFO - 2025-11-17 22:52:45 --> Config Class Initialized
INFO - 2025-11-17 22:52:45 --> Hooks Class Initialized
INFO - 2025-11-17 22:52:45 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:52:45 --> Utf8 Class Initialized
INFO - 2025-11-17 22:52:45 --> URI Class Initialized
INFO - 2025-11-17 22:52:45 --> Router Class Initialized
INFO - 2025-11-17 22:52:45 --> Output Class Initialized
INFO - 2025-11-17 22:52:45 --> Security Class Initialized
INFO - 2025-11-17 22:52:45 --> Input Class Initialized
INFO - 2025-11-17 22:52:45 --> Language Class Initialized
INFO - 2025-11-17 22:52:45 --> Loader Class Initialized
INFO - 2025-11-17 22:52:45 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:52:45 --> Helper loaded: url_helper
INFO - 2025-11-17 22:52:45 --> Helper loaded: file_helper
INFO - 2025-11-17 22:52:45 --> Helper loaded: main_helper
INFO - 2025-11-17 22:52:45 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:52:45 --> Database Driver Class Initialized
INFO - 2025-11-17 22:52:45 --> Email Class Initialized
DEBUG - 2025-11-17 22:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:52:45 --> Controller Class Initialized
INFO - 2025-11-17 22:52:45 --> Model "User_model" initialized
INFO - 2025-11-17 22:52:45 --> Model "Project_model" initialized
INFO - 2025-11-17 22:52:45 --> Helper loaded: form_helper
INFO - 2025-11-17 22:52:45 --> Form Validation Class Initialized
INFO - 2025-11-17 22:52:45 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 22:52:45 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 22:52:45 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 22:52:45 --> Model "Swot_model" initialized
INFO - 2025-11-17 22:52:45 --> Model "Swot_model" initialized
INFO - 2025-11-17 22:52:45 --> Model "Topk_service_model" initialized
INFO - 2025-11-17 22:52:45 --> Final output sent to browser
INFO - 2025-11-17 22:52:45 --> Total execution time: 0.0763
INFO - 2025-11-17 22:52:46 --> Config Class Initialized
INFO - 2025-11-17 22:52:46 --> Hooks Class Initialized
INFO - 2025-11-17 22:52:46 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:52:46 --> Utf8 Class Initialized
INFO - 2025-11-17 22:52:46 --> URI Class Initialized
INFO - 2025-11-17 22:52:46 --> Router Class Initialized
INFO - 2025-11-17 22:52:46 --> Output Class Initialized
INFO - 2025-11-17 22:52:46 --> Security Class Initialized
INFO - 2025-11-17 22:52:46 --> Input Class Initialized
INFO - 2025-11-17 22:52:46 --> Language Class Initialized
INFO - 2025-11-17 22:52:46 --> Loader Class Initialized
INFO - 2025-11-17 22:52:46 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:52:46 --> Helper loaded: url_helper
INFO - 2025-11-17 22:52:46 --> Helper loaded: file_helper
INFO - 2025-11-17 22:52:46 --> Helper loaded: main_helper
INFO - 2025-11-17 22:52:46 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:52:46 --> Database Driver Class Initialized
INFO - 2025-11-17 22:52:46 --> Email Class Initialized
DEBUG - 2025-11-17 22:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:52:46 --> Controller Class Initialized
INFO - 2025-11-17 22:52:46 --> Model "Subscription_model" initialized
INFO - 2025-11-17 22:52:46 --> Model "User_model" initialized
INFO - 2025-11-17 22:52:46 --> Model "Auth_model" initialized
INFO - 2025-11-17 22:52:46 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 22:52:46 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 22:52:46 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 22:52:46 --> File loaded: D:\laragon\www\acumena\application\views\dashboard.php
INFO - 2025-11-17 22:52:46 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 22:52:46 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 22:52:46 --> Final output sent to browser
INFO - 2025-11-17 22:52:46 --> Total execution time: 0.0855
INFO - 2025-11-17 22:52:46 --> Config Class Initialized
INFO - 2025-11-17 22:52:46 --> Hooks Class Initialized
INFO - 2025-11-17 22:52:46 --> UTF-8 Support Enabled
INFO - 2025-11-17 22:52:46 --> Utf8 Class Initialized
INFO - 2025-11-17 22:52:46 --> URI Class Initialized
INFO - 2025-11-17 22:52:46 --> Router Class Initialized
INFO - 2025-11-17 22:52:46 --> Output Class Initialized
INFO - 2025-11-17 22:52:46 --> Security Class Initialized
INFO - 2025-11-17 22:52:46 --> Input Class Initialized
INFO - 2025-11-17 22:52:46 --> Language Class Initialized
INFO - 2025-11-17 22:52:46 --> Loader Class Initialized
INFO - 2025-11-17 22:52:46 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 22:52:46 --> Helper loaded: url_helper
INFO - 2025-11-17 22:52:46 --> Helper loaded: file_helper
INFO - 2025-11-17 22:52:46 --> Helper loaded: main_helper
INFO - 2025-11-17 22:52:46 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 22:52:46 --> Database Driver Class Initialized
INFO - 2025-11-17 22:52:46 --> Email Class Initialized
DEBUG - 2025-11-17 22:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 22:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 22:52:46 --> Controller Class Initialized
INFO - 2025-11-17 22:52:46 --> Model "User_model" initialized
INFO - 2025-11-17 22:52:46 --> Model "Project_model" initialized
INFO - 2025-11-17 22:52:46 --> Helper loaded: form_helper
INFO - 2025-11-17 22:52:46 --> Form Validation Class Initialized
INFO - 2025-11-17 22:52:46 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 22:52:46 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 22:52:46 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 22:52:46 --> Model "Swot_model" initialized
INFO - 2025-11-17 22:52:46 --> Model "Swot_model" initialized
INFO - 2025-11-17 22:52:46 --> Model "Topk_service_model" initialized
INFO - 2025-11-17 22:52:46 --> Final output sent to browser
INFO - 2025-11-17 22:52:46 --> Total execution time: 0.0535
INFO - 2025-11-17 23:06:42 --> Config Class Initialized
INFO - 2025-11-17 23:06:42 --> Hooks Class Initialized
INFO - 2025-11-17 23:06:42 --> UTF-8 Support Enabled
INFO - 2025-11-17 23:06:42 --> Utf8 Class Initialized
INFO - 2025-11-17 23:06:42 --> URI Class Initialized
INFO - 2025-11-17 23:06:42 --> Router Class Initialized
INFO - 2025-11-17 23:06:42 --> Output Class Initialized
INFO - 2025-11-17 23:06:42 --> Security Class Initialized
INFO - 2025-11-17 23:06:42 --> Input Class Initialized
INFO - 2025-11-17 23:06:42 --> Language Class Initialized
INFO - 2025-11-17 23:06:42 --> Loader Class Initialized
INFO - 2025-11-17 23:06:42 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 23:06:42 --> Helper loaded: url_helper
INFO - 2025-11-17 23:06:42 --> Helper loaded: file_helper
INFO - 2025-11-17 23:06:42 --> Helper loaded: main_helper
INFO - 2025-11-17 23:06:42 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 23:06:42 --> Database Driver Class Initialized
INFO - 2025-11-17 23:06:42 --> Email Class Initialized
DEBUG - 2025-11-17 23:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 23:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 23:06:42 --> Controller Class Initialized
INFO - 2025-11-17 23:06:42 --> Model "Subscription_model" initialized
INFO - 2025-11-17 23:06:42 --> Model "User_model" initialized
INFO - 2025-11-17 23:06:42 --> Model "Auth_model" initialized
INFO - 2025-11-17 23:06:42 --> Config Class Initialized
INFO - 2025-11-17 23:06:42 --> Hooks Class Initialized
INFO - 2025-11-17 23:06:42 --> UTF-8 Support Enabled
INFO - 2025-11-17 23:06:42 --> Utf8 Class Initialized
INFO - 2025-11-17 23:06:42 --> URI Class Initialized
INFO - 2025-11-17 23:06:42 --> Router Class Initialized
INFO - 2025-11-17 23:06:42 --> Output Class Initialized
INFO - 2025-11-17 23:06:42 --> Security Class Initialized
INFO - 2025-11-17 23:06:42 --> Input Class Initialized
INFO - 2025-11-17 23:06:42 --> Language Class Initialized
INFO - 2025-11-17 23:06:42 --> Loader Class Initialized
INFO - 2025-11-17 23:06:42 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 23:06:42 --> Helper loaded: url_helper
INFO - 2025-11-17 23:06:42 --> Helper loaded: file_helper
INFO - 2025-11-17 23:06:42 --> Helper loaded: main_helper
INFO - 2025-11-17 23:06:42 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 23:06:42 --> Database Driver Class Initialized
INFO - 2025-11-17 23:06:42 --> Email Class Initialized
DEBUG - 2025-11-17 23:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 23:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 23:06:42 --> Controller Class Initialized
INFO - 2025-11-17 23:06:42 --> Config Class Initialized
INFO - 2025-11-17 23:06:42 --> Hooks Class Initialized
INFO - 2025-11-17 23:06:42 --> UTF-8 Support Enabled
INFO - 2025-11-17 23:06:42 --> Utf8 Class Initialized
INFO - 2025-11-17 23:06:42 --> URI Class Initialized
INFO - 2025-11-17 23:06:42 --> Router Class Initialized
INFO - 2025-11-17 23:06:42 --> Output Class Initialized
INFO - 2025-11-17 23:06:42 --> Security Class Initialized
INFO - 2025-11-17 23:06:42 --> Input Class Initialized
INFO - 2025-11-17 23:06:42 --> Language Class Initialized
INFO - 2025-11-17 23:06:42 --> Loader Class Initialized
INFO - 2025-11-17 23:06:42 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 23:06:42 --> Helper loaded: url_helper
INFO - 2025-11-17 23:06:42 --> Helper loaded: file_helper
INFO - 2025-11-17 23:06:42 --> Helper loaded: main_helper
INFO - 2025-11-17 23:06:42 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 23:06:42 --> Database Driver Class Initialized
INFO - 2025-11-17 23:06:42 --> Email Class Initialized
DEBUG - 2025-11-17 23:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 23:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 23:06:42 --> Controller Class Initialized
INFO - 2025-11-17 23:06:42 --> Model "Subscription_model" initialized
INFO - 2025-11-17 23:06:42 --> Model "User_model" initialized
INFO - 2025-11-17 23:06:42 --> Model "Auth_model" initialized
INFO - 2025-11-17 23:06:42 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-17 23:06:42 --> Final output sent to browser
INFO - 2025-11-17 23:06:42 --> Total execution time: 0.1638
INFO - 2025-11-17 23:06:47 --> Config Class Initialized
INFO - 2025-11-17 23:06:47 --> Hooks Class Initialized
INFO - 2025-11-17 23:06:47 --> UTF-8 Support Enabled
INFO - 2025-11-17 23:06:47 --> Utf8 Class Initialized
INFO - 2025-11-17 23:06:47 --> URI Class Initialized
INFO - 2025-11-17 23:06:47 --> Router Class Initialized
INFO - 2025-11-17 23:06:47 --> Output Class Initialized
INFO - 2025-11-17 23:06:47 --> Security Class Initialized
INFO - 2025-11-17 23:06:47 --> Input Class Initialized
INFO - 2025-11-17 23:06:47 --> Language Class Initialized
INFO - 2025-11-17 23:06:47 --> Loader Class Initialized
INFO - 2025-11-17 23:06:47 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 23:06:47 --> Helper loaded: url_helper
INFO - 2025-11-17 23:06:47 --> Helper loaded: file_helper
INFO - 2025-11-17 23:06:47 --> Helper loaded: main_helper
INFO - 2025-11-17 23:06:47 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 23:06:47 --> Database Driver Class Initialized
INFO - 2025-11-17 23:06:47 --> Email Class Initialized
DEBUG - 2025-11-17 23:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 23:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 23:06:47 --> Controller Class Initialized
INFO - 2025-11-17 23:06:47 --> Model "Subscription_model" initialized
INFO - 2025-11-17 23:06:47 --> Model "User_model" initialized
INFO - 2025-11-17 23:06:47 --> Model "Auth_model" initialized
INFO - 2025-11-17 23:06:47 --> Final output sent to browser
INFO - 2025-11-17 23:06:47 --> Total execution time: 0.2693
INFO - 2025-11-17 23:06:48 --> Config Class Initialized
INFO - 2025-11-17 23:06:48 --> Hooks Class Initialized
INFO - 2025-11-17 23:06:48 --> UTF-8 Support Enabled
INFO - 2025-11-17 23:06:48 --> Utf8 Class Initialized
INFO - 2025-11-17 23:06:48 --> URI Class Initialized
INFO - 2025-11-17 23:06:48 --> Router Class Initialized
INFO - 2025-11-17 23:06:48 --> Output Class Initialized
INFO - 2025-11-17 23:06:48 --> Security Class Initialized
INFO - 2025-11-17 23:06:48 --> Input Class Initialized
INFO - 2025-11-17 23:06:48 --> Language Class Initialized
INFO - 2025-11-17 23:06:48 --> Loader Class Initialized
INFO - 2025-11-17 23:06:48 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 23:06:48 --> Helper loaded: url_helper
INFO - 2025-11-17 23:06:48 --> Helper loaded: file_helper
INFO - 2025-11-17 23:06:48 --> Helper loaded: main_helper
INFO - 2025-11-17 23:06:48 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 23:06:48 --> Database Driver Class Initialized
INFO - 2025-11-17 23:06:48 --> Email Class Initialized
DEBUG - 2025-11-17 23:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 23:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 23:06:48 --> Controller Class Initialized
INFO - 2025-11-17 23:06:49 --> Model "Subscription_model" initialized
INFO - 2025-11-17 23:06:49 --> Model "User_model" initialized
INFO - 2025-11-17 23:06:49 --> Model "Auth_model" initialized
INFO - 2025-11-17 23:06:49 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-17 23:06:49 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-17 23:06:49 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-17 23:06:49 --> File loaded: D:\laragon\www\acumena\application\views\dashboard.php
INFO - 2025-11-17 23:06:49 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-17 23:06:49 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-17 23:06:49 --> Final output sent to browser
INFO - 2025-11-17 23:06:49 --> Total execution time: 0.1053
INFO - 2025-11-17 23:06:49 --> Config Class Initialized
INFO - 2025-11-17 23:06:49 --> Hooks Class Initialized
INFO - 2025-11-17 23:06:49 --> UTF-8 Support Enabled
INFO - 2025-11-17 23:06:49 --> Utf8 Class Initialized
INFO - 2025-11-17 23:06:49 --> URI Class Initialized
INFO - 2025-11-17 23:06:49 --> Router Class Initialized
INFO - 2025-11-17 23:06:49 --> Output Class Initialized
INFO - 2025-11-17 23:06:49 --> Security Class Initialized
INFO - 2025-11-17 23:06:49 --> Input Class Initialized
INFO - 2025-11-17 23:06:49 --> Language Class Initialized
INFO - 2025-11-17 23:06:49 --> Loader Class Initialized
INFO - 2025-11-17 23:06:49 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-17 23:06:49 --> Helper loaded: url_helper
INFO - 2025-11-17 23:06:49 --> Helper loaded: file_helper
INFO - 2025-11-17 23:06:49 --> Helper loaded: main_helper
INFO - 2025-11-17 23:06:49 --> Helper loaded: sendgrid_helper
INFO - 2025-11-17 23:06:49 --> Database Driver Class Initialized
INFO - 2025-11-17 23:06:49 --> Email Class Initialized
DEBUG - 2025-11-17 23:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 23:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 23:06:49 --> Controller Class Initialized
INFO - 2025-11-17 23:06:49 --> Model "User_model" initialized
INFO - 2025-11-17 23:06:49 --> Model "Project_model" initialized
INFO - 2025-11-17 23:06:49 --> Helper loaded: form_helper
INFO - 2025-11-17 23:06:49 --> Form Validation Class Initialized
INFO - 2025-11-17 23:06:49 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-17 23:06:49 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-17 23:06:49 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-17 23:06:49 --> Model "Swot_model" initialized
INFO - 2025-11-17 23:06:49 --> Model "Swot_model" initialized
INFO - 2025-11-17 23:06:49 --> Model "Topk_service_model" initialized
INFO - 2025-11-17 23:06:49 --> Final output sent to browser
INFO - 2025-11-17 23:06:49 --> Total execution time: 0.0678
