<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-11-19 00:18:38 --> Config Class Initialized
INFO - 2025-11-19 00:18:38 --> Hooks Class Initialized
INFO - 2025-11-19 00:18:38 --> UTF-8 Support Enabled
INFO - 2025-11-19 00:18:38 --> Utf8 Class Initialized
INFO - 2025-11-19 00:18:38 --> URI Class Initialized
INFO - 2025-11-19 00:18:39 --> Router Class Initialized
INFO - 2025-11-19 00:18:39 --> Output Class Initialized
INFO - 2025-11-19 00:18:39 --> Security Class Initialized
INFO - 2025-11-19 00:18:39 --> Input Class Initialized
INFO - 2025-11-19 00:18:39 --> Language Class Initialized
INFO - 2025-11-19 00:18:39 --> Loader Class Initialized
INFO - 2025-11-19 00:18:39 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-19 00:18:39 --> Helper loaded: url_helper
INFO - 2025-11-19 00:18:39 --> Helper loaded: file_helper
INFO - 2025-11-19 00:18:39 --> Helper loaded: main_helper
INFO - 2025-11-19 00:18:39 --> Helper loaded: sendgrid_helper
INFO - 2025-11-19 00:18:40 --> Database Driver Class Initialized
INFO - 2025-11-19 00:18:40 --> Email Class Initialized
DEBUG - 2025-11-19 00:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-19 00:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-19 00:18:40 --> Controller Class Initialized
INFO - 2025-11-19 00:18:41 --> Model "Subscription_model" initialized
INFO - 2025-11-19 00:18:41 --> Model "User_model" initialized
INFO - 2025-11-19 00:18:41 --> Model "Auth_model" initialized
INFO - 2025-11-19 00:18:41 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-19 00:18:41 --> Final output sent to browser
INFO - 2025-11-19 00:18:41 --> Total execution time: 2.8421
INFO - 2025-11-19 01:24:57 --> Config Class Initialized
INFO - 2025-11-19 01:24:57 --> Hooks Class Initialized
INFO - 2025-11-19 01:24:57 --> UTF-8 Support Enabled
INFO - 2025-11-19 01:24:57 --> Utf8 Class Initialized
INFO - 2025-11-19 01:24:57 --> URI Class Initialized
INFO - 2025-11-19 01:24:58 --> Router Class Initialized
INFO - 2025-11-19 01:24:58 --> Output Class Initialized
INFO - 2025-11-19 01:24:58 --> Security Class Initialized
INFO - 2025-11-19 01:24:58 --> Input Class Initialized
INFO - 2025-11-19 01:24:58 --> Language Class Initialized
INFO - 2025-11-19 01:24:58 --> Loader Class Initialized
INFO - 2025-11-19 01:24:58 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-19 01:24:58 --> Helper loaded: url_helper
INFO - 2025-11-19 01:24:58 --> Helper loaded: file_helper
INFO - 2025-11-19 01:24:58 --> Helper loaded: main_helper
INFO - 2025-11-19 01:24:58 --> Helper loaded: sendgrid_helper
INFO - 2025-11-19 01:24:58 --> Database Driver Class Initialized
INFO - 2025-11-19 01:24:58 --> Email Class Initialized
DEBUG - 2025-11-19 01:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-19 01:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-19 01:24:59 --> Controller Class Initialized
INFO - 2025-11-19 01:24:59 --> Model "Subscription_model" initialized
INFO - 2025-11-19 01:24:59 --> Model "User_model" initialized
INFO - 2025-11-19 01:24:59 --> Model "Auth_model" initialized
INFO - 2025-11-19 01:24:59 --> Final output sent to browser
INFO - 2025-11-19 01:24:59 --> Total execution time: 1.8961
INFO - 2025-11-19 01:25:01 --> Config Class Initialized
INFO - 2025-11-19 01:25:01 --> Hooks Class Initialized
INFO - 2025-11-19 01:25:01 --> UTF-8 Support Enabled
INFO - 2025-11-19 01:25:01 --> Utf8 Class Initialized
INFO - 2025-11-19 01:25:01 --> URI Class Initialized
INFO - 2025-11-19 01:25:01 --> Router Class Initialized
INFO - 2025-11-19 01:25:01 --> Output Class Initialized
INFO - 2025-11-19 01:25:01 --> Security Class Initialized
INFO - 2025-11-19 01:25:01 --> Input Class Initialized
INFO - 2025-11-19 01:25:01 --> Language Class Initialized
INFO - 2025-11-19 01:25:01 --> Loader Class Initialized
INFO - 2025-11-19 01:25:01 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-19 01:25:01 --> Helper loaded: url_helper
INFO - 2025-11-19 01:25:01 --> Helper loaded: file_helper
INFO - 2025-11-19 01:25:01 --> Helper loaded: main_helper
INFO - 2025-11-19 01:25:01 --> Helper loaded: sendgrid_helper
INFO - 2025-11-19 01:25:01 --> Database Driver Class Initialized
INFO - 2025-11-19 01:25:01 --> Email Class Initialized
DEBUG - 2025-11-19 01:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-19 01:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-19 01:25:01 --> Controller Class Initialized
INFO - 2025-11-19 01:25:01 --> Model "Subscription_model" initialized
INFO - 2025-11-19 01:25:01 --> Model "User_model" initialized
INFO - 2025-11-19 01:25:01 --> Model "Auth_model" initialized
INFO - 2025-11-19 01:25:01 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-19 01:25:01 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-19 01:25:01 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-19 01:25:01 --> File loaded: D:\laragon\www\acumena\application\views\dashboard.php
INFO - 2025-11-19 01:25:01 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-19 01:25:01 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-19 01:25:01 --> Final output sent to browser
INFO - 2025-11-19 01:25:01 --> Total execution time: 0.1447
INFO - 2025-11-19 01:25:01 --> Config Class Initialized
INFO - 2025-11-19 01:25:01 --> Hooks Class Initialized
INFO - 2025-11-19 01:25:01 --> UTF-8 Support Enabled
INFO - 2025-11-19 01:25:01 --> Utf8 Class Initialized
INFO - 2025-11-19 01:25:01 --> URI Class Initialized
INFO - 2025-11-19 01:25:01 --> Router Class Initialized
INFO - 2025-11-19 01:25:01 --> Output Class Initialized
INFO - 2025-11-19 01:25:01 --> Security Class Initialized
INFO - 2025-11-19 01:25:01 --> Input Class Initialized
INFO - 2025-11-19 01:25:01 --> Language Class Initialized
INFO - 2025-11-19 01:25:01 --> Loader Class Initialized
INFO - 2025-11-19 01:25:01 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-19 01:25:01 --> Helper loaded: url_helper
INFO - 2025-11-19 01:25:01 --> Helper loaded: file_helper
INFO - 2025-11-19 01:25:01 --> Helper loaded: main_helper
INFO - 2025-11-19 01:25:01 --> Helper loaded: sendgrid_helper
INFO - 2025-11-19 01:25:01 --> Database Driver Class Initialized
INFO - 2025-11-19 01:25:01 --> Email Class Initialized
DEBUG - 2025-11-19 01:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-19 01:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-19 01:25:01 --> Controller Class Initialized
INFO - 2025-11-19 01:25:01 --> Model "User_model" initialized
INFO - 2025-11-19 01:25:01 --> Model "Project_model" initialized
INFO - 2025-11-19 01:25:01 --> Helper loaded: form_helper
INFO - 2025-11-19 01:25:01 --> Form Validation Class Initialized
INFO - 2025-11-19 01:25:01 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-19 01:25:01 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-19 01:25:01 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-19 01:25:01 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:25:01 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:25:01 --> Model "Topk_service_model" initialized
INFO - 2025-11-19 01:25:01 --> Final output sent to browser
INFO - 2025-11-19 01:25:01 --> Total execution time: 0.1470
INFO - 2025-11-19 01:25:49 --> Config Class Initialized
INFO - 2025-11-19 01:25:49 --> Hooks Class Initialized
INFO - 2025-11-19 01:25:49 --> UTF-8 Support Enabled
INFO - 2025-11-19 01:25:49 --> Utf8 Class Initialized
INFO - 2025-11-19 01:25:49 --> URI Class Initialized
INFO - 2025-11-19 01:25:49 --> Router Class Initialized
INFO - 2025-11-19 01:25:50 --> Output Class Initialized
INFO - 2025-11-19 01:25:50 --> Security Class Initialized
INFO - 2025-11-19 01:25:50 --> Input Class Initialized
INFO - 2025-11-19 01:25:50 --> Language Class Initialized
INFO - 2025-11-19 01:25:50 --> Loader Class Initialized
INFO - 2025-11-19 01:25:50 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-19 01:25:50 --> Helper loaded: url_helper
INFO - 2025-11-19 01:25:50 --> Helper loaded: file_helper
INFO - 2025-11-19 01:25:50 --> Helper loaded: main_helper
INFO - 2025-11-19 01:25:50 --> Helper loaded: sendgrid_helper
INFO - 2025-11-19 01:25:50 --> Database Driver Class Initialized
INFO - 2025-11-19 01:25:50 --> Email Class Initialized
DEBUG - 2025-11-19 01:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-19 01:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-19 01:25:50 --> Controller Class Initialized
INFO - 2025-11-19 01:25:50 --> Model "Subscription_model" initialized
INFO - 2025-11-19 01:25:50 --> Model "User_model" initialized
INFO - 2025-11-19 01:25:50 --> Model "Auth_model" initialized
INFO - 2025-11-19 01:25:50 --> Model "Project_model" initialized
INFO - 2025-11-19 01:25:50 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-19 01:25:50 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-19 01:25:50 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-19 01:25:50 --> File loaded: D:\laragon\www\acumena\application\views\projects/profile.php
INFO - 2025-11-19 01:25:50 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-19 01:25:50 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-19 01:25:50 --> Final output sent to browser
INFO - 2025-11-19 01:25:50 --> Total execution time: 0.2319
INFO - 2025-11-19 01:25:50 --> Config Class Initialized
INFO - 2025-11-19 01:25:50 --> Hooks Class Initialized
INFO - 2025-11-19 01:25:50 --> UTF-8 Support Enabled
INFO - 2025-11-19 01:25:50 --> Utf8 Class Initialized
INFO - 2025-11-19 01:25:50 --> URI Class Initialized
INFO - 2025-11-19 01:25:50 --> Router Class Initialized
INFO - 2025-11-19 01:25:50 --> Output Class Initialized
INFO - 2025-11-19 01:25:50 --> Security Class Initialized
INFO - 2025-11-19 01:25:50 --> Input Class Initialized
INFO - 2025-11-19 01:25:50 --> Language Class Initialized
INFO - 2025-11-19 01:25:50 --> Loader Class Initialized
INFO - 2025-11-19 01:25:50 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-19 01:25:50 --> Helper loaded: url_helper
INFO - 2025-11-19 01:25:50 --> Helper loaded: file_helper
INFO - 2025-11-19 01:25:50 --> Helper loaded: main_helper
INFO - 2025-11-19 01:25:50 --> Helper loaded: sendgrid_helper
INFO - 2025-11-19 01:25:50 --> Database Driver Class Initialized
INFO - 2025-11-19 01:25:50 --> Email Class Initialized
DEBUG - 2025-11-19 01:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-19 01:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-19 01:25:50 --> Controller Class Initialized
INFO - 2025-11-19 01:25:50 --> Model "User_model" initialized
INFO - 2025-11-19 01:25:50 --> Model "Project_model" initialized
INFO - 2025-11-19 01:25:50 --> Helper loaded: form_helper
INFO - 2025-11-19 01:25:50 --> Form Validation Class Initialized
INFO - 2025-11-19 01:25:50 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-19 01:25:50 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-19 01:25:50 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-19 01:25:50 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:25:50 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:25:50 --> Model "Topk_service_model" initialized
INFO - 2025-11-19 01:25:50 --> Final output sent to browser
INFO - 2025-11-19 01:25:50 --> Total execution time: 0.0740
INFO - 2025-11-19 01:25:52 --> Config Class Initialized
INFO - 2025-11-19 01:25:52 --> Hooks Class Initialized
INFO - 2025-11-19 01:25:52 --> UTF-8 Support Enabled
INFO - 2025-11-19 01:25:52 --> Utf8 Class Initialized
INFO - 2025-11-19 01:25:52 --> URI Class Initialized
INFO - 2025-11-19 01:25:52 --> Router Class Initialized
INFO - 2025-11-19 01:25:52 --> Output Class Initialized
INFO - 2025-11-19 01:25:52 --> Security Class Initialized
INFO - 2025-11-19 01:25:52 --> Input Class Initialized
INFO - 2025-11-19 01:25:52 --> Language Class Initialized
INFO - 2025-11-19 01:25:52 --> Loader Class Initialized
INFO - 2025-11-19 01:25:52 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-19 01:25:52 --> Helper loaded: url_helper
INFO - 2025-11-19 01:25:52 --> Helper loaded: file_helper
INFO - 2025-11-19 01:25:52 --> Helper loaded: main_helper
INFO - 2025-11-19 01:25:52 --> Helper loaded: sendgrid_helper
INFO - 2025-11-19 01:25:52 --> Database Driver Class Initialized
INFO - 2025-11-19 01:25:52 --> Email Class Initialized
DEBUG - 2025-11-19 01:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-19 01:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-19 01:25:52 --> Controller Class Initialized
INFO - 2025-11-19 01:25:52 --> Model "User_model" initialized
INFO - 2025-11-19 01:25:52 --> Model "Project_model" initialized
INFO - 2025-11-19 01:25:52 --> Helper loaded: form_helper
INFO - 2025-11-19 01:25:52 --> Form Validation Class Initialized
INFO - 2025-11-19 01:25:52 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-19 01:25:52 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-19 01:25:52 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-19 01:25:52 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:25:52 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:25:52 --> Model "Topk_service_model" initialized
INFO - 2025-11-19 01:25:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-11-19 01:25:52 --> Final output sent to browser
INFO - 2025-11-19 01:25:52 --> Total execution time: 0.0820
INFO - 2025-11-19 01:25:52 --> Config Class Initialized
INFO - 2025-11-19 01:25:52 --> Hooks Class Initialized
INFO - 2025-11-19 01:25:52 --> UTF-8 Support Enabled
INFO - 2025-11-19 01:25:52 --> Utf8 Class Initialized
INFO - 2025-11-19 01:25:52 --> URI Class Initialized
INFO - 2025-11-19 01:25:52 --> Router Class Initialized
INFO - 2025-11-19 01:25:52 --> Output Class Initialized
INFO - 2025-11-19 01:25:52 --> Security Class Initialized
INFO - 2025-11-19 01:25:52 --> Input Class Initialized
INFO - 2025-11-19 01:25:52 --> Language Class Initialized
INFO - 2025-11-19 01:25:52 --> Loader Class Initialized
INFO - 2025-11-19 01:25:52 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-19 01:25:52 --> Helper loaded: url_helper
INFO - 2025-11-19 01:25:52 --> Helper loaded: file_helper
INFO - 2025-11-19 01:25:52 --> Helper loaded: main_helper
INFO - 2025-11-19 01:25:52 --> Helper loaded: sendgrid_helper
INFO - 2025-11-19 01:25:52 --> Database Driver Class Initialized
INFO - 2025-11-19 01:25:52 --> Email Class Initialized
DEBUG - 2025-11-19 01:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-19 01:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-19 01:25:52 --> Controller Class Initialized
INFO - 2025-11-19 01:25:52 --> Model "Subscription_model" initialized
INFO - 2025-11-19 01:25:52 --> Model "User_model" initialized
INFO - 2025-11-19 01:25:52 --> Model "Auth_model" initialized
INFO - 2025-11-19 01:25:52 --> Model "Project_model" initialized
INFO - 2025-11-19 01:25:52 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-19 01:25:52 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-19 01:25:52 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-19 01:25:52 --> File loaded: D:\laragon\www\acumena\application\views\projects/swot.php
INFO - 2025-11-19 01:25:52 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-19 01:25:52 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-19 01:25:52 --> Final output sent to browser
INFO - 2025-11-19 01:25:52 --> Total execution time: 0.1668
INFO - 2025-11-19 01:25:52 --> Config Class Initialized
INFO - 2025-11-19 01:25:52 --> Hooks Class Initialized
INFO - 2025-11-19 01:25:52 --> UTF-8 Support Enabled
INFO - 2025-11-19 01:25:52 --> Utf8 Class Initialized
INFO - 2025-11-19 01:25:52 --> URI Class Initialized
INFO - 2025-11-19 01:25:52 --> Router Class Initialized
INFO - 2025-11-19 01:25:52 --> Output Class Initialized
INFO - 2025-11-19 01:25:52 --> Security Class Initialized
INFO - 2025-11-19 01:25:52 --> Input Class Initialized
INFO - 2025-11-19 01:25:52 --> Language Class Initialized
INFO - 2025-11-19 01:25:52 --> Loader Class Initialized
INFO - 2025-11-19 01:25:52 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-19 01:25:52 --> Helper loaded: url_helper
INFO - 2025-11-19 01:25:52 --> Helper loaded: file_helper
INFO - 2025-11-19 01:25:52 --> Helper loaded: main_helper
INFO - 2025-11-19 01:25:52 --> Helper loaded: sendgrid_helper
INFO - 2025-11-19 01:25:52 --> Database Driver Class Initialized
INFO - 2025-11-19 01:25:52 --> Email Class Initialized
DEBUG - 2025-11-19 01:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-19 01:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-19 01:25:52 --> Controller Class Initialized
INFO - 2025-11-19 01:25:52 --> Model "User_model" initialized
INFO - 2025-11-19 01:25:52 --> Model "Project_model" initialized
INFO - 2025-11-19 01:25:52 --> Helper loaded: form_helper
INFO - 2025-11-19 01:25:52 --> Form Validation Class Initialized
INFO - 2025-11-19 01:25:52 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-19 01:25:52 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-19 01:25:52 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-19 01:25:52 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:25:52 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:25:52 --> Model "Topk_service_model" initialized
INFO - 2025-11-19 01:25:52 --> Final output sent to browser
INFO - 2025-11-19 01:25:52 --> Total execution time: 0.0927
INFO - 2025-11-19 01:25:55 --> Config Class Initialized
INFO - 2025-11-19 01:25:55 --> Hooks Class Initialized
INFO - 2025-11-19 01:25:55 --> UTF-8 Support Enabled
INFO - 2025-11-19 01:25:55 --> Utf8 Class Initialized
INFO - 2025-11-19 01:25:55 --> URI Class Initialized
INFO - 2025-11-19 01:25:55 --> Router Class Initialized
INFO - 2025-11-19 01:25:55 --> Output Class Initialized
INFO - 2025-11-19 01:25:55 --> Security Class Initialized
INFO - 2025-11-19 01:25:55 --> Input Class Initialized
INFO - 2025-11-19 01:25:55 --> Language Class Initialized
INFO - 2025-11-19 01:25:55 --> Loader Class Initialized
INFO - 2025-11-19 01:25:55 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-19 01:25:55 --> Helper loaded: url_helper
INFO - 2025-11-19 01:25:55 --> Helper loaded: file_helper
INFO - 2025-11-19 01:25:55 --> Helper loaded: main_helper
INFO - 2025-11-19 01:25:55 --> Helper loaded: sendgrid_helper
INFO - 2025-11-19 01:25:55 --> Database Driver Class Initialized
INFO - 2025-11-19 01:25:55 --> Email Class Initialized
DEBUG - 2025-11-19 01:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-19 01:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-19 01:25:55 --> Controller Class Initialized
INFO - 2025-11-19 01:25:55 --> Model "User_model" initialized
INFO - 2025-11-19 01:25:55 --> Model "Project_model" initialized
INFO - 2025-11-19 01:25:55 --> Helper loaded: form_helper
INFO - 2025-11-19 01:25:55 --> Form Validation Class Initialized
INFO - 2025-11-19 01:25:55 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-19 01:25:55 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-19 01:25:55 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-19 01:25:55 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:25:55 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:25:55 --> Model "Topk_service_model" initialized
INFO - 2025-11-19 01:25:55 --> Final output sent to browser
INFO - 2025-11-19 01:25:55 --> Total execution time: 0.0858
INFO - 2025-11-19 01:25:55 --> Config Class Initialized
INFO - 2025-11-19 01:25:55 --> Hooks Class Initialized
INFO - 2025-11-19 01:25:55 --> UTF-8 Support Enabled
INFO - 2025-11-19 01:25:55 --> Utf8 Class Initialized
INFO - 2025-11-19 01:25:55 --> URI Class Initialized
INFO - 2025-11-19 01:25:55 --> Router Class Initialized
INFO - 2025-11-19 01:25:55 --> Output Class Initialized
INFO - 2025-11-19 01:25:55 --> Security Class Initialized
INFO - 2025-11-19 01:25:55 --> Input Class Initialized
INFO - 2025-11-19 01:25:55 --> Language Class Initialized
INFO - 2025-11-19 01:25:55 --> Loader Class Initialized
INFO - 2025-11-19 01:25:55 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-19 01:25:55 --> Helper loaded: url_helper
INFO - 2025-11-19 01:25:55 --> Helper loaded: file_helper
INFO - 2025-11-19 01:25:55 --> Helper loaded: main_helper
INFO - 2025-11-19 01:25:55 --> Helper loaded: sendgrid_helper
INFO - 2025-11-19 01:25:55 --> Database Driver Class Initialized
INFO - 2025-11-19 01:25:55 --> Email Class Initialized
DEBUG - 2025-11-19 01:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-19 01:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-19 01:25:55 --> Controller Class Initialized
INFO - 2025-11-19 01:25:55 --> Model "Subscription_model" initialized
INFO - 2025-11-19 01:25:55 --> Model "User_model" initialized
INFO - 2025-11-19 01:25:55 --> Model "Auth_model" initialized
INFO - 2025-11-19 01:25:55 --> Model "Project_model" initialized
INFO - 2025-11-19 01:25:55 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-19 01:25:55 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-19 01:25:55 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-19 01:25:55 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ife.php
INFO - 2025-11-19 01:25:55 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-19 01:25:55 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-19 01:25:55 --> Final output sent to browser
INFO - 2025-11-19 01:25:55 --> Total execution time: 0.1294
INFO - 2025-11-19 01:25:55 --> Config Class Initialized
INFO - 2025-11-19 01:25:55 --> Hooks Class Initialized
INFO - 2025-11-19 01:25:55 --> UTF-8 Support Enabled
INFO - 2025-11-19 01:25:55 --> Utf8 Class Initialized
INFO - 2025-11-19 01:25:55 --> URI Class Initialized
INFO - 2025-11-19 01:25:55 --> Router Class Initialized
INFO - 2025-11-19 01:25:55 --> Output Class Initialized
INFO - 2025-11-19 01:25:55 --> Security Class Initialized
INFO - 2025-11-19 01:25:55 --> Input Class Initialized
INFO - 2025-11-19 01:25:55 --> Language Class Initialized
INFO - 2025-11-19 01:25:55 --> Loader Class Initialized
INFO - 2025-11-19 01:25:55 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-19 01:25:55 --> Helper loaded: url_helper
INFO - 2025-11-19 01:25:55 --> Helper loaded: file_helper
INFO - 2025-11-19 01:25:55 --> Helper loaded: main_helper
INFO - 2025-11-19 01:25:55 --> Helper loaded: sendgrid_helper
INFO - 2025-11-19 01:25:55 --> Database Driver Class Initialized
INFO - 2025-11-19 01:25:55 --> Email Class Initialized
DEBUG - 2025-11-19 01:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-19 01:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-19 01:25:55 --> Controller Class Initialized
INFO - 2025-11-19 01:25:55 --> Model "User_model" initialized
INFO - 2025-11-19 01:25:55 --> Model "Project_model" initialized
INFO - 2025-11-19 01:25:55 --> Helper loaded: form_helper
INFO - 2025-11-19 01:25:55 --> Form Validation Class Initialized
INFO - 2025-11-19 01:25:55 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-19 01:25:55 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-19 01:25:55 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-19 01:25:55 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:25:55 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:25:55 --> Model "Topk_service_model" initialized
INFO - 2025-11-19 01:25:55 --> Final output sent to browser
INFO - 2025-11-19 01:25:55 --> Total execution time: 0.0888
INFO - 2025-11-19 01:25:57 --> Config Class Initialized
INFO - 2025-11-19 01:25:57 --> Hooks Class Initialized
INFO - 2025-11-19 01:25:57 --> UTF-8 Support Enabled
INFO - 2025-11-19 01:25:57 --> Utf8 Class Initialized
INFO - 2025-11-19 01:25:57 --> URI Class Initialized
INFO - 2025-11-19 01:25:57 --> Router Class Initialized
INFO - 2025-11-19 01:25:57 --> Output Class Initialized
INFO - 2025-11-19 01:25:57 --> Security Class Initialized
INFO - 2025-11-19 01:25:57 --> Input Class Initialized
INFO - 2025-11-19 01:25:57 --> Language Class Initialized
INFO - 2025-11-19 01:25:57 --> Loader Class Initialized
INFO - 2025-11-19 01:25:57 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-19 01:25:57 --> Helper loaded: url_helper
INFO - 2025-11-19 01:25:57 --> Helper loaded: file_helper
INFO - 2025-11-19 01:25:57 --> Helper loaded: main_helper
INFO - 2025-11-19 01:25:57 --> Helper loaded: sendgrid_helper
INFO - 2025-11-19 01:25:57 --> Database Driver Class Initialized
INFO - 2025-11-19 01:25:57 --> Email Class Initialized
DEBUG - 2025-11-19 01:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-19 01:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-19 01:25:57 --> Controller Class Initialized
INFO - 2025-11-19 01:25:57 --> Model "Subscription_model" initialized
INFO - 2025-11-19 01:25:57 --> Model "User_model" initialized
INFO - 2025-11-19 01:25:57 --> Model "Auth_model" initialized
INFO - 2025-11-19 01:25:57 --> Model "Project_model" initialized
INFO - 2025-11-19 01:25:57 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-19 01:25:57 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-19 01:25:57 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-19 01:25:57 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ai.php
INFO - 2025-11-19 01:25:57 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-19 01:25:57 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-19 01:25:57 --> Final output sent to browser
INFO - 2025-11-19 01:25:57 --> Total execution time: 0.1061
INFO - 2025-11-19 01:25:57 --> Config Class Initialized
INFO - 2025-11-19 01:25:57 --> Hooks Class Initialized
INFO - 2025-11-19 01:25:57 --> UTF-8 Support Enabled
INFO - 2025-11-19 01:25:57 --> Utf8 Class Initialized
INFO - 2025-11-19 01:25:57 --> URI Class Initialized
INFO - 2025-11-19 01:25:57 --> Router Class Initialized
INFO - 2025-11-19 01:25:57 --> Output Class Initialized
INFO - 2025-11-19 01:25:57 --> Security Class Initialized
INFO - 2025-11-19 01:25:57 --> Input Class Initialized
INFO - 2025-11-19 01:25:57 --> Language Class Initialized
INFO - 2025-11-19 01:25:57 --> Loader Class Initialized
INFO - 2025-11-19 01:25:57 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-19 01:25:57 --> Helper loaded: url_helper
INFO - 2025-11-19 01:25:57 --> Helper loaded: file_helper
INFO - 2025-11-19 01:25:57 --> Helper loaded: main_helper
INFO - 2025-11-19 01:25:57 --> Helper loaded: sendgrid_helper
INFO - 2025-11-19 01:25:57 --> Database Driver Class Initialized
INFO - 2025-11-19 01:25:57 --> Email Class Initialized
DEBUG - 2025-11-19 01:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-19 01:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-19 01:25:57 --> Controller Class Initialized
INFO - 2025-11-19 01:25:57 --> Model "User_model" initialized
INFO - 2025-11-19 01:25:57 --> Model "Project_model" initialized
INFO - 2025-11-19 01:25:57 --> Helper loaded: form_helper
INFO - 2025-11-19 01:25:57 --> Form Validation Class Initialized
INFO - 2025-11-19 01:25:57 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-19 01:25:57 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-19 01:25:57 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-19 01:25:57 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:25:57 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:25:57 --> Model "Topk_service_model" initialized
INFO - 2025-11-19 01:25:57 --> Final output sent to browser
INFO - 2025-11-19 01:25:57 --> Total execution time: 0.0872
INFO - 2025-11-19 01:25:57 --> Config Class Initialized
INFO - 2025-11-19 01:25:57 --> Hooks Class Initialized
INFO - 2025-11-19 01:25:57 --> Config Class Initialized
INFO - 2025-11-19 01:25:57 --> Hooks Class Initialized
INFO - 2025-11-19 01:25:57 --> UTF-8 Support Enabled
INFO - 2025-11-19 01:25:57 --> Utf8 Class Initialized
INFO - 2025-11-19 01:25:57 --> UTF-8 Support Enabled
INFO - 2025-11-19 01:25:57 --> URI Class Initialized
INFO - 2025-11-19 01:25:57 --> Utf8 Class Initialized
INFO - 2025-11-19 01:25:57 --> URI Class Initialized
INFO - 2025-11-19 01:25:57 --> Router Class Initialized
INFO - 2025-11-19 01:25:57 --> Router Class Initialized
INFO - 2025-11-19 01:25:57 --> Output Class Initialized
INFO - 2025-11-19 01:25:57 --> Output Class Initialized
INFO - 2025-11-19 01:25:57 --> Security Class Initialized
INFO - 2025-11-19 01:25:57 --> Input Class Initialized
INFO - 2025-11-19 01:25:57 --> Security Class Initialized
INFO - 2025-11-19 01:25:57 --> Language Class Initialized
INFO - 2025-11-19 01:25:57 --> Input Class Initialized
INFO - 2025-11-19 01:25:57 --> Language Class Initialized
INFO - 2025-11-19 01:25:57 --> Loader Class Initialized
INFO - 2025-11-19 01:25:57 --> Loader Class Initialized
INFO - 2025-11-19 01:25:57 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-19 01:25:57 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-19 01:25:57 --> Helper loaded: url_helper
INFO - 2025-11-19 01:25:57 --> Helper loaded: url_helper
INFO - 2025-11-19 01:25:57 --> Helper loaded: file_helper
INFO - 2025-11-19 01:25:57 --> Helper loaded: file_helper
INFO - 2025-11-19 01:25:57 --> Helper loaded: main_helper
INFO - 2025-11-19 01:25:57 --> Helper loaded: sendgrid_helper
INFO - 2025-11-19 01:25:57 --> Helper loaded: main_helper
INFO - 2025-11-19 01:25:57 --> Helper loaded: sendgrid_helper
INFO - 2025-11-19 01:25:57 --> Database Driver Class Initialized
INFO - 2025-11-19 01:25:57 --> Database Driver Class Initialized
INFO - 2025-11-19 01:25:57 --> Email Class Initialized
INFO - 2025-11-19 01:25:57 --> Email Class Initialized
DEBUG - 2025-11-19 01:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-11-19 01:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-19 01:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-19 01:25:57 --> Controller Class Initialized
INFO - 2025-11-19 01:25:57 --> Model "User_model" initialized
INFO - 2025-11-19 01:25:57 --> Model "Project_model" initialized
INFO - 2025-11-19 01:25:57 --> Helper loaded: form_helper
INFO - 2025-11-19 01:25:57 --> Form Validation Class Initialized
INFO - 2025-11-19 01:25:57 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-19 01:25:57 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-19 01:25:57 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-19 01:25:57 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:25:57 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:25:57 --> Model "Topk_service_model" initialized
INFO - 2025-11-19 01:25:57 --> Final output sent to browser
INFO - 2025-11-19 01:25:57 --> Total execution time: 0.0978
INFO - 2025-11-19 01:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-19 01:25:57 --> Controller Class Initialized
INFO - 2025-11-19 01:25:57 --> Model "User_model" initialized
INFO - 2025-11-19 01:25:57 --> Model "Project_model" initialized
INFO - 2025-11-19 01:25:57 --> Helper loaded: form_helper
INFO - 2025-11-19 01:25:57 --> Form Validation Class Initialized
INFO - 2025-11-19 01:25:57 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-19 01:25:57 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-19 01:25:57 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-19 01:25:57 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:25:57 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:25:57 --> Model "Topk_service_model" initialized
INFO - 2025-11-19 01:25:57 --> Final output sent to browser
INFO - 2025-11-19 01:25:57 --> Total execution time: 0.1211
INFO - 2025-11-19 01:25:58 --> Config Class Initialized
INFO - 2025-11-19 01:25:58 --> Hooks Class Initialized
INFO - 2025-11-19 01:25:58 --> Config Class Initialized
INFO - 2025-11-19 01:25:58 --> Hooks Class Initialized
INFO - 2025-11-19 01:25:58 --> UTF-8 Support Enabled
INFO - 2025-11-19 01:25:58 --> Utf8 Class Initialized
INFO - 2025-11-19 01:25:58 --> URI Class Initialized
INFO - 2025-11-19 01:25:58 --> UTF-8 Support Enabled
INFO - 2025-11-19 01:25:58 --> Utf8 Class Initialized
INFO - 2025-11-19 01:25:58 --> Router Class Initialized
INFO - 2025-11-19 01:25:58 --> URI Class Initialized
INFO - 2025-11-19 01:25:58 --> Output Class Initialized
INFO - 2025-11-19 01:25:58 --> Router Class Initialized
INFO - 2025-11-19 01:25:58 --> Output Class Initialized
INFO - 2025-11-19 01:25:58 --> Security Class Initialized
INFO - 2025-11-19 01:25:58 --> Input Class Initialized
INFO - 2025-11-19 01:25:58 --> Security Class Initialized
INFO - 2025-11-19 01:25:58 --> Language Class Initialized
INFO - 2025-11-19 01:25:58 --> Input Class Initialized
INFO - 2025-11-19 01:25:58 --> Language Class Initialized
INFO - 2025-11-19 01:25:58 --> Loader Class Initialized
INFO - 2025-11-19 01:25:58 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-19 01:25:58 --> Loader Class Initialized
INFO - 2025-11-19 01:25:58 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-19 01:25:58 --> Helper loaded: url_helper
INFO - 2025-11-19 01:25:58 --> Helper loaded: file_helper
INFO - 2025-11-19 01:25:58 --> Helper loaded: url_helper
INFO - 2025-11-19 01:25:58 --> Helper loaded: file_helper
INFO - 2025-11-19 01:25:58 --> Helper loaded: main_helper
INFO - 2025-11-19 01:25:58 --> Helper loaded: sendgrid_helper
INFO - 2025-11-19 01:25:58 --> Helper loaded: main_helper
INFO - 2025-11-19 01:25:58 --> Helper loaded: sendgrid_helper
INFO - 2025-11-19 01:25:58 --> Database Driver Class Initialized
INFO - 2025-11-19 01:25:58 --> Database Driver Class Initialized
INFO - 2025-11-19 01:25:58 --> Email Class Initialized
INFO - 2025-11-19 01:25:58 --> Email Class Initialized
DEBUG - 2025-11-19 01:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-11-19 01:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-19 01:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-19 01:25:58 --> Controller Class Initialized
INFO - 2025-11-19 01:25:58 --> Model "User_model" initialized
INFO - 2025-11-19 01:25:58 --> Model "Project_model" initialized
INFO - 2025-11-19 01:25:58 --> Helper loaded: form_helper
INFO - 2025-11-19 01:25:58 --> Form Validation Class Initialized
INFO - 2025-11-19 01:25:58 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-19 01:25:58 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-19 01:25:58 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-19 01:25:58 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:25:58 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:25:58 --> Model "Topk_service_model" initialized
INFO - 2025-11-19 01:25:58 --> Final output sent to browser
INFO - 2025-11-19 01:25:58 --> Total execution time: 0.0896
INFO - 2025-11-19 01:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-19 01:25:58 --> Controller Class Initialized
INFO - 2025-11-19 01:25:58 --> Model "User_model" initialized
INFO - 2025-11-19 01:25:58 --> Model "Project_model" initialized
INFO - 2025-11-19 01:25:58 --> Helper loaded: form_helper
INFO - 2025-11-19 01:25:58 --> Form Validation Class Initialized
INFO - 2025-11-19 01:25:58 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-19 01:25:58 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-19 01:25:58 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-19 01:25:58 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:25:58 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:25:58 --> Model "Topk_service_model" initialized
INFO - 2025-11-19 01:25:58 --> Final output sent to browser
INFO - 2025-11-19 01:25:58 --> Total execution time: 0.1039
INFO - 2025-11-19 01:26:01 --> Config Class Initialized
INFO - 2025-11-19 01:26:01 --> Hooks Class Initialized
INFO - 2025-11-19 01:26:01 --> UTF-8 Support Enabled
INFO - 2025-11-19 01:26:01 --> Utf8 Class Initialized
INFO - 2025-11-19 01:26:01 --> URI Class Initialized
INFO - 2025-11-19 01:26:01 --> Router Class Initialized
INFO - 2025-11-19 01:26:01 --> Output Class Initialized
INFO - 2025-11-19 01:26:01 --> Security Class Initialized
INFO - 2025-11-19 01:26:01 --> Input Class Initialized
INFO - 2025-11-19 01:26:01 --> Language Class Initialized
INFO - 2025-11-19 01:26:01 --> Loader Class Initialized
INFO - 2025-11-19 01:26:01 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-19 01:26:01 --> Helper loaded: url_helper
INFO - 2025-11-19 01:26:01 --> Helper loaded: file_helper
INFO - 2025-11-19 01:26:01 --> Helper loaded: main_helper
INFO - 2025-11-19 01:26:01 --> Helper loaded: sendgrid_helper
INFO - 2025-11-19 01:26:01 --> Database Driver Class Initialized
INFO - 2025-11-19 01:26:01 --> Email Class Initialized
DEBUG - 2025-11-19 01:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-19 01:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-19 01:26:01 --> Controller Class Initialized
INFO - 2025-11-19 01:26:01 --> Model "User_model" initialized
INFO - 2025-11-19 01:26:01 --> Model "Project_model" initialized
INFO - 2025-11-19 01:26:01 --> Helper loaded: form_helper
INFO - 2025-11-19 01:26:01 --> Form Validation Class Initialized
INFO - 2025-11-19 01:26:01 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-19 01:26:01 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-19 01:26:01 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-19 01:26:01 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:26:01 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:26:01 --> Model "Topk_service_model" initialized
INFO - 2025-11-19 01:26:01 --> Final output sent to browser
INFO - 2025-11-19 01:26:01 --> Total execution time: 0.1122
INFO - 2025-11-19 01:26:02 --> Config Class Initialized
INFO - 2025-11-19 01:26:02 --> Hooks Class Initialized
INFO - 2025-11-19 01:26:02 --> UTF-8 Support Enabled
INFO - 2025-11-19 01:26:02 --> Utf8 Class Initialized
INFO - 2025-11-19 01:26:02 --> URI Class Initialized
INFO - 2025-11-19 01:26:02 --> Router Class Initialized
INFO - 2025-11-19 01:26:02 --> Output Class Initialized
INFO - 2025-11-19 01:26:02 --> Security Class Initialized
INFO - 2025-11-19 01:26:02 --> Input Class Initialized
INFO - 2025-11-19 01:26:02 --> Language Class Initialized
INFO - 2025-11-19 01:26:02 --> Loader Class Initialized
INFO - 2025-11-19 01:26:02 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-19 01:26:02 --> Helper loaded: url_helper
INFO - 2025-11-19 01:26:02 --> Helper loaded: file_helper
INFO - 2025-11-19 01:26:02 --> Helper loaded: main_helper
INFO - 2025-11-19 01:26:02 --> Helper loaded: sendgrid_helper
INFO - 2025-11-19 01:26:02 --> Database Driver Class Initialized
INFO - 2025-11-19 01:26:02 --> Email Class Initialized
DEBUG - 2025-11-19 01:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-19 01:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-19 01:26:02 --> Controller Class Initialized
INFO - 2025-11-19 01:26:02 --> Model "User_model" initialized
INFO - 2025-11-19 01:26:02 --> Model "Project_model" initialized
INFO - 2025-11-19 01:26:02 --> Helper loaded: form_helper
INFO - 2025-11-19 01:26:02 --> Form Validation Class Initialized
INFO - 2025-11-19 01:26:02 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-19 01:26:02 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-19 01:26:02 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-19 01:26:02 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:26:02 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:26:02 --> Model "Topk_service_model" initialized
ERROR - 2025-11-19 01:26:08 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 267,
    "totalTokenCount": 1066,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 267
      }
    ],
    "thoughtsTokenCount": 799
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "sBwdaYwM2oup-Q-mxq34Bg"
}

ERROR - 2025-11-19 01:26:12 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 284,
    "totalTokenCount": 843,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 284
      }
    ],
    "thoughtsTokenCount": 559
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "sxwdaaW7Ka-LjuMPsPvF8QY"
}

INFO - 2025-11-19 01:26:12 --> Final output sent to browser
INFO - 2025-11-19 01:26:12 --> Total execution time: 10.4157
INFO - 2025-11-19 01:26:12 --> Config Class Initialized
INFO - 2025-11-19 01:26:12 --> Hooks Class Initialized
INFO - 2025-11-19 01:26:12 --> UTF-8 Support Enabled
INFO - 2025-11-19 01:26:12 --> Utf8 Class Initialized
INFO - 2025-11-19 01:26:12 --> URI Class Initialized
INFO - 2025-11-19 01:26:12 --> Router Class Initialized
INFO - 2025-11-19 01:26:12 --> Output Class Initialized
INFO - 2025-11-19 01:26:12 --> Security Class Initialized
INFO - 2025-11-19 01:26:12 --> Input Class Initialized
INFO - 2025-11-19 01:26:12 --> Language Class Initialized
INFO - 2025-11-19 01:26:12 --> Loader Class Initialized
INFO - 2025-11-19 01:26:12 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-19 01:26:12 --> Helper loaded: url_helper
INFO - 2025-11-19 01:26:12 --> Helper loaded: file_helper
INFO - 2025-11-19 01:26:12 --> Helper loaded: main_helper
INFO - 2025-11-19 01:26:12 --> Helper loaded: sendgrid_helper
INFO - 2025-11-19 01:26:12 --> Database Driver Class Initialized
INFO - 2025-11-19 01:26:12 --> Email Class Initialized
DEBUG - 2025-11-19 01:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-19 01:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-19 01:26:12 --> Controller Class Initialized
INFO - 2025-11-19 01:26:12 --> Model "User_model" initialized
INFO - 2025-11-19 01:26:12 --> Model "Project_model" initialized
INFO - 2025-11-19 01:26:12 --> Helper loaded: form_helper
INFO - 2025-11-19 01:26:12 --> Form Validation Class Initialized
INFO - 2025-11-19 01:26:12 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-19 01:26:12 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-19 01:26:12 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-19 01:26:12 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:26:12 --> Model "Swot_model" initialized
INFO - 2025-11-19 01:26:12 --> Model "Topk_service_model" initialized
INFO - 2025-11-19 01:26:19 --> Final output sent to browser
INFO - 2025-11-19 01:26:19 --> Total execution time: 7.2407
