<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-11-09 01:22:56 --> Config Class Initialized
INFO - 2025-11-09 01:22:56 --> Hooks Class Initialized
INFO - 2025-11-09 01:22:56 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:22:56 --> Utf8 Class Initialized
INFO - 2025-11-09 01:22:56 --> URI Class Initialized
DEBUG - 2025-11-09 01:22:56 --> No URI present. Default controller set.
INFO - 2025-11-09 01:22:56 --> Router Class Initialized
INFO - 2025-11-09 01:22:56 --> Output Class Initialized
INFO - 2025-11-09 01:22:56 --> Security Class Initialized
INFO - 2025-11-09 01:22:56 --> Input Class Initialized
INFO - 2025-11-09 01:22:56 --> Language Class Initialized
INFO - 2025-11-09 01:22:56 --> Loader Class Initialized
INFO - 2025-11-09 01:22:56 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:22:56 --> Helper loaded: url_helper
INFO - 2025-11-09 01:22:56 --> Helper loaded: file_helper
INFO - 2025-11-09 01:22:56 --> Helper loaded: main_helper
INFO - 2025-11-09 01:22:56 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:22:56 --> Database Driver Class Initialized
INFO - 2025-11-09 01:22:56 --> Email Class Initialized
DEBUG - 2025-11-09 01:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:22:56 --> Controller Class Initialized
INFO - 2025-11-09 01:22:56 --> Config Class Initialized
INFO - 2025-11-09 01:22:56 --> Hooks Class Initialized
INFO - 2025-11-09 01:22:56 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:22:56 --> Utf8 Class Initialized
INFO - 2025-11-09 01:22:56 --> URI Class Initialized
INFO - 2025-11-09 01:22:56 --> Router Class Initialized
INFO - 2025-11-09 01:22:56 --> Output Class Initialized
INFO - 2025-11-09 01:22:56 --> Security Class Initialized
INFO - 2025-11-09 01:22:56 --> Input Class Initialized
INFO - 2025-11-09 01:22:56 --> Language Class Initialized
INFO - 2025-11-09 01:22:56 --> Loader Class Initialized
INFO - 2025-11-09 01:22:56 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:22:56 --> Helper loaded: url_helper
INFO - 2025-11-09 01:22:56 --> Helper loaded: file_helper
INFO - 2025-11-09 01:22:56 --> Helper loaded: main_helper
INFO - 2025-11-09 01:22:56 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:22:56 --> Database Driver Class Initialized
INFO - 2025-11-09 01:22:56 --> Email Class Initialized
DEBUG - 2025-11-09 01:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:22:56 --> Controller Class Initialized
INFO - 2025-11-09 01:22:56 --> Model "Subscription_model" initialized
INFO - 2025-11-09 01:22:56 --> Model "User_model" initialized
INFO - 2025-11-09 01:22:56 --> Model "Auth_model" initialized
INFO - 2025-11-09 01:22:56 --> Config Class Initialized
INFO - 2025-11-09 01:22:56 --> Hooks Class Initialized
INFO - 2025-11-09 01:22:56 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:22:56 --> Utf8 Class Initialized
INFO - 2025-11-09 01:22:56 --> URI Class Initialized
INFO - 2025-11-09 01:22:56 --> Router Class Initialized
INFO - 2025-11-09 01:22:56 --> Output Class Initialized
INFO - 2025-11-09 01:22:56 --> Security Class Initialized
INFO - 2025-11-09 01:22:56 --> Input Class Initialized
INFO - 2025-11-09 01:22:56 --> Language Class Initialized
INFO - 2025-11-09 01:22:56 --> Loader Class Initialized
INFO - 2025-11-09 01:22:56 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:22:56 --> Helper loaded: url_helper
INFO - 2025-11-09 01:22:56 --> Helper loaded: file_helper
INFO - 2025-11-09 01:22:56 --> Helper loaded: main_helper
INFO - 2025-11-09 01:22:56 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:22:56 --> Database Driver Class Initialized
INFO - 2025-11-09 01:22:56 --> Email Class Initialized
DEBUG - 2025-11-09 01:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:22:56 --> Controller Class Initialized
INFO - 2025-11-09 01:22:56 --> Config Class Initialized
INFO - 2025-11-09 01:22:56 --> Hooks Class Initialized
INFO - 2025-11-09 01:22:56 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:22:56 --> Utf8 Class Initialized
INFO - 2025-11-09 01:22:56 --> URI Class Initialized
INFO - 2025-11-09 01:22:56 --> Router Class Initialized
INFO - 2025-11-09 01:22:56 --> Output Class Initialized
INFO - 2025-11-09 01:22:56 --> Security Class Initialized
INFO - 2025-11-09 01:22:56 --> Input Class Initialized
INFO - 2025-11-09 01:22:56 --> Language Class Initialized
INFO - 2025-11-09 01:22:56 --> Loader Class Initialized
INFO - 2025-11-09 01:22:56 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:22:56 --> Helper loaded: url_helper
INFO - 2025-11-09 01:22:56 --> Helper loaded: file_helper
INFO - 2025-11-09 01:22:56 --> Helper loaded: main_helper
INFO - 2025-11-09 01:22:56 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:22:56 --> Database Driver Class Initialized
INFO - 2025-11-09 01:22:56 --> Email Class Initialized
DEBUG - 2025-11-09 01:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:22:56 --> Controller Class Initialized
INFO - 2025-11-09 01:22:56 --> Model "Subscription_model" initialized
INFO - 2025-11-09 01:22:56 --> Model "User_model" initialized
INFO - 2025-11-09 01:22:56 --> Model "Auth_model" initialized
INFO - 2025-11-09 01:22:56 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-09 01:22:56 --> Final output sent to browser
INFO - 2025-11-09 01:22:56 --> Total execution time: 0.1107
INFO - 2025-11-09 01:23:26 --> Config Class Initialized
INFO - 2025-11-09 01:23:26 --> Hooks Class Initialized
INFO - 2025-11-09 01:23:26 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:23:26 --> Utf8 Class Initialized
INFO - 2025-11-09 01:23:26 --> URI Class Initialized
INFO - 2025-11-09 01:23:26 --> Router Class Initialized
INFO - 2025-11-09 01:23:26 --> Output Class Initialized
INFO - 2025-11-09 01:23:26 --> Security Class Initialized
INFO - 2025-11-09 01:23:26 --> Input Class Initialized
INFO - 2025-11-09 01:23:26 --> Language Class Initialized
INFO - 2025-11-09 01:23:26 --> Loader Class Initialized
INFO - 2025-11-09 01:23:26 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:23:26 --> Helper loaded: url_helper
INFO - 2025-11-09 01:23:26 --> Helper loaded: file_helper
INFO - 2025-11-09 01:23:26 --> Helper loaded: main_helper
INFO - 2025-11-09 01:23:26 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:23:26 --> Database Driver Class Initialized
INFO - 2025-11-09 01:23:26 --> Email Class Initialized
DEBUG - 2025-11-09 01:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:23:26 --> Controller Class Initialized
INFO - 2025-11-09 01:23:26 --> Model "Subscription_model" initialized
INFO - 2025-11-09 01:23:26 --> Model "User_model" initialized
INFO - 2025-11-09 01:23:26 --> Model "Auth_model" initialized
INFO - 2025-11-09 01:23:27 --> Final output sent to browser
INFO - 2025-11-09 01:23:27 --> Total execution time: 0.3661
INFO - 2025-11-09 01:23:28 --> Config Class Initialized
INFO - 2025-11-09 01:23:28 --> Hooks Class Initialized
INFO - 2025-11-09 01:23:28 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:23:28 --> Utf8 Class Initialized
INFO - 2025-11-09 01:23:28 --> URI Class Initialized
INFO - 2025-11-09 01:23:28 --> Router Class Initialized
INFO - 2025-11-09 01:23:28 --> Output Class Initialized
INFO - 2025-11-09 01:23:28 --> Security Class Initialized
INFO - 2025-11-09 01:23:28 --> Input Class Initialized
INFO - 2025-11-09 01:23:28 --> Language Class Initialized
INFO - 2025-11-09 01:23:28 --> Loader Class Initialized
INFO - 2025-11-09 01:23:28 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:23:28 --> Helper loaded: url_helper
INFO - 2025-11-09 01:23:28 --> Helper loaded: file_helper
INFO - 2025-11-09 01:23:28 --> Helper loaded: main_helper
INFO - 2025-11-09 01:23:28 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:23:28 --> Database Driver Class Initialized
INFO - 2025-11-09 01:23:28 --> Email Class Initialized
DEBUG - 2025-11-09 01:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:23:28 --> Controller Class Initialized
INFO - 2025-11-09 01:23:28 --> Model "Subscription_model" initialized
INFO - 2025-11-09 01:23:28 --> Model "User_model" initialized
INFO - 2025-11-09 01:23:28 --> Model "Auth_model" initialized
INFO - 2025-11-09 01:23:28 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-09 01:23:28 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-09 01:23:28 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-09 01:23:28 --> File loaded: D:\laragon\www\acumena\application\views\dashboard.php
INFO - 2025-11-09 01:23:28 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-09 01:23:28 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-09 01:23:28 --> Final output sent to browser
INFO - 2025-11-09 01:23:28 --> Total execution time: 0.1148
INFO - 2025-11-09 01:23:28 --> Config Class Initialized
INFO - 2025-11-09 01:23:28 --> Hooks Class Initialized
INFO - 2025-11-09 01:23:28 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:23:28 --> Utf8 Class Initialized
INFO - 2025-11-09 01:23:28 --> URI Class Initialized
INFO - 2025-11-09 01:23:28 --> Router Class Initialized
INFO - 2025-11-09 01:23:28 --> Output Class Initialized
INFO - 2025-11-09 01:23:28 --> Security Class Initialized
INFO - 2025-11-09 01:23:28 --> Input Class Initialized
INFO - 2025-11-09 01:23:28 --> Language Class Initialized
INFO - 2025-11-09 01:23:28 --> Loader Class Initialized
INFO - 2025-11-09 01:23:28 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:23:28 --> Helper loaded: url_helper
INFO - 2025-11-09 01:23:28 --> Helper loaded: file_helper
INFO - 2025-11-09 01:23:28 --> Helper loaded: main_helper
INFO - 2025-11-09 01:23:28 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:23:28 --> Database Driver Class Initialized
INFO - 2025-11-09 01:23:28 --> Email Class Initialized
DEBUG - 2025-11-09 01:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:23:28 --> Controller Class Initialized
INFO - 2025-11-09 01:23:28 --> Model "User_model" initialized
INFO - 2025-11-09 01:23:28 --> Model "Project_model" initialized
INFO - 2025-11-09 01:23:28 --> Helper loaded: form_helper
INFO - 2025-11-09 01:23:28 --> Form Validation Class Initialized
INFO - 2025-11-09 01:23:28 --> Final output sent to browser
INFO - 2025-11-09 01:23:28 --> Total execution time: 0.0996
INFO - 2025-11-09 01:23:31 --> Config Class Initialized
INFO - 2025-11-09 01:23:31 --> Hooks Class Initialized
INFO - 2025-11-09 01:23:31 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:23:31 --> Utf8 Class Initialized
INFO - 2025-11-09 01:23:31 --> URI Class Initialized
INFO - 2025-11-09 01:23:31 --> Router Class Initialized
INFO - 2025-11-09 01:23:31 --> Output Class Initialized
INFO - 2025-11-09 01:23:31 --> Security Class Initialized
INFO - 2025-11-09 01:23:31 --> Input Class Initialized
INFO - 2025-11-09 01:23:31 --> Language Class Initialized
INFO - 2025-11-09 01:23:31 --> Loader Class Initialized
INFO - 2025-11-09 01:23:31 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:23:31 --> Helper loaded: url_helper
INFO - 2025-11-09 01:23:31 --> Helper loaded: file_helper
INFO - 2025-11-09 01:23:31 --> Helper loaded: main_helper
INFO - 2025-11-09 01:23:31 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:23:31 --> Database Driver Class Initialized
INFO - 2025-11-09 01:23:31 --> Email Class Initialized
DEBUG - 2025-11-09 01:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:23:31 --> Controller Class Initialized
INFO - 2025-11-09 01:23:31 --> Model "Subscription_model" initialized
INFO - 2025-11-09 01:23:31 --> Model "User_model" initialized
INFO - 2025-11-09 01:23:31 --> Model "Auth_model" initialized
INFO - 2025-11-09 01:23:31 --> Model "Project_model" initialized
INFO - 2025-11-09 01:23:31 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-09 01:23:31 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-09 01:23:31 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-09 01:23:31 --> File loaded: D:\laragon\www\acumena\application\views\projects/profile.php
INFO - 2025-11-09 01:23:31 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-09 01:23:31 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-09 01:23:31 --> Final output sent to browser
INFO - 2025-11-09 01:23:31 --> Total execution time: 0.1049
INFO - 2025-11-09 01:23:31 --> Config Class Initialized
INFO - 2025-11-09 01:23:31 --> Hooks Class Initialized
INFO - 2025-11-09 01:23:31 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:23:31 --> Utf8 Class Initialized
INFO - 2025-11-09 01:23:31 --> URI Class Initialized
INFO - 2025-11-09 01:23:31 --> Router Class Initialized
INFO - 2025-11-09 01:23:31 --> Output Class Initialized
INFO - 2025-11-09 01:23:31 --> Security Class Initialized
INFO - 2025-11-09 01:23:31 --> Input Class Initialized
INFO - 2025-11-09 01:23:31 --> Language Class Initialized
INFO - 2025-11-09 01:23:31 --> Loader Class Initialized
INFO - 2025-11-09 01:23:31 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:23:31 --> Helper loaded: url_helper
INFO - 2025-11-09 01:23:31 --> Helper loaded: file_helper
INFO - 2025-11-09 01:23:31 --> Helper loaded: main_helper
INFO - 2025-11-09 01:23:31 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:23:31 --> Database Driver Class Initialized
INFO - 2025-11-09 01:23:31 --> Email Class Initialized
DEBUG - 2025-11-09 01:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:23:31 --> Controller Class Initialized
INFO - 2025-11-09 01:23:31 --> Model "User_model" initialized
INFO - 2025-11-09 01:23:31 --> Model "Project_model" initialized
INFO - 2025-11-09 01:23:31 --> Helper loaded: form_helper
INFO - 2025-11-09 01:23:31 --> Form Validation Class Initialized
INFO - 2025-11-09 01:23:31 --> Final output sent to browser
INFO - 2025-11-09 01:23:31 --> Total execution time: 0.0988
INFO - 2025-11-09 01:23:34 --> Config Class Initialized
INFO - 2025-11-09 01:23:34 --> Hooks Class Initialized
INFO - 2025-11-09 01:23:34 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:23:34 --> Utf8 Class Initialized
INFO - 2025-11-09 01:23:34 --> URI Class Initialized
INFO - 2025-11-09 01:23:34 --> Router Class Initialized
INFO - 2025-11-09 01:23:34 --> Output Class Initialized
INFO - 2025-11-09 01:23:34 --> Security Class Initialized
INFO - 2025-11-09 01:23:34 --> Input Class Initialized
INFO - 2025-11-09 01:23:34 --> Language Class Initialized
INFO - 2025-11-09 01:23:34 --> Loader Class Initialized
INFO - 2025-11-09 01:23:34 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:23:34 --> Helper loaded: url_helper
INFO - 2025-11-09 01:23:34 --> Helper loaded: file_helper
INFO - 2025-11-09 01:23:34 --> Helper loaded: main_helper
INFO - 2025-11-09 01:23:34 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:23:34 --> Database Driver Class Initialized
INFO - 2025-11-09 01:23:34 --> Email Class Initialized
DEBUG - 2025-11-09 01:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:23:34 --> Controller Class Initialized
INFO - 2025-11-09 01:23:34 --> Model "User_model" initialized
INFO - 2025-11-09 01:23:34 --> Model "Project_model" initialized
INFO - 2025-11-09 01:23:34 --> Helper loaded: form_helper
INFO - 2025-11-09 01:23:34 --> Form Validation Class Initialized
INFO - 2025-11-09 01:23:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-11-09 01:23:34 --> Final output sent to browser
INFO - 2025-11-09 01:23:34 --> Total execution time: 0.0963
INFO - 2025-11-09 01:23:34 --> Config Class Initialized
INFO - 2025-11-09 01:23:34 --> Hooks Class Initialized
INFO - 2025-11-09 01:23:34 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:23:34 --> Utf8 Class Initialized
INFO - 2025-11-09 01:23:34 --> URI Class Initialized
INFO - 2025-11-09 01:23:34 --> Router Class Initialized
INFO - 2025-11-09 01:23:34 --> Output Class Initialized
INFO - 2025-11-09 01:23:34 --> Security Class Initialized
INFO - 2025-11-09 01:23:34 --> Input Class Initialized
INFO - 2025-11-09 01:23:34 --> Language Class Initialized
INFO - 2025-11-09 01:23:34 --> Loader Class Initialized
INFO - 2025-11-09 01:23:34 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:23:34 --> Helper loaded: url_helper
INFO - 2025-11-09 01:23:34 --> Helper loaded: file_helper
INFO - 2025-11-09 01:23:34 --> Helper loaded: main_helper
INFO - 2025-11-09 01:23:34 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:23:34 --> Database Driver Class Initialized
INFO - 2025-11-09 01:23:34 --> Email Class Initialized
DEBUG - 2025-11-09 01:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:23:34 --> Controller Class Initialized
INFO - 2025-11-09 01:23:34 --> Model "Subscription_model" initialized
INFO - 2025-11-09 01:23:34 --> Model "User_model" initialized
INFO - 2025-11-09 01:23:34 --> Model "Auth_model" initialized
INFO - 2025-11-09 01:23:34 --> Model "Project_model" initialized
INFO - 2025-11-09 01:23:34 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-09 01:23:34 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-09 01:23:34 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-09 01:23:34 --> File loaded: D:\laragon\www\acumena\application\views\projects/swot.php
INFO - 2025-11-09 01:23:34 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-09 01:23:34 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-09 01:23:34 --> Final output sent to browser
INFO - 2025-11-09 01:23:34 --> Total execution time: 0.1160
INFO - 2025-11-09 01:23:34 --> Config Class Initialized
INFO - 2025-11-09 01:23:34 --> Hooks Class Initialized
INFO - 2025-11-09 01:23:34 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:23:34 --> Utf8 Class Initialized
INFO - 2025-11-09 01:23:34 --> URI Class Initialized
INFO - 2025-11-09 01:23:34 --> Router Class Initialized
INFO - 2025-11-09 01:23:34 --> Output Class Initialized
INFO - 2025-11-09 01:23:34 --> Security Class Initialized
INFO - 2025-11-09 01:23:34 --> Input Class Initialized
INFO - 2025-11-09 01:23:34 --> Language Class Initialized
INFO - 2025-11-09 01:23:34 --> Loader Class Initialized
INFO - 2025-11-09 01:23:34 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:23:34 --> Helper loaded: url_helper
INFO - 2025-11-09 01:23:34 --> Helper loaded: file_helper
INFO - 2025-11-09 01:23:34 --> Helper loaded: main_helper
INFO - 2025-11-09 01:23:34 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:23:34 --> Database Driver Class Initialized
INFO - 2025-11-09 01:23:35 --> Email Class Initialized
DEBUG - 2025-11-09 01:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:23:35 --> Controller Class Initialized
INFO - 2025-11-09 01:23:35 --> Model "User_model" initialized
INFO - 2025-11-09 01:23:35 --> Model "Project_model" initialized
INFO - 2025-11-09 01:23:35 --> Helper loaded: form_helper
INFO - 2025-11-09 01:23:35 --> Form Validation Class Initialized
INFO - 2025-11-09 01:23:35 --> Final output sent to browser
INFO - 2025-11-09 01:23:35 --> Total execution time: 0.1320
INFO - 2025-11-09 01:23:36 --> Config Class Initialized
INFO - 2025-11-09 01:23:36 --> Hooks Class Initialized
INFO - 2025-11-09 01:23:36 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:23:36 --> Utf8 Class Initialized
INFO - 2025-11-09 01:23:36 --> URI Class Initialized
INFO - 2025-11-09 01:23:36 --> Router Class Initialized
INFO - 2025-11-09 01:23:36 --> Output Class Initialized
INFO - 2025-11-09 01:23:36 --> Security Class Initialized
INFO - 2025-11-09 01:23:36 --> Input Class Initialized
INFO - 2025-11-09 01:23:36 --> Language Class Initialized
INFO - 2025-11-09 01:23:36 --> Loader Class Initialized
INFO - 2025-11-09 01:23:36 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:23:36 --> Helper loaded: url_helper
INFO - 2025-11-09 01:23:36 --> Helper loaded: file_helper
INFO - 2025-11-09 01:23:36 --> Helper loaded: main_helper
INFO - 2025-11-09 01:23:36 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:23:36 --> Database Driver Class Initialized
INFO - 2025-11-09 01:23:36 --> Email Class Initialized
DEBUG - 2025-11-09 01:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:23:36 --> Controller Class Initialized
INFO - 2025-11-09 01:23:36 --> Model "User_model" initialized
INFO - 2025-11-09 01:23:36 --> Model "Project_model" initialized
INFO - 2025-11-09 01:23:36 --> Helper loaded: form_helper
INFO - 2025-11-09 01:23:36 --> Form Validation Class Initialized
INFO - 2025-11-09 01:23:36 --> Final output sent to browser
INFO - 2025-11-09 01:23:36 --> Total execution time: 0.1058
INFO - 2025-11-09 01:23:36 --> Config Class Initialized
INFO - 2025-11-09 01:23:36 --> Hooks Class Initialized
INFO - 2025-11-09 01:23:37 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:23:37 --> Utf8 Class Initialized
INFO - 2025-11-09 01:23:37 --> URI Class Initialized
INFO - 2025-11-09 01:23:37 --> Router Class Initialized
INFO - 2025-11-09 01:23:37 --> Output Class Initialized
INFO - 2025-11-09 01:23:37 --> Security Class Initialized
INFO - 2025-11-09 01:23:37 --> Input Class Initialized
INFO - 2025-11-09 01:23:37 --> Language Class Initialized
INFO - 2025-11-09 01:23:37 --> Loader Class Initialized
INFO - 2025-11-09 01:23:37 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:23:37 --> Helper loaded: url_helper
INFO - 2025-11-09 01:23:37 --> Helper loaded: file_helper
INFO - 2025-11-09 01:23:37 --> Helper loaded: main_helper
INFO - 2025-11-09 01:23:37 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:23:37 --> Database Driver Class Initialized
INFO - 2025-11-09 01:23:37 --> Email Class Initialized
DEBUG - 2025-11-09 01:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:23:37 --> Controller Class Initialized
INFO - 2025-11-09 01:23:37 --> Model "Subscription_model" initialized
INFO - 2025-11-09 01:23:37 --> Model "User_model" initialized
INFO - 2025-11-09 01:23:37 --> Model "Auth_model" initialized
INFO - 2025-11-09 01:23:37 --> Model "Project_model" initialized
INFO - 2025-11-09 01:23:37 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-09 01:23:37 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-09 01:23:37 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-09 01:23:37 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ife.php
INFO - 2025-11-09 01:23:37 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-09 01:23:37 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-09 01:23:37 --> Final output sent to browser
INFO - 2025-11-09 01:23:37 --> Total execution time: 0.1019
INFO - 2025-11-09 01:23:37 --> Config Class Initialized
INFO - 2025-11-09 01:23:37 --> Hooks Class Initialized
INFO - 2025-11-09 01:23:37 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:23:37 --> Utf8 Class Initialized
INFO - 2025-11-09 01:23:37 --> URI Class Initialized
INFO - 2025-11-09 01:23:37 --> Router Class Initialized
INFO - 2025-11-09 01:23:37 --> Output Class Initialized
INFO - 2025-11-09 01:23:37 --> Security Class Initialized
INFO - 2025-11-09 01:23:37 --> Input Class Initialized
INFO - 2025-11-09 01:23:37 --> Language Class Initialized
INFO - 2025-11-09 01:23:37 --> Loader Class Initialized
INFO - 2025-11-09 01:23:37 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:23:37 --> Helper loaded: url_helper
INFO - 2025-11-09 01:23:37 --> Helper loaded: file_helper
INFO - 2025-11-09 01:23:37 --> Helper loaded: main_helper
INFO - 2025-11-09 01:23:37 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:23:37 --> Database Driver Class Initialized
INFO - 2025-11-09 01:23:37 --> Email Class Initialized
DEBUG - 2025-11-09 01:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:23:37 --> Controller Class Initialized
INFO - 2025-11-09 01:23:37 --> Model "User_model" initialized
INFO - 2025-11-09 01:23:37 --> Model "Project_model" initialized
INFO - 2025-11-09 01:23:37 --> Helper loaded: form_helper
INFO - 2025-11-09 01:23:37 --> Form Validation Class Initialized
INFO - 2025-11-09 01:23:37 --> Final output sent to browser
INFO - 2025-11-09 01:23:37 --> Total execution time: 0.1119
INFO - 2025-11-09 01:23:40 --> Config Class Initialized
INFO - 2025-11-09 01:23:40 --> Hooks Class Initialized
INFO - 2025-11-09 01:23:40 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:23:40 --> Utf8 Class Initialized
INFO - 2025-11-09 01:23:40 --> URI Class Initialized
INFO - 2025-11-09 01:23:40 --> Router Class Initialized
INFO - 2025-11-09 01:23:40 --> Output Class Initialized
INFO - 2025-11-09 01:23:40 --> Security Class Initialized
INFO - 2025-11-09 01:23:40 --> Input Class Initialized
INFO - 2025-11-09 01:23:40 --> Language Class Initialized
INFO - 2025-11-09 01:23:40 --> Loader Class Initialized
INFO - 2025-11-09 01:23:40 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:23:40 --> Helper loaded: url_helper
INFO - 2025-11-09 01:23:40 --> Helper loaded: file_helper
INFO - 2025-11-09 01:23:40 --> Helper loaded: main_helper
INFO - 2025-11-09 01:23:40 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:23:40 --> Database Driver Class Initialized
INFO - 2025-11-09 01:23:40 --> Email Class Initialized
DEBUG - 2025-11-09 01:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:23:40 --> Controller Class Initialized
INFO - 2025-11-09 01:23:40 --> Model "User_model" initialized
INFO - 2025-11-09 01:23:40 --> Model "Project_model" initialized
INFO - 2025-11-09 01:23:40 --> Helper loaded: form_helper
INFO - 2025-11-09 01:23:40 --> Form Validation Class Initialized
INFO - 2025-11-09 01:23:40 --> Final output sent to browser
INFO - 2025-11-09 01:23:40 --> Total execution time: 0.1080
INFO - 2025-11-09 01:23:40 --> Config Class Initialized
INFO - 2025-11-09 01:23:40 --> Hooks Class Initialized
INFO - 2025-11-09 01:23:40 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:23:40 --> Utf8 Class Initialized
INFO - 2025-11-09 01:23:40 --> URI Class Initialized
INFO - 2025-11-09 01:23:40 --> Router Class Initialized
INFO - 2025-11-09 01:23:40 --> Output Class Initialized
INFO - 2025-11-09 01:23:40 --> Security Class Initialized
INFO - 2025-11-09 01:23:40 --> Input Class Initialized
INFO - 2025-11-09 01:23:40 --> Language Class Initialized
INFO - 2025-11-09 01:23:40 --> Loader Class Initialized
INFO - 2025-11-09 01:23:40 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:23:40 --> Helper loaded: url_helper
INFO - 2025-11-09 01:23:40 --> Helper loaded: file_helper
INFO - 2025-11-09 01:23:40 --> Helper loaded: main_helper
INFO - 2025-11-09 01:23:40 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:23:40 --> Database Driver Class Initialized
INFO - 2025-11-09 01:23:40 --> Email Class Initialized
DEBUG - 2025-11-09 01:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:23:40 --> Controller Class Initialized
INFO - 2025-11-09 01:23:40 --> Model "Subscription_model" initialized
INFO - 2025-11-09 01:23:40 --> Model "User_model" initialized
INFO - 2025-11-09 01:23:40 --> Model "Auth_model" initialized
INFO - 2025-11-09 01:23:40 --> Model "Project_model" initialized
INFO - 2025-11-09 01:23:40 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-09 01:23:40 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-09 01:23:40 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-09 01:23:40 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-efe.php
INFO - 2025-11-09 01:23:40 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-09 01:23:40 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-09 01:23:40 --> Final output sent to browser
INFO - 2025-11-09 01:23:40 --> Total execution time: 0.1119
INFO - 2025-11-09 01:23:40 --> Config Class Initialized
INFO - 2025-11-09 01:23:40 --> Hooks Class Initialized
INFO - 2025-11-09 01:23:40 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:23:40 --> Utf8 Class Initialized
INFO - 2025-11-09 01:23:40 --> URI Class Initialized
INFO - 2025-11-09 01:23:40 --> Router Class Initialized
INFO - 2025-11-09 01:23:40 --> Output Class Initialized
INFO - 2025-11-09 01:23:40 --> Security Class Initialized
INFO - 2025-11-09 01:23:41 --> Input Class Initialized
INFO - 2025-11-09 01:23:41 --> Language Class Initialized
INFO - 2025-11-09 01:23:41 --> Loader Class Initialized
INFO - 2025-11-09 01:23:41 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:23:41 --> Helper loaded: url_helper
INFO - 2025-11-09 01:23:41 --> Helper loaded: file_helper
INFO - 2025-11-09 01:23:41 --> Helper loaded: main_helper
INFO - 2025-11-09 01:23:41 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:23:41 --> Database Driver Class Initialized
INFO - 2025-11-09 01:23:41 --> Email Class Initialized
DEBUG - 2025-11-09 01:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:23:41 --> Controller Class Initialized
INFO - 2025-11-09 01:23:41 --> Model "User_model" initialized
INFO - 2025-11-09 01:23:41 --> Model "Project_model" initialized
INFO - 2025-11-09 01:23:41 --> Helper loaded: form_helper
INFO - 2025-11-09 01:23:41 --> Form Validation Class Initialized
INFO - 2025-11-09 01:23:41 --> Final output sent to browser
INFO - 2025-11-09 01:23:41 --> Total execution time: 0.0964
INFO - 2025-11-09 01:23:44 --> Config Class Initialized
INFO - 2025-11-09 01:23:44 --> Hooks Class Initialized
INFO - 2025-11-09 01:23:44 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:23:44 --> Utf8 Class Initialized
INFO - 2025-11-09 01:23:44 --> URI Class Initialized
INFO - 2025-11-09 01:23:44 --> Router Class Initialized
INFO - 2025-11-09 01:23:44 --> Output Class Initialized
INFO - 2025-11-09 01:23:44 --> Security Class Initialized
INFO - 2025-11-09 01:23:44 --> Input Class Initialized
INFO - 2025-11-09 01:23:44 --> Language Class Initialized
INFO - 2025-11-09 01:23:44 --> Loader Class Initialized
INFO - 2025-11-09 01:23:44 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:23:44 --> Helper loaded: url_helper
INFO - 2025-11-09 01:23:44 --> Helper loaded: file_helper
INFO - 2025-11-09 01:23:44 --> Helper loaded: main_helper
INFO - 2025-11-09 01:23:44 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:23:44 --> Database Driver Class Initialized
INFO - 2025-11-09 01:23:44 --> Email Class Initialized
DEBUG - 2025-11-09 01:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:23:44 --> Controller Class Initialized
INFO - 2025-11-09 01:23:44 --> Model "User_model" initialized
INFO - 2025-11-09 01:23:44 --> Model "Project_model" initialized
INFO - 2025-11-09 01:23:44 --> Helper loaded: form_helper
INFO - 2025-11-09 01:23:44 --> Form Validation Class Initialized
INFO - 2025-11-09 01:23:44 --> Final output sent to browser
INFO - 2025-11-09 01:23:44 --> Total execution time: 0.0982
INFO - 2025-11-09 01:23:44 --> Config Class Initialized
INFO - 2025-11-09 01:23:44 --> Hooks Class Initialized
INFO - 2025-11-09 01:23:44 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:23:44 --> Utf8 Class Initialized
INFO - 2025-11-09 01:23:44 --> URI Class Initialized
INFO - 2025-11-09 01:23:44 --> Router Class Initialized
INFO - 2025-11-09 01:23:44 --> Output Class Initialized
INFO - 2025-11-09 01:23:44 --> Security Class Initialized
INFO - 2025-11-09 01:23:44 --> Input Class Initialized
INFO - 2025-11-09 01:23:44 --> Language Class Initialized
INFO - 2025-11-09 01:23:44 --> Loader Class Initialized
INFO - 2025-11-09 01:23:44 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:23:44 --> Helper loaded: url_helper
INFO - 2025-11-09 01:23:44 --> Helper loaded: file_helper
INFO - 2025-11-09 01:23:44 --> Helper loaded: main_helper
INFO - 2025-11-09 01:23:44 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:23:44 --> Database Driver Class Initialized
INFO - 2025-11-09 01:23:44 --> Email Class Initialized
DEBUG - 2025-11-09 01:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:23:44 --> Controller Class Initialized
INFO - 2025-11-09 01:23:44 --> Model "Subscription_model" initialized
INFO - 2025-11-09 01:23:44 --> Model "User_model" initialized
INFO - 2025-11-09 01:23:44 --> Model "Auth_model" initialized
INFO - 2025-11-09 01:23:44 --> Model "Project_model" initialized
INFO - 2025-11-09 01:23:44 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-09 01:23:44 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-09 01:23:44 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-09 01:23:44 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ie.php
INFO - 2025-11-09 01:23:44 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-09 01:23:44 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-09 01:23:44 --> Final output sent to browser
INFO - 2025-11-09 01:23:44 --> Total execution time: 0.1251
INFO - 2025-11-09 01:23:44 --> Config Class Initialized
INFO - 2025-11-09 01:23:44 --> Hooks Class Initialized
INFO - 2025-11-09 01:23:44 --> Config Class Initialized
INFO - 2025-11-09 01:23:44 --> Config Class Initialized
INFO - 2025-11-09 01:23:44 --> Hooks Class Initialized
INFO - 2025-11-09 01:23:44 --> Hooks Class Initialized
INFO - 2025-11-09 01:23:44 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:23:44 --> Utf8 Class Initialized
INFO - 2025-11-09 01:23:44 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:23:44 --> URI Class Initialized
INFO - 2025-11-09 01:23:44 --> Utf8 Class Initialized
INFO - 2025-11-09 01:23:44 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:23:44 --> Utf8 Class Initialized
INFO - 2025-11-09 01:23:44 --> URI Class Initialized
INFO - 2025-11-09 01:23:44 --> Router Class Initialized
INFO - 2025-11-09 01:23:44 --> URI Class Initialized
INFO - 2025-11-09 01:23:44 --> Router Class Initialized
INFO - 2025-11-09 01:23:44 --> Output Class Initialized
INFO - 2025-11-09 01:23:44 --> Router Class Initialized
INFO - 2025-11-09 01:23:44 --> Security Class Initialized
INFO - 2025-11-09 01:23:44 --> Output Class Initialized
INFO - 2025-11-09 01:23:44 --> Output Class Initialized
INFO - 2025-11-09 01:23:44 --> Input Class Initialized
INFO - 2025-11-09 01:23:44 --> Security Class Initialized
INFO - 2025-11-09 01:23:44 --> Language Class Initialized
INFO - 2025-11-09 01:23:44 --> Security Class Initialized
INFO - 2025-11-09 01:23:44 --> Input Class Initialized
INFO - 2025-11-09 01:23:44 --> Input Class Initialized
INFO - 2025-11-09 01:23:44 --> Language Class Initialized
INFO - 2025-11-09 01:23:44 --> Language Class Initialized
INFO - 2025-11-09 01:23:44 --> Loader Class Initialized
INFO - 2025-11-09 01:23:44 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:23:44 --> Loader Class Initialized
INFO - 2025-11-09 01:23:44 --> Loader Class Initialized
INFO - 2025-11-09 01:23:44 --> Helper loaded: url_helper
INFO - 2025-11-09 01:23:44 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:23:44 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:23:44 --> Helper loaded: file_helper
INFO - 2025-11-09 01:23:44 --> Helper loaded: url_helper
INFO - 2025-11-09 01:23:44 --> Helper loaded: url_helper
INFO - 2025-11-09 01:23:44 --> Helper loaded: main_helper
INFO - 2025-11-09 01:23:44 --> Helper loaded: file_helper
INFO - 2025-11-09 01:23:44 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:23:44 --> Helper loaded: file_helper
INFO - 2025-11-09 01:23:44 --> Helper loaded: main_helper
INFO - 2025-11-09 01:23:44 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:23:44 --> Helper loaded: main_helper
INFO - 2025-11-09 01:23:44 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:23:44 --> Database Driver Class Initialized
INFO - 2025-11-09 01:23:44 --> Database Driver Class Initialized
INFO - 2025-11-09 01:23:44 --> Database Driver Class Initialized
INFO - 2025-11-09 01:23:44 --> Email Class Initialized
INFO - 2025-11-09 01:23:44 --> Email Class Initialized
INFO - 2025-11-09 01:23:44 --> Email Class Initialized
DEBUG - 2025-11-09 01:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:23:44 --> Controller Class Initialized
DEBUG - 2025-11-09 01:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-11-09 01:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:23:44 --> Model "User_model" initialized
INFO - 2025-11-09 01:23:44 --> Model "Project_model" initialized
INFO - 2025-11-09 01:23:44 --> Helper loaded: form_helper
INFO - 2025-11-09 01:23:44 --> Form Validation Class Initialized
INFO - 2025-11-09 01:23:44 --> Final output sent to browser
INFO - 2025-11-09 01:23:44 --> Total execution time: 0.1238
INFO - 2025-11-09 01:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:23:44 --> Controller Class Initialized
INFO - 2025-11-09 01:23:44 --> Model "User_model" initialized
INFO - 2025-11-09 01:23:44 --> Model "Project_model" initialized
INFO - 2025-11-09 01:23:44 --> Helper loaded: form_helper
INFO - 2025-11-09 01:23:44 --> Form Validation Class Initialized
INFO - 2025-11-09 01:23:44 --> Final output sent to browser
INFO - 2025-11-09 01:23:44 --> Total execution time: 0.1401
INFO - 2025-11-09 01:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:23:44 --> Controller Class Initialized
INFO - 2025-11-09 01:23:44 --> Model "User_model" initialized
INFO - 2025-11-09 01:23:44 --> Model "Project_model" initialized
INFO - 2025-11-09 01:23:44 --> Helper loaded: form_helper
INFO - 2025-11-09 01:23:44 --> Form Validation Class Initialized
INFO - 2025-11-09 01:23:44 --> Final output sent to browser
INFO - 2025-11-09 01:23:44 --> Total execution time: 0.1613
INFO - 2025-11-09 01:23:44 --> Config Class Initialized
INFO - 2025-11-09 01:23:44 --> Hooks Class Initialized
INFO - 2025-11-09 01:23:44 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:23:44 --> Utf8 Class Initialized
INFO - 2025-11-09 01:23:44 --> URI Class Initialized
INFO - 2025-11-09 01:23:44 --> Router Class Initialized
INFO - 2025-11-09 01:23:44 --> Output Class Initialized
INFO - 2025-11-09 01:23:44 --> Security Class Initialized
INFO - 2025-11-09 01:23:44 --> Input Class Initialized
INFO - 2025-11-09 01:23:44 --> Language Class Initialized
INFO - 2025-11-09 01:23:44 --> Loader Class Initialized
INFO - 2025-11-09 01:23:44 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:23:44 --> Helper loaded: url_helper
INFO - 2025-11-09 01:23:44 --> Helper loaded: file_helper
INFO - 2025-11-09 01:23:44 --> Helper loaded: main_helper
INFO - 2025-11-09 01:23:44 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:23:44 --> Database Driver Class Initialized
INFO - 2025-11-09 01:23:44 --> Email Class Initialized
DEBUG - 2025-11-09 01:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:23:44 --> Controller Class Initialized
INFO - 2025-11-09 01:23:44 --> Model "User_model" initialized
INFO - 2025-11-09 01:23:44 --> Model "Project_model" initialized
INFO - 2025-11-09 01:23:44 --> Helper loaded: form_helper
INFO - 2025-11-09 01:23:44 --> Form Validation Class Initialized
INFO - 2025-11-09 01:23:44 --> Final output sent to browser
INFO - 2025-11-09 01:23:44 --> Total execution time: 0.1530
INFO - 2025-11-09 01:23:46 --> Config Class Initialized
INFO - 2025-11-09 01:23:46 --> Hooks Class Initialized
INFO - 2025-11-09 01:23:46 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:23:46 --> Utf8 Class Initialized
INFO - 2025-11-09 01:23:46 --> URI Class Initialized
INFO - 2025-11-09 01:23:46 --> Router Class Initialized
INFO - 2025-11-09 01:23:46 --> Output Class Initialized
INFO - 2025-11-09 01:23:46 --> Security Class Initialized
INFO - 2025-11-09 01:23:46 --> Input Class Initialized
INFO - 2025-11-09 01:23:46 --> Language Class Initialized
INFO - 2025-11-09 01:23:46 --> Loader Class Initialized
INFO - 2025-11-09 01:23:46 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:23:46 --> Helper loaded: url_helper
INFO - 2025-11-09 01:23:46 --> Helper loaded: file_helper
INFO - 2025-11-09 01:23:46 --> Helper loaded: main_helper
INFO - 2025-11-09 01:23:46 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:23:46 --> Database Driver Class Initialized
INFO - 2025-11-09 01:23:46 --> Email Class Initialized
DEBUG - 2025-11-09 01:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:23:46 --> Controller Class Initialized
INFO - 2025-11-09 01:23:46 --> Model "Subscription_model" initialized
INFO - 2025-11-09 01:23:46 --> Model "User_model" initialized
INFO - 2025-11-09 01:23:46 --> Model "Auth_model" initialized
INFO - 2025-11-09 01:23:46 --> Model "Project_model" initialized
INFO - 2025-11-09 01:23:46 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-09 01:23:46 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-09 01:23:46 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-09 01:23:46 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ai.php
INFO - 2025-11-09 01:23:46 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-09 01:23:46 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-09 01:23:46 --> Final output sent to browser
INFO - 2025-11-09 01:23:46 --> Total execution time: 0.0939
INFO - 2025-11-09 01:25:23 --> Config Class Initialized
INFO - 2025-11-09 01:25:23 --> Hooks Class Initialized
INFO - 2025-11-09 01:25:23 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:25:23 --> Utf8 Class Initialized
INFO - 2025-11-09 01:25:23 --> URI Class Initialized
DEBUG - 2025-11-09 01:25:23 --> No URI present. Default controller set.
INFO - 2025-11-09 01:25:23 --> Router Class Initialized
INFO - 2025-11-09 01:25:23 --> Output Class Initialized
INFO - 2025-11-09 01:25:23 --> Security Class Initialized
INFO - 2025-11-09 01:25:23 --> Input Class Initialized
INFO - 2025-11-09 01:25:23 --> Language Class Initialized
INFO - 2025-11-09 01:25:23 --> Loader Class Initialized
INFO - 2025-11-09 01:25:23 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:25:23 --> Helper loaded: url_helper
INFO - 2025-11-09 01:25:23 --> Helper loaded: file_helper
INFO - 2025-11-09 01:25:23 --> Helper loaded: main_helper
INFO - 2025-11-09 01:25:23 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:25:23 --> Database Driver Class Initialized
INFO - 2025-11-09 01:25:23 --> Email Class Initialized
DEBUG - 2025-11-09 01:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:25:23 --> Controller Class Initialized
INFO - 2025-11-09 01:25:23 --> Config Class Initialized
INFO - 2025-11-09 01:25:23 --> Hooks Class Initialized
INFO - 2025-11-09 01:25:23 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:25:23 --> Utf8 Class Initialized
INFO - 2025-11-09 01:25:23 --> URI Class Initialized
INFO - 2025-11-09 01:25:23 --> Router Class Initialized
INFO - 2025-11-09 01:25:23 --> Output Class Initialized
INFO - 2025-11-09 01:25:23 --> Security Class Initialized
INFO - 2025-11-09 01:25:23 --> Input Class Initialized
INFO - 2025-11-09 01:25:23 --> Language Class Initialized
INFO - 2025-11-09 01:25:23 --> Loader Class Initialized
INFO - 2025-11-09 01:25:23 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:25:23 --> Helper loaded: url_helper
INFO - 2025-11-09 01:25:23 --> Helper loaded: file_helper
INFO - 2025-11-09 01:25:23 --> Helper loaded: main_helper
INFO - 2025-11-09 01:25:23 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:25:23 --> Database Driver Class Initialized
INFO - 2025-11-09 01:25:23 --> Email Class Initialized
DEBUG - 2025-11-09 01:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:25:23 --> Controller Class Initialized
INFO - 2025-11-09 01:25:23 --> Model "Subscription_model" initialized
INFO - 2025-11-09 01:25:23 --> Model "User_model" initialized
INFO - 2025-11-09 01:25:23 --> Model "Auth_model" initialized
INFO - 2025-11-09 01:25:23 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-09 01:25:23 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-09 01:25:23 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-09 01:25:23 --> File loaded: D:\laragon\www\acumena\application\views\dashboard.php
INFO - 2025-11-09 01:25:23 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-09 01:25:23 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-09 01:25:23 --> Final output sent to browser
INFO - 2025-11-09 01:25:23 --> Total execution time: 0.0942
INFO - 2025-11-09 01:25:23 --> Config Class Initialized
INFO - 2025-11-09 01:25:23 --> Hooks Class Initialized
INFO - 2025-11-09 01:25:23 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:25:23 --> Utf8 Class Initialized
INFO - 2025-11-09 01:25:23 --> URI Class Initialized
INFO - 2025-11-09 01:25:23 --> Router Class Initialized
INFO - 2025-11-09 01:25:23 --> Output Class Initialized
INFO - 2025-11-09 01:25:23 --> Security Class Initialized
INFO - 2025-11-09 01:25:23 --> Input Class Initialized
INFO - 2025-11-09 01:25:23 --> Language Class Initialized
INFO - 2025-11-09 01:25:23 --> Loader Class Initialized
INFO - 2025-11-09 01:25:23 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:25:23 --> Helper loaded: url_helper
INFO - 2025-11-09 01:25:23 --> Helper loaded: file_helper
INFO - 2025-11-09 01:25:23 --> Helper loaded: main_helper
INFO - 2025-11-09 01:25:23 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:25:23 --> Database Driver Class Initialized
INFO - 2025-11-09 01:25:23 --> Email Class Initialized
DEBUG - 2025-11-09 01:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:25:23 --> Controller Class Initialized
INFO - 2025-11-09 01:25:23 --> Model "User_model" initialized
INFO - 2025-11-09 01:25:23 --> Model "Project_model" initialized
INFO - 2025-11-09 01:25:23 --> Helper loaded: form_helper
INFO - 2025-11-09 01:25:23 --> Form Validation Class Initialized
INFO - 2025-11-09 01:25:23 --> Final output sent to browser
INFO - 2025-11-09 01:25:23 --> Total execution time: 0.1200
INFO - 2025-11-09 01:25:29 --> Config Class Initialized
INFO - 2025-11-09 01:25:29 --> Hooks Class Initialized
INFO - 2025-11-09 01:25:29 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:25:29 --> Utf8 Class Initialized
INFO - 2025-11-09 01:25:29 --> URI Class Initialized
INFO - 2025-11-09 01:25:29 --> Router Class Initialized
INFO - 2025-11-09 01:25:29 --> Output Class Initialized
INFO - 2025-11-09 01:25:29 --> Security Class Initialized
INFO - 2025-11-09 01:25:29 --> Input Class Initialized
INFO - 2025-11-09 01:25:29 --> Language Class Initialized
INFO - 2025-11-09 01:25:29 --> Loader Class Initialized
INFO - 2025-11-09 01:25:29 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:25:29 --> Helper loaded: url_helper
INFO - 2025-11-09 01:25:29 --> Helper loaded: file_helper
INFO - 2025-11-09 01:25:29 --> Helper loaded: main_helper
INFO - 2025-11-09 01:25:29 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:25:29 --> Database Driver Class Initialized
INFO - 2025-11-09 01:25:29 --> Email Class Initialized
DEBUG - 2025-11-09 01:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:25:29 --> Controller Class Initialized
INFO - 2025-11-09 01:25:29 --> Model "User_model" initialized
INFO - 2025-11-09 01:25:29 --> Model "Project_model" initialized
INFO - 2025-11-09 01:25:29 --> Helper loaded: form_helper
INFO - 2025-11-09 01:25:29 --> Form Validation Class Initialized
INFO - 2025-11-09 01:25:35 --> Final output sent to browser
INFO - 2025-11-09 01:25:35 --> Total execution time: 6.2628
INFO - 2025-11-09 01:25:35 --> Config Class Initialized
INFO - 2025-11-09 01:25:35 --> Hooks Class Initialized
INFO - 2025-11-09 01:25:35 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:25:35 --> Utf8 Class Initialized
INFO - 2025-11-09 01:25:35 --> URI Class Initialized
INFO - 2025-11-09 01:25:35 --> Router Class Initialized
INFO - 2025-11-09 01:25:35 --> Output Class Initialized
INFO - 2025-11-09 01:25:35 --> Security Class Initialized
INFO - 2025-11-09 01:25:35 --> Input Class Initialized
INFO - 2025-11-09 01:25:35 --> Language Class Initialized
ERROR - 2025-11-09 01:25:35 --> 404 Page Not Found: Faviconico/index
INFO - 2025-11-09 01:26:05 --> Config Class Initialized
INFO - 2025-11-09 01:26:05 --> Hooks Class Initialized
INFO - 2025-11-09 01:26:05 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:26:05 --> Utf8 Class Initialized
INFO - 2025-11-09 01:26:05 --> URI Class Initialized
INFO - 2025-11-09 01:26:05 --> Router Class Initialized
INFO - 2025-11-09 01:26:05 --> Output Class Initialized
INFO - 2025-11-09 01:26:05 --> Security Class Initialized
INFO - 2025-11-09 01:26:05 --> Input Class Initialized
INFO - 2025-11-09 01:26:05 --> Language Class Initialized
INFO - 2025-11-09 01:26:05 --> Loader Class Initialized
INFO - 2025-11-09 01:26:05 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:26:05 --> Helper loaded: url_helper
INFO - 2025-11-09 01:26:05 --> Helper loaded: file_helper
INFO - 2025-11-09 01:26:05 --> Helper loaded: main_helper
INFO - 2025-11-09 01:26:05 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:26:05 --> Database Driver Class Initialized
INFO - 2025-11-09 01:26:05 --> Email Class Initialized
DEBUG - 2025-11-09 01:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:26:05 --> Controller Class Initialized
INFO - 2025-11-09 01:26:05 --> Model "User_model" initialized
INFO - 2025-11-09 01:26:05 --> Model "Project_model" initialized
INFO - 2025-11-09 01:26:06 --> Helper loaded: form_helper
INFO - 2025-11-09 01:26:06 --> Form Validation Class Initialized
ERROR - 2025-11-09 01:26:12 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 320,
    "totalTokenCount": 1519,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 320
      }
    ],
    "thoughtsTokenCount": 1199
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "su0PadH7J8i44-EPwo258Qk"
}

INFO - 2025-11-09 01:26:12 --> Final output sent to browser
INFO - 2025-11-09 01:26:12 --> Total execution time: 7.0823
INFO - 2025-11-09 01:27:29 --> Config Class Initialized
INFO - 2025-11-09 01:27:29 --> Hooks Class Initialized
INFO - 2025-11-09 01:27:29 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:27:29 --> Utf8 Class Initialized
INFO - 2025-11-09 01:27:29 --> URI Class Initialized
INFO - 2025-11-09 01:27:29 --> Router Class Initialized
INFO - 2025-11-09 01:27:29 --> Output Class Initialized
INFO - 2025-11-09 01:27:29 --> Security Class Initialized
INFO - 2025-11-09 01:27:29 --> Input Class Initialized
INFO - 2025-11-09 01:27:29 --> Language Class Initialized
INFO - 2025-11-09 01:27:29 --> Loader Class Initialized
INFO - 2025-11-09 01:27:29 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:27:29 --> Helper loaded: url_helper
INFO - 2025-11-09 01:27:29 --> Helper loaded: file_helper
INFO - 2025-11-09 01:27:29 --> Helper loaded: main_helper
INFO - 2025-11-09 01:27:29 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:27:29 --> Database Driver Class Initialized
INFO - 2025-11-09 01:27:29 --> Email Class Initialized
DEBUG - 2025-11-09 01:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:27:29 --> Controller Class Initialized
INFO - 2025-11-09 01:27:29 --> Model "User_model" initialized
INFO - 2025-11-09 01:27:29 --> Model "Project_model" initialized
INFO - 2025-11-09 01:27:29 --> Helper loaded: form_helper
INFO - 2025-11-09 01:27:29 --> Form Validation Class Initialized
ERROR - 2025-11-09 01:27:43 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 335,
    "totalTokenCount": 1534,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 335
      }
    ],
    "thoughtsTokenCount": 1199
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "De4PaYzgIIjYjuMPuouQmQI"
}

INFO - 2025-11-09 01:27:43 --> Final output sent to browser
INFO - 2025-11-09 01:27:43 --> Total execution time: 14.1721
INFO - 2025-11-09 01:28:23 --> Config Class Initialized
INFO - 2025-11-09 01:28:23 --> Hooks Class Initialized
INFO - 2025-11-09 01:28:23 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:28:23 --> Utf8 Class Initialized
INFO - 2025-11-09 01:28:23 --> URI Class Initialized
INFO - 2025-11-09 01:28:23 --> Router Class Initialized
INFO - 2025-11-09 01:28:23 --> Output Class Initialized
INFO - 2025-11-09 01:28:23 --> Security Class Initialized
INFO - 2025-11-09 01:28:23 --> Input Class Initialized
INFO - 2025-11-09 01:28:23 --> Language Class Initialized
INFO - 2025-11-09 01:28:23 --> Loader Class Initialized
INFO - 2025-11-09 01:28:23 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:28:23 --> Helper loaded: url_helper
INFO - 2025-11-09 01:28:23 --> Helper loaded: file_helper
INFO - 2025-11-09 01:28:23 --> Helper loaded: main_helper
INFO - 2025-11-09 01:28:23 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:28:23 --> Database Driver Class Initialized
INFO - 2025-11-09 01:28:23 --> Email Class Initialized
DEBUG - 2025-11-09 01:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:28:23 --> Controller Class Initialized
INFO - 2025-11-09 01:28:23 --> Model "User_model" initialized
INFO - 2025-11-09 01:28:23 --> Model "Project_model" initialized
INFO - 2025-11-09 01:28:23 --> Helper loaded: form_helper
INFO - 2025-11-09 01:28:23 --> Form Validation Class Initialized
INFO - 2025-11-09 01:28:29 --> Final output sent to browser
INFO - 2025-11-09 01:28:29 --> Total execution time: 5.3565
INFO - 2025-11-09 01:30:50 --> Config Class Initialized
INFO - 2025-11-09 01:30:50 --> Hooks Class Initialized
INFO - 2025-11-09 01:30:50 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:30:50 --> Utf8 Class Initialized
INFO - 2025-11-09 01:30:50 --> URI Class Initialized
INFO - 2025-11-09 01:30:50 --> Router Class Initialized
INFO - 2025-11-09 01:30:50 --> Output Class Initialized
INFO - 2025-11-09 01:30:50 --> Security Class Initialized
INFO - 2025-11-09 01:30:50 --> Input Class Initialized
INFO - 2025-11-09 01:30:50 --> Language Class Initialized
INFO - 2025-11-09 01:30:50 --> Loader Class Initialized
INFO - 2025-11-09 01:30:50 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:30:50 --> Helper loaded: url_helper
INFO - 2025-11-09 01:30:50 --> Helper loaded: file_helper
INFO - 2025-11-09 01:30:50 --> Helper loaded: main_helper
INFO - 2025-11-09 01:30:50 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:30:50 --> Database Driver Class Initialized
INFO - 2025-11-09 01:30:50 --> Email Class Initialized
DEBUG - 2025-11-09 01:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:30:50 --> Controller Class Initialized
INFO - 2025-11-09 01:30:50 --> Model "Subscription_model" initialized
INFO - 2025-11-09 01:30:50 --> Model "User_model" initialized
INFO - 2025-11-09 01:30:50 --> Model "Auth_model" initialized
INFO - 2025-11-09 01:30:50 --> Model "Project_model" initialized
INFO - 2025-11-09 01:30:50 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-09 01:30:50 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-09 01:30:50 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-09 01:30:50 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ie.php
INFO - 2025-11-09 01:30:50 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-09 01:30:50 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-09 01:30:50 --> Final output sent to browser
INFO - 2025-11-09 01:30:50 --> Total execution time: 0.1226
INFO - 2025-11-09 01:30:50 --> Config Class Initialized
INFO - 2025-11-09 01:30:50 --> Config Class Initialized
INFO - 2025-11-09 01:30:50 --> Config Class Initialized
INFO - 2025-11-09 01:30:50 --> Hooks Class Initialized
INFO - 2025-11-09 01:30:50 --> Hooks Class Initialized
INFO - 2025-11-09 01:30:50 --> Hooks Class Initialized
INFO - 2025-11-09 01:30:50 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:30:50 --> Utf8 Class Initialized
INFO - 2025-11-09 01:30:50 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:30:50 --> Utf8 Class Initialized
INFO - 2025-11-09 01:30:50 --> URI Class Initialized
INFO - 2025-11-09 01:30:50 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:30:50 --> URI Class Initialized
INFO - 2025-11-09 01:30:50 --> Utf8 Class Initialized
INFO - 2025-11-09 01:30:50 --> Router Class Initialized
INFO - 2025-11-09 01:30:50 --> URI Class Initialized
INFO - 2025-11-09 01:30:50 --> Router Class Initialized
INFO - 2025-11-09 01:30:50 --> Output Class Initialized
INFO - 2025-11-09 01:30:50 --> Router Class Initialized
INFO - 2025-11-09 01:30:50 --> Security Class Initialized
INFO - 2025-11-09 01:30:50 --> Output Class Initialized
INFO - 2025-11-09 01:30:50 --> Input Class Initialized
INFO - 2025-11-09 01:30:50 --> Security Class Initialized
INFO - 2025-11-09 01:30:50 --> Language Class Initialized
INFO - 2025-11-09 01:30:50 --> Output Class Initialized
INFO - 2025-11-09 01:30:50 --> Input Class Initialized
INFO - 2025-11-09 01:30:50 --> Language Class Initialized
INFO - 2025-11-09 01:30:50 --> Security Class Initialized
INFO - 2025-11-09 01:30:50 --> Input Class Initialized
INFO - 2025-11-09 01:30:50 --> Loader Class Initialized
INFO - 2025-11-09 01:30:50 --> Language Class Initialized
INFO - 2025-11-09 01:30:50 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:30:50 --> Loader Class Initialized
INFO - 2025-11-09 01:30:50 --> Helper loaded: url_helper
INFO - 2025-11-09 01:30:50 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:30:50 --> Helper loaded: file_helper
INFO - 2025-11-09 01:30:50 --> Helper loaded: url_helper
INFO - 2025-11-09 01:30:50 --> Loader Class Initialized
INFO - 2025-11-09 01:30:50 --> Helper loaded: main_helper
INFO - 2025-11-09 01:30:50 --> Helper loaded: file_helper
INFO - 2025-11-09 01:30:50 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:30:50 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:30:50 --> Helper loaded: main_helper
INFO - 2025-11-09 01:30:50 --> Helper loaded: url_helper
INFO - 2025-11-09 01:30:50 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:30:50 --> Helper loaded: file_helper
INFO - 2025-11-09 01:30:50 --> Helper loaded: main_helper
INFO - 2025-11-09 01:30:50 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:30:50 --> Database Driver Class Initialized
INFO - 2025-11-09 01:30:50 --> Database Driver Class Initialized
INFO - 2025-11-09 01:30:50 --> Email Class Initialized
INFO - 2025-11-09 01:30:50 --> Database Driver Class Initialized
INFO - 2025-11-09 01:30:50 --> Email Class Initialized
DEBUG - 2025-11-09 01:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:30:50 --> Controller Class Initialized
INFO - 2025-11-09 01:30:50 --> Email Class Initialized
DEBUG - 2025-11-09 01:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:30:51 --> Model "User_model" initialized
INFO - 2025-11-09 01:30:51 --> Model "Project_model" initialized
DEBUG - 2025-11-09 01:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:30:51 --> Helper loaded: form_helper
INFO - 2025-11-09 01:30:51 --> Form Validation Class Initialized
INFO - 2025-11-09 01:30:51 --> Final output sent to browser
INFO - 2025-11-09 01:30:51 --> Total execution time: 0.0885
INFO - 2025-11-09 01:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:30:51 --> Controller Class Initialized
INFO - 2025-11-09 01:30:51 --> Model "User_model" initialized
INFO - 2025-11-09 01:30:51 --> Model "Project_model" initialized
INFO - 2025-11-09 01:30:51 --> Helper loaded: form_helper
INFO - 2025-11-09 01:30:51 --> Form Validation Class Initialized
INFO - 2025-11-09 01:30:51 --> Final output sent to browser
INFO - 2025-11-09 01:30:51 --> Total execution time: 0.1037
INFO - 2025-11-09 01:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:30:51 --> Controller Class Initialized
INFO - 2025-11-09 01:30:51 --> Model "User_model" initialized
INFO - 2025-11-09 01:30:51 --> Model "Project_model" initialized
INFO - 2025-11-09 01:30:51 --> Helper loaded: form_helper
INFO - 2025-11-09 01:30:51 --> Form Validation Class Initialized
INFO - 2025-11-09 01:30:51 --> Final output sent to browser
INFO - 2025-11-09 01:30:51 --> Total execution time: 0.1190
INFO - 2025-11-09 01:30:51 --> Config Class Initialized
INFO - 2025-11-09 01:30:51 --> Hooks Class Initialized
INFO - 2025-11-09 01:30:51 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:30:51 --> Utf8 Class Initialized
INFO - 2025-11-09 01:30:51 --> URI Class Initialized
INFO - 2025-11-09 01:30:51 --> Router Class Initialized
INFO - 2025-11-09 01:30:51 --> Output Class Initialized
INFO - 2025-11-09 01:30:51 --> Security Class Initialized
INFO - 2025-11-09 01:30:51 --> Input Class Initialized
INFO - 2025-11-09 01:30:51 --> Language Class Initialized
INFO - 2025-11-09 01:30:51 --> Loader Class Initialized
INFO - 2025-11-09 01:30:51 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:30:51 --> Helper loaded: url_helper
INFO - 2025-11-09 01:30:51 --> Helper loaded: file_helper
INFO - 2025-11-09 01:30:51 --> Helper loaded: main_helper
INFO - 2025-11-09 01:30:51 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:30:51 --> Database Driver Class Initialized
INFO - 2025-11-09 01:30:51 --> Email Class Initialized
DEBUG - 2025-11-09 01:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:30:51 --> Controller Class Initialized
INFO - 2025-11-09 01:30:51 --> Model "User_model" initialized
INFO - 2025-11-09 01:30:51 --> Model "Project_model" initialized
INFO - 2025-11-09 01:30:51 --> Helper loaded: form_helper
INFO - 2025-11-09 01:30:51 --> Form Validation Class Initialized
INFO - 2025-11-09 01:30:51 --> Final output sent to browser
INFO - 2025-11-09 01:30:51 --> Total execution time: 0.1034
INFO - 2025-11-09 01:30:53 --> Config Class Initialized
INFO - 2025-11-09 01:30:53 --> Hooks Class Initialized
INFO - 2025-11-09 01:30:53 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:30:53 --> Utf8 Class Initialized
INFO - 2025-11-09 01:30:53 --> URI Class Initialized
INFO - 2025-11-09 01:30:53 --> Router Class Initialized
INFO - 2025-11-09 01:30:53 --> Output Class Initialized
INFO - 2025-11-09 01:30:53 --> Security Class Initialized
INFO - 2025-11-09 01:30:53 --> Input Class Initialized
INFO - 2025-11-09 01:30:53 --> Language Class Initialized
INFO - 2025-11-09 01:30:53 --> Loader Class Initialized
INFO - 2025-11-09 01:30:53 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:30:53 --> Helper loaded: url_helper
INFO - 2025-11-09 01:30:53 --> Helper loaded: file_helper
INFO - 2025-11-09 01:30:53 --> Helper loaded: main_helper
INFO - 2025-11-09 01:30:53 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:30:53 --> Database Driver Class Initialized
INFO - 2025-11-09 01:30:53 --> Email Class Initialized
DEBUG - 2025-11-09 01:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:30:53 --> Controller Class Initialized
INFO - 2025-11-09 01:30:53 --> Model "Subscription_model" initialized
INFO - 2025-11-09 01:30:53 --> Model "User_model" initialized
INFO - 2025-11-09 01:30:53 --> Model "Auth_model" initialized
INFO - 2025-11-09 01:30:53 --> Model "Project_model" initialized
INFO - 2025-11-09 01:30:53 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-09 01:30:53 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-09 01:30:53 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-09 01:30:53 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-efe.php
INFO - 2025-11-09 01:30:53 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-09 01:30:53 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-09 01:30:53 --> Final output sent to browser
INFO - 2025-11-09 01:30:53 --> Total execution time: 0.0876
INFO - 2025-11-09 01:30:53 --> Config Class Initialized
INFO - 2025-11-09 01:30:53 --> Hooks Class Initialized
INFO - 2025-11-09 01:30:53 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:30:53 --> Utf8 Class Initialized
INFO - 2025-11-09 01:30:53 --> URI Class Initialized
INFO - 2025-11-09 01:30:53 --> Router Class Initialized
INFO - 2025-11-09 01:30:53 --> Output Class Initialized
INFO - 2025-11-09 01:30:53 --> Security Class Initialized
INFO - 2025-11-09 01:30:53 --> Input Class Initialized
INFO - 2025-11-09 01:30:53 --> Language Class Initialized
INFO - 2025-11-09 01:30:53 --> Loader Class Initialized
INFO - 2025-11-09 01:30:53 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:30:53 --> Helper loaded: url_helper
INFO - 2025-11-09 01:30:53 --> Helper loaded: file_helper
INFO - 2025-11-09 01:30:53 --> Helper loaded: main_helper
INFO - 2025-11-09 01:30:53 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:30:53 --> Database Driver Class Initialized
INFO - 2025-11-09 01:30:53 --> Email Class Initialized
DEBUG - 2025-11-09 01:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:30:53 --> Controller Class Initialized
INFO - 2025-11-09 01:30:53 --> Model "User_model" initialized
INFO - 2025-11-09 01:30:53 --> Model "Project_model" initialized
INFO - 2025-11-09 01:30:53 --> Helper loaded: form_helper
INFO - 2025-11-09 01:30:53 --> Form Validation Class Initialized
INFO - 2025-11-09 01:30:53 --> Final output sent to browser
INFO - 2025-11-09 01:30:53 --> Total execution time: 0.0844
INFO - 2025-11-09 01:30:56 --> Config Class Initialized
INFO - 2025-11-09 01:30:56 --> Hooks Class Initialized
INFO - 2025-11-09 01:30:56 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:30:56 --> Utf8 Class Initialized
INFO - 2025-11-09 01:30:56 --> URI Class Initialized
INFO - 2025-11-09 01:30:57 --> Router Class Initialized
INFO - 2025-11-09 01:30:57 --> Output Class Initialized
INFO - 2025-11-09 01:30:57 --> Security Class Initialized
INFO - 2025-11-09 01:30:57 --> Input Class Initialized
INFO - 2025-11-09 01:30:57 --> Language Class Initialized
INFO - 2025-11-09 01:30:57 --> Loader Class Initialized
INFO - 2025-11-09 01:30:57 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:30:57 --> Helper loaded: url_helper
INFO - 2025-11-09 01:30:57 --> Helper loaded: file_helper
INFO - 2025-11-09 01:30:57 --> Helper loaded: main_helper
INFO - 2025-11-09 01:30:57 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:30:57 --> Database Driver Class Initialized
INFO - 2025-11-09 01:30:57 --> Email Class Initialized
DEBUG - 2025-11-09 01:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:30:57 --> Controller Class Initialized
INFO - 2025-11-09 01:30:57 --> Model "Subscription_model" initialized
INFO - 2025-11-09 01:30:57 --> Model "User_model" initialized
INFO - 2025-11-09 01:30:57 --> Model "Auth_model" initialized
INFO - 2025-11-09 01:30:57 --> Model "Project_model" initialized
INFO - 2025-11-09 01:30:57 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-09 01:30:57 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-09 01:30:57 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-09 01:30:57 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ife.php
INFO - 2025-11-09 01:30:57 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-09 01:30:57 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-09 01:30:57 --> Final output sent to browser
INFO - 2025-11-09 01:30:57 --> Total execution time: 0.0939
INFO - 2025-11-09 01:30:57 --> Config Class Initialized
INFO - 2025-11-09 01:30:57 --> Hooks Class Initialized
INFO - 2025-11-09 01:30:57 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:30:57 --> Utf8 Class Initialized
INFO - 2025-11-09 01:30:57 --> URI Class Initialized
INFO - 2025-11-09 01:30:57 --> Router Class Initialized
INFO - 2025-11-09 01:30:57 --> Output Class Initialized
INFO - 2025-11-09 01:30:57 --> Security Class Initialized
INFO - 2025-11-09 01:30:57 --> Input Class Initialized
INFO - 2025-11-09 01:30:57 --> Language Class Initialized
INFO - 2025-11-09 01:30:57 --> Loader Class Initialized
INFO - 2025-11-09 01:30:57 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:30:57 --> Helper loaded: url_helper
INFO - 2025-11-09 01:30:57 --> Helper loaded: file_helper
INFO - 2025-11-09 01:30:57 --> Helper loaded: main_helper
INFO - 2025-11-09 01:30:57 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:30:57 --> Database Driver Class Initialized
INFO - 2025-11-09 01:30:57 --> Email Class Initialized
DEBUG - 2025-11-09 01:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:30:57 --> Controller Class Initialized
INFO - 2025-11-09 01:30:57 --> Model "User_model" initialized
INFO - 2025-11-09 01:30:57 --> Model "Project_model" initialized
INFO - 2025-11-09 01:30:57 --> Helper loaded: form_helper
INFO - 2025-11-09 01:30:57 --> Form Validation Class Initialized
INFO - 2025-11-09 01:30:57 --> Final output sent to browser
INFO - 2025-11-09 01:30:57 --> Total execution time: 0.0981
INFO - 2025-11-09 01:31:04 --> Config Class Initialized
INFO - 2025-11-09 01:31:04 --> Hooks Class Initialized
INFO - 2025-11-09 01:31:04 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:31:04 --> Utf8 Class Initialized
INFO - 2025-11-09 01:31:04 --> URI Class Initialized
INFO - 2025-11-09 01:31:04 --> Router Class Initialized
INFO - 2025-11-09 01:31:04 --> Output Class Initialized
INFO - 2025-11-09 01:31:04 --> Security Class Initialized
INFO - 2025-11-09 01:31:04 --> Input Class Initialized
INFO - 2025-11-09 01:31:04 --> Language Class Initialized
INFO - 2025-11-09 01:31:04 --> Loader Class Initialized
INFO - 2025-11-09 01:31:04 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:31:04 --> Helper loaded: url_helper
INFO - 2025-11-09 01:31:04 --> Helper loaded: file_helper
INFO - 2025-11-09 01:31:04 --> Helper loaded: main_helper
INFO - 2025-11-09 01:31:04 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:31:04 --> Database Driver Class Initialized
INFO - 2025-11-09 01:31:04 --> Email Class Initialized
DEBUG - 2025-11-09 01:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:31:04 --> Controller Class Initialized
INFO - 2025-11-09 01:31:04 --> Model "Subscription_model" initialized
INFO - 2025-11-09 01:31:04 --> Model "User_model" initialized
INFO - 2025-11-09 01:31:04 --> Model "Auth_model" initialized
INFO - 2025-11-09 01:31:04 --> Model "Project_model" initialized
INFO - 2025-11-09 01:31:04 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-09 01:31:04 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-09 01:31:04 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-09 01:31:04 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ai.php
INFO - 2025-11-09 01:31:04 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-09 01:31:04 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-09 01:31:04 --> Final output sent to browser
INFO - 2025-11-09 01:31:04 --> Total execution time: 0.1202
INFO - 2025-11-09 01:31:12 --> Config Class Initialized
INFO - 2025-11-09 01:31:12 --> Hooks Class Initialized
INFO - 2025-11-09 01:31:12 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:31:12 --> Utf8 Class Initialized
INFO - 2025-11-09 01:31:12 --> URI Class Initialized
INFO - 2025-11-09 01:31:12 --> Router Class Initialized
INFO - 2025-11-09 01:31:12 --> Output Class Initialized
INFO - 2025-11-09 01:31:12 --> Security Class Initialized
INFO - 2025-11-09 01:31:12 --> Input Class Initialized
INFO - 2025-11-09 01:31:12 --> Language Class Initialized
INFO - 2025-11-09 01:31:12 --> Loader Class Initialized
INFO - 2025-11-09 01:31:12 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:31:12 --> Helper loaded: url_helper
INFO - 2025-11-09 01:31:12 --> Helper loaded: file_helper
INFO - 2025-11-09 01:31:12 --> Helper loaded: main_helper
INFO - 2025-11-09 01:31:12 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:31:12 --> Database Driver Class Initialized
INFO - 2025-11-09 01:31:12 --> Email Class Initialized
DEBUG - 2025-11-09 01:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:31:12 --> Controller Class Initialized
INFO - 2025-11-09 01:31:12 --> Model "Subscription_model" initialized
INFO - 2025-11-09 01:31:12 --> Model "User_model" initialized
INFO - 2025-11-09 01:31:12 --> Model "Auth_model" initialized
INFO - 2025-11-09 01:31:12 --> Model "Project_model" initialized
INFO - 2025-11-09 01:31:12 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-09 01:31:12 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-09 01:31:12 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-09 01:31:12 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ife.php
INFO - 2025-11-09 01:31:12 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-09 01:31:12 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-09 01:31:12 --> Final output sent to browser
INFO - 2025-11-09 01:31:12 --> Total execution time: 0.0935
INFO - 2025-11-09 01:31:12 --> Config Class Initialized
INFO - 2025-11-09 01:31:12 --> Hooks Class Initialized
INFO - 2025-11-09 01:31:12 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:31:12 --> Utf8 Class Initialized
INFO - 2025-11-09 01:31:12 --> URI Class Initialized
INFO - 2025-11-09 01:31:12 --> Router Class Initialized
INFO - 2025-11-09 01:31:12 --> Output Class Initialized
INFO - 2025-11-09 01:31:12 --> Security Class Initialized
INFO - 2025-11-09 01:31:12 --> Input Class Initialized
INFO - 2025-11-09 01:31:12 --> Language Class Initialized
INFO - 2025-11-09 01:31:12 --> Loader Class Initialized
INFO - 2025-11-09 01:31:12 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:31:12 --> Helper loaded: url_helper
INFO - 2025-11-09 01:31:12 --> Helper loaded: file_helper
INFO - 2025-11-09 01:31:12 --> Helper loaded: main_helper
INFO - 2025-11-09 01:31:12 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:31:12 --> Database Driver Class Initialized
INFO - 2025-11-09 01:31:12 --> Email Class Initialized
DEBUG - 2025-11-09 01:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:31:12 --> Controller Class Initialized
INFO - 2025-11-09 01:31:12 --> Model "User_model" initialized
INFO - 2025-11-09 01:31:12 --> Model "Project_model" initialized
INFO - 2025-11-09 01:31:12 --> Helper loaded: form_helper
INFO - 2025-11-09 01:31:12 --> Form Validation Class Initialized
INFO - 2025-11-09 01:31:12 --> Final output sent to browser
INFO - 2025-11-09 01:31:12 --> Total execution time: 0.0922
INFO - 2025-11-09 01:31:15 --> Config Class Initialized
INFO - 2025-11-09 01:31:15 --> Hooks Class Initialized
INFO - 2025-11-09 01:31:15 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:31:15 --> Utf8 Class Initialized
INFO - 2025-11-09 01:31:15 --> URI Class Initialized
INFO - 2025-11-09 01:31:15 --> Router Class Initialized
INFO - 2025-11-09 01:31:15 --> Output Class Initialized
INFO - 2025-11-09 01:31:15 --> Security Class Initialized
INFO - 2025-11-09 01:31:15 --> Input Class Initialized
INFO - 2025-11-09 01:31:15 --> Language Class Initialized
INFO - 2025-11-09 01:31:15 --> Loader Class Initialized
INFO - 2025-11-09 01:31:15 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:31:15 --> Helper loaded: url_helper
INFO - 2025-11-09 01:31:15 --> Helper loaded: file_helper
INFO - 2025-11-09 01:31:15 --> Helper loaded: main_helper
INFO - 2025-11-09 01:31:15 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:31:15 --> Database Driver Class Initialized
INFO - 2025-11-09 01:31:15 --> Email Class Initialized
DEBUG - 2025-11-09 01:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:31:15 --> Controller Class Initialized
INFO - 2025-11-09 01:31:15 --> Model "Subscription_model" initialized
INFO - 2025-11-09 01:31:15 --> Model "User_model" initialized
INFO - 2025-11-09 01:31:15 --> Model "Auth_model" initialized
INFO - 2025-11-09 01:31:15 --> Model "Project_model" initialized
INFO - 2025-11-09 01:31:15 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-09 01:31:15 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-09 01:31:15 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-09 01:31:15 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-efe.php
INFO - 2025-11-09 01:31:15 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-09 01:31:15 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-09 01:31:16 --> Final output sent to browser
INFO - 2025-11-09 01:31:16 --> Total execution time: 0.0909
INFO - 2025-11-09 01:31:16 --> Config Class Initialized
INFO - 2025-11-09 01:31:16 --> Hooks Class Initialized
INFO - 2025-11-09 01:31:16 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:31:16 --> Utf8 Class Initialized
INFO - 2025-11-09 01:31:16 --> URI Class Initialized
INFO - 2025-11-09 01:31:16 --> Router Class Initialized
INFO - 2025-11-09 01:31:16 --> Output Class Initialized
INFO - 2025-11-09 01:31:16 --> Security Class Initialized
INFO - 2025-11-09 01:31:16 --> Input Class Initialized
INFO - 2025-11-09 01:31:16 --> Language Class Initialized
INFO - 2025-11-09 01:31:16 --> Loader Class Initialized
INFO - 2025-11-09 01:31:16 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:31:16 --> Helper loaded: url_helper
INFO - 2025-11-09 01:31:16 --> Helper loaded: file_helper
INFO - 2025-11-09 01:31:16 --> Helper loaded: main_helper
INFO - 2025-11-09 01:31:16 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:31:16 --> Database Driver Class Initialized
INFO - 2025-11-09 01:31:16 --> Email Class Initialized
DEBUG - 2025-11-09 01:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:31:16 --> Controller Class Initialized
INFO - 2025-11-09 01:31:16 --> Model "User_model" initialized
INFO - 2025-11-09 01:31:16 --> Model "Project_model" initialized
INFO - 2025-11-09 01:31:16 --> Helper loaded: form_helper
INFO - 2025-11-09 01:31:16 --> Form Validation Class Initialized
INFO - 2025-11-09 01:31:16 --> Final output sent to browser
INFO - 2025-11-09 01:31:16 --> Total execution time: 0.1012
INFO - 2025-11-09 01:31:20 --> Config Class Initialized
INFO - 2025-11-09 01:31:20 --> Hooks Class Initialized
INFO - 2025-11-09 01:31:20 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:31:20 --> Utf8 Class Initialized
INFO - 2025-11-09 01:31:20 --> URI Class Initialized
INFO - 2025-11-09 01:31:20 --> Router Class Initialized
INFO - 2025-11-09 01:31:20 --> Output Class Initialized
INFO - 2025-11-09 01:31:20 --> Security Class Initialized
INFO - 2025-11-09 01:31:20 --> Input Class Initialized
INFO - 2025-11-09 01:31:20 --> Language Class Initialized
INFO - 2025-11-09 01:31:20 --> Loader Class Initialized
INFO - 2025-11-09 01:31:20 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:31:20 --> Helper loaded: url_helper
INFO - 2025-11-09 01:31:20 --> Helper loaded: file_helper
INFO - 2025-11-09 01:31:20 --> Helper loaded: main_helper
INFO - 2025-11-09 01:31:20 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:31:20 --> Database Driver Class Initialized
INFO - 2025-11-09 01:31:20 --> Email Class Initialized
DEBUG - 2025-11-09 01:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:31:20 --> Controller Class Initialized
INFO - 2025-11-09 01:31:20 --> Model "Subscription_model" initialized
INFO - 2025-11-09 01:31:20 --> Model "User_model" initialized
INFO - 2025-11-09 01:31:20 --> Model "Auth_model" initialized
INFO - 2025-11-09 01:31:20 --> Model "Project_model" initialized
INFO - 2025-11-09 01:31:20 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-09 01:31:20 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-09 01:31:20 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-09 01:31:20 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ai.php
INFO - 2025-11-09 01:31:20 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-09 01:31:20 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-09 01:31:20 --> Final output sent to browser
INFO - 2025-11-09 01:31:20 --> Total execution time: 0.0901
INFO - 2025-11-09 01:31:27 --> Config Class Initialized
INFO - 2025-11-09 01:31:27 --> Hooks Class Initialized
INFO - 2025-11-09 01:31:27 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:31:27 --> Utf8 Class Initialized
INFO - 2025-11-09 01:31:27 --> URI Class Initialized
INFO - 2025-11-09 01:31:27 --> Router Class Initialized
INFO - 2025-11-09 01:31:27 --> Output Class Initialized
INFO - 2025-11-09 01:31:27 --> Security Class Initialized
INFO - 2025-11-09 01:31:27 --> Input Class Initialized
INFO - 2025-11-09 01:31:27 --> Language Class Initialized
INFO - 2025-11-09 01:31:28 --> Loader Class Initialized
INFO - 2025-11-09 01:31:28 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:31:28 --> Helper loaded: url_helper
INFO - 2025-11-09 01:31:28 --> Helper loaded: file_helper
INFO - 2025-11-09 01:31:28 --> Helper loaded: main_helper
INFO - 2025-11-09 01:31:28 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:31:28 --> Database Driver Class Initialized
INFO - 2025-11-09 01:31:28 --> Email Class Initialized
DEBUG - 2025-11-09 01:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:31:28 --> Controller Class Initialized
INFO - 2025-11-09 01:31:28 --> Model "User_model" initialized
INFO - 2025-11-09 01:31:28 --> Model "Project_model" initialized
INFO - 2025-11-09 01:31:28 --> Helper loaded: form_helper
INFO - 2025-11-09 01:31:28 --> Form Validation Class Initialized
INFO - 2025-11-09 01:31:32 --> Config Class Initialized
INFO - 2025-11-09 01:31:32 --> Hooks Class Initialized
INFO - 2025-11-09 01:31:32 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:31:32 --> Utf8 Class Initialized
INFO - 2025-11-09 01:31:32 --> URI Class Initialized
INFO - 2025-11-09 01:31:32 --> Router Class Initialized
INFO - 2025-11-09 01:31:32 --> Output Class Initialized
INFO - 2025-11-09 01:31:32 --> Security Class Initialized
INFO - 2025-11-09 01:31:32 --> Input Class Initialized
INFO - 2025-11-09 01:31:32 --> Language Class Initialized
INFO - 2025-11-09 01:31:32 --> Loader Class Initialized
INFO - 2025-11-09 01:31:32 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:31:32 --> Helper loaded: url_helper
INFO - 2025-11-09 01:31:32 --> Helper loaded: file_helper
INFO - 2025-11-09 01:31:32 --> Helper loaded: main_helper
INFO - 2025-11-09 01:31:32 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:31:32 --> Database Driver Class Initialized
INFO - 2025-11-09 01:31:32 --> Email Class Initialized
DEBUG - 2025-11-09 01:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2025-11-09 01:31:35 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 392,
    "totalTokenCount": 1591,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 392
      }
    ],
    "thoughtsTokenCount": 1199
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "9e4PabuaCqXGjuMP7rDN6Q0"
}

INFO - 2025-11-09 01:31:35 --> Final output sent to browser
INFO - 2025-11-09 01:31:35 --> Total execution time: 7.4349
INFO - 2025-11-09 01:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:31:35 --> Controller Class Initialized
INFO - 2025-11-09 01:31:35 --> Model "Subscription_model" initialized
INFO - 2025-11-09 01:31:35 --> Model "User_model" initialized
INFO - 2025-11-09 01:31:35 --> Model "Auth_model" initialized
INFO - 2025-11-09 01:31:35 --> Model "Project_model" initialized
INFO - 2025-11-09 01:31:35 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-09 01:31:35 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-09 01:31:35 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-09 01:31:35 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-efe.php
INFO - 2025-11-09 01:31:35 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-09 01:31:35 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-09 01:31:35 --> Final output sent to browser
INFO - 2025-11-09 01:31:35 --> Total execution time: 2.8119
INFO - 2025-11-09 01:31:35 --> Config Class Initialized
INFO - 2025-11-09 01:31:35 --> Hooks Class Initialized
INFO - 2025-11-09 01:31:35 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:31:35 --> Utf8 Class Initialized
INFO - 2025-11-09 01:31:35 --> URI Class Initialized
INFO - 2025-11-09 01:31:35 --> Router Class Initialized
INFO - 2025-11-09 01:31:35 --> Output Class Initialized
INFO - 2025-11-09 01:31:35 --> Security Class Initialized
INFO - 2025-11-09 01:31:35 --> Input Class Initialized
INFO - 2025-11-09 01:31:35 --> Language Class Initialized
INFO - 2025-11-09 01:31:35 --> Loader Class Initialized
INFO - 2025-11-09 01:31:35 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:31:35 --> Helper loaded: url_helper
INFO - 2025-11-09 01:31:35 --> Helper loaded: file_helper
INFO - 2025-11-09 01:31:35 --> Helper loaded: main_helper
INFO - 2025-11-09 01:31:35 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:31:35 --> Database Driver Class Initialized
INFO - 2025-11-09 01:31:35 --> Email Class Initialized
DEBUG - 2025-11-09 01:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:31:35 --> Controller Class Initialized
INFO - 2025-11-09 01:31:35 --> Model "User_model" initialized
INFO - 2025-11-09 01:31:35 --> Model "Project_model" initialized
INFO - 2025-11-09 01:31:35 --> Helper loaded: form_helper
INFO - 2025-11-09 01:31:35 --> Form Validation Class Initialized
INFO - 2025-11-09 01:31:35 --> Final output sent to browser
INFO - 2025-11-09 01:31:35 --> Total execution time: 0.1000
INFO - 2025-11-09 01:43:02 --> Config Class Initialized
INFO - 2025-11-09 01:43:02 --> Hooks Class Initialized
INFO - 2025-11-09 01:43:02 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:43:02 --> Utf8 Class Initialized
INFO - 2025-11-09 01:43:02 --> URI Class Initialized
INFO - 2025-11-09 01:43:02 --> Router Class Initialized
INFO - 2025-11-09 01:43:02 --> Output Class Initialized
INFO - 2025-11-09 01:43:02 --> Security Class Initialized
INFO - 2025-11-09 01:43:02 --> Input Class Initialized
INFO - 2025-11-09 01:43:02 --> Language Class Initialized
INFO - 2025-11-09 01:43:02 --> Loader Class Initialized
INFO - 2025-11-09 01:43:02 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:43:02 --> Helper loaded: url_helper
INFO - 2025-11-09 01:43:02 --> Helper loaded: file_helper
INFO - 2025-11-09 01:43:02 --> Helper loaded: main_helper
INFO - 2025-11-09 01:43:02 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:43:02 --> Database Driver Class Initialized
INFO - 2025-11-09 01:43:02 --> Email Class Initialized
DEBUG - 2025-11-09 01:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:43:02 --> Controller Class Initialized
INFO - 2025-11-09 01:43:02 --> Model "User_model" initialized
INFO - 2025-11-09 01:43:02 --> Model "Project_model" initialized
INFO - 2025-11-09 01:43:02 --> Helper loaded: form_helper
INFO - 2025-11-09 01:43:02 --> Form Validation Class Initialized
INFO - 2025-11-09 01:43:02 --> Final output sent to browser
INFO - 2025-11-09 01:43:02 --> Total execution time: 0.1106
INFO - 2025-11-09 01:43:14 --> Config Class Initialized
INFO - 2025-11-09 01:43:14 --> Hooks Class Initialized
INFO - 2025-11-09 01:43:14 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:43:14 --> Utf8 Class Initialized
INFO - 2025-11-09 01:43:14 --> URI Class Initialized
INFO - 2025-11-09 01:43:14 --> Router Class Initialized
INFO - 2025-11-09 01:43:14 --> Output Class Initialized
INFO - 2025-11-09 01:43:14 --> Security Class Initialized
INFO - 2025-11-09 01:43:14 --> Input Class Initialized
INFO - 2025-11-09 01:43:14 --> Language Class Initialized
INFO - 2025-11-09 01:43:14 --> Loader Class Initialized
INFO - 2025-11-09 01:43:14 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:43:14 --> Helper loaded: url_helper
INFO - 2025-11-09 01:43:14 --> Helper loaded: file_helper
INFO - 2025-11-09 01:43:14 --> Helper loaded: main_helper
INFO - 2025-11-09 01:43:14 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:43:15 --> Database Driver Class Initialized
INFO - 2025-11-09 01:43:15 --> Email Class Initialized
DEBUG - 2025-11-09 01:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:43:15 --> Controller Class Initialized
INFO - 2025-11-09 01:43:15 --> Model "User_model" initialized
INFO - 2025-11-09 01:43:15 --> Model "Project_model" initialized
INFO - 2025-11-09 01:43:15 --> Helper loaded: form_helper
INFO - 2025-11-09 01:43:15 --> Form Validation Class Initialized
ERROR - 2025-11-09 01:43:22 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 392,
    "totalTokenCount": 1591,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 392
      }
    ],
    "thoughtsTokenCount": 1199
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "sfEPacy6PLvJ4-EP5byT6Qs"
}

INFO - 2025-11-09 01:43:22 --> Final output sent to browser
INFO - 2025-11-09 01:43:22 --> Total execution time: 7.1712
INFO - 2025-11-09 01:57:42 --> Config Class Initialized
INFO - 2025-11-09 01:57:42 --> Hooks Class Initialized
INFO - 2025-11-09 01:57:42 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:57:42 --> Utf8 Class Initialized
INFO - 2025-11-09 01:57:42 --> URI Class Initialized
INFO - 2025-11-09 01:57:42 --> Router Class Initialized
INFO - 2025-11-09 01:57:42 --> Output Class Initialized
INFO - 2025-11-09 01:57:42 --> Security Class Initialized
INFO - 2025-11-09 01:57:42 --> Input Class Initialized
INFO - 2025-11-09 01:57:42 --> Language Class Initialized
INFO - 2025-11-09 01:57:42 --> Loader Class Initialized
INFO - 2025-11-09 01:57:42 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:57:42 --> Helper loaded: url_helper
INFO - 2025-11-09 01:57:42 --> Helper loaded: file_helper
INFO - 2025-11-09 01:57:42 --> Helper loaded: main_helper
INFO - 2025-11-09 01:57:42 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:57:42 --> Database Driver Class Initialized
INFO - 2025-11-09 01:57:42 --> Email Class Initialized
DEBUG - 2025-11-09 01:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:57:42 --> Controller Class Initialized
INFO - 2025-11-09 01:57:42 --> Model "User_model" initialized
INFO - 2025-11-09 01:57:42 --> Model "Project_model" initialized
INFO - 2025-11-09 01:57:42 --> Helper loaded: form_helper
INFO - 2025-11-09 01:57:42 --> Form Validation Class Initialized
INFO - 2025-11-09 01:57:42 --> Final output sent to browser
INFO - 2025-11-09 01:57:42 --> Total execution time: 0.1133
INFO - 2025-11-09 01:59:01 --> Config Class Initialized
INFO - 2025-11-09 01:59:01 --> Hooks Class Initialized
INFO - 2025-11-09 01:59:01 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:59:01 --> Utf8 Class Initialized
INFO - 2025-11-09 01:59:01 --> URI Class Initialized
INFO - 2025-11-09 01:59:01 --> Router Class Initialized
INFO - 2025-11-09 01:59:01 --> Output Class Initialized
INFO - 2025-11-09 01:59:01 --> Security Class Initialized
INFO - 2025-11-09 01:59:01 --> Input Class Initialized
INFO - 2025-11-09 01:59:01 --> Language Class Initialized
INFO - 2025-11-09 01:59:01 --> Loader Class Initialized
INFO - 2025-11-09 01:59:01 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:59:01 --> Helper loaded: url_helper
INFO - 2025-11-09 01:59:01 --> Helper loaded: file_helper
INFO - 2025-11-09 01:59:01 --> Helper loaded: main_helper
INFO - 2025-11-09 01:59:01 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:59:01 --> Database Driver Class Initialized
INFO - 2025-11-09 01:59:01 --> Email Class Initialized
DEBUG - 2025-11-09 01:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:59:01 --> Controller Class Initialized
INFO - 2025-11-09 01:59:01 --> Model "User_model" initialized
INFO - 2025-11-09 01:59:01 --> Model "Project_model" initialized
INFO - 2025-11-09 01:59:01 --> Helper loaded: form_helper
INFO - 2025-11-09 01:59:01 --> Form Validation Class Initialized
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "s_id" D:\laragon\www\acumena\application\models\Project_model.php 531
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "o_id" D:\laragon\www\acumena\application\models\Project_model.php 532
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "s_description" D:\laragon\www\acumena\application\models\Project_model.php 533
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "o_description" D:\laragon\www\acumena\application\models\Project_model.php 534
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "s_id" D:\laragon\www\acumena\application\models\Project_model.php 531
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "o_id" D:\laragon\www\acumena\application\models\Project_model.php 532
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "s_description" D:\laragon\www\acumena\application\models\Project_model.php 533
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "o_description" D:\laragon\www\acumena\application\models\Project_model.php 534
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "s_id" D:\laragon\www\acumena\application\models\Project_model.php 531
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "o_id" D:\laragon\www\acumena\application\models\Project_model.php 532
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "s_description" D:\laragon\www\acumena\application\models\Project_model.php 533
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "o_description" D:\laragon\www\acumena\application\models\Project_model.php 534
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "s_id" D:\laragon\www\acumena\application\models\Project_model.php 531
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "o_id" D:\laragon\www\acumena\application\models\Project_model.php 532
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "s_description" D:\laragon\www\acumena\application\models\Project_model.php 533
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "o_description" D:\laragon\www\acumena\application\models\Project_model.php 534
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "s_id" D:\laragon\www\acumena\application\models\Project_model.php 531
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "o_id" D:\laragon\www\acumena\application\models\Project_model.php 532
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "s_description" D:\laragon\www\acumena\application\models\Project_model.php 533
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "o_description" D:\laragon\www\acumena\application\models\Project_model.php 534
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "s_id" D:\laragon\www\acumena\application\models\Project_model.php 531
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "o_id" D:\laragon\www\acumena\application\models\Project_model.php 532
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "s_description" D:\laragon\www\acumena\application\models\Project_model.php 533
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "o_description" D:\laragon\www\acumena\application\models\Project_model.php 534
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "s_id" D:\laragon\www\acumena\application\models\Project_model.php 531
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "o_id" D:\laragon\www\acumena\application\models\Project_model.php 532
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "s_description" D:\laragon\www\acumena\application\models\Project_model.php 533
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "o_description" D:\laragon\www\acumena\application\models\Project_model.php 534
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "s_id" D:\laragon\www\acumena\application\models\Project_model.php 531
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "o_id" D:\laragon\www\acumena\application\models\Project_model.php 532
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "s_description" D:\laragon\www\acumena\application\models\Project_model.php 533
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "o_description" D:\laragon\www\acumena\application\models\Project_model.php 534
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "s_id" D:\laragon\www\acumena\application\models\Project_model.php 531
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "o_id" D:\laragon\www\acumena\application\models\Project_model.php 532
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "s_description" D:\laragon\www\acumena\application\models\Project_model.php 533
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "o_description" D:\laragon\www\acumena\application\models\Project_model.php 534
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "s_id" D:\laragon\www\acumena\application\models\Project_model.php 531
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "o_id" D:\laragon\www\acumena\application\models\Project_model.php 532
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "s_description" D:\laragon\www\acumena\application\models\Project_model.php 533
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "o_description" D:\laragon\www\acumena\application\models\Project_model.php 534
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "s_id" D:\laragon\www\acumena\application\models\Project_model.php 531
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "o_id" D:\laragon\www\acumena\application\models\Project_model.php 532
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "s_description" D:\laragon\www\acumena\application\models\Project_model.php 533
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "o_description" D:\laragon\www\acumena\application\models\Project_model.php 534
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "s_id" D:\laragon\www\acumena\application\models\Project_model.php 531
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "o_id" D:\laragon\www\acumena\application\models\Project_model.php 532
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "s_description" D:\laragon\www\acumena\application\models\Project_model.php 533
ERROR - 2025-11-09 01:59:01 --> Severity: Warning --> Undefined array key "o_description" D:\laragon\www\acumena\application\models\Project_model.php 534
INFO - 2025-11-09 01:59:04 --> Final output sent to browser
INFO - 2025-11-09 01:59:04 --> Total execution time: 3.5210
INFO - 2025-11-09 01:59:29 --> Config Class Initialized
INFO - 2025-11-09 01:59:29 --> Hooks Class Initialized
INFO - 2025-11-09 01:59:29 --> UTF-8 Support Enabled
INFO - 2025-11-09 01:59:29 --> Utf8 Class Initialized
INFO - 2025-11-09 01:59:29 --> URI Class Initialized
INFO - 2025-11-09 01:59:29 --> Router Class Initialized
INFO - 2025-11-09 01:59:29 --> Output Class Initialized
INFO - 2025-11-09 01:59:29 --> Security Class Initialized
INFO - 2025-11-09 01:59:29 --> Input Class Initialized
INFO - 2025-11-09 01:59:29 --> Language Class Initialized
INFO - 2025-11-09 01:59:29 --> Loader Class Initialized
INFO - 2025-11-09 01:59:29 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 01:59:29 --> Helper loaded: url_helper
INFO - 2025-11-09 01:59:29 --> Helper loaded: file_helper
INFO - 2025-11-09 01:59:29 --> Helper loaded: main_helper
INFO - 2025-11-09 01:59:29 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 01:59:29 --> Database Driver Class Initialized
INFO - 2025-11-09 01:59:29 --> Email Class Initialized
DEBUG - 2025-11-09 01:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 01:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 01:59:29 --> Controller Class Initialized
INFO - 2025-11-09 01:59:29 --> Model "User_model" initialized
INFO - 2025-11-09 01:59:29 --> Model "Project_model" initialized
INFO - 2025-11-09 01:59:29 --> Helper loaded: form_helper
INFO - 2025-11-09 01:59:29 --> Form Validation Class Initialized
ERROR - 2025-11-09 01:59:39 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 392,
    "totalTokenCount": 1591,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 392
      }
    ],
    "thoughtsTokenCount": 1199
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "iPUPab2tNvyM4-EPlqXD-Q8"
}

INFO - 2025-11-09 01:59:39 --> Final output sent to browser
INFO - 2025-11-09 01:59:39 --> Total execution time: 9.6527
INFO - 2025-11-09 02:11:28 --> Config Class Initialized
INFO - 2025-11-09 02:11:28 --> Hooks Class Initialized
INFO - 2025-11-09 02:11:28 --> UTF-8 Support Enabled
INFO - 2025-11-09 02:11:28 --> Utf8 Class Initialized
INFO - 2025-11-09 02:11:28 --> URI Class Initialized
INFO - 2025-11-09 02:11:28 --> Router Class Initialized
INFO - 2025-11-09 02:11:28 --> Output Class Initialized
INFO - 2025-11-09 02:11:28 --> Security Class Initialized
INFO - 2025-11-09 02:11:28 --> Input Class Initialized
INFO - 2025-11-09 02:11:28 --> Language Class Initialized
INFO - 2025-11-09 02:11:28 --> Loader Class Initialized
INFO - 2025-11-09 02:11:28 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 02:11:28 --> Helper loaded: url_helper
INFO - 2025-11-09 02:11:28 --> Helper loaded: file_helper
INFO - 2025-11-09 02:11:28 --> Helper loaded: main_helper
INFO - 2025-11-09 02:11:28 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 02:11:28 --> Database Driver Class Initialized
INFO - 2025-11-09 02:11:28 --> Email Class Initialized
DEBUG - 2025-11-09 02:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 02:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 02:11:28 --> Controller Class Initialized
INFO - 2025-11-09 02:11:28 --> Model "Subscription_model" initialized
INFO - 2025-11-09 02:11:28 --> Model "User_model" initialized
INFO - 2025-11-09 02:11:28 --> Model "Auth_model" initialized
INFO - 2025-11-09 02:11:28 --> Model "Project_model" initialized
INFO - 2025-11-09 02:11:28 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-09 02:11:28 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-09 02:11:28 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-09 02:11:28 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ai.php
INFO - 2025-11-09 02:11:28 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-09 02:11:28 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-09 02:11:28 --> Final output sent to browser
INFO - 2025-11-09 02:11:28 --> Total execution time: 0.1267
INFO - 2025-11-09 02:46:35 --> Config Class Initialized
INFO - 2025-11-09 02:46:36 --> Hooks Class Initialized
INFO - 2025-11-09 02:46:36 --> UTF-8 Support Enabled
INFO - 2025-11-09 02:46:36 --> Utf8 Class Initialized
INFO - 2025-11-09 02:46:36 --> URI Class Initialized
INFO - 2025-11-09 02:46:36 --> Router Class Initialized
INFO - 2025-11-09 02:46:36 --> Output Class Initialized
INFO - 2025-11-09 02:46:36 --> Security Class Initialized
INFO - 2025-11-09 02:46:36 --> Input Class Initialized
INFO - 2025-11-09 02:46:36 --> Language Class Initialized
INFO - 2025-11-09 02:46:36 --> Loader Class Initialized
INFO - 2025-11-09 02:46:36 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 02:46:37 --> Helper loaded: url_helper
INFO - 2025-11-09 02:46:37 --> Helper loaded: file_helper
INFO - 2025-11-09 02:46:37 --> Helper loaded: main_helper
INFO - 2025-11-09 02:46:37 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 02:46:37 --> Database Driver Class Initialized
INFO - 2025-11-09 02:46:37 --> Email Class Initialized
DEBUG - 2025-11-09 02:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 02:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 02:46:37 --> Controller Class Initialized
INFO - 2025-11-09 02:46:38 --> Model "Subscription_model" initialized
INFO - 2025-11-09 02:46:38 --> Model "User_model" initialized
INFO - 2025-11-09 02:46:38 --> Model "Auth_model" initialized
INFO - 2025-11-09 02:46:38 --> Model "Project_model" initialized
INFO - 2025-11-09 02:46:38 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-09 02:46:38 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-09 02:46:38 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-09 02:46:38 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ai.php
INFO - 2025-11-09 02:46:38 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-09 02:46:38 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-09 02:46:38 --> Final output sent to browser
INFO - 2025-11-09 02:46:38 --> Total execution time: 2.7629
INFO - 2025-11-09 02:46:41 --> Config Class Initialized
INFO - 2025-11-09 02:46:41 --> Hooks Class Initialized
INFO - 2025-11-09 02:46:41 --> UTF-8 Support Enabled
INFO - 2025-11-09 02:46:41 --> Utf8 Class Initialized
INFO - 2025-11-09 02:46:41 --> URI Class Initialized
INFO - 2025-11-09 02:46:41 --> Router Class Initialized
INFO - 2025-11-09 02:46:41 --> Output Class Initialized
INFO - 2025-11-09 02:46:41 --> Security Class Initialized
INFO - 2025-11-09 02:46:41 --> Input Class Initialized
INFO - 2025-11-09 02:46:41 --> Language Class Initialized
INFO - 2025-11-09 02:46:41 --> Loader Class Initialized
INFO - 2025-11-09 02:46:41 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 02:46:41 --> Helper loaded: url_helper
INFO - 2025-11-09 02:46:41 --> Helper loaded: file_helper
INFO - 2025-11-09 02:46:41 --> Helper loaded: main_helper
INFO - 2025-11-09 02:46:41 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 02:46:41 --> Database Driver Class Initialized
INFO - 2025-11-09 02:46:41 --> Email Class Initialized
DEBUG - 2025-11-09 02:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 02:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 02:46:41 --> Controller Class Initialized
INFO - 2025-11-09 02:46:41 --> Model "User_model" initialized
INFO - 2025-11-09 02:46:41 --> Model "Project_model" initialized
INFO - 2025-11-09 02:46:41 --> Helper loaded: form_helper
INFO - 2025-11-09 02:46:41 --> Form Validation Class Initialized
INFO - 2025-11-09 02:46:41 --> Final output sent to browser
INFO - 2025-11-09 02:46:41 --> Total execution time: 0.1441
INFO - 2025-11-09 02:46:41 --> Config Class Initialized
INFO - 2025-11-09 02:46:41 --> Hooks Class Initialized
INFO - 2025-11-09 02:46:41 --> UTF-8 Support Enabled
INFO - 2025-11-09 02:46:41 --> Utf8 Class Initialized
INFO - 2025-11-09 02:46:41 --> URI Class Initialized
INFO - 2025-11-09 02:46:41 --> Router Class Initialized
INFO - 2025-11-09 02:46:41 --> Output Class Initialized
INFO - 2025-11-09 02:46:41 --> Security Class Initialized
INFO - 2025-11-09 02:46:41 --> Input Class Initialized
INFO - 2025-11-09 02:46:41 --> Language Class Initialized
INFO - 2025-11-09 02:46:41 --> Loader Class Initialized
INFO - 2025-11-09 02:46:41 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 02:46:41 --> Helper loaded: url_helper
INFO - 2025-11-09 02:46:41 --> Helper loaded: file_helper
INFO - 2025-11-09 02:46:41 --> Helper loaded: main_helper
INFO - 2025-11-09 02:46:41 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 02:46:41 --> Database Driver Class Initialized
INFO - 2025-11-09 02:46:41 --> Email Class Initialized
DEBUG - 2025-11-09 02:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 02:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 02:46:41 --> Controller Class Initialized
INFO - 2025-11-09 02:46:41 --> Model "User_model" initialized
INFO - 2025-11-09 02:46:41 --> Model "Project_model" initialized
INFO - 2025-11-09 02:46:41 --> Helper loaded: form_helper
INFO - 2025-11-09 02:46:41 --> Form Validation Class Initialized
INFO - 2025-11-09 02:46:41 --> Final output sent to browser
INFO - 2025-11-09 02:46:41 --> Total execution time: 0.0658
INFO - 2025-11-09 02:51:18 --> Config Class Initialized
INFO - 2025-11-09 02:51:18 --> Hooks Class Initialized
INFO - 2025-11-09 02:51:18 --> UTF-8 Support Enabled
INFO - 2025-11-09 02:51:18 --> Utf8 Class Initialized
INFO - 2025-11-09 02:51:18 --> URI Class Initialized
INFO - 2025-11-09 02:51:18 --> Router Class Initialized
INFO - 2025-11-09 02:51:18 --> Output Class Initialized
INFO - 2025-11-09 02:51:18 --> Security Class Initialized
INFO - 2025-11-09 02:51:18 --> Input Class Initialized
INFO - 2025-11-09 02:51:18 --> Language Class Initialized
INFO - 2025-11-09 02:51:18 --> Loader Class Initialized
INFO - 2025-11-09 02:51:18 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 02:51:18 --> Helper loaded: url_helper
INFO - 2025-11-09 02:51:18 --> Helper loaded: file_helper
INFO - 2025-11-09 02:51:18 --> Helper loaded: main_helper
INFO - 2025-11-09 02:51:18 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 02:51:18 --> Database Driver Class Initialized
INFO - 2025-11-09 02:51:18 --> Email Class Initialized
DEBUG - 2025-11-09 02:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 02:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 02:51:18 --> Controller Class Initialized
INFO - 2025-11-09 02:51:18 --> Model "User_model" initialized
INFO - 2025-11-09 02:51:18 --> Model "Project_model" initialized
INFO - 2025-11-09 02:51:18 --> Helper loaded: form_helper
INFO - 2025-11-09 02:51:18 --> Form Validation Class Initialized
INFO - 2025-11-09 02:51:18 --> Final output sent to browser
INFO - 2025-11-09 02:51:18 --> Total execution time: 0.0961
INFO - 2025-11-09 02:51:49 --> Config Class Initialized
INFO - 2025-11-09 02:51:49 --> Hooks Class Initialized
INFO - 2025-11-09 02:51:49 --> UTF-8 Support Enabled
INFO - 2025-11-09 02:51:49 --> Utf8 Class Initialized
INFO - 2025-11-09 02:51:49 --> URI Class Initialized
INFO - 2025-11-09 02:51:49 --> Router Class Initialized
INFO - 2025-11-09 02:51:49 --> Output Class Initialized
INFO - 2025-11-09 02:51:49 --> Security Class Initialized
INFO - 2025-11-09 02:51:49 --> Input Class Initialized
INFO - 2025-11-09 02:51:49 --> Language Class Initialized
INFO - 2025-11-09 02:51:49 --> Loader Class Initialized
INFO - 2025-11-09 02:51:49 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 02:51:49 --> Helper loaded: url_helper
INFO - 2025-11-09 02:51:49 --> Helper loaded: file_helper
INFO - 2025-11-09 02:51:49 --> Helper loaded: main_helper
INFO - 2025-11-09 02:51:49 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 02:51:49 --> Database Driver Class Initialized
INFO - 2025-11-09 02:51:49 --> Email Class Initialized
DEBUG - 2025-11-09 02:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 02:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 02:51:49 --> Controller Class Initialized
INFO - 2025-11-09 02:51:49 --> Model "User_model" initialized
INFO - 2025-11-09 02:51:49 --> Model "Project_model" initialized
INFO - 2025-11-09 02:51:49 --> Helper loaded: form_helper
INFO - 2025-11-09 02:51:49 --> Form Validation Class Initialized
INFO - 2025-11-09 02:51:49 --> Final output sent to browser
INFO - 2025-11-09 02:51:49 --> Total execution time: 0.0742
INFO - 2025-11-09 02:52:33 --> Config Class Initialized
INFO - 2025-11-09 02:52:33 --> Hooks Class Initialized
INFO - 2025-11-09 02:52:33 --> UTF-8 Support Enabled
INFO - 2025-11-09 02:52:33 --> Utf8 Class Initialized
INFO - 2025-11-09 02:52:33 --> URI Class Initialized
INFO - 2025-11-09 02:52:33 --> Router Class Initialized
INFO - 2025-11-09 02:52:33 --> Output Class Initialized
INFO - 2025-11-09 02:52:33 --> Security Class Initialized
INFO - 2025-11-09 02:52:33 --> Input Class Initialized
INFO - 2025-11-09 02:52:33 --> Language Class Initialized
INFO - 2025-11-09 02:52:33 --> Loader Class Initialized
INFO - 2025-11-09 02:52:33 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 02:52:33 --> Helper loaded: url_helper
INFO - 2025-11-09 02:52:33 --> Helper loaded: file_helper
INFO - 2025-11-09 02:52:33 --> Helper loaded: main_helper
INFO - 2025-11-09 02:52:33 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 02:52:33 --> Database Driver Class Initialized
INFO - 2025-11-09 02:52:33 --> Email Class Initialized
DEBUG - 2025-11-09 02:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 02:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 02:52:33 --> Controller Class Initialized
INFO - 2025-11-09 02:52:33 --> Model "User_model" initialized
INFO - 2025-11-09 02:52:33 --> Model "Project_model" initialized
INFO - 2025-11-09 02:52:33 --> Helper loaded: form_helper
INFO - 2025-11-09 02:52:33 --> Form Validation Class Initialized
INFO - 2025-11-09 02:52:33 --> Final output sent to browser
INFO - 2025-11-09 02:52:33 --> Total execution time: 0.1047
INFO - 2025-11-09 02:54:32 --> Config Class Initialized
INFO - 2025-11-09 02:54:32 --> Hooks Class Initialized
INFO - 2025-11-09 02:54:32 --> UTF-8 Support Enabled
INFO - 2025-11-09 02:54:32 --> Utf8 Class Initialized
INFO - 2025-11-09 02:54:32 --> URI Class Initialized
INFO - 2025-11-09 02:54:32 --> Router Class Initialized
INFO - 2025-11-09 02:54:32 --> Output Class Initialized
INFO - 2025-11-09 02:54:32 --> Security Class Initialized
INFO - 2025-11-09 02:54:32 --> Input Class Initialized
INFO - 2025-11-09 02:54:32 --> Language Class Initialized
INFO - 2025-11-09 02:54:32 --> Loader Class Initialized
INFO - 2025-11-09 02:54:32 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 02:54:32 --> Helper loaded: url_helper
INFO - 2025-11-09 02:54:32 --> Helper loaded: file_helper
INFO - 2025-11-09 02:54:32 --> Helper loaded: main_helper
INFO - 2025-11-09 02:54:32 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 02:54:32 --> Database Driver Class Initialized
INFO - 2025-11-09 02:54:32 --> Email Class Initialized
DEBUG - 2025-11-09 02:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 02:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 02:54:32 --> Controller Class Initialized
INFO - 2025-11-09 02:54:32 --> Model "User_model" initialized
INFO - 2025-11-09 02:54:32 --> Model "Project_model" initialized
INFO - 2025-11-09 02:54:32 --> Helper loaded: form_helper
INFO - 2025-11-09 02:54:32 --> Form Validation Class Initialized
INFO - 2025-11-09 02:54:32 --> Final output sent to browser
INFO - 2025-11-09 02:54:32 --> Total execution time: 0.0893
INFO - 2025-11-09 03:03:53 --> Config Class Initialized
INFO - 2025-11-09 03:03:53 --> Hooks Class Initialized
INFO - 2025-11-09 03:03:53 --> UTF-8 Support Enabled
INFO - 2025-11-09 03:03:53 --> Utf8 Class Initialized
INFO - 2025-11-09 03:03:53 --> URI Class Initialized
INFO - 2025-11-09 03:03:53 --> Router Class Initialized
INFO - 2025-11-09 03:03:53 --> Output Class Initialized
INFO - 2025-11-09 03:03:54 --> Security Class Initialized
INFO - 2025-11-09 03:03:54 --> Input Class Initialized
INFO - 2025-11-09 03:03:54 --> Language Class Initialized
INFO - 2025-11-09 03:03:54 --> Loader Class Initialized
INFO - 2025-11-09 03:03:54 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 03:03:54 --> Helper loaded: url_helper
INFO - 2025-11-09 03:03:54 --> Helper loaded: file_helper
INFO - 2025-11-09 03:03:54 --> Helper loaded: main_helper
INFO - 2025-11-09 03:03:54 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 03:03:54 --> Database Driver Class Initialized
INFO - 2025-11-09 03:03:54 --> Email Class Initialized
DEBUG - 2025-11-09 03:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 03:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 03:03:54 --> Controller Class Initialized
INFO - 2025-11-09 03:03:54 --> Model "User_model" initialized
INFO - 2025-11-09 03:03:54 --> Model "Project_model" initialized
INFO - 2025-11-09 03:03:54 --> Helper loaded: form_helper
INFO - 2025-11-09 03:03:54 --> Form Validation Class Initialized
ERROR - 2025-11-09 03:03:54 --> Severity: Warning --> Undefined property: Api_project::$project_ai_generation_run_model D:\laragon\www\acumena\system\core\Model.php 74
ERROR - 2025-11-09 03:03:54 --> Severity: error --> Exception: Call to a member function get_by_hash() on null D:\laragon\www\acumena\application\models\Project_model.php 490
INFO - 2025-11-09 03:05:30 --> Config Class Initialized
INFO - 2025-11-09 03:05:30 --> Hooks Class Initialized
INFO - 2025-11-09 03:05:30 --> UTF-8 Support Enabled
INFO - 2025-11-09 03:05:30 --> Utf8 Class Initialized
INFO - 2025-11-09 03:05:30 --> URI Class Initialized
INFO - 2025-11-09 03:05:30 --> Router Class Initialized
INFO - 2025-11-09 03:05:30 --> Output Class Initialized
INFO - 2025-11-09 03:05:30 --> Security Class Initialized
INFO - 2025-11-09 03:05:30 --> Input Class Initialized
INFO - 2025-11-09 03:05:30 --> Language Class Initialized
INFO - 2025-11-09 03:05:30 --> Loader Class Initialized
INFO - 2025-11-09 03:05:30 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 03:05:30 --> Helper loaded: url_helper
INFO - 2025-11-09 03:05:30 --> Helper loaded: file_helper
INFO - 2025-11-09 03:05:30 --> Helper loaded: main_helper
INFO - 2025-11-09 03:05:30 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 03:05:30 --> Database Driver Class Initialized
INFO - 2025-11-09 03:05:30 --> Email Class Initialized
DEBUG - 2025-11-09 03:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 03:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 03:05:30 --> Controller Class Initialized
INFO - 2025-11-09 03:05:30 --> Model "User_model" initialized
INFO - 2025-11-09 03:05:30 --> Model "Project_model" initialized
INFO - 2025-11-09 03:05:30 --> Helper loaded: form_helper
INFO - 2025-11-09 03:05:30 --> Form Validation Class Initialized
ERROR - 2025-11-09 03:05:30 --> Severity: Warning --> Array to string conversion D:\laragon\www\acumena\system\database\DB_query_builder.php 2515
ERROR - 2025-11-09 03:05:30 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `id`, `project_id`, `pair_type`, `input_hash`, `status`, `created_at`
FROM `project_ai_generation_run`
WHERE `project_id` = '3'
AND `pair_type` = Array
AND `input_hash` = 'beefe0640fae449626a55e7f3fd2568d57de94bc214cc9cc97f3cd5c62e4839a'
INFO - 2025-11-09 03:05:30 --> Language file loaded: language/english/db_lang.php
INFO - 2025-11-09 03:08:49 --> Config Class Initialized
INFO - 2025-11-09 03:08:49 --> Hooks Class Initialized
INFO - 2025-11-09 03:08:49 --> UTF-8 Support Enabled
INFO - 2025-11-09 03:08:49 --> Utf8 Class Initialized
INFO - 2025-11-09 03:08:49 --> URI Class Initialized
INFO - 2025-11-09 03:08:49 --> Router Class Initialized
INFO - 2025-11-09 03:08:49 --> Output Class Initialized
INFO - 2025-11-09 03:08:49 --> Security Class Initialized
INFO - 2025-11-09 03:08:49 --> Input Class Initialized
INFO - 2025-11-09 03:08:49 --> Language Class Initialized
INFO - 2025-11-09 03:08:49 --> Loader Class Initialized
INFO - 2025-11-09 03:08:49 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 03:08:49 --> Helper loaded: url_helper
INFO - 2025-11-09 03:08:49 --> Helper loaded: file_helper
INFO - 2025-11-09 03:08:49 --> Helper loaded: main_helper
INFO - 2025-11-09 03:08:49 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 03:08:50 --> Database Driver Class Initialized
INFO - 2025-11-09 03:08:50 --> Email Class Initialized
DEBUG - 2025-11-09 03:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 03:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 03:08:50 --> Controller Class Initialized
INFO - 2025-11-09 03:08:50 --> Model "User_model" initialized
INFO - 2025-11-09 03:08:50 --> Model "Project_model" initialized
INFO - 2025-11-09 03:08:50 --> Helper loaded: form_helper
INFO - 2025-11-09 03:08:50 --> Form Validation Class Initialized
INFO - 2025-11-09 03:08:50 --> Final output sent to browser
INFO - 2025-11-09 03:08:50 --> Total execution time: 0.1055
INFO - 2025-11-09 03:14:38 --> Config Class Initialized
INFO - 2025-11-09 03:14:38 --> Hooks Class Initialized
INFO - 2025-11-09 03:14:38 --> UTF-8 Support Enabled
INFO - 2025-11-09 03:14:38 --> Utf8 Class Initialized
INFO - 2025-11-09 03:14:38 --> URI Class Initialized
INFO - 2025-11-09 03:14:38 --> Router Class Initialized
INFO - 2025-11-09 03:14:38 --> Output Class Initialized
INFO - 2025-11-09 03:14:38 --> Security Class Initialized
INFO - 2025-11-09 03:14:38 --> Input Class Initialized
INFO - 2025-11-09 03:14:38 --> Language Class Initialized
INFO - 2025-11-09 03:14:38 --> Loader Class Initialized
INFO - 2025-11-09 03:14:38 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 03:14:38 --> Helper loaded: url_helper
INFO - 2025-11-09 03:14:38 --> Helper loaded: file_helper
INFO - 2025-11-09 03:14:38 --> Helper loaded: main_helper
INFO - 2025-11-09 03:14:38 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 03:14:38 --> Database Driver Class Initialized
INFO - 2025-11-09 03:14:38 --> Email Class Initialized
DEBUG - 2025-11-09 03:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 03:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 03:14:38 --> Controller Class Initialized
INFO - 2025-11-09 03:14:38 --> Model "User_model" initialized
INFO - 2025-11-09 03:14:38 --> Model "Project_model" initialized
INFO - 2025-11-09 03:14:38 --> Helper loaded: form_helper
INFO - 2025-11-09 03:14:38 --> Form Validation Class Initialized
ERROR - 2025-11-09 03:14:38 --> Severity: Warning --> Array to string conversion D:\laragon\www\acumena\system\database\DB_driver.php 1426
ERROR - 2025-11-09 03:14:38 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `project_ai_generation_run` (`project_id`, `pair_type`, `input_hash`, `model`, `temperature`, `max_output_tokens`, `stage`, `created_at`) VALUES ('3', Array, '8402f62978ceaf06d4ba0ebcacc23f64423e2827a7714bfecc465b1c97e158b5', 'gemini-1.5-flash', 0.2, 1200, 'initialized', '2025-11-09 03:14:38')
INFO - 2025-11-09 03:14:38 --> Language file loaded: language/english/db_lang.php
INFO - 2025-11-09 03:15:30 --> Config Class Initialized
INFO - 2025-11-09 03:15:30 --> Hooks Class Initialized
INFO - 2025-11-09 03:15:30 --> UTF-8 Support Enabled
INFO - 2025-11-09 03:15:30 --> Utf8 Class Initialized
INFO - 2025-11-09 03:15:30 --> URI Class Initialized
INFO - 2025-11-09 03:15:30 --> Router Class Initialized
INFO - 2025-11-09 03:15:30 --> Output Class Initialized
INFO - 2025-11-09 03:15:30 --> Security Class Initialized
INFO - 2025-11-09 03:15:30 --> Input Class Initialized
INFO - 2025-11-09 03:15:30 --> Language Class Initialized
INFO - 2025-11-09 03:15:30 --> Loader Class Initialized
INFO - 2025-11-09 03:15:30 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 03:15:30 --> Helper loaded: url_helper
INFO - 2025-11-09 03:15:30 --> Helper loaded: file_helper
INFO - 2025-11-09 03:15:30 --> Helper loaded: main_helper
INFO - 2025-11-09 03:15:30 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 03:15:30 --> Database Driver Class Initialized
INFO - 2025-11-09 03:15:30 --> Email Class Initialized
DEBUG - 2025-11-09 03:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 03:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 03:15:30 --> Controller Class Initialized
INFO - 2025-11-09 03:15:30 --> Model "User_model" initialized
INFO - 2025-11-09 03:15:30 --> Model "Project_model" initialized
INFO - 2025-11-09 03:15:30 --> Helper loaded: form_helper
INFO - 2025-11-09 03:15:30 --> Form Validation Class Initialized
INFO - 2025-11-09 03:15:30 --> Final output sent to browser
INFO - 2025-11-09 03:15:30 --> Total execution time: 0.0842
INFO - 2025-11-09 03:16:03 --> Config Class Initialized
INFO - 2025-11-09 03:16:03 --> Hooks Class Initialized
INFO - 2025-11-09 03:16:03 --> UTF-8 Support Enabled
INFO - 2025-11-09 03:16:03 --> Utf8 Class Initialized
INFO - 2025-11-09 03:16:03 --> URI Class Initialized
INFO - 2025-11-09 03:16:03 --> Router Class Initialized
INFO - 2025-11-09 03:16:03 --> Output Class Initialized
INFO - 2025-11-09 03:16:03 --> Security Class Initialized
INFO - 2025-11-09 03:16:03 --> Input Class Initialized
INFO - 2025-11-09 03:16:03 --> Language Class Initialized
INFO - 2025-11-09 03:16:03 --> Loader Class Initialized
INFO - 2025-11-09 03:16:03 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 03:16:03 --> Helper loaded: url_helper
INFO - 2025-11-09 03:16:03 --> Helper loaded: file_helper
INFO - 2025-11-09 03:16:03 --> Helper loaded: main_helper
INFO - 2025-11-09 03:16:03 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 03:16:03 --> Database Driver Class Initialized
INFO - 2025-11-09 03:16:03 --> Email Class Initialized
DEBUG - 2025-11-09 03:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 03:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 03:16:03 --> Controller Class Initialized
INFO - 2025-11-09 03:16:03 --> Model "User_model" initialized
INFO - 2025-11-09 03:16:03 --> Model "Project_model" initialized
INFO - 2025-11-09 03:16:03 --> Helper loaded: form_helper
INFO - 2025-11-09 03:16:03 --> Form Validation Class Initialized
ERROR - 2025-11-09 03:16:03 --> Severity: Warning --> Undefined array key "stage" D:\laragon\www\acumena\application\models\Project_model.php 499
INFO - 2025-11-09 03:16:03 --> Final output sent to browser
INFO - 2025-11-09 03:16:03 --> Total execution time: 0.0921
INFO - 2025-11-09 03:17:04 --> Config Class Initialized
INFO - 2025-11-09 03:17:04 --> Hooks Class Initialized
INFO - 2025-11-09 03:17:04 --> UTF-8 Support Enabled
INFO - 2025-11-09 03:17:04 --> Utf8 Class Initialized
INFO - 2025-11-09 03:17:04 --> URI Class Initialized
INFO - 2025-11-09 03:17:04 --> Router Class Initialized
INFO - 2025-11-09 03:17:04 --> Output Class Initialized
INFO - 2025-11-09 03:17:04 --> Security Class Initialized
INFO - 2025-11-09 03:17:04 --> Input Class Initialized
INFO - 2025-11-09 03:17:04 --> Language Class Initialized
INFO - 2025-11-09 03:17:04 --> Loader Class Initialized
INFO - 2025-11-09 03:17:04 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 03:17:04 --> Helper loaded: url_helper
INFO - 2025-11-09 03:17:04 --> Helper loaded: file_helper
INFO - 2025-11-09 03:17:04 --> Helper loaded: main_helper
INFO - 2025-11-09 03:17:04 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 03:17:04 --> Database Driver Class Initialized
INFO - 2025-11-09 03:17:04 --> Email Class Initialized
DEBUG - 2025-11-09 03:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 03:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 03:17:04 --> Controller Class Initialized
INFO - 2025-11-09 03:17:04 --> Model "User_model" initialized
INFO - 2025-11-09 03:17:04 --> Model "Project_model" initialized
INFO - 2025-11-09 03:17:04 --> Helper loaded: form_helper
INFO - 2025-11-09 03:17:04 --> Form Validation Class Initialized
ERROR - 2025-11-09 03:17:04 --> Severity: Warning --> Undefined array key "stage" D:\laragon\www\acumena\application\models\Project_model.php 500
INFO - 2025-11-09 03:17:04 --> Final output sent to browser
INFO - 2025-11-09 03:17:04 --> Total execution time: 0.0893
INFO - 2025-11-09 03:17:30 --> Config Class Initialized
INFO - 2025-11-09 03:17:30 --> Hooks Class Initialized
INFO - 2025-11-09 03:17:30 --> UTF-8 Support Enabled
INFO - 2025-11-09 03:17:30 --> Utf8 Class Initialized
INFO - 2025-11-09 03:17:30 --> URI Class Initialized
INFO - 2025-11-09 03:17:30 --> Router Class Initialized
INFO - 2025-11-09 03:17:30 --> Output Class Initialized
INFO - 2025-11-09 03:17:30 --> Security Class Initialized
INFO - 2025-11-09 03:17:30 --> Input Class Initialized
INFO - 2025-11-09 03:17:30 --> Language Class Initialized
INFO - 2025-11-09 03:17:30 --> Loader Class Initialized
INFO - 2025-11-09 03:17:30 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 03:17:30 --> Helper loaded: url_helper
INFO - 2025-11-09 03:17:30 --> Helper loaded: file_helper
INFO - 2025-11-09 03:17:30 --> Helper loaded: main_helper
INFO - 2025-11-09 03:17:30 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 03:17:30 --> Database Driver Class Initialized
INFO - 2025-11-09 03:17:30 --> Email Class Initialized
DEBUG - 2025-11-09 03:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 03:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 03:17:30 --> Controller Class Initialized
INFO - 2025-11-09 03:17:30 --> Model "User_model" initialized
INFO - 2025-11-09 03:17:30 --> Model "Project_model" initialized
INFO - 2025-11-09 03:17:30 --> Helper loaded: form_helper
INFO - 2025-11-09 03:17:30 --> Form Validation Class Initialized
INFO - 2025-11-09 03:17:30 --> Final output sent to browser
INFO - 2025-11-09 03:17:30 --> Total execution time: 0.1135
INFO - 2025-11-09 03:17:45 --> Config Class Initialized
INFO - 2025-11-09 03:17:45 --> Hooks Class Initialized
INFO - 2025-11-09 03:17:45 --> UTF-8 Support Enabled
INFO - 2025-11-09 03:17:45 --> Utf8 Class Initialized
INFO - 2025-11-09 03:17:45 --> URI Class Initialized
INFO - 2025-11-09 03:17:45 --> Router Class Initialized
INFO - 2025-11-09 03:17:45 --> Output Class Initialized
INFO - 2025-11-09 03:17:45 --> Security Class Initialized
INFO - 2025-11-09 03:17:45 --> Input Class Initialized
INFO - 2025-11-09 03:17:45 --> Language Class Initialized
INFO - 2025-11-09 03:17:45 --> Loader Class Initialized
INFO - 2025-11-09 03:17:45 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 03:17:45 --> Helper loaded: url_helper
INFO - 2025-11-09 03:17:45 --> Helper loaded: file_helper
INFO - 2025-11-09 03:17:45 --> Helper loaded: main_helper
INFO - 2025-11-09 03:17:45 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 03:17:45 --> Database Driver Class Initialized
INFO - 2025-11-09 03:17:45 --> Email Class Initialized
DEBUG - 2025-11-09 03:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 03:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 03:17:45 --> Controller Class Initialized
INFO - 2025-11-09 03:17:45 --> Model "User_model" initialized
INFO - 2025-11-09 03:17:45 --> Model "Project_model" initialized
INFO - 2025-11-09 03:17:45 --> Helper loaded: form_helper
INFO - 2025-11-09 03:17:45 --> Form Validation Class Initialized
INFO - 2025-11-09 03:17:45 --> Final output sent to browser
INFO - 2025-11-09 03:17:45 --> Total execution time: 0.1294
INFO - 2025-11-09 03:19:28 --> Config Class Initialized
INFO - 2025-11-09 03:19:28 --> Hooks Class Initialized
INFO - 2025-11-09 03:19:28 --> UTF-8 Support Enabled
INFO - 2025-11-09 03:19:28 --> Utf8 Class Initialized
INFO - 2025-11-09 03:19:28 --> URI Class Initialized
INFO - 2025-11-09 03:19:28 --> Router Class Initialized
INFO - 2025-11-09 03:19:28 --> Output Class Initialized
INFO - 2025-11-09 03:19:28 --> Security Class Initialized
INFO - 2025-11-09 03:19:28 --> Input Class Initialized
INFO - 2025-11-09 03:19:28 --> Language Class Initialized
INFO - 2025-11-09 03:19:28 --> Loader Class Initialized
INFO - 2025-11-09 03:19:28 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 03:19:28 --> Helper loaded: url_helper
INFO - 2025-11-09 03:19:28 --> Helper loaded: file_helper
INFO - 2025-11-09 03:19:28 --> Helper loaded: main_helper
INFO - 2025-11-09 03:19:28 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 03:19:28 --> Database Driver Class Initialized
INFO - 2025-11-09 03:19:28 --> Email Class Initialized
DEBUG - 2025-11-09 03:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 03:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 03:19:28 --> Controller Class Initialized
INFO - 2025-11-09 03:19:28 --> Model "User_model" initialized
INFO - 2025-11-09 03:19:28 --> Model "Project_model" initialized
INFO - 2025-11-09 03:19:28 --> Helper loaded: form_helper
INFO - 2025-11-09 03:19:28 --> Form Validation Class Initialized
INFO - 2025-11-09 03:19:28 --> Final output sent to browser
INFO - 2025-11-09 03:19:28 --> Total execution time: 0.0860
INFO - 2025-11-09 03:19:45 --> Config Class Initialized
INFO - 2025-11-09 03:19:45 --> Hooks Class Initialized
INFO - 2025-11-09 03:19:45 --> UTF-8 Support Enabled
INFO - 2025-11-09 03:19:45 --> Utf8 Class Initialized
INFO - 2025-11-09 03:19:45 --> URI Class Initialized
INFO - 2025-11-09 03:19:45 --> Router Class Initialized
INFO - 2025-11-09 03:19:45 --> Output Class Initialized
INFO - 2025-11-09 03:19:45 --> Security Class Initialized
INFO - 2025-11-09 03:19:45 --> Input Class Initialized
INFO - 2025-11-09 03:19:45 --> Language Class Initialized
INFO - 2025-11-09 03:19:45 --> Loader Class Initialized
INFO - 2025-11-09 03:19:45 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 03:19:45 --> Helper loaded: url_helper
INFO - 2025-11-09 03:19:45 --> Helper loaded: file_helper
INFO - 2025-11-09 03:19:45 --> Helper loaded: main_helper
INFO - 2025-11-09 03:19:45 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 03:19:45 --> Database Driver Class Initialized
INFO - 2025-11-09 03:19:45 --> Email Class Initialized
DEBUG - 2025-11-09 03:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 03:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 03:19:46 --> Controller Class Initialized
INFO - 2025-11-09 03:19:46 --> Model "User_model" initialized
INFO - 2025-11-09 03:19:46 --> Model "Project_model" initialized
INFO - 2025-11-09 03:19:46 --> Helper loaded: form_helper
INFO - 2025-11-09 03:19:46 --> Form Validation Class Initialized
INFO - 2025-11-09 03:19:46 --> Final output sent to browser
INFO - 2025-11-09 03:19:46 --> Total execution time: 0.1147
INFO - 2025-11-09 03:24:20 --> Config Class Initialized
INFO - 2025-11-09 03:24:20 --> Hooks Class Initialized
INFO - 2025-11-09 03:24:20 --> UTF-8 Support Enabled
INFO - 2025-11-09 03:24:20 --> Utf8 Class Initialized
INFO - 2025-11-09 03:24:20 --> URI Class Initialized
INFO - 2025-11-09 03:24:20 --> Router Class Initialized
INFO - 2025-11-09 03:24:20 --> Output Class Initialized
INFO - 2025-11-09 03:24:20 --> Security Class Initialized
INFO - 2025-11-09 03:24:20 --> Input Class Initialized
INFO - 2025-11-09 03:24:20 --> Language Class Initialized
INFO - 2025-11-09 03:24:20 --> Loader Class Initialized
INFO - 2025-11-09 03:24:20 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 03:24:20 --> Helper loaded: url_helper
INFO - 2025-11-09 03:24:20 --> Helper loaded: file_helper
INFO - 2025-11-09 03:24:20 --> Helper loaded: main_helper
INFO - 2025-11-09 03:24:20 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 03:24:20 --> Database Driver Class Initialized
INFO - 2025-11-09 03:24:20 --> Email Class Initialized
DEBUG - 2025-11-09 03:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 03:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 03:24:20 --> Controller Class Initialized
INFO - 2025-11-09 03:24:20 --> Model "User_model" initialized
INFO - 2025-11-09 03:24:20 --> Model "Project_model" initialized
INFO - 2025-11-09 03:24:20 --> Helper loaded: form_helper
INFO - 2025-11-09 03:24:20 --> Form Validation Class Initialized
ERROR - 2025-11-09 03:24:20 --> Severity: Warning --> Undefined variable $top_k D:\laragon\www\acumena\application\controllers\Api_project.php 617
INFO - 2025-11-09 03:24:20 --> Final output sent to browser
INFO - 2025-11-09 03:24:20 --> Total execution time: 0.0743
INFO - 2025-11-09 03:25:03 --> Config Class Initialized
INFO - 2025-11-09 03:25:03 --> Hooks Class Initialized
INFO - 2025-11-09 03:25:03 --> UTF-8 Support Enabled
INFO - 2025-11-09 03:25:03 --> Utf8 Class Initialized
INFO - 2025-11-09 03:25:03 --> URI Class Initialized
INFO - 2025-11-09 03:25:03 --> Router Class Initialized
INFO - 2025-11-09 03:25:03 --> Output Class Initialized
INFO - 2025-11-09 03:25:03 --> Security Class Initialized
INFO - 2025-11-09 03:25:03 --> Input Class Initialized
INFO - 2025-11-09 03:25:03 --> Language Class Initialized
INFO - 2025-11-09 03:25:03 --> Loader Class Initialized
INFO - 2025-11-09 03:25:03 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 03:25:03 --> Helper loaded: url_helper
INFO - 2025-11-09 03:25:03 --> Helper loaded: file_helper
INFO - 2025-11-09 03:25:03 --> Helper loaded: main_helper
INFO - 2025-11-09 03:25:03 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 03:25:03 --> Database Driver Class Initialized
INFO - 2025-11-09 03:25:03 --> Email Class Initialized
DEBUG - 2025-11-09 03:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 03:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 03:25:03 --> Controller Class Initialized
INFO - 2025-11-09 03:25:03 --> Model "User_model" initialized
INFO - 2025-11-09 03:25:03 --> Model "Project_model" initialized
INFO - 2025-11-09 03:25:03 --> Helper loaded: form_helper
INFO - 2025-11-09 03:25:03 --> Form Validation Class Initialized
INFO - 2025-11-09 03:25:03 --> Final output sent to browser
INFO - 2025-11-09 03:25:03 --> Total execution time: 0.1293
INFO - 2025-11-09 03:29:54 --> Config Class Initialized
INFO - 2025-11-09 03:29:54 --> Hooks Class Initialized
INFO - 2025-11-09 03:29:54 --> UTF-8 Support Enabled
INFO - 2025-11-09 03:29:54 --> Utf8 Class Initialized
INFO - 2025-11-09 03:29:54 --> URI Class Initialized
INFO - 2025-11-09 03:29:54 --> Router Class Initialized
INFO - 2025-11-09 03:29:54 --> Output Class Initialized
INFO - 2025-11-09 03:29:54 --> Security Class Initialized
INFO - 2025-11-09 03:29:54 --> Input Class Initialized
INFO - 2025-11-09 03:29:54 --> Language Class Initialized
INFO - 2025-11-09 03:29:54 --> Loader Class Initialized
INFO - 2025-11-09 03:29:54 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 03:29:54 --> Helper loaded: url_helper
INFO - 2025-11-09 03:29:54 --> Helper loaded: file_helper
INFO - 2025-11-09 03:29:54 --> Helper loaded: main_helper
INFO - 2025-11-09 03:29:54 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 03:29:54 --> Database Driver Class Initialized
INFO - 2025-11-09 03:29:54 --> Email Class Initialized
DEBUG - 2025-11-09 03:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 03:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 03:29:54 --> Controller Class Initialized
INFO - 2025-11-09 03:29:54 --> Model "User_model" initialized
INFO - 2025-11-09 03:29:54 --> Model "Project_model" initialized
INFO - 2025-11-09 03:29:54 --> Helper loaded: form_helper
INFO - 2025-11-09 03:29:54 --> Form Validation Class Initialized
INFO - 2025-11-09 03:29:54 --> Final output sent to browser
INFO - 2025-11-09 03:29:54 --> Total execution time: 0.0710
INFO - 2025-11-09 03:30:27 --> Config Class Initialized
INFO - 2025-11-09 03:30:27 --> Hooks Class Initialized
INFO - 2025-11-09 03:30:27 --> UTF-8 Support Enabled
INFO - 2025-11-09 03:30:27 --> Utf8 Class Initialized
INFO - 2025-11-09 03:30:27 --> URI Class Initialized
INFO - 2025-11-09 03:30:27 --> Router Class Initialized
INFO - 2025-11-09 03:30:27 --> Output Class Initialized
INFO - 2025-11-09 03:30:27 --> Security Class Initialized
INFO - 2025-11-09 03:30:27 --> Input Class Initialized
INFO - 2025-11-09 03:30:27 --> Language Class Initialized
INFO - 2025-11-09 03:30:27 --> Loader Class Initialized
INFO - 2025-11-09 03:30:27 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 03:30:27 --> Helper loaded: url_helper
INFO - 2025-11-09 03:30:27 --> Helper loaded: file_helper
INFO - 2025-11-09 03:30:27 --> Helper loaded: main_helper
INFO - 2025-11-09 03:30:27 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 03:30:27 --> Database Driver Class Initialized
INFO - 2025-11-09 03:30:27 --> Email Class Initialized
DEBUG - 2025-11-09 03:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 03:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 03:30:27 --> Controller Class Initialized
INFO - 2025-11-09 03:30:27 --> Model "User_model" initialized
INFO - 2025-11-09 03:30:27 --> Model "Project_model" initialized
INFO - 2025-11-09 03:30:27 --> Helper loaded: form_helper
INFO - 2025-11-09 03:30:27 --> Form Validation Class Initialized
INFO - 2025-11-09 03:30:27 --> Final output sent to browser
INFO - 2025-11-09 03:30:27 --> Total execution time: 0.1004
INFO - 2025-11-09 03:43:36 --> Config Class Initialized
INFO - 2025-11-09 03:43:36 --> Hooks Class Initialized
INFO - 2025-11-09 03:43:36 --> UTF-8 Support Enabled
INFO - 2025-11-09 03:43:36 --> Utf8 Class Initialized
INFO - 2025-11-09 03:43:36 --> URI Class Initialized
INFO - 2025-11-09 03:43:36 --> Router Class Initialized
INFO - 2025-11-09 03:43:36 --> Output Class Initialized
INFO - 2025-11-09 03:43:36 --> Security Class Initialized
INFO - 2025-11-09 03:43:36 --> Input Class Initialized
INFO - 2025-11-09 03:43:36 --> Language Class Initialized
INFO - 2025-11-09 03:43:36 --> Loader Class Initialized
INFO - 2025-11-09 03:43:36 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 03:43:36 --> Helper loaded: url_helper
INFO - 2025-11-09 03:43:36 --> Helper loaded: file_helper
INFO - 2025-11-09 03:43:36 --> Helper loaded: main_helper
INFO - 2025-11-09 03:43:36 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 03:43:36 --> Database Driver Class Initialized
INFO - 2025-11-09 03:43:36 --> Email Class Initialized
DEBUG - 2025-11-09 03:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 03:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 03:43:36 --> Controller Class Initialized
INFO - 2025-11-09 03:43:36 --> Model "User_model" initialized
INFO - 2025-11-09 03:43:36 --> Model "Project_model" initialized
INFO - 2025-11-09 03:43:36 --> Helper loaded: form_helper
INFO - 2025-11-09 03:43:36 --> Form Validation Class Initialized
INFO - 2025-11-09 03:43:36 --> Final output sent to browser
INFO - 2025-11-09 03:43:36 --> Total execution time: 0.0886
INFO - 2025-11-09 04:22:12 --> Config Class Initialized
INFO - 2025-11-09 04:22:12 --> Hooks Class Initialized
INFO - 2025-11-09 04:22:12 --> UTF-8 Support Enabled
INFO - 2025-11-09 04:22:12 --> Utf8 Class Initialized
INFO - 2025-11-09 04:22:12 --> URI Class Initialized
INFO - 2025-11-09 04:22:12 --> Router Class Initialized
INFO - 2025-11-09 04:22:12 --> Output Class Initialized
INFO - 2025-11-09 04:22:12 --> Security Class Initialized
INFO - 2025-11-09 04:22:12 --> Input Class Initialized
INFO - 2025-11-09 04:22:12 --> Language Class Initialized
INFO - 2025-11-09 04:22:12 --> Loader Class Initialized
INFO - 2025-11-09 04:22:12 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 04:22:12 --> Helper loaded: url_helper
INFO - 2025-11-09 04:22:12 --> Helper loaded: file_helper
INFO - 2025-11-09 04:22:12 --> Helper loaded: main_helper
INFO - 2025-11-09 04:22:12 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 04:22:13 --> Database Driver Class Initialized
INFO - 2025-11-09 04:22:13 --> Email Class Initialized
DEBUG - 2025-11-09 04:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 04:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 04:22:13 --> Controller Class Initialized
INFO - 2025-11-09 04:22:13 --> Model "User_model" initialized
INFO - 2025-11-09 04:22:13 --> Model "Project_model" initialized
INFO - 2025-11-09 04:22:13 --> Helper loaded: form_helper
INFO - 2025-11-09 04:22:13 --> Form Validation Class Initialized
ERROR - 2025-11-09 04:22:13 --> Severity: error --> Exception: Unsupported operand types: string + int D:\laragon\www\acumena\application\models\Project_model.php 712
INFO - 2025-11-09 04:26:07 --> Config Class Initialized
INFO - 2025-11-09 04:26:07 --> Hooks Class Initialized
INFO - 2025-11-09 04:26:07 --> UTF-8 Support Enabled
INFO - 2025-11-09 04:26:07 --> Utf8 Class Initialized
INFO - 2025-11-09 04:26:07 --> URI Class Initialized
INFO - 2025-11-09 04:26:07 --> Router Class Initialized
INFO - 2025-11-09 04:26:07 --> Output Class Initialized
INFO - 2025-11-09 04:26:07 --> Security Class Initialized
INFO - 2025-11-09 04:26:07 --> Input Class Initialized
INFO - 2025-11-09 04:26:07 --> Language Class Initialized
INFO - 2025-11-09 04:26:07 --> Loader Class Initialized
INFO - 2025-11-09 04:26:07 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 04:26:07 --> Helper loaded: url_helper
INFO - 2025-11-09 04:26:07 --> Helper loaded: file_helper
INFO - 2025-11-09 04:26:07 --> Helper loaded: main_helper
INFO - 2025-11-09 04:26:07 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 04:26:07 --> Database Driver Class Initialized
INFO - 2025-11-09 04:26:07 --> Email Class Initialized
DEBUG - 2025-11-09 04:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 04:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 04:26:07 --> Controller Class Initialized
INFO - 2025-11-09 04:26:07 --> Model "User_model" initialized
INFO - 2025-11-09 04:26:07 --> Model "Project_model" initialized
INFO - 2025-11-09 04:26:07 --> Helper loaded: form_helper
INFO - 2025-11-09 04:26:07 --> Form Validation Class Initialized
INFO - 2025-11-09 04:26:07 --> Final output sent to browser
INFO - 2025-11-09 04:26:07 --> Total execution time: 0.0945
INFO - 2025-11-09 04:26:55 --> Config Class Initialized
INFO - 2025-11-09 04:26:55 --> Hooks Class Initialized
INFO - 2025-11-09 04:26:55 --> UTF-8 Support Enabled
INFO - 2025-11-09 04:26:55 --> Utf8 Class Initialized
INFO - 2025-11-09 04:26:55 --> URI Class Initialized
INFO - 2025-11-09 04:26:55 --> Router Class Initialized
INFO - 2025-11-09 04:26:55 --> Output Class Initialized
INFO - 2025-11-09 04:26:55 --> Security Class Initialized
INFO - 2025-11-09 04:26:55 --> Input Class Initialized
INFO - 2025-11-09 04:26:55 --> Language Class Initialized
INFO - 2025-11-09 04:26:55 --> Loader Class Initialized
INFO - 2025-11-09 04:26:55 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 04:26:55 --> Helper loaded: url_helper
INFO - 2025-11-09 04:26:55 --> Helper loaded: file_helper
INFO - 2025-11-09 04:26:55 --> Helper loaded: main_helper
INFO - 2025-11-09 04:26:55 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 04:26:55 --> Database Driver Class Initialized
INFO - 2025-11-09 04:26:55 --> Email Class Initialized
DEBUG - 2025-11-09 04:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 04:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 04:26:55 --> Controller Class Initialized
INFO - 2025-11-09 04:26:55 --> Model "User_model" initialized
INFO - 2025-11-09 04:26:55 --> Model "Project_model" initialized
INFO - 2025-11-09 04:26:55 --> Helper loaded: form_helper
INFO - 2025-11-09 04:26:55 --> Form Validation Class Initialized
INFO - 2025-11-09 04:26:55 --> Final output sent to browser
INFO - 2025-11-09 04:26:55 --> Total execution time: 0.0829
INFO - 2025-11-09 04:26:57 --> Config Class Initialized
INFO - 2025-11-09 04:26:57 --> Hooks Class Initialized
INFO - 2025-11-09 04:26:57 --> UTF-8 Support Enabled
INFO - 2025-11-09 04:26:57 --> Utf8 Class Initialized
INFO - 2025-11-09 04:26:57 --> URI Class Initialized
INFO - 2025-11-09 04:26:57 --> Router Class Initialized
INFO - 2025-11-09 04:26:57 --> Output Class Initialized
INFO - 2025-11-09 04:26:57 --> Security Class Initialized
INFO - 2025-11-09 04:26:57 --> Input Class Initialized
INFO - 2025-11-09 04:26:57 --> Language Class Initialized
INFO - 2025-11-09 04:26:57 --> Loader Class Initialized
INFO - 2025-11-09 04:26:57 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 04:26:57 --> Helper loaded: url_helper
INFO - 2025-11-09 04:26:57 --> Helper loaded: file_helper
INFO - 2025-11-09 04:26:57 --> Helper loaded: main_helper
INFO - 2025-11-09 04:26:57 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 04:26:57 --> Database Driver Class Initialized
INFO - 2025-11-09 04:26:57 --> Email Class Initialized
DEBUG - 2025-11-09 04:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 04:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 04:26:57 --> Controller Class Initialized
INFO - 2025-11-09 04:26:57 --> Model "User_model" initialized
INFO - 2025-11-09 04:26:57 --> Model "Project_model" initialized
INFO - 2025-11-09 04:26:57 --> Helper loaded: form_helper
INFO - 2025-11-09 04:26:57 --> Form Validation Class Initialized
INFO - 2025-11-09 04:26:57 --> Final output sent to browser
INFO - 2025-11-09 04:26:57 --> Total execution time: 0.0813
INFO - 2025-11-09 04:29:39 --> Config Class Initialized
INFO - 2025-11-09 04:29:39 --> Hooks Class Initialized
INFO - 2025-11-09 04:29:39 --> UTF-8 Support Enabled
INFO - 2025-11-09 04:29:39 --> Utf8 Class Initialized
INFO - 2025-11-09 04:29:39 --> URI Class Initialized
INFO - 2025-11-09 04:29:39 --> Router Class Initialized
INFO - 2025-11-09 04:29:39 --> Output Class Initialized
INFO - 2025-11-09 04:29:39 --> Security Class Initialized
INFO - 2025-11-09 04:29:39 --> Input Class Initialized
INFO - 2025-11-09 04:29:39 --> Language Class Initialized
INFO - 2025-11-09 04:29:39 --> Loader Class Initialized
INFO - 2025-11-09 04:29:39 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 04:29:39 --> Helper loaded: url_helper
INFO - 2025-11-09 04:29:39 --> Helper loaded: file_helper
INFO - 2025-11-09 04:29:39 --> Helper loaded: main_helper
INFO - 2025-11-09 04:29:39 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 04:29:39 --> Database Driver Class Initialized
INFO - 2025-11-09 04:29:39 --> Email Class Initialized
DEBUG - 2025-11-09 04:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 04:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 04:29:39 --> Controller Class Initialized
INFO - 2025-11-09 04:29:39 --> Model "User_model" initialized
INFO - 2025-11-09 04:29:39 --> Model "Project_model" initialized
INFO - 2025-11-09 04:29:39 --> Helper loaded: form_helper
INFO - 2025-11-09 04:29:39 --> Form Validation Class Initialized
INFO - 2025-11-09 04:29:39 --> Final output sent to browser
INFO - 2025-11-09 04:29:39 --> Total execution time: 0.0707
INFO - 2025-11-09 04:29:41 --> Config Class Initialized
INFO - 2025-11-09 04:29:41 --> Hooks Class Initialized
INFO - 2025-11-09 04:29:41 --> UTF-8 Support Enabled
INFO - 2025-11-09 04:29:41 --> Utf8 Class Initialized
INFO - 2025-11-09 04:29:41 --> URI Class Initialized
INFO - 2025-11-09 04:29:41 --> Router Class Initialized
INFO - 2025-11-09 04:29:41 --> Output Class Initialized
INFO - 2025-11-09 04:29:41 --> Security Class Initialized
INFO - 2025-11-09 04:29:41 --> Input Class Initialized
INFO - 2025-11-09 04:29:41 --> Language Class Initialized
INFO - 2025-11-09 04:29:41 --> Loader Class Initialized
INFO - 2025-11-09 04:29:41 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 04:29:41 --> Helper loaded: url_helper
INFO - 2025-11-09 04:29:41 --> Helper loaded: file_helper
INFO - 2025-11-09 04:29:41 --> Helper loaded: main_helper
INFO - 2025-11-09 04:29:41 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 04:29:42 --> Database Driver Class Initialized
INFO - 2025-11-09 04:29:42 --> Email Class Initialized
DEBUG - 2025-11-09 04:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 04:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 04:29:42 --> Controller Class Initialized
INFO - 2025-11-09 04:29:42 --> Model "User_model" initialized
INFO - 2025-11-09 04:29:42 --> Model "Project_model" initialized
INFO - 2025-11-09 04:29:42 --> Helper loaded: form_helper
INFO - 2025-11-09 04:29:42 --> Form Validation Class Initialized
INFO - 2025-11-09 04:29:42 --> Final output sent to browser
INFO - 2025-11-09 04:29:42 --> Total execution time: 0.1111
INFO - 2025-11-09 05:01:26 --> Config Class Initialized
INFO - 2025-11-09 05:01:26 --> Hooks Class Initialized
INFO - 2025-11-09 05:01:26 --> UTF-8 Support Enabled
INFO - 2025-11-09 05:01:26 --> Utf8 Class Initialized
INFO - 2025-11-09 05:01:26 --> URI Class Initialized
INFO - 2025-11-09 05:01:26 --> Router Class Initialized
INFO - 2025-11-09 05:01:26 --> Output Class Initialized
INFO - 2025-11-09 05:01:26 --> Security Class Initialized
INFO - 2025-11-09 05:01:27 --> Input Class Initialized
INFO - 2025-11-09 05:01:27 --> Language Class Initialized
INFO - 2025-11-09 05:01:27 --> Loader Class Initialized
INFO - 2025-11-09 05:01:27 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 05:01:27 --> Helper loaded: url_helper
INFO - 2025-11-09 05:01:27 --> Helper loaded: file_helper
INFO - 2025-11-09 05:01:27 --> Helper loaded: main_helper
INFO - 2025-11-09 05:01:27 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 05:01:27 --> Database Driver Class Initialized
INFO - 2025-11-09 05:01:28 --> Email Class Initialized
DEBUG - 2025-11-09 05:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 05:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 05:01:28 --> Controller Class Initialized
INFO - 2025-11-09 05:01:28 --> Model "User_model" initialized
INFO - 2025-11-09 05:01:28 --> Model "Project_model" initialized
INFO - 2025-11-09 05:01:28 --> Helper loaded: form_helper
INFO - 2025-11-09 05:01:28 --> Form Validation Class Initialized
INFO - 2025-11-09 05:01:28 --> Model "Project_ai_generation_run_model" initialized
ERROR - 2025-11-09 05:01:28 --> Severity: error --> Exception: Unable to locate the model you have specified: Ai_pair_filtered_model D:\laragon\www\acumena\system\core\Loader.php 357
INFO - 2025-11-09 05:05:55 --> Config Class Initialized
INFO - 2025-11-09 05:05:55 --> Hooks Class Initialized
INFO - 2025-11-09 05:05:55 --> UTF-8 Support Enabled
INFO - 2025-11-09 05:05:55 --> Utf8 Class Initialized
INFO - 2025-11-09 05:05:55 --> URI Class Initialized
INFO - 2025-11-09 05:05:55 --> Router Class Initialized
INFO - 2025-11-09 05:05:55 --> Output Class Initialized
INFO - 2025-11-09 05:05:55 --> Security Class Initialized
INFO - 2025-11-09 05:05:55 --> Input Class Initialized
INFO - 2025-11-09 05:05:55 --> Language Class Initialized
INFO - 2025-11-09 05:05:55 --> Loader Class Initialized
INFO - 2025-11-09 05:05:55 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 05:05:55 --> Helper loaded: url_helper
INFO - 2025-11-09 05:05:55 --> Helper loaded: file_helper
INFO - 2025-11-09 05:05:55 --> Helper loaded: main_helper
INFO - 2025-11-09 05:05:55 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 05:05:55 --> Database Driver Class Initialized
INFO - 2025-11-09 05:05:56 --> Email Class Initialized
DEBUG - 2025-11-09 05:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 05:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 05:05:56 --> Controller Class Initialized
INFO - 2025-11-09 05:05:56 --> Model "User_model" initialized
INFO - 2025-11-09 05:05:56 --> Model "Project_model" initialized
INFO - 2025-11-09 05:05:56 --> Helper loaded: form_helper
INFO - 2025-11-09 05:05:56 --> Form Validation Class Initialized
INFO - 2025-11-09 05:05:56 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-09 05:05:56 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-09 05:05:56 --> Model "Ai_strategy_model" initialized
ERROR - 2025-11-09 05:05:56 --> Severity: error --> Exception: Unable to locate the model you have specified: Swot_model D:\laragon\www\acumena\system\core\Loader.php 357
INFO - 2025-11-09 05:14:26 --> Config Class Initialized
INFO - 2025-11-09 05:14:26 --> Hooks Class Initialized
INFO - 2025-11-09 05:14:26 --> UTF-8 Support Enabled
INFO - 2025-11-09 05:14:26 --> Utf8 Class Initialized
INFO - 2025-11-09 05:14:26 --> URI Class Initialized
INFO - 2025-11-09 05:14:26 --> Router Class Initialized
INFO - 2025-11-09 05:14:26 --> Output Class Initialized
INFO - 2025-11-09 05:14:26 --> Security Class Initialized
INFO - 2025-11-09 05:14:26 --> Input Class Initialized
INFO - 2025-11-09 05:14:26 --> Language Class Initialized
INFO - 2025-11-09 05:14:26 --> Loader Class Initialized
INFO - 2025-11-09 05:14:26 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 05:14:26 --> Helper loaded: url_helper
INFO - 2025-11-09 05:14:26 --> Helper loaded: file_helper
INFO - 2025-11-09 05:14:26 --> Helper loaded: main_helper
INFO - 2025-11-09 05:14:26 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 05:14:26 --> Database Driver Class Initialized
INFO - 2025-11-09 05:14:26 --> Email Class Initialized
DEBUG - 2025-11-09 05:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 05:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 05:14:26 --> Controller Class Initialized
INFO - 2025-11-09 05:14:26 --> Model "User_model" initialized
INFO - 2025-11-09 05:14:26 --> Model "Project_model" initialized
INFO - 2025-11-09 05:14:26 --> Helper loaded: form_helper
INFO - 2025-11-09 05:14:26 --> Form Validation Class Initialized
INFO - 2025-11-09 05:14:26 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-09 05:14:26 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-09 05:14:26 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-09 05:14:26 --> Model "Swot_model" initialized
ERROR - 2025-11-09 05:14:26 --> Severity: error --> Exception: Unable to locate the model you have specified: Topk_service_model D:\laragon\www\acumena\system\core\Loader.php 357
INFO - 2025-11-09 05:14:28 --> Config Class Initialized
INFO - 2025-11-09 05:14:28 --> Hooks Class Initialized
INFO - 2025-11-09 05:14:28 --> UTF-8 Support Enabled
INFO - 2025-11-09 05:14:28 --> Utf8 Class Initialized
INFO - 2025-11-09 05:14:28 --> URI Class Initialized
INFO - 2025-11-09 05:14:28 --> Router Class Initialized
INFO - 2025-11-09 05:14:28 --> Output Class Initialized
INFO - 2025-11-09 05:14:28 --> Security Class Initialized
INFO - 2025-11-09 05:14:28 --> Input Class Initialized
INFO - 2025-11-09 05:14:28 --> Language Class Initialized
INFO - 2025-11-09 05:14:28 --> Loader Class Initialized
INFO - 2025-11-09 05:14:28 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 05:14:28 --> Helper loaded: url_helper
INFO - 2025-11-09 05:14:28 --> Helper loaded: file_helper
INFO - 2025-11-09 05:14:28 --> Helper loaded: main_helper
INFO - 2025-11-09 05:14:28 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 05:14:28 --> Database Driver Class Initialized
INFO - 2025-11-09 05:14:28 --> Email Class Initialized
DEBUG - 2025-11-09 05:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 05:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 05:14:28 --> Controller Class Initialized
INFO - 2025-11-09 05:14:28 --> Model "User_model" initialized
INFO - 2025-11-09 05:14:28 --> Model "Project_model" initialized
INFO - 2025-11-09 05:14:28 --> Helper loaded: form_helper
INFO - 2025-11-09 05:14:28 --> Form Validation Class Initialized
INFO - 2025-11-09 05:14:28 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-09 05:14:28 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-09 05:14:28 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-09 05:14:28 --> Model "Swot_model" initialized
ERROR - 2025-11-09 05:14:28 --> Severity: error --> Exception: Unable to locate the model you have specified: Topk_service_model D:\laragon\www\acumena\system\core\Loader.php 357
INFO - 2025-11-09 05:16:16 --> Config Class Initialized
INFO - 2025-11-09 05:16:16 --> Hooks Class Initialized
INFO - 2025-11-09 05:16:16 --> UTF-8 Support Enabled
INFO - 2025-11-09 05:16:16 --> Utf8 Class Initialized
INFO - 2025-11-09 05:16:16 --> URI Class Initialized
INFO - 2025-11-09 05:16:16 --> Router Class Initialized
INFO - 2025-11-09 05:16:16 --> Output Class Initialized
INFO - 2025-11-09 05:16:16 --> Security Class Initialized
INFO - 2025-11-09 05:16:16 --> Input Class Initialized
INFO - 2025-11-09 05:16:16 --> Language Class Initialized
INFO - 2025-11-09 05:16:16 --> Loader Class Initialized
INFO - 2025-11-09 05:16:16 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 05:16:16 --> Helper loaded: url_helper
INFO - 2025-11-09 05:16:16 --> Helper loaded: file_helper
INFO - 2025-11-09 05:16:16 --> Helper loaded: main_helper
INFO - 2025-11-09 05:16:16 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 05:16:16 --> Database Driver Class Initialized
INFO - 2025-11-09 05:16:16 --> Email Class Initialized
DEBUG - 2025-11-09 05:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 05:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 05:16:16 --> Controller Class Initialized
INFO - 2025-11-09 05:16:16 --> Model "User_model" initialized
INFO - 2025-11-09 05:16:16 --> Model "Project_model" initialized
INFO - 2025-11-09 05:16:16 --> Helper loaded: form_helper
INFO - 2025-11-09 05:16:16 --> Form Validation Class Initialized
INFO - 2025-11-09 05:16:16 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-09 05:16:16 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-09 05:16:16 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-09 05:16:16 --> Model "Swot_model" initialized
INFO - 2025-11-09 05:16:16 --> Model "Swot_model" initialized
INFO - 2025-11-09 05:16:16 --> Model "Topk_service_model" initialized
INFO - 2025-11-09 05:16:16 --> Final output sent to browser
INFO - 2025-11-09 05:16:16 --> Total execution time: 0.0828
INFO - 2025-11-09 05:17:15 --> Config Class Initialized
INFO - 2025-11-09 05:17:15 --> Hooks Class Initialized
INFO - 2025-11-09 05:17:15 --> UTF-8 Support Enabled
INFO - 2025-11-09 05:17:15 --> Utf8 Class Initialized
INFO - 2025-11-09 05:17:15 --> URI Class Initialized
INFO - 2025-11-09 05:17:15 --> Router Class Initialized
INFO - 2025-11-09 05:17:15 --> Output Class Initialized
INFO - 2025-11-09 05:17:15 --> Security Class Initialized
INFO - 2025-11-09 05:17:15 --> Input Class Initialized
INFO - 2025-11-09 05:17:15 --> Language Class Initialized
INFO - 2025-11-09 05:17:15 --> Loader Class Initialized
INFO - 2025-11-09 05:17:15 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 05:17:15 --> Helper loaded: url_helper
INFO - 2025-11-09 05:17:15 --> Helper loaded: file_helper
INFO - 2025-11-09 05:17:15 --> Helper loaded: main_helper
INFO - 2025-11-09 05:17:15 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 05:17:15 --> Database Driver Class Initialized
INFO - 2025-11-09 05:17:15 --> Email Class Initialized
DEBUG - 2025-11-09 05:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 05:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 05:17:15 --> Controller Class Initialized
INFO - 2025-11-09 05:17:15 --> Model "User_model" initialized
INFO - 2025-11-09 05:17:15 --> Model "Project_model" initialized
INFO - 2025-11-09 05:17:15 --> Helper loaded: form_helper
INFO - 2025-11-09 05:17:15 --> Form Validation Class Initialized
INFO - 2025-11-09 05:17:15 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-09 05:17:15 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-09 05:17:15 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-09 05:17:15 --> Model "Swot_model" initialized
INFO - 2025-11-09 05:17:15 --> Model "Swot_model" initialized
INFO - 2025-11-09 05:17:15 --> Model "Topk_service_model" initialized
INFO - 2025-11-09 05:17:15 --> Final output sent to browser
INFO - 2025-11-09 05:17:15 --> Total execution time: 0.0692
INFO - 2025-11-09 05:18:09 --> Config Class Initialized
INFO - 2025-11-09 05:18:09 --> Hooks Class Initialized
INFO - 2025-11-09 05:18:09 --> UTF-8 Support Enabled
INFO - 2025-11-09 05:18:09 --> Utf8 Class Initialized
INFO - 2025-11-09 05:18:09 --> URI Class Initialized
INFO - 2025-11-09 05:18:09 --> Router Class Initialized
INFO - 2025-11-09 05:18:09 --> Output Class Initialized
INFO - 2025-11-09 05:18:09 --> Security Class Initialized
INFO - 2025-11-09 05:18:09 --> Input Class Initialized
INFO - 2025-11-09 05:18:09 --> Language Class Initialized
INFO - 2025-11-09 05:18:09 --> Loader Class Initialized
INFO - 2025-11-09 05:18:09 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 05:18:09 --> Helper loaded: url_helper
INFO - 2025-11-09 05:18:09 --> Helper loaded: file_helper
INFO - 2025-11-09 05:18:09 --> Helper loaded: main_helper
INFO - 2025-11-09 05:18:09 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 05:18:09 --> Database Driver Class Initialized
INFO - 2025-11-09 05:18:09 --> Email Class Initialized
DEBUG - 2025-11-09 05:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 05:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 05:18:09 --> Controller Class Initialized
INFO - 2025-11-09 05:18:09 --> Model "User_model" initialized
INFO - 2025-11-09 05:18:09 --> Model "Project_model" initialized
INFO - 2025-11-09 05:18:09 --> Helper loaded: form_helper
INFO - 2025-11-09 05:18:09 --> Form Validation Class Initialized
INFO - 2025-11-09 05:18:09 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-09 05:18:09 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-09 05:18:09 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-09 05:18:09 --> Model "Swot_model" initialized
INFO - 2025-11-09 05:18:09 --> Model "Swot_model" initialized
INFO - 2025-11-09 05:18:09 --> Model "Topk_service_model" initialized
ERROR - 2025-11-09 05:18:09 --> Query error: Unknown column 'is_active' in 'where clause' - Invalid query: UPDATE `project_ai_generation_run` SET `is_active` = 0, `archived_at` = '2025-11-09 05:18:09'
WHERE `project_id` = 3
AND `pair_type` = 'W-T'
AND `is_active` = 1
INFO - 2025-11-09 05:18:09 --> Language file loaded: language/english/db_lang.php
INFO - 2025-11-09 05:19:27 --> Config Class Initialized
INFO - 2025-11-09 05:19:27 --> Hooks Class Initialized
INFO - 2025-11-09 05:19:27 --> UTF-8 Support Enabled
INFO - 2025-11-09 05:19:27 --> Utf8 Class Initialized
INFO - 2025-11-09 05:19:27 --> URI Class Initialized
INFO - 2025-11-09 05:19:27 --> Router Class Initialized
INFO - 2025-11-09 05:19:27 --> Output Class Initialized
INFO - 2025-11-09 05:19:27 --> Security Class Initialized
INFO - 2025-11-09 05:19:27 --> Input Class Initialized
INFO - 2025-11-09 05:19:27 --> Language Class Initialized
INFO - 2025-11-09 05:19:27 --> Loader Class Initialized
INFO - 2025-11-09 05:19:27 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 05:19:27 --> Helper loaded: url_helper
INFO - 2025-11-09 05:19:27 --> Helper loaded: file_helper
INFO - 2025-11-09 05:19:27 --> Helper loaded: main_helper
INFO - 2025-11-09 05:19:27 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 05:19:27 --> Database Driver Class Initialized
INFO - 2025-11-09 05:19:27 --> Email Class Initialized
DEBUG - 2025-11-09 05:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 05:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 05:19:27 --> Controller Class Initialized
INFO - 2025-11-09 05:19:27 --> Model "User_model" initialized
INFO - 2025-11-09 05:19:27 --> Model "Project_model" initialized
INFO - 2025-11-09 05:19:27 --> Helper loaded: form_helper
INFO - 2025-11-09 05:19:27 --> Form Validation Class Initialized
INFO - 2025-11-09 05:19:27 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-09 05:19:27 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-09 05:19:27 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-09 05:19:27 --> Model "Swot_model" initialized
INFO - 2025-11-09 05:19:27 --> Model "Swot_model" initialized
INFO - 2025-11-09 05:19:27 --> Model "Topk_service_model" initialized
ERROR - 2025-11-09 05:19:27 --> Query error: Unknown column 'archived_at' in 'field list' - Invalid query: UPDATE `project_ai_generation_run` SET `is_active` = 0, `archived_at` = '2025-11-09 05:19:27'
WHERE `project_id` = 3
AND `pair_type` = 'W-T'
AND `is_active` = 1
INFO - 2025-11-09 05:19:27 --> Language file loaded: language/english/db_lang.php
INFO - 2025-11-09 05:19:49 --> Config Class Initialized
INFO - 2025-11-09 05:19:49 --> Hooks Class Initialized
INFO - 2025-11-09 05:19:49 --> UTF-8 Support Enabled
INFO - 2025-11-09 05:19:49 --> Utf8 Class Initialized
INFO - 2025-11-09 05:19:49 --> URI Class Initialized
INFO - 2025-11-09 05:19:49 --> Router Class Initialized
INFO - 2025-11-09 05:19:49 --> Output Class Initialized
INFO - 2025-11-09 05:19:49 --> Security Class Initialized
INFO - 2025-11-09 05:19:49 --> Input Class Initialized
INFO - 2025-11-09 05:19:49 --> Language Class Initialized
INFO - 2025-11-09 05:19:49 --> Loader Class Initialized
INFO - 2025-11-09 05:19:49 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 05:19:49 --> Helper loaded: url_helper
INFO - 2025-11-09 05:19:49 --> Helper loaded: file_helper
INFO - 2025-11-09 05:19:49 --> Helper loaded: main_helper
INFO - 2025-11-09 05:19:49 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 05:19:49 --> Database Driver Class Initialized
INFO - 2025-11-09 05:19:49 --> Email Class Initialized
DEBUG - 2025-11-09 05:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 05:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 05:19:49 --> Controller Class Initialized
INFO - 2025-11-09 05:19:49 --> Model "User_model" initialized
INFO - 2025-11-09 05:19:49 --> Model "Project_model" initialized
INFO - 2025-11-09 05:19:49 --> Helper loaded: form_helper
INFO - 2025-11-09 05:19:49 --> Form Validation Class Initialized
INFO - 2025-11-09 05:19:49 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-09 05:19:49 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-09 05:19:49 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-09 05:19:49 --> Model "Swot_model" initialized
INFO - 2025-11-09 05:19:49 --> Model "Swot_model" initialized
INFO - 2025-11-09 05:19:49 --> Model "Topk_service_model" initialized
INFO - 2025-11-09 05:19:49 --> Final output sent to browser
INFO - 2025-11-09 05:19:49 --> Total execution time: 0.1196
INFO - 2025-11-09 05:19:56 --> Config Class Initialized
INFO - 2025-11-09 05:19:56 --> Hooks Class Initialized
INFO - 2025-11-09 05:19:56 --> UTF-8 Support Enabled
INFO - 2025-11-09 05:19:56 --> Utf8 Class Initialized
INFO - 2025-11-09 05:19:56 --> URI Class Initialized
INFO - 2025-11-09 05:19:56 --> Router Class Initialized
INFO - 2025-11-09 05:19:56 --> Output Class Initialized
INFO - 2025-11-09 05:19:56 --> Security Class Initialized
INFO - 2025-11-09 05:19:56 --> Input Class Initialized
INFO - 2025-11-09 05:19:56 --> Language Class Initialized
INFO - 2025-11-09 05:19:56 --> Loader Class Initialized
INFO - 2025-11-09 05:19:56 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 05:19:56 --> Helper loaded: url_helper
INFO - 2025-11-09 05:19:56 --> Helper loaded: file_helper
INFO - 2025-11-09 05:19:56 --> Helper loaded: main_helper
INFO - 2025-11-09 05:19:56 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 05:19:56 --> Database Driver Class Initialized
INFO - 2025-11-09 05:19:56 --> Email Class Initialized
DEBUG - 2025-11-09 05:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 05:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 05:19:56 --> Controller Class Initialized
INFO - 2025-11-09 05:19:56 --> Model "User_model" initialized
INFO - 2025-11-09 05:19:56 --> Model "Project_model" initialized
INFO - 2025-11-09 05:19:56 --> Helper loaded: form_helper
INFO - 2025-11-09 05:19:56 --> Form Validation Class Initialized
INFO - 2025-11-09 05:19:56 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-09 05:19:56 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-09 05:19:56 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-09 05:19:56 --> Model "Swot_model" initialized
INFO - 2025-11-09 05:19:56 --> Model "Swot_model" initialized
INFO - 2025-11-09 05:19:56 --> Model "Topk_service_model" initialized
INFO - 2025-11-09 05:19:56 --> Final output sent to browser
INFO - 2025-11-09 05:19:56 --> Total execution time: 0.1026
INFO - 2025-11-09 05:21:23 --> Config Class Initialized
INFO - 2025-11-09 05:21:23 --> Hooks Class Initialized
INFO - 2025-11-09 05:21:23 --> UTF-8 Support Enabled
INFO - 2025-11-09 05:21:23 --> Utf8 Class Initialized
INFO - 2025-11-09 05:21:23 --> URI Class Initialized
INFO - 2025-11-09 05:21:23 --> Router Class Initialized
INFO - 2025-11-09 05:21:23 --> Output Class Initialized
INFO - 2025-11-09 05:21:23 --> Security Class Initialized
INFO - 2025-11-09 05:21:23 --> Input Class Initialized
INFO - 2025-11-09 05:21:23 --> Language Class Initialized
INFO - 2025-11-09 05:21:23 --> Loader Class Initialized
INFO - 2025-11-09 05:21:23 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 05:21:23 --> Helper loaded: url_helper
INFO - 2025-11-09 05:21:23 --> Helper loaded: file_helper
INFO - 2025-11-09 05:21:23 --> Helper loaded: main_helper
INFO - 2025-11-09 05:21:23 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 05:21:23 --> Database Driver Class Initialized
INFO - 2025-11-09 05:21:23 --> Email Class Initialized
DEBUG - 2025-11-09 05:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 05:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 05:21:23 --> Controller Class Initialized
INFO - 2025-11-09 05:21:23 --> Model "User_model" initialized
INFO - 2025-11-09 05:21:23 --> Model "Project_model" initialized
INFO - 2025-11-09 05:21:23 --> Helper loaded: form_helper
INFO - 2025-11-09 05:21:23 --> Form Validation Class Initialized
INFO - 2025-11-09 05:21:23 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-09 05:21:23 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-09 05:21:23 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-09 05:21:23 --> Model "Swot_model" initialized
INFO - 2025-11-09 05:21:23 --> Model "Swot_model" initialized
INFO - 2025-11-09 05:21:23 --> Model "Topk_service_model" initialized
ERROR - 2025-11-09 05:21:23 --> semantic_filter error: Api_project::semantic_filter_pairs_array(): Return value must be of type array, none returned
INFO - 2025-11-09 05:21:23 --> Final output sent to browser
INFO - 2025-11-09 05:21:23 --> Total execution time: 0.1084
INFO - 2025-11-09 05:24:18 --> Config Class Initialized
INFO - 2025-11-09 05:24:18 --> Hooks Class Initialized
INFO - 2025-11-09 05:24:18 --> UTF-8 Support Enabled
INFO - 2025-11-09 05:24:18 --> Utf8 Class Initialized
INFO - 2025-11-09 05:24:18 --> URI Class Initialized
INFO - 2025-11-09 05:24:18 --> Router Class Initialized
INFO - 2025-11-09 05:24:18 --> Output Class Initialized
INFO - 2025-11-09 05:24:18 --> Security Class Initialized
INFO - 2025-11-09 05:24:18 --> Input Class Initialized
INFO - 2025-11-09 05:24:18 --> Language Class Initialized
ERROR - 2025-11-09 05:24:18 --> Severity: error --> Exception: syntax error, unexpected token "(" D:\laragon\www\acumena\application\controllers\Api_project.php 671
INFO - 2025-11-09 05:24:38 --> Config Class Initialized
INFO - 2025-11-09 05:24:38 --> Hooks Class Initialized
INFO - 2025-11-09 05:24:38 --> UTF-8 Support Enabled
INFO - 2025-11-09 05:24:38 --> Utf8 Class Initialized
INFO - 2025-11-09 05:24:38 --> URI Class Initialized
INFO - 2025-11-09 05:24:38 --> Router Class Initialized
INFO - 2025-11-09 05:24:38 --> Output Class Initialized
INFO - 2025-11-09 05:24:38 --> Security Class Initialized
INFO - 2025-11-09 05:24:38 --> Input Class Initialized
INFO - 2025-11-09 05:24:38 --> Language Class Initialized
INFO - 2025-11-09 05:24:38 --> Loader Class Initialized
INFO - 2025-11-09 05:24:38 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 05:24:38 --> Helper loaded: url_helper
INFO - 2025-11-09 05:24:38 --> Helper loaded: file_helper
INFO - 2025-11-09 05:24:38 --> Helper loaded: main_helper
INFO - 2025-11-09 05:24:38 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 05:24:38 --> Database Driver Class Initialized
INFO - 2025-11-09 05:24:38 --> Email Class Initialized
DEBUG - 2025-11-09 05:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 05:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 05:24:38 --> Controller Class Initialized
INFO - 2025-11-09 05:24:38 --> Model "User_model" initialized
INFO - 2025-11-09 05:24:38 --> Model "Project_model" initialized
INFO - 2025-11-09 05:24:38 --> Helper loaded: form_helper
INFO - 2025-11-09 05:24:38 --> Form Validation Class Initialized
INFO - 2025-11-09 05:24:38 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-09 05:24:38 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-09 05:24:38 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-09 05:24:38 --> Model "Swot_model" initialized
INFO - 2025-11-09 05:24:38 --> Model "Swot_model" initialized
INFO - 2025-11-09 05:24:38 --> Model "Topk_service_model" initialized
ERROR - 2025-11-09 05:24:49 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 383,
    "totalTokenCount": 1582,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 383
      }
    ],
    "thoughtsTokenCount": 1199
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "niUQad_nMbqVg8UPx6nX-Q8"
}

INFO - 2025-11-09 05:24:49 --> Final output sent to browser
INFO - 2025-11-09 05:24:49 --> Total execution time: 10.3157
INFO - 2025-11-09 05:26:39 --> Config Class Initialized
INFO - 2025-11-09 05:26:39 --> Hooks Class Initialized
INFO - 2025-11-09 05:26:39 --> UTF-8 Support Enabled
INFO - 2025-11-09 05:26:39 --> Utf8 Class Initialized
INFO - 2025-11-09 05:26:39 --> URI Class Initialized
INFO - 2025-11-09 05:26:39 --> Router Class Initialized
INFO - 2025-11-09 05:26:39 --> Output Class Initialized
INFO - 2025-11-09 05:26:39 --> Security Class Initialized
INFO - 2025-11-09 05:26:39 --> Input Class Initialized
INFO - 2025-11-09 05:26:39 --> Language Class Initialized
INFO - 2025-11-09 05:26:39 --> Loader Class Initialized
INFO - 2025-11-09 05:26:39 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 05:26:39 --> Helper loaded: url_helper
INFO - 2025-11-09 05:26:39 --> Helper loaded: file_helper
INFO - 2025-11-09 05:26:39 --> Helper loaded: main_helper
INFO - 2025-11-09 05:26:39 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 05:26:39 --> Database Driver Class Initialized
INFO - 2025-11-09 05:26:39 --> Email Class Initialized
DEBUG - 2025-11-09 05:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 05:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 05:26:39 --> Controller Class Initialized
INFO - 2025-11-09 05:26:39 --> Model "User_model" initialized
INFO - 2025-11-09 05:26:39 --> Model "Project_model" initialized
INFO - 2025-11-09 05:26:39 --> Helper loaded: form_helper
INFO - 2025-11-09 05:26:39 --> Form Validation Class Initialized
INFO - 2025-11-09 05:26:39 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-09 05:26:39 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-09 05:26:39 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-09 05:26:39 --> Model "Swot_model" initialized
INFO - 2025-11-09 05:26:39 --> Model "Swot_model" initialized
INFO - 2025-11-09 05:26:39 --> Model "Topk_service_model" initialized
ERROR - 2025-11-09 05:26:39 --> strategies error: Api_project::generate_strategies_from_pairs(): Return value must be of type array, none returned
INFO - 2025-11-09 05:26:39 --> Final output sent to browser
INFO - 2025-11-09 05:26:39 --> Total execution time: 0.0927
INFO - 2025-11-09 05:28:42 --> Config Class Initialized
INFO - 2025-11-09 05:28:42 --> Hooks Class Initialized
INFO - 2025-11-09 05:28:42 --> UTF-8 Support Enabled
INFO - 2025-11-09 05:28:42 --> Utf8 Class Initialized
INFO - 2025-11-09 05:28:42 --> URI Class Initialized
INFO - 2025-11-09 05:28:42 --> Router Class Initialized
INFO - 2025-11-09 05:28:42 --> Output Class Initialized
INFO - 2025-11-09 05:28:42 --> Security Class Initialized
INFO - 2025-11-09 05:28:42 --> Input Class Initialized
INFO - 2025-11-09 05:28:42 --> Language Class Initialized
INFO - 2025-11-09 05:28:42 --> Loader Class Initialized
INFO - 2025-11-09 05:28:42 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 05:28:42 --> Helper loaded: url_helper
INFO - 2025-11-09 05:28:42 --> Helper loaded: file_helper
INFO - 2025-11-09 05:28:42 --> Helper loaded: main_helper
INFO - 2025-11-09 05:28:42 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 05:28:42 --> Database Driver Class Initialized
INFO - 2025-11-09 05:28:42 --> Email Class Initialized
DEBUG - 2025-11-09 05:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 05:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 05:28:42 --> Controller Class Initialized
INFO - 2025-11-09 05:28:42 --> Model "User_model" initialized
INFO - 2025-11-09 05:28:42 --> Model "Project_model" initialized
INFO - 2025-11-09 05:28:42 --> Helper loaded: form_helper
INFO - 2025-11-09 05:28:42 --> Form Validation Class Initialized
INFO - 2025-11-09 05:28:42 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-09 05:28:42 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-09 05:28:42 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-09 05:28:42 --> Model "Swot_model" initialized
INFO - 2025-11-09 05:28:42 --> Model "Swot_model" initialized
INFO - 2025-11-09 05:28:42 --> Model "Topk_service_model" initialized
ERROR - 2025-11-09 05:28:47 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 242,
    "totalTokenCount": 1041,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 242
      }
    ],
    "thoughtsTokenCount": 799
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "jSYQaYmYKJuyjuMPsP2rgQI"
}

ERROR - 2025-11-09 05:28:47 --> Query error: Table 'acumena.ai_strategy' doesn't exist - Invalid query: DELETE FROM `ai_strategy`
WHERE `run_id` = 3
INFO - 2025-11-09 05:28:47 --> Language file loaded: language/english/db_lang.php
INFO - 2025-11-09 05:30:47 --> Config Class Initialized
INFO - 2025-11-09 05:30:47 --> Hooks Class Initialized
INFO - 2025-11-09 05:30:47 --> UTF-8 Support Enabled
INFO - 2025-11-09 05:30:47 --> Utf8 Class Initialized
INFO - 2025-11-09 05:30:47 --> URI Class Initialized
INFO - 2025-11-09 05:30:47 --> Router Class Initialized
INFO - 2025-11-09 05:30:47 --> Output Class Initialized
INFO - 2025-11-09 05:30:47 --> Security Class Initialized
INFO - 2025-11-09 05:30:47 --> Input Class Initialized
INFO - 2025-11-09 05:30:47 --> Language Class Initialized
INFO - 2025-11-09 05:30:47 --> Loader Class Initialized
INFO - 2025-11-09 05:30:47 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 05:30:47 --> Helper loaded: url_helper
INFO - 2025-11-09 05:30:47 --> Helper loaded: file_helper
INFO - 2025-11-09 05:30:47 --> Helper loaded: main_helper
INFO - 2025-11-09 05:30:47 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 05:30:47 --> Database Driver Class Initialized
INFO - 2025-11-09 05:30:47 --> Email Class Initialized
DEBUG - 2025-11-09 05:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 05:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 05:30:47 --> Controller Class Initialized
INFO - 2025-11-09 05:30:47 --> Model "User_model" initialized
INFO - 2025-11-09 05:30:47 --> Model "Project_model" initialized
INFO - 2025-11-09 05:30:47 --> Helper loaded: form_helper
INFO - 2025-11-09 05:30:47 --> Form Validation Class Initialized
INFO - 2025-11-09 05:30:47 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-09 05:30:47 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-09 05:30:47 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-09 05:30:47 --> Model "Swot_model" initialized
INFO - 2025-11-09 05:30:47 --> Model "Swot_model" initialized
INFO - 2025-11-09 05:30:47 --> Model "Topk_service_model" initialized
ERROR - 2025-11-09 05:30:52 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 242,
    "totalTokenCount": 1041,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 242
      }
    ],
    "thoughtsTokenCount": 799
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "CicQaeaUHpTMg8UPo9GIqQU"
}

INFO - 2025-11-09 05:30:52 --> Final output sent to browser
INFO - 2025-11-09 05:30:52 --> Total execution time: 5.3004
INFO - 2025-11-09 05:35:55 --> Config Class Initialized
INFO - 2025-11-09 05:35:55 --> Hooks Class Initialized
INFO - 2025-11-09 05:35:55 --> UTF-8 Support Enabled
INFO - 2025-11-09 05:35:55 --> Utf8 Class Initialized
INFO - 2025-11-09 05:35:55 --> URI Class Initialized
INFO - 2025-11-09 05:35:55 --> Router Class Initialized
INFO - 2025-11-09 05:35:55 --> Output Class Initialized
INFO - 2025-11-09 05:35:55 --> Security Class Initialized
INFO - 2025-11-09 05:35:55 --> Input Class Initialized
INFO - 2025-11-09 05:35:55 --> Language Class Initialized
INFO - 2025-11-09 05:35:55 --> Loader Class Initialized
INFO - 2025-11-09 05:35:55 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 05:35:55 --> Helper loaded: url_helper
INFO - 2025-11-09 05:35:55 --> Helper loaded: file_helper
INFO - 2025-11-09 05:35:55 --> Helper loaded: main_helper
INFO - 2025-11-09 05:35:55 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 05:35:55 --> Database Driver Class Initialized
INFO - 2025-11-09 05:35:55 --> Email Class Initialized
DEBUG - 2025-11-09 05:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 05:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 05:35:55 --> Controller Class Initialized
INFO - 2025-11-09 05:35:55 --> Model "User_model" initialized
INFO - 2025-11-09 05:35:55 --> Model "Project_model" initialized
INFO - 2025-11-09 05:35:55 --> Helper loaded: form_helper
INFO - 2025-11-09 05:35:55 --> Form Validation Class Initialized
INFO - 2025-11-09 05:35:55 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-09 05:35:55 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-09 05:35:55 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-09 05:35:55 --> Model "Swot_model" initialized
INFO - 2025-11-09 05:35:55 --> Model "Swot_model" initialized
INFO - 2025-11-09 05:35:55 --> Model "Topk_service_model" initialized
ERROR - 2025-11-09 05:36:00 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 242,
    "totalTokenCount": 1041,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 242
      }
    ],
    "thoughtsTokenCount": 799
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "PigQaZmpPKvu4-EPi9it4AE"
}

ERROR - 2025-11-09 05:36:04 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 259,
    "totalTokenCount": 818,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 259
      }
    ],
    "thoughtsTokenCount": 559
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "QigQaffhNI22juMPirnj-A8"
}

INFO - 2025-11-09 05:36:04 --> Final output sent to browser
INFO - 2025-11-09 05:36:04 --> Total execution time: 9.4162
INFO - 2025-11-09 05:37:33 --> Config Class Initialized
INFO - 2025-11-09 05:37:33 --> Hooks Class Initialized
INFO - 2025-11-09 05:37:33 --> UTF-8 Support Enabled
INFO - 2025-11-09 05:37:33 --> Utf8 Class Initialized
INFO - 2025-11-09 05:37:33 --> URI Class Initialized
INFO - 2025-11-09 05:37:33 --> Router Class Initialized
INFO - 2025-11-09 05:37:33 --> Output Class Initialized
INFO - 2025-11-09 05:37:33 --> Security Class Initialized
INFO - 2025-11-09 05:37:33 --> Input Class Initialized
INFO - 2025-11-09 05:37:33 --> Language Class Initialized
INFO - 2025-11-09 05:37:33 --> Loader Class Initialized
INFO - 2025-11-09 05:37:33 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-09 05:37:33 --> Helper loaded: url_helper
INFO - 2025-11-09 05:37:33 --> Helper loaded: file_helper
INFO - 2025-11-09 05:37:33 --> Helper loaded: main_helper
INFO - 2025-11-09 05:37:33 --> Helper loaded: sendgrid_helper
INFO - 2025-11-09 05:37:33 --> Database Driver Class Initialized
INFO - 2025-11-09 05:37:33 --> Email Class Initialized
DEBUG - 2025-11-09 05:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-09 05:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-09 05:37:33 --> Controller Class Initialized
INFO - 2025-11-09 05:37:33 --> Model "User_model" initialized
INFO - 2025-11-09 05:37:33 --> Model "Project_model" initialized
INFO - 2025-11-09 05:37:33 --> Helper loaded: form_helper
INFO - 2025-11-09 05:37:33 --> Form Validation Class Initialized
INFO - 2025-11-09 05:37:33 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-09 05:37:33 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-09 05:37:33 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-09 05:37:33 --> Model "Swot_model" initialized
INFO - 2025-11-09 05:37:33 --> Model "Swot_model" initialized
INFO - 2025-11-09 05:37:33 --> Model "Topk_service_model" initialized
ERROR - 2025-11-09 05:37:38 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 242,
    "totalTokenCount": 1041,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 242
      }
    ],
    "thoughtsTokenCount": 799
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "oCgQabahNv6u4-EPtcTAqA4"
}

ERROR - 2025-11-09 05:37:41 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 259,
    "totalTokenCount": 818,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 259
      }
    ],
    "thoughtsTokenCount": 559
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "pCgQaZmnCvW64-EP5YaF4Ag"
}

INFO - 2025-11-09 05:37:41 --> Final output sent to browser
INFO - 2025-11-09 05:37:41 --> Total execution time: 8.9133
