<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-11-13 11:50:18 --> Config Class Initialized
INFO - 2025-11-13 11:50:18 --> Hooks Class Initialized
INFO - 2025-11-13 11:50:18 --> UTF-8 Support Enabled
INFO - 2025-11-13 11:50:18 --> Utf8 Class Initialized
INFO - 2025-11-13 11:50:18 --> URI Class Initialized
DEBUG - 2025-11-13 11:50:18 --> No URI present. Default controller set.
INFO - 2025-11-13 11:50:18 --> Router Class Initialized
INFO - 2025-11-13 11:50:18 --> Output Class Initialized
INFO - 2025-11-13 11:50:18 --> Security Class Initialized
INFO - 2025-11-13 11:50:18 --> Input Class Initialized
INFO - 2025-11-13 11:50:18 --> Language Class Initialized
INFO - 2025-11-13 11:50:18 --> Loader Class Initialized
INFO - 2025-11-13 11:50:18 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-13 11:50:18 --> Helper loaded: url_helper
INFO - 2025-11-13 11:50:18 --> Helper loaded: file_helper
INFO - 2025-11-13 11:50:18 --> Helper loaded: main_helper
INFO - 2025-11-13 11:50:18 --> Helper loaded: sendgrid_helper
INFO - 2025-11-13 11:50:18 --> Database Driver Class Initialized
INFO - 2025-11-13 11:50:18 --> Email Class Initialized
DEBUG - 2025-11-13 11:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-13 11:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-13 11:50:18 --> Controller Class Initialized
INFO - 2025-11-13 11:50:18 --> Config Class Initialized
INFO - 2025-11-13 11:50:18 --> Hooks Class Initialized
INFO - 2025-11-13 11:50:18 --> UTF-8 Support Enabled
INFO - 2025-11-13 11:50:18 --> Utf8 Class Initialized
INFO - 2025-11-13 11:50:18 --> URI Class Initialized
INFO - 2025-11-13 11:50:18 --> Router Class Initialized
INFO - 2025-11-13 11:50:18 --> Output Class Initialized
INFO - 2025-11-13 11:50:18 --> Security Class Initialized
INFO - 2025-11-13 11:50:18 --> Input Class Initialized
INFO - 2025-11-13 11:50:18 --> Language Class Initialized
INFO - 2025-11-13 11:50:18 --> Loader Class Initialized
INFO - 2025-11-13 11:50:18 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-13 11:50:18 --> Helper loaded: url_helper
INFO - 2025-11-13 11:50:18 --> Helper loaded: file_helper
INFO - 2025-11-13 11:50:18 --> Helper loaded: main_helper
INFO - 2025-11-13 11:50:18 --> Helper loaded: sendgrid_helper
INFO - 2025-11-13 11:50:18 --> Database Driver Class Initialized
INFO - 2025-11-13 11:50:18 --> Email Class Initialized
DEBUG - 2025-11-13 11:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-13 11:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-13 11:50:18 --> Controller Class Initialized
INFO - 2025-11-13 11:50:18 --> Model "Subscription_model" initialized
INFO - 2025-11-13 11:50:18 --> Model "User_model" initialized
INFO - 2025-11-13 11:50:18 --> Model "Auth_model" initialized
INFO - 2025-11-13 11:50:18 --> Config Class Initialized
INFO - 2025-11-13 11:50:18 --> Hooks Class Initialized
INFO - 2025-11-13 11:50:18 --> UTF-8 Support Enabled
INFO - 2025-11-13 11:50:18 --> Utf8 Class Initialized
INFO - 2025-11-13 11:50:18 --> URI Class Initialized
INFO - 2025-11-13 11:50:18 --> Router Class Initialized
INFO - 2025-11-13 11:50:18 --> Output Class Initialized
INFO - 2025-11-13 11:50:18 --> Security Class Initialized
INFO - 2025-11-13 11:50:18 --> Input Class Initialized
INFO - 2025-11-13 11:50:18 --> Language Class Initialized
INFO - 2025-11-13 11:50:18 --> Loader Class Initialized
INFO - 2025-11-13 11:50:18 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-13 11:50:18 --> Helper loaded: url_helper
INFO - 2025-11-13 11:50:18 --> Helper loaded: file_helper
INFO - 2025-11-13 11:50:18 --> Helper loaded: main_helper
INFO - 2025-11-13 11:50:18 --> Helper loaded: sendgrid_helper
INFO - 2025-11-13 11:50:18 --> Database Driver Class Initialized
INFO - 2025-11-13 11:50:18 --> Email Class Initialized
DEBUG - 2025-11-13 11:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-13 11:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-13 11:50:18 --> Controller Class Initialized
INFO - 2025-11-13 11:50:18 --> Config Class Initialized
INFO - 2025-11-13 11:50:18 --> Hooks Class Initialized
INFO - 2025-11-13 11:50:18 --> UTF-8 Support Enabled
INFO - 2025-11-13 11:50:18 --> Utf8 Class Initialized
INFO - 2025-11-13 11:50:18 --> URI Class Initialized
INFO - 2025-11-13 11:50:18 --> Router Class Initialized
INFO - 2025-11-13 11:50:18 --> Output Class Initialized
INFO - 2025-11-13 11:50:18 --> Security Class Initialized
INFO - 2025-11-13 11:50:18 --> Input Class Initialized
INFO - 2025-11-13 11:50:18 --> Language Class Initialized
INFO - 2025-11-13 11:50:18 --> Loader Class Initialized
INFO - 2025-11-13 11:50:18 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-13 11:50:18 --> Helper loaded: url_helper
INFO - 2025-11-13 11:50:18 --> Helper loaded: file_helper
INFO - 2025-11-13 11:50:18 --> Helper loaded: main_helper
INFO - 2025-11-13 11:50:18 --> Helper loaded: sendgrid_helper
INFO - 2025-11-13 11:50:18 --> Database Driver Class Initialized
INFO - 2025-11-13 11:50:18 --> Email Class Initialized
DEBUG - 2025-11-13 11:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-13 11:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-13 11:50:18 --> Controller Class Initialized
INFO - 2025-11-13 11:50:18 --> Model "Subscription_model" initialized
INFO - 2025-11-13 11:50:18 --> Model "User_model" initialized
INFO - 2025-11-13 11:50:18 --> Model "Auth_model" initialized
INFO - 2025-11-13 11:50:18 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-13 11:50:18 --> Final output sent to browser
INFO - 2025-11-13 11:50:18 --> Total execution time: 0.0747
INFO - 2025-11-13 11:50:42 --> Config Class Initialized
INFO - 2025-11-13 11:50:42 --> Hooks Class Initialized
INFO - 2025-11-13 11:50:42 --> UTF-8 Support Enabled
INFO - 2025-11-13 11:50:42 --> Utf8 Class Initialized
INFO - 2025-11-13 11:50:42 --> URI Class Initialized
DEBUG - 2025-11-13 11:50:42 --> No URI present. Default controller set.
INFO - 2025-11-13 11:50:42 --> Router Class Initialized
INFO - 2025-11-13 11:50:42 --> Output Class Initialized
INFO - 2025-11-13 11:50:42 --> Security Class Initialized
INFO - 2025-11-13 11:50:42 --> Input Class Initialized
INFO - 2025-11-13 11:50:42 --> Language Class Initialized
INFO - 2025-11-13 11:50:42 --> Loader Class Initialized
INFO - 2025-11-13 11:50:42 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-13 11:50:42 --> Helper loaded: url_helper
INFO - 2025-11-13 11:50:42 --> Helper loaded: file_helper
INFO - 2025-11-13 11:50:42 --> Helper loaded: main_helper
INFO - 2025-11-13 11:50:42 --> Helper loaded: sendgrid_helper
INFO - 2025-11-13 11:50:42 --> Database Driver Class Initialized
INFO - 2025-11-13 11:50:42 --> Email Class Initialized
DEBUG - 2025-11-13 11:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-13 11:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-13 11:50:42 --> Controller Class Initialized
INFO - 2025-11-13 11:50:42 --> Config Class Initialized
INFO - 2025-11-13 11:50:42 --> Hooks Class Initialized
INFO - 2025-11-13 11:50:42 --> UTF-8 Support Enabled
INFO - 2025-11-13 11:50:42 --> Utf8 Class Initialized
INFO - 2025-11-13 11:50:42 --> URI Class Initialized
INFO - 2025-11-13 11:50:42 --> Router Class Initialized
INFO - 2025-11-13 11:50:42 --> Output Class Initialized
INFO - 2025-11-13 11:50:42 --> Security Class Initialized
INFO - 2025-11-13 11:50:42 --> Input Class Initialized
INFO - 2025-11-13 11:50:42 --> Language Class Initialized
INFO - 2025-11-13 11:50:42 --> Loader Class Initialized
INFO - 2025-11-13 11:50:42 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-13 11:50:42 --> Helper loaded: url_helper
INFO - 2025-11-13 11:50:42 --> Helper loaded: file_helper
INFO - 2025-11-13 11:50:42 --> Helper loaded: main_helper
INFO - 2025-11-13 11:50:42 --> Helper loaded: sendgrid_helper
INFO - 2025-11-13 11:50:42 --> Database Driver Class Initialized
INFO - 2025-11-13 11:50:42 --> Email Class Initialized
DEBUG - 2025-11-13 11:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-13 11:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-13 11:50:42 --> Controller Class Initialized
INFO - 2025-11-13 11:50:42 --> Model "Subscription_model" initialized
INFO - 2025-11-13 11:50:42 --> Model "User_model" initialized
INFO - 2025-11-13 11:50:42 --> Model "Auth_model" initialized
INFO - 2025-11-13 11:50:42 --> Config Class Initialized
INFO - 2025-11-13 11:50:42 --> Hooks Class Initialized
INFO - 2025-11-13 11:50:42 --> UTF-8 Support Enabled
INFO - 2025-11-13 11:50:42 --> Utf8 Class Initialized
INFO - 2025-11-13 11:50:42 --> URI Class Initialized
INFO - 2025-11-13 11:50:42 --> Router Class Initialized
INFO - 2025-11-13 11:50:42 --> Output Class Initialized
INFO - 2025-11-13 11:50:42 --> Security Class Initialized
INFO - 2025-11-13 11:50:42 --> Input Class Initialized
INFO - 2025-11-13 11:50:42 --> Language Class Initialized
INFO - 2025-11-13 11:50:42 --> Loader Class Initialized
INFO - 2025-11-13 11:50:42 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-13 11:50:42 --> Helper loaded: url_helper
INFO - 2025-11-13 11:50:42 --> Helper loaded: file_helper
INFO - 2025-11-13 11:50:42 --> Helper loaded: main_helper
INFO - 2025-11-13 11:50:42 --> Helper loaded: sendgrid_helper
INFO - 2025-11-13 11:50:42 --> Database Driver Class Initialized
INFO - 2025-11-13 11:50:42 --> Email Class Initialized
DEBUG - 2025-11-13 11:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-13 11:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-13 11:50:42 --> Controller Class Initialized
INFO - 2025-11-13 11:50:42 --> Config Class Initialized
INFO - 2025-11-13 11:50:42 --> Hooks Class Initialized
INFO - 2025-11-13 11:50:42 --> UTF-8 Support Enabled
INFO - 2025-11-13 11:50:42 --> Utf8 Class Initialized
INFO - 2025-11-13 11:50:42 --> URI Class Initialized
INFO - 2025-11-13 11:50:42 --> Router Class Initialized
INFO - 2025-11-13 11:50:42 --> Output Class Initialized
INFO - 2025-11-13 11:50:42 --> Security Class Initialized
INFO - 2025-11-13 11:50:42 --> Input Class Initialized
INFO - 2025-11-13 11:50:42 --> Language Class Initialized
INFO - 2025-11-13 11:50:42 --> Loader Class Initialized
INFO - 2025-11-13 11:50:42 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-13 11:50:42 --> Helper loaded: url_helper
INFO - 2025-11-13 11:50:42 --> Helper loaded: file_helper
INFO - 2025-11-13 11:50:42 --> Helper loaded: main_helper
INFO - 2025-11-13 11:50:42 --> Helper loaded: sendgrid_helper
INFO - 2025-11-13 11:50:42 --> Database Driver Class Initialized
INFO - 2025-11-13 11:50:42 --> Email Class Initialized
DEBUG - 2025-11-13 11:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-13 11:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-13 11:50:42 --> Controller Class Initialized
INFO - 2025-11-13 11:50:42 --> Model "Subscription_model" initialized
INFO - 2025-11-13 11:50:42 --> Model "User_model" initialized
INFO - 2025-11-13 11:50:42 --> Model "Auth_model" initialized
INFO - 2025-11-13 11:50:42 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-13 11:50:42 --> Final output sent to browser
INFO - 2025-11-13 11:50:42 --> Total execution time: 0.0892
INFO - 2025-11-13 11:58:16 --> Config Class Initialized
INFO - 2025-11-13 11:58:16 --> Hooks Class Initialized
INFO - 2025-11-13 11:58:16 --> UTF-8 Support Enabled
INFO - 2025-11-13 11:58:16 --> Utf8 Class Initialized
INFO - 2025-11-13 11:58:16 --> URI Class Initialized
INFO - 2025-11-13 11:58:16 --> Router Class Initialized
INFO - 2025-11-13 11:58:16 --> Output Class Initialized
INFO - 2025-11-13 11:58:16 --> Security Class Initialized
INFO - 2025-11-13 11:58:16 --> Input Class Initialized
INFO - 2025-11-13 11:58:16 --> Language Class Initialized
INFO - 2025-11-13 11:58:16 --> Loader Class Initialized
INFO - 2025-11-13 11:58:16 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-13 11:58:16 --> Helper loaded: url_helper
INFO - 2025-11-13 11:58:16 --> Helper loaded: file_helper
INFO - 2025-11-13 11:58:16 --> Helper loaded: main_helper
INFO - 2025-11-13 11:58:17 --> Helper loaded: sendgrid_helper
INFO - 2025-11-13 11:58:17 --> Database Driver Class Initialized
INFO - 2025-11-13 11:58:17 --> Email Class Initialized
DEBUG - 2025-11-13 11:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-13 11:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-13 11:58:18 --> Controller Class Initialized
INFO - 2025-11-13 11:58:18 --> Model "Subscription_model" initialized
INFO - 2025-11-13 11:58:18 --> Model "User_model" initialized
INFO - 2025-11-13 11:58:18 --> Model "Auth_model" initialized
INFO - 2025-11-13 11:58:18 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-13 11:58:18 --> Final output sent to browser
INFO - 2025-11-13 11:58:18 --> Total execution time: 1.4132
INFO - 2025-11-13 11:58:20 --> Config Class Initialized
INFO - 2025-11-13 11:58:20 --> Hooks Class Initialized
INFO - 2025-11-13 11:58:20 --> UTF-8 Support Enabled
INFO - 2025-11-13 11:58:20 --> Utf8 Class Initialized
INFO - 2025-11-13 12:46:38 --> Config Class Initialized
INFO - 2025-11-13 12:46:38 --> Hooks Class Initialized
INFO - 2025-11-13 12:46:38 --> UTF-8 Support Enabled
INFO - 2025-11-13 12:46:38 --> Utf8 Class Initialized
INFO - 2025-11-13 12:46:38 --> URI Class Initialized
INFO - 2025-11-13 12:46:38 --> Router Class Initialized
INFO - 2025-11-13 12:46:38 --> Output Class Initialized
INFO - 2025-11-13 12:46:38 --> Security Class Initialized
INFO - 2025-11-13 12:46:38 --> Input Class Initialized
INFO - 2025-11-13 12:46:38 --> Language Class Initialized
INFO - 2025-11-13 12:46:38 --> Loader Class Initialized
INFO - 2025-11-13 12:46:38 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-13 12:46:38 --> Helper loaded: url_helper
INFO - 2025-11-13 12:46:38 --> Helper loaded: file_helper
INFO - 2025-11-13 12:46:38 --> Helper loaded: main_helper
INFO - 2025-11-13 12:46:38 --> Helper loaded: sendgrid_helper
INFO - 2025-11-13 12:46:38 --> Database Driver Class Initialized
INFO - 2025-11-13 12:46:38 --> Email Class Initialized
DEBUG - 2025-11-13 12:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-13 12:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-13 12:46:38 --> Controller Class Initialized
INFO - 2025-11-13 12:46:38 --> Model "Subscription_model" initialized
INFO - 2025-11-13 12:46:38 --> Model "User_model" initialized
INFO - 2025-11-13 12:46:38 --> Model "Auth_model" initialized
INFO - 2025-11-13 12:46:38 --> Final output sent to browser
INFO - 2025-11-13 12:46:38 --> Total execution time: 0.3935
INFO - 2025-11-13 12:46:40 --> Config Class Initialized
INFO - 2025-11-13 12:46:40 --> Hooks Class Initialized
INFO - 2025-11-13 12:46:40 --> UTF-8 Support Enabled
INFO - 2025-11-13 12:46:40 --> Utf8 Class Initialized
INFO - 2025-11-13 12:46:40 --> URI Class Initialized
INFO - 2025-11-13 12:46:40 --> Router Class Initialized
INFO - 2025-11-13 12:46:40 --> Output Class Initialized
INFO - 2025-11-13 12:46:40 --> Security Class Initialized
INFO - 2025-11-13 12:46:40 --> Input Class Initialized
INFO - 2025-11-13 12:46:40 --> Language Class Initialized
INFO - 2025-11-13 12:46:40 --> Loader Class Initialized
INFO - 2025-11-13 12:46:40 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-13 12:46:40 --> Helper loaded: url_helper
INFO - 2025-11-13 12:46:40 --> Helper loaded: file_helper
INFO - 2025-11-13 12:46:40 --> Helper loaded: main_helper
INFO - 2025-11-13 12:46:40 --> Helper loaded: sendgrid_helper
INFO - 2025-11-13 12:46:40 --> Database Driver Class Initialized
INFO - 2025-11-13 12:46:40 --> Email Class Initialized
DEBUG - 2025-11-13 12:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-13 12:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-13 12:46:40 --> Controller Class Initialized
INFO - 2025-11-13 12:46:40 --> Model "Subscription_model" initialized
INFO - 2025-11-13 12:46:40 --> Model "User_model" initialized
INFO - 2025-11-13 12:46:40 --> Model "Auth_model" initialized
INFO - 2025-11-13 12:46:40 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-13 12:46:40 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-13 12:46:40 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-13 12:46:40 --> File loaded: D:\laragon\www\acumena\application\views\dashboard.php
INFO - 2025-11-13 12:46:40 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-13 12:46:40 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-13 12:46:40 --> Final output sent to browser
INFO - 2025-11-13 12:46:40 --> Total execution time: 0.1544
INFO - 2025-11-13 12:46:40 --> Config Class Initialized
INFO - 2025-11-13 12:46:40 --> Hooks Class Initialized
INFO - 2025-11-13 12:46:40 --> UTF-8 Support Enabled
INFO - 2025-11-13 12:46:40 --> Utf8 Class Initialized
INFO - 2025-11-13 12:46:40 --> URI Class Initialized
INFO - 2025-11-13 12:46:40 --> Router Class Initialized
INFO - 2025-11-13 12:46:40 --> Output Class Initialized
INFO - 2025-11-13 12:46:40 --> Security Class Initialized
INFO - 2025-11-13 12:46:40 --> Input Class Initialized
INFO - 2025-11-13 12:46:40 --> Language Class Initialized
INFO - 2025-11-13 12:46:40 --> Loader Class Initialized
INFO - 2025-11-13 12:46:40 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-13 12:46:40 --> Helper loaded: url_helper
INFO - 2025-11-13 12:46:40 --> Helper loaded: file_helper
INFO - 2025-11-13 12:46:40 --> Helper loaded: main_helper
INFO - 2025-11-13 12:46:40 --> Helper loaded: sendgrid_helper
INFO - 2025-11-13 12:46:40 --> Database Driver Class Initialized
INFO - 2025-11-13 12:46:40 --> Email Class Initialized
DEBUG - 2025-11-13 12:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-13 12:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-13 12:46:40 --> Controller Class Initialized
INFO - 2025-11-13 12:46:40 --> Model "User_model" initialized
INFO - 2025-11-13 12:46:40 --> Model "Project_model" initialized
INFO - 2025-11-13 12:46:40 --> Helper loaded: form_helper
INFO - 2025-11-13 12:46:40 --> Form Validation Class Initialized
INFO - 2025-11-13 12:46:40 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-13 12:46:40 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-13 12:46:40 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-13 12:46:40 --> Model "Swot_model" initialized
INFO - 2025-11-13 12:46:40 --> Model "Swot_model" initialized
INFO - 2025-11-13 12:46:40 --> Model "Topk_service_model" initialized
INFO - 2025-11-13 12:46:40 --> Final output sent to browser
INFO - 2025-11-13 12:46:40 --> Total execution time: 0.1632
INFO - 2025-11-13 12:46:45 --> Config Class Initialized
INFO - 2025-11-13 12:46:45 --> Hooks Class Initialized
INFO - 2025-11-13 12:46:45 --> UTF-8 Support Enabled
INFO - 2025-11-13 12:46:45 --> Utf8 Class Initialized
INFO - 2025-11-13 12:46:45 --> URI Class Initialized
INFO - 2025-11-13 12:46:45 --> Router Class Initialized
INFO - 2025-11-13 12:46:45 --> Output Class Initialized
INFO - 2025-11-13 12:46:45 --> Security Class Initialized
INFO - 2025-11-13 12:46:45 --> Input Class Initialized
INFO - 2025-11-13 12:46:45 --> Language Class Initialized
INFO - 2025-11-13 12:46:45 --> Loader Class Initialized
INFO - 2025-11-13 12:46:45 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-13 12:46:45 --> Helper loaded: url_helper
INFO - 2025-11-13 12:46:45 --> Helper loaded: file_helper
INFO - 2025-11-13 12:46:45 --> Helper loaded: main_helper
INFO - 2025-11-13 12:46:45 --> Helper loaded: sendgrid_helper
INFO - 2025-11-13 12:46:45 --> Database Driver Class Initialized
INFO - 2025-11-13 12:46:45 --> Email Class Initialized
DEBUG - 2025-11-13 12:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-13 12:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-13 12:46:45 --> Controller Class Initialized
INFO - 2025-11-13 12:46:45 --> Model "Subscription_model" initialized
INFO - 2025-11-13 12:46:45 --> Model "User_model" initialized
INFO - 2025-11-13 12:46:45 --> Model "Auth_model" initialized
INFO - 2025-11-13 12:46:45 --> Model "Project_model" initialized
INFO - 2025-11-13 12:46:45 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-13 12:46:45 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-13 12:46:45 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-13 12:46:45 --> File loaded: D:\laragon\www\acumena\application\views\projects/profile.php
INFO - 2025-11-13 12:46:45 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-13 12:46:45 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-13 12:46:45 --> Final output sent to browser
INFO - 2025-11-13 12:46:45 --> Total execution time: 0.0821
INFO - 2025-11-13 12:46:45 --> Config Class Initialized
INFO - 2025-11-13 12:46:45 --> Hooks Class Initialized
INFO - 2025-11-13 12:46:45 --> UTF-8 Support Enabled
INFO - 2025-11-13 12:46:45 --> Utf8 Class Initialized
INFO - 2025-11-13 12:46:45 --> URI Class Initialized
INFO - 2025-11-13 12:46:45 --> Router Class Initialized
INFO - 2025-11-13 12:46:45 --> Output Class Initialized
INFO - 2025-11-13 12:46:45 --> Security Class Initialized
INFO - 2025-11-13 12:46:45 --> Input Class Initialized
INFO - 2025-11-13 12:46:45 --> Language Class Initialized
INFO - 2025-11-13 12:46:45 --> Loader Class Initialized
INFO - 2025-11-13 12:46:45 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-13 12:46:45 --> Helper loaded: url_helper
INFO - 2025-11-13 12:46:45 --> Helper loaded: file_helper
INFO - 2025-11-13 12:46:45 --> Helper loaded: main_helper
INFO - 2025-11-13 12:46:45 --> Helper loaded: sendgrid_helper
INFO - 2025-11-13 12:46:45 --> Database Driver Class Initialized
INFO - 2025-11-13 12:46:45 --> Email Class Initialized
DEBUG - 2025-11-13 12:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-13 12:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-13 12:46:45 --> Controller Class Initialized
INFO - 2025-11-13 12:46:45 --> Model "User_model" initialized
INFO - 2025-11-13 12:46:45 --> Model "Project_model" initialized
INFO - 2025-11-13 12:46:45 --> Helper loaded: form_helper
INFO - 2025-11-13 12:46:45 --> Form Validation Class Initialized
INFO - 2025-11-13 12:46:45 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-13 12:46:45 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-13 12:46:45 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-13 12:46:45 --> Model "Swot_model" initialized
INFO - 2025-11-13 12:46:45 --> Model "Swot_model" initialized
INFO - 2025-11-13 12:46:45 --> Model "Topk_service_model" initialized
INFO - 2025-11-13 12:46:45 --> Final output sent to browser
INFO - 2025-11-13 12:46:45 --> Total execution time: 0.0918
INFO - 2025-11-13 12:46:50 --> Config Class Initialized
INFO - 2025-11-13 12:46:50 --> Hooks Class Initialized
INFO - 2025-11-13 12:46:50 --> UTF-8 Support Enabled
INFO - 2025-11-13 12:46:50 --> Utf8 Class Initialized
INFO - 2025-11-13 12:46:50 --> URI Class Initialized
INFO - 2025-11-13 12:46:50 --> Router Class Initialized
INFO - 2025-11-13 12:46:50 --> Output Class Initialized
INFO - 2025-11-13 12:46:50 --> Security Class Initialized
INFO - 2025-11-13 12:46:50 --> Input Class Initialized
INFO - 2025-11-13 12:46:50 --> Language Class Initialized
INFO - 2025-11-13 12:46:50 --> Loader Class Initialized
INFO - 2025-11-13 12:46:50 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-13 12:46:50 --> Helper loaded: url_helper
INFO - 2025-11-13 12:46:50 --> Helper loaded: file_helper
INFO - 2025-11-13 12:46:50 --> Helper loaded: main_helper
INFO - 2025-11-13 12:46:50 --> Helper loaded: sendgrid_helper
INFO - 2025-11-13 12:46:50 --> Database Driver Class Initialized
INFO - 2025-11-13 12:46:50 --> Email Class Initialized
DEBUG - 2025-11-13 12:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-13 12:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-13 12:46:50 --> Controller Class Initialized
INFO - 2025-11-13 12:46:50 --> Model "User_model" initialized
INFO - 2025-11-13 12:46:50 --> Model "Project_model" initialized
INFO - 2025-11-13 12:46:50 --> Helper loaded: form_helper
INFO - 2025-11-13 12:46:50 --> Form Validation Class Initialized
INFO - 2025-11-13 12:46:50 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-13 12:46:50 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-13 12:46:50 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-13 12:46:50 --> Model "Swot_model" initialized
INFO - 2025-11-13 12:46:50 --> Model "Swot_model" initialized
INFO - 2025-11-13 12:46:50 --> Model "Topk_service_model" initialized
INFO - 2025-11-13 12:46:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-11-13 12:46:50 --> Final output sent to browser
INFO - 2025-11-13 12:46:50 --> Total execution time: 0.1932
INFO - 2025-11-13 12:46:50 --> Config Class Initialized
INFO - 2025-11-13 12:46:50 --> Hooks Class Initialized
INFO - 2025-11-13 12:46:50 --> UTF-8 Support Enabled
INFO - 2025-11-13 12:46:50 --> Utf8 Class Initialized
INFO - 2025-11-13 12:46:50 --> URI Class Initialized
INFO - 2025-11-13 12:46:50 --> Router Class Initialized
INFO - 2025-11-13 12:46:50 --> Output Class Initialized
INFO - 2025-11-13 12:46:50 --> Security Class Initialized
INFO - 2025-11-13 12:46:50 --> Input Class Initialized
INFO - 2025-11-13 12:46:50 --> Language Class Initialized
INFO - 2025-11-13 12:46:50 --> Loader Class Initialized
INFO - 2025-11-13 12:46:50 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-13 12:46:50 --> Helper loaded: url_helper
INFO - 2025-11-13 12:46:50 --> Helper loaded: file_helper
INFO - 2025-11-13 12:46:50 --> Helper loaded: main_helper
INFO - 2025-11-13 12:46:50 --> Helper loaded: sendgrid_helper
INFO - 2025-11-13 12:46:50 --> Database Driver Class Initialized
INFO - 2025-11-13 12:46:50 --> Email Class Initialized
DEBUG - 2025-11-13 12:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-13 12:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-13 12:46:50 --> Controller Class Initialized
INFO - 2025-11-13 12:46:50 --> Model "Subscription_model" initialized
INFO - 2025-11-13 12:46:50 --> Model "User_model" initialized
INFO - 2025-11-13 12:46:50 --> Model "Auth_model" initialized
INFO - 2025-11-13 12:46:50 --> Model "Project_model" initialized
INFO - 2025-11-13 12:46:50 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-13 12:46:50 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-13 12:46:50 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-13 12:46:50 --> File loaded: D:\laragon\www\acumena\application\views\projects/swot.php
INFO - 2025-11-13 12:46:50 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-13 12:46:50 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-13 12:46:50 --> Final output sent to browser
INFO - 2025-11-13 12:46:50 --> Total execution time: 0.0939
INFO - 2025-11-13 12:46:50 --> Config Class Initialized
INFO - 2025-11-13 12:46:50 --> Hooks Class Initialized
INFO - 2025-11-13 12:46:50 --> UTF-8 Support Enabled
INFO - 2025-11-13 12:46:50 --> Utf8 Class Initialized
INFO - 2025-11-13 12:46:50 --> URI Class Initialized
INFO - 2025-11-13 12:46:50 --> Router Class Initialized
INFO - 2025-11-13 12:46:50 --> Output Class Initialized
INFO - 2025-11-13 12:46:50 --> Security Class Initialized
INFO - 2025-11-13 12:46:50 --> Input Class Initialized
INFO - 2025-11-13 12:46:50 --> Language Class Initialized
INFO - 2025-11-13 12:46:50 --> Loader Class Initialized
INFO - 2025-11-13 12:46:50 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-13 12:46:50 --> Helper loaded: url_helper
INFO - 2025-11-13 12:46:50 --> Helper loaded: file_helper
INFO - 2025-11-13 12:46:50 --> Helper loaded: main_helper
INFO - 2025-11-13 12:46:50 --> Helper loaded: sendgrid_helper
INFO - 2025-11-13 12:46:50 --> Database Driver Class Initialized
INFO - 2025-11-13 12:46:50 --> Email Class Initialized
DEBUG - 2025-11-13 12:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-13 12:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-13 12:46:50 --> Controller Class Initialized
INFO - 2025-11-13 12:46:50 --> Model "User_model" initialized
INFO - 2025-11-13 12:46:50 --> Model "Project_model" initialized
INFO - 2025-11-13 12:46:50 --> Helper loaded: form_helper
INFO - 2025-11-13 12:46:50 --> Form Validation Class Initialized
INFO - 2025-11-13 12:46:50 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-13 12:46:50 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-13 12:46:50 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-13 12:46:50 --> Model "Swot_model" initialized
INFO - 2025-11-13 12:46:50 --> Model "Swot_model" initialized
INFO - 2025-11-13 12:46:50 --> Model "Topk_service_model" initialized
INFO - 2025-11-13 12:46:50 --> Final output sent to browser
INFO - 2025-11-13 12:46:50 --> Total execution time: 0.1501
INFO - 2025-11-13 12:46:52 --> Config Class Initialized
INFO - 2025-11-13 12:46:52 --> Hooks Class Initialized
INFO - 2025-11-13 12:46:52 --> UTF-8 Support Enabled
INFO - 2025-11-13 12:46:52 --> Utf8 Class Initialized
INFO - 2025-11-13 12:46:52 --> URI Class Initialized
INFO - 2025-11-13 12:46:52 --> Router Class Initialized
INFO - 2025-11-13 12:46:52 --> Output Class Initialized
INFO - 2025-11-13 12:46:52 --> Security Class Initialized
INFO - 2025-11-13 12:46:52 --> Input Class Initialized
INFO - 2025-11-13 12:46:52 --> Language Class Initialized
INFO - 2025-11-13 12:46:52 --> Loader Class Initialized
INFO - 2025-11-13 12:46:52 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-13 12:46:52 --> Helper loaded: url_helper
INFO - 2025-11-13 12:46:52 --> Helper loaded: file_helper
INFO - 2025-11-13 12:46:52 --> Helper loaded: main_helper
INFO - 2025-11-13 12:46:52 --> Helper loaded: sendgrid_helper
INFO - 2025-11-13 12:46:52 --> Database Driver Class Initialized
INFO - 2025-11-13 12:46:52 --> Email Class Initialized
DEBUG - 2025-11-13 12:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-13 12:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-13 12:46:52 --> Controller Class Initialized
INFO - 2025-11-13 12:46:52 --> Model "User_model" initialized
INFO - 2025-11-13 12:46:52 --> Model "Project_model" initialized
INFO - 2025-11-13 12:46:52 --> Helper loaded: form_helper
INFO - 2025-11-13 12:46:52 --> Form Validation Class Initialized
INFO - 2025-11-13 12:46:52 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-13 12:46:52 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-13 12:46:52 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-13 12:46:52 --> Model "Swot_model" initialized
INFO - 2025-11-13 12:46:52 --> Model "Swot_model" initialized
INFO - 2025-11-13 12:46:52 --> Model "Topk_service_model" initialized
INFO - 2025-11-13 12:46:52 --> Final output sent to browser
INFO - 2025-11-13 12:46:52 --> Total execution time: 0.0903
INFO - 2025-11-13 12:46:53 --> Config Class Initialized
INFO - 2025-11-13 12:46:53 --> Hooks Class Initialized
INFO - 2025-11-13 12:46:53 --> UTF-8 Support Enabled
INFO - 2025-11-13 12:46:53 --> Utf8 Class Initialized
INFO - 2025-11-13 12:46:53 --> URI Class Initialized
INFO - 2025-11-13 12:46:53 --> Router Class Initialized
INFO - 2025-11-13 12:46:53 --> Output Class Initialized
INFO - 2025-11-13 12:46:53 --> Security Class Initialized
INFO - 2025-11-13 12:46:53 --> Input Class Initialized
INFO - 2025-11-13 12:46:53 --> Language Class Initialized
INFO - 2025-11-13 12:46:53 --> Loader Class Initialized
INFO - 2025-11-13 12:46:53 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-13 12:46:53 --> Helper loaded: url_helper
INFO - 2025-11-13 12:46:53 --> Helper loaded: file_helper
INFO - 2025-11-13 12:46:53 --> Helper loaded: main_helper
INFO - 2025-11-13 12:46:53 --> Helper loaded: sendgrid_helper
INFO - 2025-11-13 12:46:53 --> Database Driver Class Initialized
INFO - 2025-11-13 12:46:53 --> Email Class Initialized
DEBUG - 2025-11-13 12:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-13 12:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-13 12:46:53 --> Controller Class Initialized
INFO - 2025-11-13 12:46:53 --> Model "Subscription_model" initialized
INFO - 2025-11-13 12:46:53 --> Model "User_model" initialized
INFO - 2025-11-13 12:46:53 --> Model "Auth_model" initialized
INFO - 2025-11-13 12:46:53 --> Model "Project_model" initialized
INFO - 2025-11-13 12:46:53 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-13 12:46:53 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-13 12:46:53 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-13 12:46:53 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ife.php
INFO - 2025-11-13 12:46:53 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-13 12:46:53 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-13 12:46:53 --> Final output sent to browser
INFO - 2025-11-13 12:46:53 --> Total execution time: 0.0891
INFO - 2025-11-13 12:46:53 --> Config Class Initialized
INFO - 2025-11-13 12:46:53 --> Hooks Class Initialized
INFO - 2025-11-13 12:46:53 --> UTF-8 Support Enabled
INFO - 2025-11-13 12:46:53 --> Utf8 Class Initialized
INFO - 2025-11-13 12:46:53 --> URI Class Initialized
INFO - 2025-11-13 12:46:53 --> Router Class Initialized
INFO - 2025-11-13 12:46:53 --> Output Class Initialized
INFO - 2025-11-13 12:46:53 --> Security Class Initialized
INFO - 2025-11-13 12:46:53 --> Input Class Initialized
INFO - 2025-11-13 12:46:53 --> Language Class Initialized
INFO - 2025-11-13 12:46:53 --> Loader Class Initialized
INFO - 2025-11-13 12:46:53 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-13 12:46:53 --> Helper loaded: url_helper
INFO - 2025-11-13 12:46:53 --> Helper loaded: file_helper
INFO - 2025-11-13 12:46:53 --> Helper loaded: main_helper
INFO - 2025-11-13 12:46:53 --> Helper loaded: sendgrid_helper
INFO - 2025-11-13 12:46:53 --> Database Driver Class Initialized
INFO - 2025-11-13 12:46:53 --> Email Class Initialized
DEBUG - 2025-11-13 12:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-13 12:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-13 12:46:53 --> Controller Class Initialized
INFO - 2025-11-13 12:46:53 --> Model "User_model" initialized
INFO - 2025-11-13 12:46:53 --> Model "Project_model" initialized
INFO - 2025-11-13 12:46:53 --> Helper loaded: form_helper
INFO - 2025-11-13 12:46:53 --> Form Validation Class Initialized
INFO - 2025-11-13 12:46:53 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-13 12:46:53 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-13 12:46:53 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-13 12:46:53 --> Model "Swot_model" initialized
INFO - 2025-11-13 12:46:53 --> Model "Swot_model" initialized
INFO - 2025-11-13 12:46:53 --> Model "Topk_service_model" initialized
INFO - 2025-11-13 12:46:53 --> Final output sent to browser
INFO - 2025-11-13 12:46:53 --> Total execution time: 0.1003
INFO - 2025-11-13 12:46:57 --> Config Class Initialized
INFO - 2025-11-13 12:46:57 --> Hooks Class Initialized
INFO - 2025-11-13 12:46:57 --> UTF-8 Support Enabled
INFO - 2025-11-13 12:46:57 --> Utf8 Class Initialized
INFO - 2025-11-13 12:46:57 --> URI Class Initialized
INFO - 2025-11-13 12:46:57 --> Router Class Initialized
INFO - 2025-11-13 12:46:57 --> Output Class Initialized
INFO - 2025-11-13 12:46:57 --> Security Class Initialized
INFO - 2025-11-13 12:46:57 --> Input Class Initialized
INFO - 2025-11-13 12:46:57 --> Language Class Initialized
INFO - 2025-11-13 12:46:57 --> Loader Class Initialized
INFO - 2025-11-13 12:46:57 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-13 12:46:57 --> Helper loaded: url_helper
INFO - 2025-11-13 12:46:57 --> Helper loaded: file_helper
INFO - 2025-11-13 12:46:57 --> Helper loaded: main_helper
INFO - 2025-11-13 12:46:57 --> Helper loaded: sendgrid_helper
INFO - 2025-11-13 12:46:57 --> Database Driver Class Initialized
INFO - 2025-11-13 12:46:57 --> Email Class Initialized
DEBUG - 2025-11-13 12:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-13 12:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-13 12:46:57 --> Controller Class Initialized
INFO - 2025-11-13 12:46:57 --> Model "Subscription_model" initialized
INFO - 2025-11-13 12:46:57 --> Model "User_model" initialized
INFO - 2025-11-13 12:46:57 --> Model "Auth_model" initialized
INFO - 2025-11-13 12:46:57 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-13 12:46:57 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-13 12:46:57 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-13 12:46:57 --> File loaded: D:\laragon\www\acumena\application\views\dashboard.php
INFO - 2025-11-13 12:46:57 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-13 12:46:57 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-13 12:46:57 --> Final output sent to browser
INFO - 2025-11-13 12:46:57 --> Total execution time: 0.0995
INFO - 2025-11-13 12:46:57 --> Config Class Initialized
INFO - 2025-11-13 12:46:57 --> Hooks Class Initialized
INFO - 2025-11-13 12:46:57 --> UTF-8 Support Enabled
INFO - 2025-11-13 12:46:57 --> Utf8 Class Initialized
INFO - 2025-11-13 12:46:57 --> URI Class Initialized
INFO - 2025-11-13 12:46:57 --> Router Class Initialized
INFO - 2025-11-13 12:46:57 --> Output Class Initialized
INFO - 2025-11-13 12:46:57 --> Security Class Initialized
INFO - 2025-11-13 12:46:57 --> Input Class Initialized
INFO - 2025-11-13 12:46:57 --> Language Class Initialized
INFO - 2025-11-13 12:46:57 --> Loader Class Initialized
INFO - 2025-11-13 12:46:57 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-13 12:46:57 --> Helper loaded: url_helper
INFO - 2025-11-13 12:46:57 --> Helper loaded: file_helper
INFO - 2025-11-13 12:46:57 --> Helper loaded: main_helper
INFO - 2025-11-13 12:46:57 --> Helper loaded: sendgrid_helper
INFO - 2025-11-13 12:46:57 --> Database Driver Class Initialized
INFO - 2025-11-13 12:46:57 --> Email Class Initialized
DEBUG - 2025-11-13 12:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-13 12:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-13 12:46:57 --> Controller Class Initialized
INFO - 2025-11-13 12:46:57 --> Model "User_model" initialized
INFO - 2025-11-13 12:46:57 --> Model "Project_model" initialized
INFO - 2025-11-13 12:46:57 --> Helper loaded: form_helper
INFO - 2025-11-13 12:46:57 --> Form Validation Class Initialized
INFO - 2025-11-13 12:46:57 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-13 12:46:57 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-13 12:46:57 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-13 12:46:57 --> Model "Swot_model" initialized
INFO - 2025-11-13 12:46:57 --> Model "Swot_model" initialized
INFO - 2025-11-13 12:46:57 --> Model "Topk_service_model" initialized
INFO - 2025-11-13 12:46:57 --> Final output sent to browser
INFO - 2025-11-13 12:46:57 --> Total execution time: 0.1188
INFO - 2025-11-13 12:54:17 --> Config Class Initialized
INFO - 2025-11-13 12:54:17 --> Hooks Class Initialized
INFO - 2025-11-13 12:54:17 --> UTF-8 Support Enabled
INFO - 2025-11-13 12:54:17 --> Utf8 Class Initialized
INFO - 2025-11-13 12:54:17 --> URI Class Initialized
INFO - 2025-11-13 12:54:17 --> Router Class Initialized
INFO - 2025-11-13 12:54:17 --> Output Class Initialized
INFO - 2025-11-13 12:54:17 --> Security Class Initialized
INFO - 2025-11-13 12:54:17 --> Input Class Initialized
INFO - 2025-11-13 12:54:17 --> Language Class Initialized
ERROR - 2025-11-13 12:54:17 --> 404 Page Not Found: Faviconico/index
INFO - 2025-11-13 13:17:16 --> Config Class Initialized
INFO - 2025-11-13 13:17:16 --> Hooks Class Initialized
INFO - 2025-11-13 13:17:16 --> UTF-8 Support Enabled
INFO - 2025-11-13 13:17:16 --> Utf8 Class Initialized
INFO - 2025-11-13 13:17:16 --> URI Class Initialized
INFO - 2025-11-13 13:17:16 --> Router Class Initialized
INFO - 2025-11-13 13:17:16 --> Output Class Initialized
INFO - 2025-11-13 13:17:16 --> Security Class Initialized
INFO - 2025-11-13 13:17:16 --> Input Class Initialized
INFO - 2025-11-13 13:17:16 --> Language Class Initialized
INFO - 2025-11-13 13:17:16 --> Loader Class Initialized
INFO - 2025-11-13 13:17:16 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-13 13:17:16 --> Helper loaded: url_helper
INFO - 2025-11-13 13:17:16 --> Helper loaded: file_helper
INFO - 2025-11-13 13:17:16 --> Helper loaded: main_helper
INFO - 2025-11-13 13:17:16 --> Helper loaded: sendgrid_helper
INFO - 2025-11-13 13:17:16 --> Database Driver Class Initialized
INFO - 2025-11-13 13:17:16 --> Email Class Initialized
DEBUG - 2025-11-13 13:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-13 13:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-13 13:17:16 --> Controller Class Initialized
INFO - 2025-11-13 13:17:16 --> Model "Subscription_model" initialized
INFO - 2025-11-13 13:17:16 --> Model "User_model" initialized
INFO - 2025-11-13 13:17:16 --> Model "Auth_model" initialized
INFO - 2025-11-13 13:17:16 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-13 13:17:16 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-13 13:17:16 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-13 13:17:16 --> File loaded: D:\laragon\www\acumena\application\views\dashboard.php
INFO - 2025-11-13 13:17:16 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-13 13:17:16 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-13 13:17:16 --> Final output sent to browser
INFO - 2025-11-13 13:17:16 --> Total execution time: 0.0869
