<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-11-16 11:39:38 --> Config Class Initialized
INFO - 2025-11-16 11:39:38 --> Hooks Class Initialized
INFO - 2025-11-16 11:39:38 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:39:38 --> Utf8 Class Initialized
INFO - 2025-11-16 11:39:38 --> URI Class Initialized
DEBUG - 2025-11-16 11:39:38 --> No URI present. Default controller set.
INFO - 2025-11-16 11:39:38 --> Router Class Initialized
INFO - 2025-11-16 11:39:38 --> Output Class Initialized
INFO - 2025-11-16 11:39:38 --> Security Class Initialized
INFO - 2025-11-16 11:39:38 --> Input Class Initialized
INFO - 2025-11-16 11:39:38 --> Language Class Initialized
INFO - 2025-11-16 11:39:39 --> Loader Class Initialized
INFO - 2025-11-16 11:39:39 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:39:39 --> Helper loaded: url_helper
INFO - 2025-11-16 11:39:39 --> Helper loaded: file_helper
INFO - 2025-11-16 11:39:39 --> Helper loaded: main_helper
INFO - 2025-11-16 11:39:39 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:39:39 --> Database Driver Class Initialized
INFO - 2025-11-16 11:39:39 --> Email Class Initialized
DEBUG - 2025-11-16 11:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:39:40 --> Controller Class Initialized
INFO - 2025-11-16 11:39:40 --> Config Class Initialized
INFO - 2025-11-16 11:39:40 --> Hooks Class Initialized
INFO - 2025-11-16 11:39:40 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:39:40 --> Utf8 Class Initialized
INFO - 2025-11-16 11:39:40 --> URI Class Initialized
INFO - 2025-11-16 11:39:40 --> Router Class Initialized
INFO - 2025-11-16 11:39:40 --> Output Class Initialized
INFO - 2025-11-16 11:39:40 --> Security Class Initialized
INFO - 2025-11-16 11:39:40 --> Input Class Initialized
INFO - 2025-11-16 11:39:40 --> Language Class Initialized
INFO - 2025-11-16 11:39:40 --> Loader Class Initialized
INFO - 2025-11-16 11:39:40 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:39:40 --> Helper loaded: url_helper
INFO - 2025-11-16 11:39:40 --> Helper loaded: file_helper
INFO - 2025-11-16 11:39:40 --> Helper loaded: main_helper
INFO - 2025-11-16 11:39:40 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:39:40 --> Database Driver Class Initialized
INFO - 2025-11-16 11:39:40 --> Email Class Initialized
DEBUG - 2025-11-16 11:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:39:40 --> Controller Class Initialized
INFO - 2025-11-16 11:39:40 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:39:40 --> Model "User_model" initialized
INFO - 2025-11-16 11:39:40 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:39:40 --> Config Class Initialized
INFO - 2025-11-16 11:39:40 --> Hooks Class Initialized
INFO - 2025-11-16 11:39:40 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:39:40 --> Utf8 Class Initialized
INFO - 2025-11-16 11:39:40 --> URI Class Initialized
INFO - 2025-11-16 11:39:40 --> Router Class Initialized
INFO - 2025-11-16 11:39:40 --> Output Class Initialized
INFO - 2025-11-16 11:39:40 --> Security Class Initialized
INFO - 2025-11-16 11:39:40 --> Input Class Initialized
INFO - 2025-11-16 11:39:40 --> Language Class Initialized
INFO - 2025-11-16 11:39:40 --> Loader Class Initialized
INFO - 2025-11-16 11:39:40 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:39:40 --> Helper loaded: url_helper
INFO - 2025-11-16 11:39:40 --> Helper loaded: file_helper
INFO - 2025-11-16 11:39:40 --> Helper loaded: main_helper
INFO - 2025-11-16 11:39:40 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:39:40 --> Database Driver Class Initialized
INFO - 2025-11-16 11:39:40 --> Email Class Initialized
DEBUG - 2025-11-16 11:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:39:40 --> Controller Class Initialized
INFO - 2025-11-16 11:39:40 --> Config Class Initialized
INFO - 2025-11-16 11:39:40 --> Hooks Class Initialized
INFO - 2025-11-16 11:39:40 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:39:40 --> Utf8 Class Initialized
INFO - 2025-11-16 11:39:40 --> URI Class Initialized
INFO - 2025-11-16 11:39:40 --> Router Class Initialized
INFO - 2025-11-16 11:39:40 --> Output Class Initialized
INFO - 2025-11-16 11:39:40 --> Security Class Initialized
INFO - 2025-11-16 11:39:40 --> Input Class Initialized
INFO - 2025-11-16 11:39:40 --> Language Class Initialized
INFO - 2025-11-16 11:39:40 --> Loader Class Initialized
INFO - 2025-11-16 11:39:40 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:39:40 --> Helper loaded: url_helper
INFO - 2025-11-16 11:39:40 --> Helper loaded: file_helper
INFO - 2025-11-16 11:39:40 --> Helper loaded: main_helper
INFO - 2025-11-16 11:39:40 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:39:40 --> Database Driver Class Initialized
INFO - 2025-11-16 11:39:40 --> Email Class Initialized
DEBUG - 2025-11-16 11:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:39:40 --> Controller Class Initialized
INFO - 2025-11-16 11:39:40 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:39:40 --> Model "User_model" initialized
INFO - 2025-11-16 11:39:40 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:39:40 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-16 11:39:40 --> Final output sent to browser
INFO - 2025-11-16 11:39:40 --> Total execution time: 0.1043
INFO - 2025-11-16 11:39:50 --> Config Class Initialized
INFO - 2025-11-16 11:39:50 --> Hooks Class Initialized
INFO - 2025-11-16 11:39:50 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:39:50 --> Utf8 Class Initialized
INFO - 2025-11-16 11:39:50 --> URI Class Initialized
INFO - 2025-11-16 11:39:50 --> Router Class Initialized
INFO - 2025-11-16 11:39:50 --> Output Class Initialized
INFO - 2025-11-16 11:39:50 --> Security Class Initialized
INFO - 2025-11-16 11:39:50 --> Input Class Initialized
INFO - 2025-11-16 11:39:50 --> Language Class Initialized
INFO - 2025-11-16 11:39:50 --> Loader Class Initialized
INFO - 2025-11-16 11:39:50 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:39:50 --> Helper loaded: url_helper
INFO - 2025-11-16 11:39:50 --> Helper loaded: file_helper
INFO - 2025-11-16 11:39:50 --> Helper loaded: main_helper
INFO - 2025-11-16 11:39:50 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:39:50 --> Database Driver Class Initialized
INFO - 2025-11-16 11:39:50 --> Email Class Initialized
DEBUG - 2025-11-16 11:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:39:50 --> Controller Class Initialized
INFO - 2025-11-16 11:39:50 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:39:50 --> Model "User_model" initialized
INFO - 2025-11-16 11:39:50 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:39:50 --> Final output sent to browser
INFO - 2025-11-16 11:39:50 --> Total execution time: 0.2912
INFO - 2025-11-16 11:39:55 --> Config Class Initialized
INFO - 2025-11-16 11:39:55 --> Hooks Class Initialized
INFO - 2025-11-16 11:39:55 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:39:55 --> Utf8 Class Initialized
INFO - 2025-11-16 11:39:55 --> URI Class Initialized
INFO - 2025-11-16 11:39:55 --> Router Class Initialized
INFO - 2025-11-16 11:39:55 --> Output Class Initialized
INFO - 2025-11-16 11:39:55 --> Security Class Initialized
INFO - 2025-11-16 11:39:55 --> Input Class Initialized
INFO - 2025-11-16 11:39:55 --> Language Class Initialized
INFO - 2025-11-16 11:39:55 --> Loader Class Initialized
INFO - 2025-11-16 11:39:55 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:39:55 --> Helper loaded: url_helper
INFO - 2025-11-16 11:39:55 --> Helper loaded: file_helper
INFO - 2025-11-16 11:39:55 --> Helper loaded: main_helper
INFO - 2025-11-16 11:39:55 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:39:55 --> Database Driver Class Initialized
INFO - 2025-11-16 11:39:55 --> Email Class Initialized
DEBUG - 2025-11-16 11:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:39:55 --> Controller Class Initialized
INFO - 2025-11-16 11:39:55 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:39:55 --> Model "User_model" initialized
INFO - 2025-11-16 11:39:55 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:39:55 --> Final output sent to browser
INFO - 2025-11-16 11:39:55 --> Total execution time: 0.2678
INFO - 2025-11-16 11:39:57 --> Config Class Initialized
INFO - 2025-11-16 11:39:57 --> Hooks Class Initialized
INFO - 2025-11-16 11:39:57 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:39:57 --> Utf8 Class Initialized
INFO - 2025-11-16 11:39:57 --> URI Class Initialized
INFO - 2025-11-16 11:39:57 --> Router Class Initialized
INFO - 2025-11-16 11:39:57 --> Output Class Initialized
INFO - 2025-11-16 11:39:57 --> Security Class Initialized
INFO - 2025-11-16 11:39:57 --> Input Class Initialized
INFO - 2025-11-16 11:39:57 --> Language Class Initialized
INFO - 2025-11-16 11:39:57 --> Loader Class Initialized
INFO - 2025-11-16 11:39:57 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:39:57 --> Helper loaded: url_helper
INFO - 2025-11-16 11:39:57 --> Helper loaded: file_helper
INFO - 2025-11-16 11:39:57 --> Helper loaded: main_helper
INFO - 2025-11-16 11:39:57 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:39:57 --> Database Driver Class Initialized
INFO - 2025-11-16 11:39:57 --> Email Class Initialized
DEBUG - 2025-11-16 11:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:39:57 --> Controller Class Initialized
INFO - 2025-11-16 11:39:57 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:39:57 --> Model "User_model" initialized
INFO - 2025-11-16 11:39:57 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:39:57 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 11:39:57 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 11:39:57 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 11:39:57 --> File loaded: D:\laragon\www\acumena\application\views\dashboard.php
INFO - 2025-11-16 11:39:57 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 11:39:57 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 11:39:57 --> Final output sent to browser
INFO - 2025-11-16 11:39:57 --> Total execution time: 0.3744
INFO - 2025-11-16 11:39:57 --> Config Class Initialized
INFO - 2025-11-16 11:39:57 --> Hooks Class Initialized
INFO - 2025-11-16 11:39:57 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:39:57 --> Utf8 Class Initialized
INFO - 2025-11-16 11:39:57 --> URI Class Initialized
INFO - 2025-11-16 11:39:57 --> Router Class Initialized
INFO - 2025-11-16 11:39:57 --> Output Class Initialized
INFO - 2025-11-16 11:39:57 --> Security Class Initialized
INFO - 2025-11-16 11:39:57 --> Input Class Initialized
INFO - 2025-11-16 11:39:57 --> Language Class Initialized
INFO - 2025-11-16 11:39:57 --> Loader Class Initialized
INFO - 2025-11-16 11:39:57 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:39:57 --> Helper loaded: url_helper
INFO - 2025-11-16 11:39:57 --> Helper loaded: file_helper
INFO - 2025-11-16 11:39:57 --> Helper loaded: main_helper
INFO - 2025-11-16 11:39:57 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:39:57 --> Database Driver Class Initialized
INFO - 2025-11-16 11:39:57 --> Email Class Initialized
DEBUG - 2025-11-16 11:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:39:57 --> Controller Class Initialized
INFO - 2025-11-16 11:39:57 --> Model "User_model" initialized
INFO - 2025-11-16 11:39:57 --> Model "Project_model" initialized
INFO - 2025-11-16 11:39:57 --> Helper loaded: form_helper
INFO - 2025-11-16 11:39:57 --> Form Validation Class Initialized
INFO - 2025-11-16 11:39:57 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-16 11:39:57 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-16 11:39:58 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-16 11:39:58 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:39:58 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:39:58 --> Model "Topk_service_model" initialized
INFO - 2025-11-16 11:39:58 --> Final output sent to browser
INFO - 2025-11-16 11:39:58 --> Total execution time: 0.5601
INFO - 2025-11-16 11:40:07 --> Config Class Initialized
INFO - 2025-11-16 11:40:07 --> Hooks Class Initialized
INFO - 2025-11-16 11:40:07 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:40:07 --> Utf8 Class Initialized
INFO - 2025-11-16 11:40:07 --> URI Class Initialized
INFO - 2025-11-16 11:40:07 --> Router Class Initialized
INFO - 2025-11-16 11:40:08 --> Output Class Initialized
INFO - 2025-11-16 11:40:08 --> Security Class Initialized
INFO - 2025-11-16 11:40:08 --> Input Class Initialized
INFO - 2025-11-16 11:40:08 --> Language Class Initialized
INFO - 2025-11-16 11:40:08 --> Loader Class Initialized
INFO - 2025-11-16 11:40:08 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:40:08 --> Helper loaded: url_helper
INFO - 2025-11-16 11:40:08 --> Helper loaded: file_helper
INFO - 2025-11-16 11:40:08 --> Helper loaded: main_helper
INFO - 2025-11-16 11:40:08 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:40:08 --> Database Driver Class Initialized
INFO - 2025-11-16 11:40:08 --> Email Class Initialized
DEBUG - 2025-11-16 11:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:40:08 --> Controller Class Initialized
INFO - 2025-11-16 11:40:08 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:40:08 --> Model "User_model" initialized
INFO - 2025-11-16 11:40:08 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:40:08 --> Model "Project_model" initialized
INFO - 2025-11-16 11:40:08 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 11:40:08 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 11:40:08 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 11:40:08 --> File loaded: D:\laragon\www\acumena\application\views\projects/index.php
INFO - 2025-11-16 11:40:08 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 11:40:08 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 11:40:08 --> Final output sent to browser
INFO - 2025-11-16 11:40:08 --> Total execution time: 0.2363
INFO - 2025-11-16 11:40:08 --> Config Class Initialized
INFO - 2025-11-16 11:40:08 --> Hooks Class Initialized
INFO - 2025-11-16 11:40:08 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:40:08 --> Utf8 Class Initialized
INFO - 2025-11-16 11:40:08 --> URI Class Initialized
INFO - 2025-11-16 11:40:08 --> Router Class Initialized
INFO - 2025-11-16 11:40:08 --> Output Class Initialized
INFO - 2025-11-16 11:40:08 --> Security Class Initialized
INFO - 2025-11-16 11:40:08 --> Input Class Initialized
INFO - 2025-11-16 11:40:08 --> Language Class Initialized
INFO - 2025-11-16 11:40:08 --> Loader Class Initialized
INFO - 2025-11-16 11:40:08 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:40:08 --> Helper loaded: url_helper
INFO - 2025-11-16 11:40:08 --> Helper loaded: file_helper
INFO - 2025-11-16 11:40:08 --> Helper loaded: main_helper
INFO - 2025-11-16 11:40:08 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:40:08 --> Database Driver Class Initialized
INFO - 2025-11-16 11:40:08 --> Email Class Initialized
DEBUG - 2025-11-16 11:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:40:08 --> Controller Class Initialized
INFO - 2025-11-16 11:40:08 --> Model "User_model" initialized
INFO - 2025-11-16 11:40:08 --> Model "Project_model" initialized
INFO - 2025-11-16 11:40:08 --> Helper loaded: form_helper
INFO - 2025-11-16 11:40:08 --> Form Validation Class Initialized
INFO - 2025-11-16 11:40:08 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-16 11:40:08 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-16 11:40:08 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-16 11:40:08 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:40:08 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:40:08 --> Model "Topk_service_model" initialized
INFO - 2025-11-16 11:40:08 --> Final output sent to browser
INFO - 2025-11-16 11:40:08 --> Total execution time: 0.1028
INFO - 2025-11-16 11:40:16 --> Config Class Initialized
INFO - 2025-11-16 11:40:16 --> Hooks Class Initialized
INFO - 2025-11-16 11:40:16 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:40:16 --> Utf8 Class Initialized
INFO - 2025-11-16 11:40:16 --> URI Class Initialized
INFO - 2025-11-16 11:40:16 --> Router Class Initialized
INFO - 2025-11-16 11:40:16 --> Output Class Initialized
INFO - 2025-11-16 11:40:16 --> Security Class Initialized
INFO - 2025-11-16 11:40:16 --> Input Class Initialized
INFO - 2025-11-16 11:40:16 --> Language Class Initialized
INFO - 2025-11-16 11:40:16 --> Loader Class Initialized
INFO - 2025-11-16 11:40:16 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:40:16 --> Helper loaded: url_helper
INFO - 2025-11-16 11:40:16 --> Helper loaded: file_helper
INFO - 2025-11-16 11:40:16 --> Helper loaded: main_helper
INFO - 2025-11-16 11:40:16 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:40:16 --> Database Driver Class Initialized
INFO - 2025-11-16 11:40:16 --> Email Class Initialized
DEBUG - 2025-11-16 11:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:40:16 --> Controller Class Initialized
INFO - 2025-11-16 11:40:16 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:40:16 --> Model "User_model" initialized
INFO - 2025-11-16 11:40:16 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:40:16 --> Model "Project_model" initialized
INFO - 2025-11-16 11:40:16 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 11:40:16 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 11:40:16 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 11:40:16 --> File loaded: D:\laragon\www\acumena\application\views\projects/profile.php
INFO - 2025-11-16 11:40:16 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 11:40:16 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 11:40:16 --> Final output sent to browser
INFO - 2025-11-16 11:40:16 --> Total execution time: 0.1786
INFO - 2025-11-16 11:40:16 --> Config Class Initialized
INFO - 2025-11-16 11:40:16 --> Hooks Class Initialized
INFO - 2025-11-16 11:40:16 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:40:16 --> Utf8 Class Initialized
INFO - 2025-11-16 11:40:16 --> URI Class Initialized
INFO - 2025-11-16 11:40:16 --> Router Class Initialized
INFO - 2025-11-16 11:40:16 --> Output Class Initialized
INFO - 2025-11-16 11:40:16 --> Security Class Initialized
INFO - 2025-11-16 11:40:16 --> Input Class Initialized
INFO - 2025-11-16 11:40:16 --> Language Class Initialized
INFO - 2025-11-16 11:40:16 --> Loader Class Initialized
INFO - 2025-11-16 11:40:16 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:40:16 --> Helper loaded: url_helper
INFO - 2025-11-16 11:40:16 --> Helper loaded: file_helper
INFO - 2025-11-16 11:40:16 --> Helper loaded: main_helper
INFO - 2025-11-16 11:40:16 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:40:16 --> Database Driver Class Initialized
INFO - 2025-11-16 11:40:17 --> Email Class Initialized
DEBUG - 2025-11-16 11:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:40:17 --> Controller Class Initialized
INFO - 2025-11-16 11:40:17 --> Model "User_model" initialized
INFO - 2025-11-16 11:40:17 --> Model "Project_model" initialized
INFO - 2025-11-16 11:40:17 --> Helper loaded: form_helper
INFO - 2025-11-16 11:40:17 --> Form Validation Class Initialized
INFO - 2025-11-16 11:40:17 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-16 11:40:17 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-16 11:40:17 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-16 11:40:17 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:40:17 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:40:17 --> Model "Topk_service_model" initialized
INFO - 2025-11-16 11:40:17 --> Final output sent to browser
INFO - 2025-11-16 11:40:17 --> Total execution time: 0.0760
INFO - 2025-11-16 11:40:21 --> Config Class Initialized
INFO - 2025-11-16 11:40:21 --> Hooks Class Initialized
INFO - 2025-11-16 11:40:21 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:40:21 --> Utf8 Class Initialized
INFO - 2025-11-16 11:40:22 --> URI Class Initialized
INFO - 2025-11-16 11:40:22 --> Router Class Initialized
INFO - 2025-11-16 11:40:22 --> Output Class Initialized
INFO - 2025-11-16 11:40:22 --> Security Class Initialized
INFO - 2025-11-16 11:40:22 --> Input Class Initialized
INFO - 2025-11-16 11:40:22 --> Language Class Initialized
INFO - 2025-11-16 11:40:22 --> Loader Class Initialized
INFO - 2025-11-16 11:40:22 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:40:22 --> Helper loaded: url_helper
INFO - 2025-11-16 11:40:22 --> Helper loaded: file_helper
INFO - 2025-11-16 11:40:22 --> Helper loaded: main_helper
INFO - 2025-11-16 11:40:22 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:40:22 --> Database Driver Class Initialized
INFO - 2025-11-16 11:40:22 --> Email Class Initialized
DEBUG - 2025-11-16 11:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:40:22 --> Controller Class Initialized
INFO - 2025-11-16 11:40:22 --> Model "User_model" initialized
INFO - 2025-11-16 11:40:22 --> Model "Project_model" initialized
INFO - 2025-11-16 11:40:22 --> Helper loaded: form_helper
INFO - 2025-11-16 11:40:22 --> Form Validation Class Initialized
INFO - 2025-11-16 11:40:22 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-16 11:40:22 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-16 11:40:22 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-16 11:40:22 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:40:22 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:40:22 --> Model "Topk_service_model" initialized
INFO - 2025-11-16 11:40:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-11-16 11:40:22 --> Final output sent to browser
INFO - 2025-11-16 11:40:22 --> Total execution time: 0.1499
INFO - 2025-11-16 11:40:22 --> Config Class Initialized
INFO - 2025-11-16 11:40:22 --> Hooks Class Initialized
INFO - 2025-11-16 11:40:22 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:40:22 --> Utf8 Class Initialized
INFO - 2025-11-16 11:40:22 --> URI Class Initialized
INFO - 2025-11-16 11:40:22 --> Router Class Initialized
INFO - 2025-11-16 11:40:22 --> Output Class Initialized
INFO - 2025-11-16 11:40:22 --> Security Class Initialized
INFO - 2025-11-16 11:40:22 --> Input Class Initialized
INFO - 2025-11-16 11:40:22 --> Language Class Initialized
INFO - 2025-11-16 11:40:22 --> Loader Class Initialized
INFO - 2025-11-16 11:40:22 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:40:22 --> Helper loaded: url_helper
INFO - 2025-11-16 11:40:22 --> Helper loaded: file_helper
INFO - 2025-11-16 11:40:22 --> Helper loaded: main_helper
INFO - 2025-11-16 11:40:22 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:40:22 --> Database Driver Class Initialized
INFO - 2025-11-16 11:40:22 --> Email Class Initialized
DEBUG - 2025-11-16 11:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:40:22 --> Controller Class Initialized
INFO - 2025-11-16 11:40:22 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:40:22 --> Model "User_model" initialized
INFO - 2025-11-16 11:40:22 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:40:22 --> Model "Project_model" initialized
INFO - 2025-11-16 11:40:22 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 11:40:22 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 11:40:22 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 11:40:22 --> File loaded: D:\laragon\www\acumena\application\views\projects/swot.php
INFO - 2025-11-16 11:40:22 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 11:40:22 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 11:40:22 --> Final output sent to browser
INFO - 2025-11-16 11:40:22 --> Total execution time: 0.1555
INFO - 2025-11-16 11:40:22 --> Config Class Initialized
INFO - 2025-11-16 11:40:22 --> Hooks Class Initialized
INFO - 2025-11-16 11:40:22 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:40:22 --> Utf8 Class Initialized
INFO - 2025-11-16 11:40:22 --> URI Class Initialized
INFO - 2025-11-16 11:40:22 --> Router Class Initialized
INFO - 2025-11-16 11:40:22 --> Output Class Initialized
INFO - 2025-11-16 11:40:22 --> Security Class Initialized
INFO - 2025-11-16 11:40:22 --> Input Class Initialized
INFO - 2025-11-16 11:40:22 --> Language Class Initialized
INFO - 2025-11-16 11:40:22 --> Loader Class Initialized
INFO - 2025-11-16 11:40:22 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:40:22 --> Helper loaded: url_helper
INFO - 2025-11-16 11:40:22 --> Helper loaded: file_helper
INFO - 2025-11-16 11:40:22 --> Helper loaded: main_helper
INFO - 2025-11-16 11:40:22 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:40:22 --> Database Driver Class Initialized
INFO - 2025-11-16 11:40:22 --> Email Class Initialized
DEBUG - 2025-11-16 11:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:40:22 --> Controller Class Initialized
INFO - 2025-11-16 11:40:22 --> Model "User_model" initialized
INFO - 2025-11-16 11:40:22 --> Model "Project_model" initialized
INFO - 2025-11-16 11:40:22 --> Helper loaded: form_helper
INFO - 2025-11-16 11:40:22 --> Form Validation Class Initialized
INFO - 2025-11-16 11:40:22 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-16 11:40:22 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-16 11:40:22 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-16 11:40:22 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:40:22 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:40:22 --> Model "Topk_service_model" initialized
INFO - 2025-11-16 11:40:22 --> Final output sent to browser
INFO - 2025-11-16 11:40:22 --> Total execution time: 0.0676
INFO - 2025-11-16 11:40:24 --> Config Class Initialized
INFO - 2025-11-16 11:40:24 --> Hooks Class Initialized
INFO - 2025-11-16 11:40:24 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:40:24 --> Utf8 Class Initialized
INFO - 2025-11-16 11:40:24 --> URI Class Initialized
INFO - 2025-11-16 11:40:24 --> Router Class Initialized
INFO - 2025-11-16 11:40:24 --> Output Class Initialized
INFO - 2025-11-16 11:40:24 --> Security Class Initialized
INFO - 2025-11-16 11:40:24 --> Input Class Initialized
INFO - 2025-11-16 11:40:24 --> Language Class Initialized
INFO - 2025-11-16 11:40:24 --> Loader Class Initialized
INFO - 2025-11-16 11:40:24 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:40:24 --> Helper loaded: url_helper
INFO - 2025-11-16 11:40:24 --> Helper loaded: file_helper
INFO - 2025-11-16 11:40:24 --> Helper loaded: main_helper
INFO - 2025-11-16 11:40:24 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:40:24 --> Database Driver Class Initialized
INFO - 2025-11-16 11:40:24 --> Email Class Initialized
DEBUG - 2025-11-16 11:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:40:24 --> Controller Class Initialized
INFO - 2025-11-16 11:40:24 --> Model "User_model" initialized
INFO - 2025-11-16 11:40:24 --> Model "Project_model" initialized
INFO - 2025-11-16 11:40:24 --> Helper loaded: form_helper
INFO - 2025-11-16 11:40:24 --> Form Validation Class Initialized
INFO - 2025-11-16 11:40:24 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-16 11:40:24 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-16 11:40:24 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-16 11:40:24 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:40:24 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:40:24 --> Model "Topk_service_model" initialized
INFO - 2025-11-16 11:40:24 --> Final output sent to browser
INFO - 2025-11-16 11:40:24 --> Total execution time: 0.0902
INFO - 2025-11-16 11:40:24 --> Config Class Initialized
INFO - 2025-11-16 11:40:24 --> Hooks Class Initialized
INFO - 2025-11-16 11:40:24 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:40:24 --> Utf8 Class Initialized
INFO - 2025-11-16 11:40:24 --> URI Class Initialized
INFO - 2025-11-16 11:40:24 --> Router Class Initialized
INFO - 2025-11-16 11:40:24 --> Output Class Initialized
INFO - 2025-11-16 11:40:24 --> Security Class Initialized
INFO - 2025-11-16 11:40:24 --> Input Class Initialized
INFO - 2025-11-16 11:40:24 --> Language Class Initialized
INFO - 2025-11-16 11:40:24 --> Loader Class Initialized
INFO - 2025-11-16 11:40:24 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:40:24 --> Helper loaded: url_helper
INFO - 2025-11-16 11:40:24 --> Helper loaded: file_helper
INFO - 2025-11-16 11:40:24 --> Helper loaded: main_helper
INFO - 2025-11-16 11:40:24 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:40:24 --> Database Driver Class Initialized
INFO - 2025-11-16 11:40:24 --> Email Class Initialized
DEBUG - 2025-11-16 11:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:40:24 --> Controller Class Initialized
INFO - 2025-11-16 11:40:24 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:40:24 --> Model "User_model" initialized
INFO - 2025-11-16 11:40:24 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:40:24 --> Model "Project_model" initialized
INFO - 2025-11-16 11:40:24 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 11:40:24 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 11:40:24 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 11:40:24 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ife.php
INFO - 2025-11-16 11:40:24 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 11:40:24 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 11:40:24 --> Final output sent to browser
INFO - 2025-11-16 11:40:24 --> Total execution time: 0.1150
INFO - 2025-11-16 11:40:25 --> Config Class Initialized
INFO - 2025-11-16 11:40:25 --> Hooks Class Initialized
INFO - 2025-11-16 11:40:25 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:40:25 --> Utf8 Class Initialized
INFO - 2025-11-16 11:40:25 --> URI Class Initialized
INFO - 2025-11-16 11:40:25 --> Router Class Initialized
INFO - 2025-11-16 11:40:25 --> Output Class Initialized
INFO - 2025-11-16 11:40:25 --> Security Class Initialized
INFO - 2025-11-16 11:40:25 --> Input Class Initialized
INFO - 2025-11-16 11:40:25 --> Language Class Initialized
INFO - 2025-11-16 11:40:25 --> Loader Class Initialized
INFO - 2025-11-16 11:40:25 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:40:25 --> Helper loaded: url_helper
INFO - 2025-11-16 11:40:25 --> Helper loaded: file_helper
INFO - 2025-11-16 11:40:25 --> Helper loaded: main_helper
INFO - 2025-11-16 11:40:25 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:40:25 --> Database Driver Class Initialized
INFO - 2025-11-16 11:40:25 --> Email Class Initialized
DEBUG - 2025-11-16 11:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:40:25 --> Controller Class Initialized
INFO - 2025-11-16 11:40:25 --> Model "User_model" initialized
INFO - 2025-11-16 11:40:25 --> Model "Project_model" initialized
INFO - 2025-11-16 11:40:25 --> Helper loaded: form_helper
INFO - 2025-11-16 11:40:25 --> Form Validation Class Initialized
INFO - 2025-11-16 11:40:25 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-16 11:40:25 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-16 11:40:25 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-16 11:40:25 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:40:25 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:40:25 --> Model "Topk_service_model" initialized
INFO - 2025-11-16 11:40:25 --> Final output sent to browser
INFO - 2025-11-16 11:40:25 --> Total execution time: 0.0893
INFO - 2025-11-16 11:40:28 --> Config Class Initialized
INFO - 2025-11-16 11:40:28 --> Hooks Class Initialized
INFO - 2025-11-16 11:40:28 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:40:28 --> Utf8 Class Initialized
INFO - 2025-11-16 11:40:28 --> URI Class Initialized
INFO - 2025-11-16 11:40:28 --> Router Class Initialized
INFO - 2025-11-16 11:40:28 --> Output Class Initialized
INFO - 2025-11-16 11:40:28 --> Security Class Initialized
INFO - 2025-11-16 11:40:28 --> Input Class Initialized
INFO - 2025-11-16 11:40:28 --> Language Class Initialized
INFO - 2025-11-16 11:40:28 --> Loader Class Initialized
INFO - 2025-11-16 11:40:28 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:40:28 --> Helper loaded: url_helper
INFO - 2025-11-16 11:40:28 --> Helper loaded: file_helper
INFO - 2025-11-16 11:40:28 --> Helper loaded: main_helper
INFO - 2025-11-16 11:40:28 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:40:28 --> Database Driver Class Initialized
INFO - 2025-11-16 11:40:28 --> Email Class Initialized
DEBUG - 2025-11-16 11:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:40:28 --> Controller Class Initialized
INFO - 2025-11-16 11:40:28 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:40:28 --> Model "User_model" initialized
INFO - 2025-11-16 11:40:28 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:40:28 --> Model "Project_model" initialized
INFO - 2025-11-16 11:40:28 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 11:40:28 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 11:40:28 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 11:40:29 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ai.php
INFO - 2025-11-16 11:40:29 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 11:40:29 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 11:40:29 --> Final output sent to browser
INFO - 2025-11-16 11:40:29 --> Total execution time: 0.1807
INFO - 2025-11-16 11:40:29 --> Config Class Initialized
INFO - 2025-11-16 11:40:29 --> Hooks Class Initialized
INFO - 2025-11-16 11:40:29 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:40:29 --> Utf8 Class Initialized
INFO - 2025-11-16 11:40:29 --> URI Class Initialized
INFO - 2025-11-16 11:40:29 --> Router Class Initialized
INFO - 2025-11-16 11:40:29 --> Output Class Initialized
INFO - 2025-11-16 11:40:29 --> Security Class Initialized
INFO - 2025-11-16 11:40:29 --> Input Class Initialized
INFO - 2025-11-16 11:40:29 --> Language Class Initialized
INFO - 2025-11-16 11:40:29 --> Loader Class Initialized
INFO - 2025-11-16 11:40:29 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:40:29 --> Helper loaded: url_helper
INFO - 2025-11-16 11:40:29 --> Helper loaded: file_helper
INFO - 2025-11-16 11:40:29 --> Helper loaded: main_helper
INFO - 2025-11-16 11:40:29 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:40:29 --> Database Driver Class Initialized
INFO - 2025-11-16 11:40:29 --> Email Class Initialized
DEBUG - 2025-11-16 11:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:40:29 --> Controller Class Initialized
INFO - 2025-11-16 11:40:29 --> Model "User_model" initialized
INFO - 2025-11-16 11:40:29 --> Model "Project_model" initialized
INFO - 2025-11-16 11:40:29 --> Helper loaded: form_helper
INFO - 2025-11-16 11:40:29 --> Form Validation Class Initialized
INFO - 2025-11-16 11:40:29 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-16 11:40:29 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-16 11:40:29 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-16 11:40:29 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:40:29 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:40:29 --> Model "Topk_service_model" initialized
INFO - 2025-11-16 11:40:29 --> Final output sent to browser
INFO - 2025-11-16 11:40:29 --> Total execution time: 0.0796
INFO - 2025-11-16 11:40:29 --> Config Class Initialized
INFO - 2025-11-16 11:40:29 --> Config Class Initialized
INFO - 2025-11-16 11:40:29 --> Hooks Class Initialized
INFO - 2025-11-16 11:40:29 --> Hooks Class Initialized
INFO - 2025-11-16 11:40:29 --> Config Class Initialized
INFO - 2025-11-16 11:40:29 --> Hooks Class Initialized
INFO - 2025-11-16 11:40:29 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:40:29 --> Utf8 Class Initialized
INFO - 2025-11-16 11:40:29 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:40:29 --> Utf8 Class Initialized
INFO - 2025-11-16 11:40:29 --> URI Class Initialized
INFO - 2025-11-16 11:40:29 --> URI Class Initialized
INFO - 2025-11-16 11:40:29 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:40:29 --> Utf8 Class Initialized
INFO - 2025-11-16 11:40:29 --> Router Class Initialized
INFO - 2025-11-16 11:40:29 --> URI Class Initialized
INFO - 2025-11-16 11:40:29 --> Router Class Initialized
INFO - 2025-11-16 11:40:29 --> Output Class Initialized
INFO - 2025-11-16 11:40:29 --> Router Class Initialized
INFO - 2025-11-16 11:40:29 --> Output Class Initialized
INFO - 2025-11-16 11:40:29 --> Security Class Initialized
INFO - 2025-11-16 11:40:29 --> Input Class Initialized
INFO - 2025-11-16 11:40:29 --> Security Class Initialized
INFO - 2025-11-16 11:40:29 --> Output Class Initialized
INFO - 2025-11-16 11:40:29 --> Input Class Initialized
INFO - 2025-11-16 11:40:29 --> Language Class Initialized
INFO - 2025-11-16 11:40:29 --> Security Class Initialized
INFO - 2025-11-16 11:40:29 --> Language Class Initialized
INFO - 2025-11-16 11:40:29 --> Input Class Initialized
INFO - 2025-11-16 11:40:29 --> Language Class Initialized
INFO - 2025-11-16 11:40:29 --> Loader Class Initialized
INFO - 2025-11-16 11:40:29 --> Loader Class Initialized
INFO - 2025-11-16 11:40:29 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:40:29 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:40:29 --> Loader Class Initialized
INFO - 2025-11-16 11:40:29 --> Helper loaded: url_helper
INFO - 2025-11-16 11:40:29 --> Helper loaded: url_helper
INFO - 2025-11-16 11:40:29 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:40:29 --> Helper loaded: file_helper
INFO - 2025-11-16 11:40:29 --> Helper loaded: file_helper
INFO - 2025-11-16 11:40:29 --> Helper loaded: url_helper
INFO - 2025-11-16 11:40:29 --> Helper loaded: main_helper
INFO - 2025-11-16 11:40:29 --> Helper loaded: main_helper
INFO - 2025-11-16 11:40:29 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:40:29 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:40:29 --> Helper loaded: file_helper
INFO - 2025-11-16 11:40:29 --> Helper loaded: main_helper
INFO - 2025-11-16 11:40:29 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:40:29 --> Database Driver Class Initialized
INFO - 2025-11-16 11:40:29 --> Database Driver Class Initialized
INFO - 2025-11-16 11:40:29 --> Database Driver Class Initialized
INFO - 2025-11-16 11:40:29 --> Email Class Initialized
INFO - 2025-11-16 11:40:29 --> Email Class Initialized
DEBUG - 2025-11-16 11:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:40:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-11-16 11:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:40:29 --> Controller Class Initialized
INFO - 2025-11-16 11:40:29 --> Email Class Initialized
INFO - 2025-11-16 11:40:29 --> Model "User_model" initialized
INFO - 2025-11-16 11:40:29 --> Model "Project_model" initialized
INFO - 2025-11-16 11:40:29 --> Helper loaded: form_helper
INFO - 2025-11-16 11:40:29 --> Form Validation Class Initialized
DEBUG - 2025-11-16 11:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:40:29 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-16 11:40:29 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-16 11:40:29 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-16 11:40:29 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:40:29 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:40:29 --> Model "Topk_service_model" initialized
INFO - 2025-11-16 11:40:29 --> Final output sent to browser
INFO - 2025-11-16 11:40:29 --> Total execution time: 0.0723
INFO - 2025-11-16 11:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:40:29 --> Controller Class Initialized
INFO - 2025-11-16 11:40:29 --> Model "User_model" initialized
INFO - 2025-11-16 11:40:29 --> Model "Project_model" initialized
INFO - 2025-11-16 11:40:29 --> Helper loaded: form_helper
INFO - 2025-11-16 11:40:29 --> Form Validation Class Initialized
INFO - 2025-11-16 11:40:29 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-16 11:40:29 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-16 11:40:29 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-16 11:40:29 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:40:29 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:40:29 --> Model "Topk_service_model" initialized
INFO - 2025-11-16 11:40:29 --> Final output sent to browser
INFO - 2025-11-16 11:40:29 --> Total execution time: 0.0867
INFO - 2025-11-16 11:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:40:29 --> Controller Class Initialized
INFO - 2025-11-16 11:40:29 --> Model "User_model" initialized
INFO - 2025-11-16 11:40:29 --> Model "Project_model" initialized
INFO - 2025-11-16 11:40:29 --> Helper loaded: form_helper
INFO - 2025-11-16 11:40:29 --> Form Validation Class Initialized
INFO - 2025-11-16 11:40:29 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-16 11:40:29 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-16 11:40:29 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-16 11:40:29 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:40:29 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:40:29 --> Model "Topk_service_model" initialized
INFO - 2025-11-16 11:40:29 --> Final output sent to browser
INFO - 2025-11-16 11:40:29 --> Total execution time: 0.0997
INFO - 2025-11-16 11:40:30 --> Config Class Initialized
INFO - 2025-11-16 11:40:30 --> Hooks Class Initialized
INFO - 2025-11-16 11:40:30 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:40:30 --> Utf8 Class Initialized
INFO - 2025-11-16 11:40:30 --> URI Class Initialized
INFO - 2025-11-16 11:40:30 --> Router Class Initialized
INFO - 2025-11-16 11:40:30 --> Output Class Initialized
INFO - 2025-11-16 11:40:30 --> Security Class Initialized
INFO - 2025-11-16 11:40:30 --> Input Class Initialized
INFO - 2025-11-16 11:40:30 --> Language Class Initialized
INFO - 2025-11-16 11:40:30 --> Loader Class Initialized
INFO - 2025-11-16 11:40:30 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:40:30 --> Helper loaded: url_helper
INFO - 2025-11-16 11:40:30 --> Helper loaded: file_helper
INFO - 2025-11-16 11:40:30 --> Helper loaded: main_helper
INFO - 2025-11-16 11:40:30 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:40:30 --> Database Driver Class Initialized
INFO - 2025-11-16 11:40:30 --> Email Class Initialized
DEBUG - 2025-11-16 11:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:40:30 --> Controller Class Initialized
INFO - 2025-11-16 11:40:30 --> Model "User_model" initialized
INFO - 2025-11-16 11:40:30 --> Model "Project_model" initialized
INFO - 2025-11-16 11:40:30 --> Helper loaded: form_helper
INFO - 2025-11-16 11:40:30 --> Form Validation Class Initialized
INFO - 2025-11-16 11:40:30 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-16 11:40:30 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-16 11:40:30 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-16 11:40:30 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:40:30 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:40:30 --> Model "Topk_service_model" initialized
INFO - 2025-11-16 11:40:30 --> Final output sent to browser
INFO - 2025-11-16 11:40:30 --> Total execution time: 0.1256
INFO - 2025-11-16 11:40:44 --> Config Class Initialized
INFO - 2025-11-16 11:40:44 --> Hooks Class Initialized
INFO - 2025-11-16 11:40:44 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:40:44 --> Utf8 Class Initialized
INFO - 2025-11-16 11:40:44 --> URI Class Initialized
INFO - 2025-11-16 11:40:44 --> Router Class Initialized
INFO - 2025-11-16 11:40:44 --> Output Class Initialized
INFO - 2025-11-16 11:40:44 --> Security Class Initialized
INFO - 2025-11-16 11:40:44 --> Input Class Initialized
INFO - 2025-11-16 11:40:44 --> Language Class Initialized
INFO - 2025-11-16 11:40:44 --> Loader Class Initialized
INFO - 2025-11-16 11:40:44 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:40:44 --> Helper loaded: url_helper
INFO - 2025-11-16 11:40:44 --> Helper loaded: file_helper
INFO - 2025-11-16 11:40:44 --> Helper loaded: main_helper
INFO - 2025-11-16 11:40:44 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:40:44 --> Database Driver Class Initialized
INFO - 2025-11-16 11:40:44 --> Email Class Initialized
DEBUG - 2025-11-16 11:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:40:44 --> Controller Class Initialized
INFO - 2025-11-16 11:40:44 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:40:44 --> Model "User_model" initialized
INFO - 2025-11-16 11:40:44 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:40:44 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 11:40:44 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 11:40:44 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 11:40:44 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 11:40:44 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 11:40:44 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 11:40:44 --> Final output sent to browser
INFO - 2025-11-16 11:40:44 --> Total execution time: 0.1865
INFO - 2025-11-16 11:40:57 --> Config Class Initialized
INFO - 2025-11-16 11:40:57 --> Hooks Class Initialized
INFO - 2025-11-16 11:40:57 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:40:57 --> Utf8 Class Initialized
INFO - 2025-11-16 11:40:57 --> URI Class Initialized
INFO - 2025-11-16 11:40:57 --> Router Class Initialized
INFO - 2025-11-16 11:40:57 --> Output Class Initialized
INFO - 2025-11-16 11:40:57 --> Security Class Initialized
INFO - 2025-11-16 11:40:57 --> Input Class Initialized
INFO - 2025-11-16 11:40:57 --> Language Class Initialized
INFO - 2025-11-16 11:40:57 --> Loader Class Initialized
INFO - 2025-11-16 11:40:57 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:40:57 --> Helper loaded: url_helper
INFO - 2025-11-16 11:40:57 --> Helper loaded: file_helper
INFO - 2025-11-16 11:40:57 --> Helper loaded: main_helper
INFO - 2025-11-16 11:40:57 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:40:57 --> Database Driver Class Initialized
INFO - 2025-11-16 11:40:57 --> Email Class Initialized
DEBUG - 2025-11-16 11:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:40:57 --> Controller Class Initialized
INFO - 2025-11-16 11:40:57 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:40:57 --> Model "User_model" initialized
INFO - 2025-11-16 11:40:57 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:40:57 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 11:40:57 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 11:40:57 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 11:40:58 --> File loaded: D:\laragon\www\acumena\application\views\settings/index.php
INFO - 2025-11-16 11:40:58 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 11:40:58 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 11:40:58 --> Final output sent to browser
INFO - 2025-11-16 11:40:58 --> Total execution time: 0.2011
INFO - 2025-11-16 11:40:58 --> Config Class Initialized
INFO - 2025-11-16 11:40:58 --> Hooks Class Initialized
INFO - 2025-11-16 11:40:58 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:40:58 --> Utf8 Class Initialized
INFO - 2025-11-16 11:40:58 --> URI Class Initialized
INFO - 2025-11-16 11:40:58 --> Router Class Initialized
INFO - 2025-11-16 11:40:58 --> Output Class Initialized
INFO - 2025-11-16 11:40:58 --> Security Class Initialized
INFO - 2025-11-16 11:40:58 --> Input Class Initialized
INFO - 2025-11-16 11:40:58 --> Language Class Initialized
INFO - 2025-11-16 11:40:58 --> Loader Class Initialized
INFO - 2025-11-16 11:40:58 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:40:58 --> Helper loaded: url_helper
INFO - 2025-11-16 11:40:58 --> Helper loaded: file_helper
INFO - 2025-11-16 11:40:58 --> Helper loaded: main_helper
INFO - 2025-11-16 11:40:58 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:40:58 --> Database Driver Class Initialized
INFO - 2025-11-16 11:40:58 --> Email Class Initialized
DEBUG - 2025-11-16 11:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:40:58 --> Controller Class Initialized
INFO - 2025-11-16 11:40:58 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:40:58 --> Model "User_model" initialized
INFO - 2025-11-16 11:40:58 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:40:58 --> Final output sent to browser
INFO - 2025-11-16 11:40:58 --> Total execution time: 0.1258
INFO - 2025-11-16 11:40:59 --> Config Class Initialized
INFO - 2025-11-16 11:40:59 --> Hooks Class Initialized
INFO - 2025-11-16 11:40:59 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:40:59 --> Utf8 Class Initialized
INFO - 2025-11-16 11:40:59 --> URI Class Initialized
INFO - 2025-11-16 11:40:59 --> Router Class Initialized
INFO - 2025-11-16 11:40:59 --> Output Class Initialized
INFO - 2025-11-16 11:40:59 --> Security Class Initialized
INFO - 2025-11-16 11:40:59 --> Input Class Initialized
INFO - 2025-11-16 11:40:59 --> Language Class Initialized
INFO - 2025-11-16 11:40:59 --> Loader Class Initialized
INFO - 2025-11-16 11:40:59 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:40:59 --> Helper loaded: url_helper
INFO - 2025-11-16 11:40:59 --> Helper loaded: file_helper
INFO - 2025-11-16 11:40:59 --> Helper loaded: main_helper
INFO - 2025-11-16 11:40:59 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:40:59 --> Database Driver Class Initialized
INFO - 2025-11-16 11:40:59 --> Email Class Initialized
DEBUG - 2025-11-16 11:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:40:59 --> Controller Class Initialized
INFO - 2025-11-16 11:40:59 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:40:59 --> Model "User_model" initialized
INFO - 2025-11-16 11:40:59 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:40:59 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 11:40:59 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 11:40:59 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 11:40:59 --> File loaded: D:\laragon\www\acumena\application\views\dashboard.php
INFO - 2025-11-16 11:40:59 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 11:40:59 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 11:40:59 --> Final output sent to browser
INFO - 2025-11-16 11:40:59 --> Total execution time: 0.0835
INFO - 2025-11-16 11:40:59 --> Config Class Initialized
INFO - 2025-11-16 11:40:59 --> Hooks Class Initialized
INFO - 2025-11-16 11:40:59 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:40:59 --> Utf8 Class Initialized
INFO - 2025-11-16 11:40:59 --> URI Class Initialized
INFO - 2025-11-16 11:40:59 --> Router Class Initialized
INFO - 2025-11-16 11:40:59 --> Output Class Initialized
INFO - 2025-11-16 11:40:59 --> Security Class Initialized
INFO - 2025-11-16 11:40:59 --> Input Class Initialized
INFO - 2025-11-16 11:40:59 --> Language Class Initialized
INFO - 2025-11-16 11:40:59 --> Loader Class Initialized
INFO - 2025-11-16 11:40:59 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:40:59 --> Helper loaded: url_helper
INFO - 2025-11-16 11:40:59 --> Helper loaded: file_helper
INFO - 2025-11-16 11:40:59 --> Helper loaded: main_helper
INFO - 2025-11-16 11:40:59 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:40:59 --> Database Driver Class Initialized
INFO - 2025-11-16 11:40:59 --> Email Class Initialized
DEBUG - 2025-11-16 11:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:40:59 --> Controller Class Initialized
INFO - 2025-11-16 11:40:59 --> Model "User_model" initialized
INFO - 2025-11-16 11:40:59 --> Model "Project_model" initialized
INFO - 2025-11-16 11:40:59 --> Helper loaded: form_helper
INFO - 2025-11-16 11:40:59 --> Form Validation Class Initialized
INFO - 2025-11-16 11:40:59 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-16 11:40:59 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-16 11:40:59 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-16 11:40:59 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:40:59 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:40:59 --> Model "Topk_service_model" initialized
INFO - 2025-11-16 11:40:59 --> Final output sent to browser
INFO - 2025-11-16 11:40:59 --> Total execution time: 0.0687
INFO - 2025-11-16 11:41:01 --> Config Class Initialized
INFO - 2025-11-16 11:41:01 --> Hooks Class Initialized
INFO - 2025-11-16 11:41:01 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:41:01 --> Utf8 Class Initialized
INFO - 2025-11-16 11:41:01 --> URI Class Initialized
INFO - 2025-11-16 11:41:01 --> Router Class Initialized
INFO - 2025-11-16 11:41:01 --> Output Class Initialized
INFO - 2025-11-16 11:41:01 --> Security Class Initialized
INFO - 2025-11-16 11:41:01 --> Input Class Initialized
INFO - 2025-11-16 11:41:01 --> Language Class Initialized
INFO - 2025-11-16 11:41:01 --> Loader Class Initialized
INFO - 2025-11-16 11:41:01 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:41:01 --> Helper loaded: url_helper
INFO - 2025-11-16 11:41:01 --> Helper loaded: file_helper
INFO - 2025-11-16 11:41:01 --> Helper loaded: main_helper
INFO - 2025-11-16 11:41:01 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:41:01 --> Database Driver Class Initialized
INFO - 2025-11-16 11:41:01 --> Email Class Initialized
DEBUG - 2025-11-16 11:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:41:01 --> Controller Class Initialized
INFO - 2025-11-16 11:41:01 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:41:01 --> Model "User_model" initialized
INFO - 2025-11-16 11:41:01 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:41:01 --> Model "Project_model" initialized
INFO - 2025-11-16 11:41:01 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 11:41:01 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 11:41:01 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 11:41:01 --> File loaded: D:\laragon\www\acumena\application\views\projects/index.php
INFO - 2025-11-16 11:41:01 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 11:41:01 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 11:41:01 --> Final output sent to browser
INFO - 2025-11-16 11:41:01 --> Total execution time: 0.0821
INFO - 2025-11-16 11:41:01 --> Config Class Initialized
INFO - 2025-11-16 11:41:01 --> Hooks Class Initialized
INFO - 2025-11-16 11:41:01 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:41:01 --> Utf8 Class Initialized
INFO - 2025-11-16 11:41:01 --> URI Class Initialized
INFO - 2025-11-16 11:41:01 --> Router Class Initialized
INFO - 2025-11-16 11:41:01 --> Output Class Initialized
INFO - 2025-11-16 11:41:01 --> Security Class Initialized
INFO - 2025-11-16 11:41:01 --> Input Class Initialized
INFO - 2025-11-16 11:41:01 --> Language Class Initialized
INFO - 2025-11-16 11:41:01 --> Loader Class Initialized
INFO - 2025-11-16 11:41:01 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:41:01 --> Helper loaded: url_helper
INFO - 2025-11-16 11:41:01 --> Helper loaded: file_helper
INFO - 2025-11-16 11:41:01 --> Helper loaded: main_helper
INFO - 2025-11-16 11:41:01 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:41:01 --> Database Driver Class Initialized
INFO - 2025-11-16 11:41:01 --> Email Class Initialized
DEBUG - 2025-11-16 11:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:41:01 --> Controller Class Initialized
INFO - 2025-11-16 11:41:02 --> Model "User_model" initialized
INFO - 2025-11-16 11:41:02 --> Model "Project_model" initialized
INFO - 2025-11-16 11:41:02 --> Helper loaded: form_helper
INFO - 2025-11-16 11:41:02 --> Form Validation Class Initialized
INFO - 2025-11-16 11:41:02 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-16 11:41:02 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-16 11:41:02 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-16 11:41:02 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:41:02 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:41:02 --> Model "Topk_service_model" initialized
INFO - 2025-11-16 11:41:02 --> Final output sent to browser
INFO - 2025-11-16 11:41:02 --> Total execution time: 0.0859
INFO - 2025-11-16 11:41:03 --> Config Class Initialized
INFO - 2025-11-16 11:41:03 --> Hooks Class Initialized
INFO - 2025-11-16 11:41:03 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:41:03 --> Utf8 Class Initialized
INFO - 2025-11-16 11:41:03 --> URI Class Initialized
INFO - 2025-11-16 11:41:03 --> Router Class Initialized
INFO - 2025-11-16 11:41:03 --> Output Class Initialized
INFO - 2025-11-16 11:41:03 --> Security Class Initialized
INFO - 2025-11-16 11:41:03 --> Input Class Initialized
INFO - 2025-11-16 11:41:03 --> Language Class Initialized
INFO - 2025-11-16 11:41:03 --> Loader Class Initialized
INFO - 2025-11-16 11:41:03 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:41:03 --> Helper loaded: url_helper
INFO - 2025-11-16 11:41:03 --> Helper loaded: file_helper
INFO - 2025-11-16 11:41:03 --> Helper loaded: main_helper
INFO - 2025-11-16 11:41:03 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:41:03 --> Database Driver Class Initialized
INFO - 2025-11-16 11:41:04 --> Email Class Initialized
DEBUG - 2025-11-16 11:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:41:04 --> Controller Class Initialized
INFO - 2025-11-16 11:41:04 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:41:04 --> Model "User_model" initialized
INFO - 2025-11-16 11:41:04 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:41:04 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 11:41:04 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 11:41:04 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 11:41:04 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 11:41:04 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 11:41:04 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 11:41:04 --> Final output sent to browser
INFO - 2025-11-16 11:41:04 --> Total execution time: 0.0849
INFO - 2025-11-16 11:41:17 --> Config Class Initialized
INFO - 2025-11-16 11:41:17 --> Hooks Class Initialized
INFO - 2025-11-16 11:41:17 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:41:17 --> Utf8 Class Initialized
INFO - 2025-11-16 11:41:17 --> URI Class Initialized
INFO - 2025-11-16 11:41:17 --> Router Class Initialized
INFO - 2025-11-16 11:41:17 --> Output Class Initialized
INFO - 2025-11-16 11:41:17 --> Security Class Initialized
INFO - 2025-11-16 11:41:17 --> Input Class Initialized
INFO - 2025-11-16 11:41:17 --> Language Class Initialized
INFO - 2025-11-16 11:41:17 --> Loader Class Initialized
INFO - 2025-11-16 11:41:17 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:41:17 --> Helper loaded: url_helper
INFO - 2025-11-16 11:41:17 --> Helper loaded: file_helper
INFO - 2025-11-16 11:41:17 --> Helper loaded: main_helper
INFO - 2025-11-16 11:41:17 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:41:17 --> Database Driver Class Initialized
INFO - 2025-11-16 11:41:17 --> Email Class Initialized
DEBUG - 2025-11-16 11:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:41:17 --> Controller Class Initialized
INFO - 2025-11-16 11:41:17 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:41:17 --> Model "User_model" initialized
INFO - 2025-11-16 11:41:17 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:41:17 --> Model "Project_model" initialized
INFO - 2025-11-16 11:41:17 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 11:41:17 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 11:41:17 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 11:41:17 --> File loaded: D:\laragon\www\acumena\application\views\projects/index.php
INFO - 2025-11-16 11:41:17 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 11:41:17 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 11:41:17 --> Final output sent to browser
INFO - 2025-11-16 11:41:17 --> Total execution time: 0.0972
INFO - 2025-11-16 11:41:17 --> Config Class Initialized
INFO - 2025-11-16 11:41:17 --> Hooks Class Initialized
INFO - 2025-11-16 11:41:17 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:41:17 --> Utf8 Class Initialized
INFO - 2025-11-16 11:41:17 --> URI Class Initialized
INFO - 2025-11-16 11:41:17 --> Router Class Initialized
INFO - 2025-11-16 11:41:17 --> Output Class Initialized
INFO - 2025-11-16 11:41:17 --> Security Class Initialized
INFO - 2025-11-16 11:41:17 --> Input Class Initialized
INFO - 2025-11-16 11:41:17 --> Language Class Initialized
INFO - 2025-11-16 11:41:17 --> Loader Class Initialized
INFO - 2025-11-16 11:41:17 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:41:17 --> Helper loaded: url_helper
INFO - 2025-11-16 11:41:17 --> Helper loaded: file_helper
INFO - 2025-11-16 11:41:17 --> Helper loaded: main_helper
INFO - 2025-11-16 11:41:17 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:41:17 --> Database Driver Class Initialized
INFO - 2025-11-16 11:41:17 --> Email Class Initialized
DEBUG - 2025-11-16 11:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:41:17 --> Controller Class Initialized
INFO - 2025-11-16 11:41:17 --> Model "User_model" initialized
INFO - 2025-11-16 11:41:17 --> Model "Project_model" initialized
INFO - 2025-11-16 11:41:17 --> Helper loaded: form_helper
INFO - 2025-11-16 11:41:17 --> Form Validation Class Initialized
INFO - 2025-11-16 11:41:17 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-16 11:41:17 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-16 11:41:17 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-16 11:41:17 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:41:17 --> Model "Swot_model" initialized
INFO - 2025-11-16 11:41:17 --> Model "Topk_service_model" initialized
INFO - 2025-11-16 11:41:17 --> Final output sent to browser
INFO - 2025-11-16 11:41:17 --> Total execution time: 0.0826
INFO - 2025-11-16 11:41:18 --> Config Class Initialized
INFO - 2025-11-16 11:41:18 --> Hooks Class Initialized
INFO - 2025-11-16 11:41:18 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:41:18 --> Utf8 Class Initialized
INFO - 2025-11-16 11:41:18 --> URI Class Initialized
INFO - 2025-11-16 11:41:18 --> Router Class Initialized
INFO - 2025-11-16 11:41:18 --> Output Class Initialized
INFO - 2025-11-16 11:41:18 --> Security Class Initialized
INFO - 2025-11-16 11:41:18 --> Input Class Initialized
INFO - 2025-11-16 11:41:18 --> Language Class Initialized
INFO - 2025-11-16 11:41:18 --> Loader Class Initialized
INFO - 2025-11-16 11:41:18 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:41:18 --> Helper loaded: url_helper
INFO - 2025-11-16 11:41:18 --> Helper loaded: file_helper
INFO - 2025-11-16 11:41:18 --> Helper loaded: main_helper
INFO - 2025-11-16 11:41:18 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:41:18 --> Database Driver Class Initialized
INFO - 2025-11-16 11:41:18 --> Email Class Initialized
DEBUG - 2025-11-16 11:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:41:18 --> Controller Class Initialized
INFO - 2025-11-16 11:41:18 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:41:18 --> Model "User_model" initialized
INFO - 2025-11-16 11:41:18 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:41:18 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 11:41:18 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 11:41:18 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 11:41:18 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 11:41:18 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 11:41:18 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 11:41:18 --> Final output sent to browser
INFO - 2025-11-16 11:41:18 --> Total execution time: 0.0627
INFO - 2025-11-16 11:41:20 --> Config Class Initialized
INFO - 2025-11-16 11:41:20 --> Hooks Class Initialized
INFO - 2025-11-16 11:41:20 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:41:20 --> Utf8 Class Initialized
INFO - 2025-11-16 11:41:20 --> URI Class Initialized
INFO - 2025-11-16 11:41:20 --> Router Class Initialized
INFO - 2025-11-16 11:41:20 --> Output Class Initialized
INFO - 2025-11-16 11:41:20 --> Security Class Initialized
INFO - 2025-11-16 11:41:20 --> Input Class Initialized
INFO - 2025-11-16 11:41:20 --> Language Class Initialized
INFO - 2025-11-16 11:41:20 --> Loader Class Initialized
INFO - 2025-11-16 11:41:20 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:41:20 --> Helper loaded: url_helper
INFO - 2025-11-16 11:41:20 --> Helper loaded: file_helper
INFO - 2025-11-16 11:41:20 --> Helper loaded: main_helper
INFO - 2025-11-16 11:41:20 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:41:20 --> Database Driver Class Initialized
INFO - 2025-11-16 11:41:20 --> Email Class Initialized
DEBUG - 2025-11-16 11:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:41:20 --> Controller Class Initialized
INFO - 2025-11-16 11:41:20 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:41:20 --> Model "User_model" initialized
INFO - 2025-11-16 11:41:20 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:41:20 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 11:41:20 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 11:41:20 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 11:41:20 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 11:41:20 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 11:41:20 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 11:41:20 --> Final output sent to browser
INFO - 2025-11-16 11:41:20 --> Total execution time: 0.0747
INFO - 2025-11-16 11:41:23 --> Config Class Initialized
INFO - 2025-11-16 11:41:23 --> Hooks Class Initialized
INFO - 2025-11-16 11:41:23 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:41:23 --> Utf8 Class Initialized
INFO - 2025-11-16 11:41:23 --> URI Class Initialized
INFO - 2025-11-16 11:41:23 --> Router Class Initialized
INFO - 2025-11-16 11:41:23 --> Output Class Initialized
INFO - 2025-11-16 11:41:23 --> Security Class Initialized
INFO - 2025-11-16 11:41:23 --> Input Class Initialized
INFO - 2025-11-16 11:41:23 --> Language Class Initialized
INFO - 2025-11-16 11:41:23 --> Loader Class Initialized
INFO - 2025-11-16 11:41:23 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:41:23 --> Helper loaded: url_helper
INFO - 2025-11-16 11:41:23 --> Helper loaded: file_helper
INFO - 2025-11-16 11:41:23 --> Helper loaded: main_helper
INFO - 2025-11-16 11:41:23 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:41:23 --> Database Driver Class Initialized
INFO - 2025-11-16 11:41:23 --> Email Class Initialized
DEBUG - 2025-11-16 11:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:41:23 --> Controller Class Initialized
INFO - 2025-11-16 11:41:23 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:41:23 --> Model "User_model" initialized
INFO - 2025-11-16 11:41:23 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:41:23 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 11:41:23 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 11:41:23 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 11:41:23 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 11:41:23 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 11:41:23 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 11:41:23 --> Final output sent to browser
INFO - 2025-11-16 11:41:23 --> Total execution time: 0.0826
INFO - 2025-11-16 11:41:25 --> Config Class Initialized
INFO - 2025-11-16 11:41:25 --> Hooks Class Initialized
INFO - 2025-11-16 11:41:25 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:41:25 --> Utf8 Class Initialized
INFO - 2025-11-16 11:41:25 --> URI Class Initialized
INFO - 2025-11-16 11:41:25 --> Router Class Initialized
INFO - 2025-11-16 11:41:25 --> Output Class Initialized
INFO - 2025-11-16 11:41:25 --> Security Class Initialized
INFO - 2025-11-16 11:41:25 --> Input Class Initialized
INFO - 2025-11-16 11:41:25 --> Language Class Initialized
INFO - 2025-11-16 11:41:25 --> Loader Class Initialized
INFO - 2025-11-16 11:41:25 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:41:25 --> Helper loaded: url_helper
INFO - 2025-11-16 11:41:25 --> Helper loaded: file_helper
INFO - 2025-11-16 11:41:25 --> Helper loaded: main_helper
INFO - 2025-11-16 11:41:25 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:41:25 --> Database Driver Class Initialized
INFO - 2025-11-16 11:41:25 --> Email Class Initialized
DEBUG - 2025-11-16 11:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:41:25 --> Controller Class Initialized
INFO - 2025-11-16 11:41:25 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:41:25 --> Model "User_model" initialized
INFO - 2025-11-16 11:41:25 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:41:25 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 11:41:25 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 11:41:25 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 11:41:25 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 11:41:25 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 11:41:25 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 11:41:25 --> Final output sent to browser
INFO - 2025-11-16 11:41:25 --> Total execution time: 0.0978
INFO - 2025-11-16 11:41:28 --> Config Class Initialized
INFO - 2025-11-16 11:41:28 --> Hooks Class Initialized
INFO - 2025-11-16 11:41:28 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:41:28 --> Utf8 Class Initialized
INFO - 2025-11-16 11:41:28 --> URI Class Initialized
INFO - 2025-11-16 11:41:28 --> Router Class Initialized
INFO - 2025-11-16 11:41:28 --> Output Class Initialized
INFO - 2025-11-16 11:41:28 --> Security Class Initialized
INFO - 2025-11-16 11:41:28 --> Input Class Initialized
INFO - 2025-11-16 11:41:28 --> Language Class Initialized
INFO - 2025-11-16 11:41:28 --> Loader Class Initialized
INFO - 2025-11-16 11:41:28 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:41:28 --> Helper loaded: url_helper
INFO - 2025-11-16 11:41:28 --> Helper loaded: file_helper
INFO - 2025-11-16 11:41:28 --> Helper loaded: main_helper
INFO - 2025-11-16 11:41:28 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:41:28 --> Database Driver Class Initialized
INFO - 2025-11-16 11:41:28 --> Email Class Initialized
DEBUG - 2025-11-16 11:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:41:28 --> Controller Class Initialized
INFO - 2025-11-16 11:41:28 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:41:28 --> Model "User_model" initialized
INFO - 2025-11-16 11:41:28 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:41:28 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 11:41:28 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 11:41:28 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 11:41:28 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 11:41:28 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 11:41:28 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 11:41:28 --> Final output sent to browser
INFO - 2025-11-16 11:41:28 --> Total execution time: 0.0794
INFO - 2025-11-16 11:45:23 --> Config Class Initialized
INFO - 2025-11-16 11:45:23 --> Hooks Class Initialized
INFO - 2025-11-16 11:45:23 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:45:23 --> Utf8 Class Initialized
INFO - 2025-11-16 11:45:23 --> URI Class Initialized
INFO - 2025-11-16 11:45:23 --> Router Class Initialized
INFO - 2025-11-16 11:45:23 --> Output Class Initialized
INFO - 2025-11-16 11:45:23 --> Security Class Initialized
INFO - 2025-11-16 11:45:23 --> Input Class Initialized
INFO - 2025-11-16 11:45:23 --> Language Class Initialized
INFO - 2025-11-16 11:45:23 --> Loader Class Initialized
INFO - 2025-11-16 11:45:23 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:45:23 --> Helper loaded: url_helper
INFO - 2025-11-16 11:45:23 --> Helper loaded: file_helper
INFO - 2025-11-16 11:45:23 --> Helper loaded: main_helper
INFO - 2025-11-16 11:45:23 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:45:23 --> Database Driver Class Initialized
INFO - 2025-11-16 11:45:23 --> Email Class Initialized
DEBUG - 2025-11-16 11:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:45:23 --> Controller Class Initialized
INFO - 2025-11-16 11:45:23 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:45:23 --> Model "User_model" initialized
INFO - 2025-11-16 11:45:23 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:45:23 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 11:45:23 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 11:45:23 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 11:45:23 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 11:45:23 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 11:45:23 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 11:45:23 --> Final output sent to browser
INFO - 2025-11-16 11:45:23 --> Total execution time: 0.0831
INFO - 2025-11-16 11:47:46 --> Config Class Initialized
INFO - 2025-11-16 11:47:46 --> Hooks Class Initialized
INFO - 2025-11-16 11:47:46 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:47:46 --> Utf8 Class Initialized
INFO - 2025-11-16 11:47:46 --> URI Class Initialized
INFO - 2025-11-16 11:47:46 --> Router Class Initialized
INFO - 2025-11-16 11:47:46 --> Output Class Initialized
INFO - 2025-11-16 11:47:46 --> Security Class Initialized
INFO - 2025-11-16 11:47:46 --> Input Class Initialized
INFO - 2025-11-16 11:47:46 --> Language Class Initialized
INFO - 2025-11-16 11:47:46 --> Loader Class Initialized
INFO - 2025-11-16 11:47:46 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:47:46 --> Helper loaded: url_helper
INFO - 2025-11-16 11:47:46 --> Helper loaded: file_helper
INFO - 2025-11-16 11:47:46 --> Helper loaded: main_helper
INFO - 2025-11-16 11:47:46 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:47:46 --> Database Driver Class Initialized
INFO - 2025-11-16 11:47:46 --> Email Class Initialized
DEBUG - 2025-11-16 11:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:47:46 --> Controller Class Initialized
INFO - 2025-11-16 11:47:46 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:47:46 --> Model "User_model" initialized
INFO - 2025-11-16 11:47:46 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:47:46 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-16 11:47:46 --> Final output sent to browser
INFO - 2025-11-16 11:47:46 --> Total execution time: 0.1194
INFO - 2025-11-16 11:47:55 --> Config Class Initialized
INFO - 2025-11-16 11:47:55 --> Hooks Class Initialized
INFO - 2025-11-16 11:47:55 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:47:55 --> Utf8 Class Initialized
INFO - 2025-11-16 11:47:55 --> URI Class Initialized
INFO - 2025-11-16 11:47:55 --> Router Class Initialized
INFO - 2025-11-16 11:47:55 --> Output Class Initialized
INFO - 2025-11-16 11:47:55 --> Security Class Initialized
INFO - 2025-11-16 11:47:55 --> Input Class Initialized
INFO - 2025-11-16 11:47:55 --> Language Class Initialized
INFO - 2025-11-16 11:47:55 --> Loader Class Initialized
INFO - 2025-11-16 11:47:55 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:47:55 --> Helper loaded: url_helper
INFO - 2025-11-16 11:47:55 --> Helper loaded: file_helper
INFO - 2025-11-16 11:47:55 --> Helper loaded: main_helper
INFO - 2025-11-16 11:47:55 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:47:55 --> Database Driver Class Initialized
INFO - 2025-11-16 11:47:55 --> Email Class Initialized
DEBUG - 2025-11-16 11:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:47:55 --> Controller Class Initialized
INFO - 2025-11-16 11:47:55 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:47:55 --> Model "User_model" initialized
INFO - 2025-11-16 11:47:55 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:47:55 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 11:47:55 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 11:47:55 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 11:47:55 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 11:47:55 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 11:47:55 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 11:47:55 --> Final output sent to browser
INFO - 2025-11-16 11:47:55 --> Total execution time: 0.0726
INFO - 2025-11-16 11:49:46 --> Config Class Initialized
INFO - 2025-11-16 11:49:46 --> Hooks Class Initialized
INFO - 2025-11-16 11:49:46 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:49:46 --> Utf8 Class Initialized
INFO - 2025-11-16 11:49:46 --> URI Class Initialized
INFO - 2025-11-16 11:49:46 --> Router Class Initialized
INFO - 2025-11-16 11:49:46 --> Output Class Initialized
INFO - 2025-11-16 11:49:46 --> Security Class Initialized
INFO - 2025-11-16 11:49:46 --> Input Class Initialized
INFO - 2025-11-16 11:49:46 --> Language Class Initialized
INFO - 2025-11-16 11:49:46 --> Loader Class Initialized
INFO - 2025-11-16 11:49:46 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:49:46 --> Helper loaded: url_helper
INFO - 2025-11-16 11:49:46 --> Helper loaded: file_helper
INFO - 2025-11-16 11:49:46 --> Helper loaded: main_helper
INFO - 2025-11-16 11:49:46 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:49:46 --> Database Driver Class Initialized
INFO - 2025-11-16 11:49:46 --> Email Class Initialized
DEBUG - 2025-11-16 11:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:49:46 --> Controller Class Initialized
INFO - 2025-11-16 11:49:46 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:49:46 --> Model "User_model" initialized
INFO - 2025-11-16 11:49:46 --> Model "Auth_model" initialized
ERROR - 2025-11-16 11:49:46 --> Severity: error --> Exception: Call to undefined method Auth_model::get_user() D:\laragon\www\acumena\application\controllers\Subscription.php 24
INFO - 2025-11-16 11:50:15 --> Config Class Initialized
INFO - 2025-11-16 11:50:15 --> Hooks Class Initialized
INFO - 2025-11-16 11:50:15 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:50:15 --> Utf8 Class Initialized
INFO - 2025-11-16 11:50:15 --> URI Class Initialized
INFO - 2025-11-16 11:50:15 --> Router Class Initialized
INFO - 2025-11-16 11:50:15 --> Output Class Initialized
INFO - 2025-11-16 11:50:15 --> Security Class Initialized
INFO - 2025-11-16 11:50:15 --> Input Class Initialized
INFO - 2025-11-16 11:50:15 --> Language Class Initialized
INFO - 2025-11-16 11:50:15 --> Loader Class Initialized
INFO - 2025-11-16 11:50:15 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:50:15 --> Helper loaded: url_helper
INFO - 2025-11-16 11:50:15 --> Helper loaded: file_helper
INFO - 2025-11-16 11:50:15 --> Helper loaded: main_helper
INFO - 2025-11-16 11:50:15 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:50:15 --> Database Driver Class Initialized
INFO - 2025-11-16 11:50:15 --> Email Class Initialized
DEBUG - 2025-11-16 11:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:50:15 --> Controller Class Initialized
INFO - 2025-11-16 11:50:15 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:50:15 --> Model "User_model" initialized
INFO - 2025-11-16 11:50:15 --> Model "Auth_model" initialized
ERROR - 2025-11-16 11:50:15 --> Severity: error --> Exception: Call to undefined method Auth_model::get_user() D:\laragon\www\acumena\application\controllers\Subscription.php 24
INFO - 2025-11-16 11:50:47 --> Config Class Initialized
INFO - 2025-11-16 11:50:47 --> Hooks Class Initialized
INFO - 2025-11-16 11:50:47 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:50:47 --> Utf8 Class Initialized
INFO - 2025-11-16 11:50:47 --> URI Class Initialized
INFO - 2025-11-16 11:50:47 --> Router Class Initialized
INFO - 2025-11-16 11:50:47 --> Output Class Initialized
INFO - 2025-11-16 11:50:47 --> Security Class Initialized
INFO - 2025-11-16 11:50:47 --> Input Class Initialized
INFO - 2025-11-16 11:50:47 --> Language Class Initialized
INFO - 2025-11-16 11:50:47 --> Loader Class Initialized
INFO - 2025-11-16 11:50:47 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:50:47 --> Helper loaded: url_helper
INFO - 2025-11-16 11:50:47 --> Helper loaded: file_helper
INFO - 2025-11-16 11:50:47 --> Helper loaded: main_helper
INFO - 2025-11-16 11:50:47 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:50:47 --> Database Driver Class Initialized
INFO - 2025-11-16 11:50:47 --> Email Class Initialized
DEBUG - 2025-11-16 11:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:50:47 --> Controller Class Initialized
INFO - 2025-11-16 11:50:47 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:50:47 --> Model "User_model" initialized
INFO - 2025-11-16 11:50:47 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:50:47 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 11:50:47 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 11:50:47 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 11:50:47 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 11:50:47 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 11:50:47 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 11:50:47 --> Final output sent to browser
INFO - 2025-11-16 11:50:47 --> Total execution time: 0.0912
INFO - 2025-11-16 11:51:58 --> Config Class Initialized
INFO - 2025-11-16 11:51:58 --> Hooks Class Initialized
INFO - 2025-11-16 11:51:58 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:51:58 --> Utf8 Class Initialized
INFO - 2025-11-16 11:51:58 --> URI Class Initialized
INFO - 2025-11-16 11:51:58 --> Router Class Initialized
INFO - 2025-11-16 11:51:58 --> Output Class Initialized
INFO - 2025-11-16 11:51:58 --> Security Class Initialized
INFO - 2025-11-16 11:51:58 --> Input Class Initialized
INFO - 2025-11-16 11:51:58 --> Language Class Initialized
INFO - 2025-11-16 11:51:58 --> Loader Class Initialized
INFO - 2025-11-16 11:51:58 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:51:58 --> Helper loaded: url_helper
INFO - 2025-11-16 11:51:58 --> Helper loaded: file_helper
INFO - 2025-11-16 11:51:58 --> Helper loaded: main_helper
INFO - 2025-11-16 11:51:58 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:51:58 --> Database Driver Class Initialized
INFO - 2025-11-16 11:51:58 --> Email Class Initialized
DEBUG - 2025-11-16 11:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:51:58 --> Controller Class Initialized
INFO - 2025-11-16 11:51:58 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:51:58 --> Model "User_model" initialized
INFO - 2025-11-16 11:51:58 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:51:58 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 11:51:58 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 11:51:58 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 11:51:58 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 11:51:58 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 11:51:58 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 11:51:58 --> Final output sent to browser
INFO - 2025-11-16 11:51:58 --> Total execution time: 0.0816
INFO - 2025-11-16 11:52:57 --> Config Class Initialized
INFO - 2025-11-16 11:52:57 --> Hooks Class Initialized
INFO - 2025-11-16 11:52:57 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:52:57 --> Utf8 Class Initialized
INFO - 2025-11-16 11:52:57 --> URI Class Initialized
INFO - 2025-11-16 11:52:57 --> Router Class Initialized
INFO - 2025-11-16 11:52:57 --> Output Class Initialized
INFO - 2025-11-16 11:52:57 --> Security Class Initialized
INFO - 2025-11-16 11:52:57 --> Input Class Initialized
INFO - 2025-11-16 11:52:57 --> Language Class Initialized
INFO - 2025-11-16 11:52:57 --> Loader Class Initialized
INFO - 2025-11-16 11:52:57 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:52:57 --> Helper loaded: url_helper
INFO - 2025-11-16 11:52:57 --> Helper loaded: file_helper
INFO - 2025-11-16 11:52:57 --> Helper loaded: main_helper
INFO - 2025-11-16 11:52:57 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:52:57 --> Database Driver Class Initialized
INFO - 2025-11-16 11:52:57 --> Email Class Initialized
DEBUG - 2025-11-16 11:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:52:57 --> Controller Class Initialized
INFO - 2025-11-16 11:52:57 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:52:57 --> Model "User_model" initialized
INFO - 2025-11-16 11:52:57 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:52:57 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 11:52:57 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 11:52:57 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 11:52:57 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 11:52:57 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 11:52:57 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 11:52:57 --> Final output sent to browser
INFO - 2025-11-16 11:52:57 --> Total execution time: 0.0821
INFO - 2025-11-16 11:53:58 --> Config Class Initialized
INFO - 2025-11-16 11:53:58 --> Hooks Class Initialized
INFO - 2025-11-16 11:53:58 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:53:58 --> Utf8 Class Initialized
INFO - 2025-11-16 11:53:58 --> URI Class Initialized
INFO - 2025-11-16 11:53:58 --> Router Class Initialized
INFO - 2025-11-16 11:53:58 --> Output Class Initialized
INFO - 2025-11-16 11:53:58 --> Security Class Initialized
INFO - 2025-11-16 11:53:58 --> Input Class Initialized
INFO - 2025-11-16 11:53:58 --> Language Class Initialized
INFO - 2025-11-16 11:53:58 --> Loader Class Initialized
INFO - 2025-11-16 11:53:58 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:53:58 --> Helper loaded: url_helper
INFO - 2025-11-16 11:53:58 --> Helper loaded: file_helper
INFO - 2025-11-16 11:53:58 --> Helper loaded: main_helper
INFO - 2025-11-16 11:53:58 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:53:58 --> Database Driver Class Initialized
INFO - 2025-11-16 11:53:58 --> Email Class Initialized
DEBUG - 2025-11-16 11:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:53:58 --> Controller Class Initialized
INFO - 2025-11-16 11:53:58 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:53:58 --> Model "User_model" initialized
INFO - 2025-11-16 11:53:58 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:53:58 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 11:53:58 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 11:53:58 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 11:53:58 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 11:53:58 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 11:53:58 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 11:53:58 --> Final output sent to browser
INFO - 2025-11-16 11:53:58 --> Total execution time: 0.0834
INFO - 2025-11-16 11:57:59 --> Config Class Initialized
INFO - 2025-11-16 11:57:59 --> Hooks Class Initialized
INFO - 2025-11-16 11:57:59 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:57:59 --> Utf8 Class Initialized
INFO - 2025-11-16 11:57:59 --> URI Class Initialized
INFO - 2025-11-16 11:57:59 --> Router Class Initialized
INFO - 2025-11-16 11:57:59 --> Output Class Initialized
INFO - 2025-11-16 11:57:59 --> Security Class Initialized
INFO - 2025-11-16 11:57:59 --> Input Class Initialized
INFO - 2025-11-16 11:57:59 --> Language Class Initialized
INFO - 2025-11-16 11:57:59 --> Loader Class Initialized
INFO - 2025-11-16 11:57:59 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:57:59 --> Helper loaded: url_helper
INFO - 2025-11-16 11:57:59 --> Helper loaded: file_helper
INFO - 2025-11-16 11:57:59 --> Helper loaded: main_helper
INFO - 2025-11-16 11:57:59 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:57:59 --> Database Driver Class Initialized
INFO - 2025-11-16 11:57:59 --> Email Class Initialized
DEBUG - 2025-11-16 11:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:57:59 --> Controller Class Initialized
INFO - 2025-11-16 11:57:59 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:57:59 --> Model "User_model" initialized
INFO - 2025-11-16 11:57:59 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:57:59 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 11:57:59 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 11:57:59 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 11:57:59 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 11:57:59 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 11:57:59 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 11:57:59 --> Final output sent to browser
INFO - 2025-11-16 11:57:59 --> Total execution time: 0.0727
INFO - 2025-11-16 11:58:38 --> Config Class Initialized
INFO - 2025-11-16 11:58:38 --> Hooks Class Initialized
INFO - 2025-11-16 11:58:38 --> UTF-8 Support Enabled
INFO - 2025-11-16 11:58:38 --> Utf8 Class Initialized
INFO - 2025-11-16 11:58:38 --> URI Class Initialized
INFO - 2025-11-16 11:58:38 --> Router Class Initialized
INFO - 2025-11-16 11:58:38 --> Output Class Initialized
INFO - 2025-11-16 11:58:38 --> Security Class Initialized
INFO - 2025-11-16 11:58:38 --> Input Class Initialized
INFO - 2025-11-16 11:58:38 --> Language Class Initialized
INFO - 2025-11-16 11:58:38 --> Loader Class Initialized
INFO - 2025-11-16 11:58:38 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 11:58:38 --> Helper loaded: url_helper
INFO - 2025-11-16 11:58:38 --> Helper loaded: file_helper
INFO - 2025-11-16 11:58:38 --> Helper loaded: main_helper
INFO - 2025-11-16 11:58:38 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 11:58:38 --> Database Driver Class Initialized
INFO - 2025-11-16 11:58:38 --> Email Class Initialized
DEBUG - 2025-11-16 11:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 11:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 11:58:38 --> Controller Class Initialized
INFO - 2025-11-16 11:58:38 --> Model "Subscription_model" initialized
INFO - 2025-11-16 11:58:38 --> Model "User_model" initialized
INFO - 2025-11-16 11:58:38 --> Model "Auth_model" initialized
INFO - 2025-11-16 11:58:38 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 11:58:38 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 11:58:38 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 11:58:38 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 11:58:38 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 11:58:38 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 11:58:38 --> Final output sent to browser
INFO - 2025-11-16 11:58:38 --> Total execution time: 0.1018
INFO - 2025-11-16 12:01:44 --> Config Class Initialized
INFO - 2025-11-16 12:01:44 --> Hooks Class Initialized
INFO - 2025-11-16 12:01:44 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:01:44 --> Utf8 Class Initialized
INFO - 2025-11-16 12:01:44 --> URI Class Initialized
INFO - 2025-11-16 12:01:44 --> Router Class Initialized
INFO - 2025-11-16 12:01:44 --> Output Class Initialized
INFO - 2025-11-16 12:01:44 --> Security Class Initialized
INFO - 2025-11-16 12:01:44 --> Input Class Initialized
INFO - 2025-11-16 12:01:44 --> Language Class Initialized
INFO - 2025-11-16 12:01:44 --> Loader Class Initialized
INFO - 2025-11-16 12:01:44 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:01:44 --> Helper loaded: url_helper
INFO - 2025-11-16 12:01:44 --> Helper loaded: file_helper
INFO - 2025-11-16 12:01:44 --> Helper loaded: main_helper
INFO - 2025-11-16 12:01:44 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:01:44 --> Database Driver Class Initialized
INFO - 2025-11-16 12:01:44 --> Email Class Initialized
DEBUG - 2025-11-16 12:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:01:44 --> Controller Class Initialized
INFO - 2025-11-16 12:01:44 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:01:44 --> Model "User_model" initialized
INFO - 2025-11-16 12:01:44 --> Model "Auth_model" initialized
INFO - 2025-11-16 12:01:44 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-16 12:01:44 --> Final output sent to browser
INFO - 2025-11-16 12:01:44 --> Total execution time: 0.0821
INFO - 2025-11-16 12:01:45 --> Config Class Initialized
INFO - 2025-11-16 12:01:45 --> Hooks Class Initialized
INFO - 2025-11-16 12:01:45 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:01:45 --> Utf8 Class Initialized
INFO - 2025-11-16 12:01:45 --> URI Class Initialized
INFO - 2025-11-16 12:01:45 --> Router Class Initialized
INFO - 2025-11-16 12:01:45 --> Output Class Initialized
INFO - 2025-11-16 12:01:45 --> Security Class Initialized
INFO - 2025-11-16 12:01:45 --> Input Class Initialized
INFO - 2025-11-16 12:01:45 --> Language Class Initialized
INFO - 2025-11-16 12:01:45 --> Loader Class Initialized
INFO - 2025-11-16 12:01:45 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:01:45 --> Helper loaded: url_helper
INFO - 2025-11-16 12:01:45 --> Helper loaded: file_helper
INFO - 2025-11-16 12:01:45 --> Helper loaded: main_helper
INFO - 2025-11-16 12:01:45 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:01:45 --> Database Driver Class Initialized
INFO - 2025-11-16 12:01:45 --> Email Class Initialized
DEBUG - 2025-11-16 12:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:01:45 --> Controller Class Initialized
INFO - 2025-11-16 12:01:45 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:01:45 --> Model "User_model" initialized
INFO - 2025-11-16 12:01:45 --> Model "Auth_model" initialized
ERROR - 2025-11-16 12:01:45 --> Query error: Unknown column 'user_id' in 'where clause' - Invalid query: SELECT *
FROM `subscriptions`
WHERE `user_id` = '1'
INFO - 2025-11-16 12:01:46 --> Language file loaded: language/english/db_lang.php
INFO - 2025-11-16 12:01:46 --> Config Class Initialized
INFO - 2025-11-16 12:01:46 --> Hooks Class Initialized
INFO - 2025-11-16 12:01:46 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:01:46 --> Utf8 Class Initialized
INFO - 2025-11-16 12:01:46 --> URI Class Initialized
INFO - 2025-11-16 12:01:46 --> Router Class Initialized
INFO - 2025-11-16 12:01:46 --> Output Class Initialized
INFO - 2025-11-16 12:01:46 --> Security Class Initialized
INFO - 2025-11-16 12:01:46 --> Input Class Initialized
INFO - 2025-11-16 12:01:46 --> Language Class Initialized
INFO - 2025-11-16 12:01:46 --> Loader Class Initialized
INFO - 2025-11-16 12:01:46 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:01:46 --> Helper loaded: url_helper
INFO - 2025-11-16 12:01:46 --> Helper loaded: file_helper
INFO - 2025-11-16 12:01:46 --> Helper loaded: main_helper
INFO - 2025-11-16 12:01:46 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:01:46 --> Database Driver Class Initialized
INFO - 2025-11-16 12:01:46 --> Email Class Initialized
DEBUG - 2025-11-16 12:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:01:46 --> Controller Class Initialized
INFO - 2025-11-16 12:01:46 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:01:46 --> Model "User_model" initialized
INFO - 2025-11-16 12:01:46 --> Model "Auth_model" initialized
ERROR - 2025-11-16 12:01:46 --> Query error: Unknown column 'user_id' in 'where clause' - Invalid query: SELECT *
FROM `subscriptions`
WHERE `user_id` = '1'
INFO - 2025-11-16 12:01:46 --> Language file loaded: language/english/db_lang.php
INFO - 2025-11-16 12:05:19 --> Config Class Initialized
INFO - 2025-11-16 12:05:19 --> Hooks Class Initialized
INFO - 2025-11-16 12:05:19 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:05:19 --> Utf8 Class Initialized
INFO - 2025-11-16 12:05:19 --> URI Class Initialized
INFO - 2025-11-16 12:05:19 --> Router Class Initialized
INFO - 2025-11-16 12:05:19 --> Output Class Initialized
INFO - 2025-11-16 12:05:19 --> Security Class Initialized
INFO - 2025-11-16 12:05:19 --> Input Class Initialized
INFO - 2025-11-16 12:05:19 --> Language Class Initialized
INFO - 2025-11-16 12:05:19 --> Loader Class Initialized
INFO - 2025-11-16 12:05:19 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:05:19 --> Helper loaded: url_helper
INFO - 2025-11-16 12:05:19 --> Helper loaded: file_helper
INFO - 2025-11-16 12:05:20 --> Helper loaded: main_helper
INFO - 2025-11-16 12:05:20 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:05:20 --> Database Driver Class Initialized
INFO - 2025-11-16 12:05:20 --> Email Class Initialized
DEBUG - 2025-11-16 12:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:05:20 --> Controller Class Initialized
INFO - 2025-11-16 12:05:20 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:05:20 --> Model "User_model" initialized
INFO - 2025-11-16 12:05:20 --> Model "Auth_model" initialized
INFO - 2025-11-16 12:05:20 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 12:05:20 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 12:05:20 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 12:05:20 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 12:05:20 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 12:05:20 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 12:05:20 --> Final output sent to browser
INFO - 2025-11-16 12:05:20 --> Total execution time: 0.0996
INFO - 2025-11-16 12:05:50 --> Config Class Initialized
INFO - 2025-11-16 12:05:50 --> Hooks Class Initialized
INFO - 2025-11-16 12:05:50 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:05:50 --> Utf8 Class Initialized
INFO - 2025-11-16 12:05:50 --> URI Class Initialized
INFO - 2025-11-16 12:05:50 --> Router Class Initialized
INFO - 2025-11-16 12:05:50 --> Output Class Initialized
INFO - 2025-11-16 12:05:50 --> Security Class Initialized
INFO - 2025-11-16 12:05:50 --> Input Class Initialized
INFO - 2025-11-16 12:05:50 --> Language Class Initialized
INFO - 2025-11-16 12:05:50 --> Loader Class Initialized
INFO - 2025-11-16 12:05:50 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:05:50 --> Helper loaded: url_helper
INFO - 2025-11-16 12:05:50 --> Helper loaded: file_helper
INFO - 2025-11-16 12:05:50 --> Helper loaded: main_helper
INFO - 2025-11-16 12:05:50 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:05:50 --> Database Driver Class Initialized
INFO - 2025-11-16 12:05:50 --> Email Class Initialized
DEBUG - 2025-11-16 12:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:05:50 --> Controller Class Initialized
INFO - 2025-11-16 12:05:50 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:05:50 --> Model "User_model" initialized
INFO - 2025-11-16 12:05:50 --> Model "Auth_model" initialized
INFO - 2025-11-16 12:05:50 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 12:05:50 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 12:05:50 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 12:05:50 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 12:05:50 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 12:05:50 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 12:05:50 --> Final output sent to browser
INFO - 2025-11-16 12:05:50 --> Total execution time: 0.0789
INFO - 2025-11-16 12:07:41 --> Config Class Initialized
INFO - 2025-11-16 12:07:41 --> Hooks Class Initialized
INFO - 2025-11-16 12:07:41 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:07:41 --> Utf8 Class Initialized
INFO - 2025-11-16 12:07:41 --> URI Class Initialized
INFO - 2025-11-16 12:07:41 --> Router Class Initialized
INFO - 2025-11-16 12:07:41 --> Output Class Initialized
INFO - 2025-11-16 12:07:41 --> Security Class Initialized
INFO - 2025-11-16 12:07:41 --> Input Class Initialized
INFO - 2025-11-16 12:07:41 --> Language Class Initialized
INFO - 2025-11-16 12:07:41 --> Loader Class Initialized
INFO - 2025-11-16 12:07:41 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:07:41 --> Helper loaded: url_helper
INFO - 2025-11-16 12:07:41 --> Helper loaded: file_helper
INFO - 2025-11-16 12:07:41 --> Helper loaded: main_helper
INFO - 2025-11-16 12:07:41 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:07:41 --> Database Driver Class Initialized
INFO - 2025-11-16 12:07:41 --> Email Class Initialized
DEBUG - 2025-11-16 12:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:07:41 --> Controller Class Initialized
INFO - 2025-11-16 12:07:41 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:07:41 --> Model "User_model" initialized
INFO - 2025-11-16 12:07:41 --> Model "Auth_model" initialized
INFO - 2025-11-16 12:07:41 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 12:07:41 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 12:07:41 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
ERROR - 2025-11-16 12:07:41 --> Severity: Warning --> Undefined property: stdClass::$start_date D:\laragon\www\acumena\application\views\subscriptions\index.php 29
ERROR - 2025-11-16 12:07:41 --> Severity: Warning --> Undefined property: stdClass::$end_date D:\laragon\www\acumena\application\views\subscriptions\index.php 29
INFO - 2025-11-16 12:07:41 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 12:07:41 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 12:07:41 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 12:07:41 --> Final output sent to browser
INFO - 2025-11-16 12:07:41 --> Total execution time: 0.1699
INFO - 2025-11-16 12:08:04 --> Config Class Initialized
INFO - 2025-11-16 12:08:04 --> Hooks Class Initialized
INFO - 2025-11-16 12:08:04 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:08:04 --> Utf8 Class Initialized
INFO - 2025-11-16 12:08:04 --> URI Class Initialized
INFO - 2025-11-16 12:08:04 --> Router Class Initialized
INFO - 2025-11-16 12:08:04 --> Output Class Initialized
INFO - 2025-11-16 12:08:04 --> Security Class Initialized
INFO - 2025-11-16 12:08:04 --> Input Class Initialized
INFO - 2025-11-16 12:08:04 --> Language Class Initialized
INFO - 2025-11-16 12:08:04 --> Loader Class Initialized
INFO - 2025-11-16 12:08:04 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:08:04 --> Helper loaded: url_helper
INFO - 2025-11-16 12:08:04 --> Helper loaded: file_helper
INFO - 2025-11-16 12:08:04 --> Helper loaded: main_helper
INFO - 2025-11-16 12:08:04 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:08:04 --> Database Driver Class Initialized
INFO - 2025-11-16 12:08:04 --> Email Class Initialized
DEBUG - 2025-11-16 12:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:08:04 --> Controller Class Initialized
INFO - 2025-11-16 12:08:04 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:08:04 --> Model "User_model" initialized
INFO - 2025-11-16 12:08:04 --> Model "Auth_model" initialized
INFO - 2025-11-16 12:08:04 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 12:08:04 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 12:08:04 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
ERROR - 2025-11-16 12:08:04 --> Severity: Warning --> Undefined property: stdClass::$date_start D:\laragon\www\acumena\application\views\subscriptions\index.php 29
ERROR - 2025-11-16 12:08:04 --> Severity: Warning --> Undefined property: stdClass::$date_end D:\laragon\www\acumena\application\views\subscriptions\index.php 29
INFO - 2025-11-16 12:08:04 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 12:08:04 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 12:08:04 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 12:08:04 --> Final output sent to browser
INFO - 2025-11-16 12:08:04 --> Total execution time: 0.1206
INFO - 2025-11-16 12:08:05 --> Config Class Initialized
INFO - 2025-11-16 12:08:05 --> Hooks Class Initialized
INFO - 2025-11-16 12:08:05 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:08:05 --> Utf8 Class Initialized
INFO - 2025-11-16 12:08:05 --> URI Class Initialized
INFO - 2025-11-16 12:08:05 --> Router Class Initialized
INFO - 2025-11-16 12:08:05 --> Output Class Initialized
INFO - 2025-11-16 12:08:05 --> Security Class Initialized
INFO - 2025-11-16 12:08:05 --> Input Class Initialized
INFO - 2025-11-16 12:08:05 --> Language Class Initialized
INFO - 2025-11-16 12:08:05 --> Loader Class Initialized
INFO - 2025-11-16 12:08:05 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:08:05 --> Helper loaded: url_helper
INFO - 2025-11-16 12:08:05 --> Helper loaded: file_helper
INFO - 2025-11-16 12:08:05 --> Helper loaded: main_helper
INFO - 2025-11-16 12:08:05 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:08:05 --> Database Driver Class Initialized
INFO - 2025-11-16 12:08:05 --> Email Class Initialized
DEBUG - 2025-11-16 12:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:08:05 --> Controller Class Initialized
INFO - 2025-11-16 12:08:05 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:08:05 --> Model "User_model" initialized
INFO - 2025-11-16 12:08:05 --> Model "Auth_model" initialized
INFO - 2025-11-16 12:08:05 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 12:08:05 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 12:08:05 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
ERROR - 2025-11-16 12:08:05 --> Severity: Warning --> Undefined property: stdClass::$date_start D:\laragon\www\acumena\application\views\subscriptions\index.php 29
ERROR - 2025-11-16 12:08:05 --> Severity: Warning --> Undefined property: stdClass::$date_end D:\laragon\www\acumena\application\views\subscriptions\index.php 29
INFO - 2025-11-16 12:08:05 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 12:08:05 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 12:08:05 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 12:08:05 --> Final output sent to browser
INFO - 2025-11-16 12:08:05 --> Total execution time: 0.1184
INFO - 2025-11-16 12:33:29 --> Config Class Initialized
INFO - 2025-11-16 12:33:29 --> Hooks Class Initialized
INFO - 2025-11-16 12:33:29 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:33:29 --> Utf8 Class Initialized
INFO - 2025-11-16 12:33:29 --> URI Class Initialized
INFO - 2025-11-16 12:33:29 --> Router Class Initialized
INFO - 2025-11-16 12:33:29 --> Output Class Initialized
INFO - 2025-11-16 12:33:30 --> Security Class Initialized
INFO - 2025-11-16 12:33:30 --> Input Class Initialized
INFO - 2025-11-16 12:33:30 --> Language Class Initialized
INFO - 2025-11-16 12:33:30 --> Loader Class Initialized
INFO - 2025-11-16 12:33:30 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:33:30 --> Helper loaded: url_helper
INFO - 2025-11-16 12:33:30 --> Helper loaded: file_helper
INFO - 2025-11-16 12:33:30 --> Helper loaded: main_helper
INFO - 2025-11-16 12:33:30 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:33:30 --> Database Driver Class Initialized
INFO - 2025-11-16 12:33:31 --> Email Class Initialized
DEBUG - 2025-11-16 12:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:33:31 --> Controller Class Initialized
INFO - 2025-11-16 12:33:31 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:33:31 --> Model "User_model" initialized
INFO - 2025-11-16 12:33:31 --> Model "Auth_model" initialized
INFO - 2025-11-16 12:33:31 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 12:33:31 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 12:33:31 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
ERROR - 2025-11-16 12:33:31 --> Severity: Warning --> Undefined property: stdClass::$date_start D:\laragon\www\acumena\application\views\subscriptions\index.php 29
ERROR - 2025-11-16 12:33:31 --> Severity: Warning --> Undefined property: stdClass::$date_end D:\laragon\www\acumena\application\views\subscriptions\index.php 29
INFO - 2025-11-16 12:33:31 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 12:33:31 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 12:33:31 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 12:33:31 --> Final output sent to browser
INFO - 2025-11-16 12:33:31 --> Total execution time: 2.7135
INFO - 2025-11-16 12:40:27 --> Config Class Initialized
INFO - 2025-11-16 12:40:27 --> Hooks Class Initialized
INFO - 2025-11-16 12:40:27 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:40:27 --> Utf8 Class Initialized
INFO - 2025-11-16 12:40:27 --> URI Class Initialized
INFO - 2025-11-16 12:40:27 --> Router Class Initialized
INFO - 2025-11-16 12:40:27 --> Output Class Initialized
INFO - 2025-11-16 12:40:27 --> Security Class Initialized
INFO - 2025-11-16 12:40:27 --> Input Class Initialized
INFO - 2025-11-16 12:40:27 --> Language Class Initialized
INFO - 2025-11-16 12:40:27 --> Loader Class Initialized
INFO - 2025-11-16 12:40:27 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:40:27 --> Helper loaded: url_helper
INFO - 2025-11-16 12:40:27 --> Helper loaded: file_helper
INFO - 2025-11-16 12:40:27 --> Helper loaded: main_helper
INFO - 2025-11-16 12:40:27 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:40:27 --> Database Driver Class Initialized
INFO - 2025-11-16 12:40:27 --> Email Class Initialized
DEBUG - 2025-11-16 12:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:40:27 --> Controller Class Initialized
INFO - 2025-11-16 12:40:27 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:40:27 --> Model "User_model" initialized
INFO - 2025-11-16 12:40:27 --> Model "Auth_model" initialized
INFO - 2025-11-16 12:40:27 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 12:40:27 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 12:40:27 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
ERROR - 2025-11-16 12:40:27 --> Severity: Warning --> Undefined property: stdClass::$date_start D:\laragon\www\acumena\application\views\subscriptions\index.php 29
ERROR - 2025-11-16 12:40:27 --> Severity: Warning --> Undefined property: stdClass::$date_end D:\laragon\www\acumena\application\views\subscriptions\index.php 29
INFO - 2025-11-16 12:40:27 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 12:40:27 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 12:40:27 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 12:40:27 --> Final output sent to browser
INFO - 2025-11-16 12:40:27 --> Total execution time: 0.1043
INFO - 2025-11-16 12:42:10 --> Config Class Initialized
INFO - 2025-11-16 12:42:10 --> Hooks Class Initialized
INFO - 2025-11-16 12:42:10 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:42:10 --> Utf8 Class Initialized
INFO - 2025-11-16 12:42:10 --> URI Class Initialized
INFO - 2025-11-16 12:42:10 --> Router Class Initialized
INFO - 2025-11-16 12:42:10 --> Output Class Initialized
INFO - 2025-11-16 12:42:10 --> Security Class Initialized
INFO - 2025-11-16 12:42:10 --> Input Class Initialized
INFO - 2025-11-16 12:42:10 --> Language Class Initialized
INFO - 2025-11-16 12:42:10 --> Loader Class Initialized
INFO - 2025-11-16 12:42:10 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:42:10 --> Helper loaded: url_helper
INFO - 2025-11-16 12:42:10 --> Helper loaded: file_helper
INFO - 2025-11-16 12:42:10 --> Helper loaded: main_helper
INFO - 2025-11-16 12:42:10 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:42:10 --> Database Driver Class Initialized
INFO - 2025-11-16 12:42:10 --> Email Class Initialized
DEBUG - 2025-11-16 12:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:42:10 --> Controller Class Initialized
INFO - 2025-11-16 12:42:10 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:42:10 --> Model "User_model" initialized
INFO - 2025-11-16 12:42:10 --> Model "Auth_model" initialized
INFO - 2025-11-16 12:42:10 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 12:42:10 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 12:42:10 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
ERROR - 2025-11-16 12:42:10 --> Severity: Warning --> Attempt to read property "date_start" on array D:\laragon\www\acumena\application\views\subscriptions\index.php 29
ERROR - 2025-11-16 12:42:10 --> Severity: Warning --> Attempt to read property "date_end" on array D:\laragon\www\acumena\application\views\subscriptions\index.php 29
INFO - 2025-11-16 12:42:10 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 12:42:10 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 12:42:10 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 12:42:10 --> Final output sent to browser
INFO - 2025-11-16 12:42:10 --> Total execution time: 0.0777
INFO - 2025-11-16 12:42:11 --> Config Class Initialized
INFO - 2025-11-16 12:42:11 --> Hooks Class Initialized
INFO - 2025-11-16 12:42:11 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:42:11 --> Utf8 Class Initialized
INFO - 2025-11-16 12:42:11 --> URI Class Initialized
INFO - 2025-11-16 12:42:11 --> Router Class Initialized
INFO - 2025-11-16 12:42:11 --> Output Class Initialized
INFO - 2025-11-16 12:42:11 --> Security Class Initialized
INFO - 2025-11-16 12:42:11 --> Input Class Initialized
INFO - 2025-11-16 12:42:11 --> Language Class Initialized
INFO - 2025-11-16 12:42:11 --> Loader Class Initialized
INFO - 2025-11-16 12:42:11 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:42:11 --> Helper loaded: url_helper
INFO - 2025-11-16 12:42:11 --> Helper loaded: file_helper
INFO - 2025-11-16 12:42:11 --> Helper loaded: main_helper
INFO - 2025-11-16 12:42:11 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:42:11 --> Database Driver Class Initialized
INFO - 2025-11-16 12:42:11 --> Email Class Initialized
DEBUG - 2025-11-16 12:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:42:11 --> Controller Class Initialized
INFO - 2025-11-16 12:42:11 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:42:11 --> Model "User_model" initialized
INFO - 2025-11-16 12:42:11 --> Model "Auth_model" initialized
INFO - 2025-11-16 12:42:11 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 12:42:11 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 12:42:11 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
ERROR - 2025-11-16 12:42:11 --> Severity: Warning --> Attempt to read property "date_start" on array D:\laragon\www\acumena\application\views\subscriptions\index.php 29
ERROR - 2025-11-16 12:42:11 --> Severity: Warning --> Attempt to read property "date_end" on array D:\laragon\www\acumena\application\views\subscriptions\index.php 29
INFO - 2025-11-16 12:42:11 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 12:42:11 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 12:42:11 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 12:42:11 --> Final output sent to browser
INFO - 2025-11-16 12:42:11 --> Total execution time: 0.0757
INFO - 2025-11-16 12:42:12 --> Config Class Initialized
INFO - 2025-11-16 12:42:12 --> Hooks Class Initialized
INFO - 2025-11-16 12:42:12 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:42:12 --> Utf8 Class Initialized
INFO - 2025-11-16 12:42:12 --> URI Class Initialized
INFO - 2025-11-16 12:42:12 --> Router Class Initialized
INFO - 2025-11-16 12:42:12 --> Output Class Initialized
INFO - 2025-11-16 12:42:12 --> Security Class Initialized
INFO - 2025-11-16 12:42:12 --> Input Class Initialized
INFO - 2025-11-16 12:42:12 --> Language Class Initialized
INFO - 2025-11-16 12:42:12 --> Loader Class Initialized
INFO - 2025-11-16 12:42:12 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:42:12 --> Helper loaded: url_helper
INFO - 2025-11-16 12:42:12 --> Helper loaded: file_helper
INFO - 2025-11-16 12:42:12 --> Helper loaded: main_helper
INFO - 2025-11-16 12:42:12 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:42:12 --> Database Driver Class Initialized
INFO - 2025-11-16 12:42:12 --> Email Class Initialized
DEBUG - 2025-11-16 12:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:42:12 --> Controller Class Initialized
INFO - 2025-11-16 12:42:12 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:42:12 --> Model "User_model" initialized
INFO - 2025-11-16 12:42:12 --> Model "Auth_model" initialized
INFO - 2025-11-16 12:42:12 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 12:42:12 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 12:42:12 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
ERROR - 2025-11-16 12:42:12 --> Severity: Warning --> Attempt to read property "date_start" on array D:\laragon\www\acumena\application\views\subscriptions\index.php 29
ERROR - 2025-11-16 12:42:12 --> Severity: Warning --> Attempt to read property "date_end" on array D:\laragon\www\acumena\application\views\subscriptions\index.php 29
INFO - 2025-11-16 12:42:12 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 12:42:12 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 12:42:12 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 12:42:12 --> Final output sent to browser
INFO - 2025-11-16 12:42:12 --> Total execution time: 0.1022
INFO - 2025-11-16 12:42:58 --> Config Class Initialized
INFO - 2025-11-16 12:42:58 --> Hooks Class Initialized
INFO - 2025-11-16 12:42:58 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:42:58 --> Utf8 Class Initialized
INFO - 2025-11-16 12:42:58 --> URI Class Initialized
INFO - 2025-11-16 12:42:58 --> Router Class Initialized
INFO - 2025-11-16 12:42:58 --> Output Class Initialized
INFO - 2025-11-16 12:42:58 --> Security Class Initialized
INFO - 2025-11-16 12:42:58 --> Input Class Initialized
INFO - 2025-11-16 12:42:58 --> Language Class Initialized
INFO - 2025-11-16 12:42:58 --> Loader Class Initialized
INFO - 2025-11-16 12:42:58 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:42:58 --> Helper loaded: url_helper
INFO - 2025-11-16 12:42:58 --> Helper loaded: file_helper
INFO - 2025-11-16 12:42:58 --> Helper loaded: main_helper
INFO - 2025-11-16 12:42:58 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:42:58 --> Database Driver Class Initialized
INFO - 2025-11-16 12:42:58 --> Email Class Initialized
DEBUG - 2025-11-16 12:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:42:58 --> Controller Class Initialized
INFO - 2025-11-16 12:42:58 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:42:58 --> Model "User_model" initialized
INFO - 2025-11-16 12:42:58 --> Model "Auth_model" initialized
INFO - 2025-11-16 12:42:58 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 12:42:58 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 12:42:58 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
ERROR - 2025-11-16 12:42:58 --> Severity: Warning --> Undefined property: stdClass::$date_start D:\laragon\www\acumena\application\views\subscriptions\index.php 29
ERROR - 2025-11-16 12:42:58 --> Severity: Warning --> Undefined property: stdClass::$date_end D:\laragon\www\acumena\application\views\subscriptions\index.php 29
INFO - 2025-11-16 12:42:58 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 12:42:58 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 12:42:58 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 12:42:58 --> Final output sent to browser
INFO - 2025-11-16 12:42:58 --> Total execution time: 0.1107
INFO - 2025-11-16 12:43:18 --> Config Class Initialized
INFO - 2025-11-16 12:43:18 --> Hooks Class Initialized
INFO - 2025-11-16 12:43:18 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:43:18 --> Utf8 Class Initialized
INFO - 2025-11-16 12:43:18 --> URI Class Initialized
INFO - 2025-11-16 12:43:18 --> Router Class Initialized
INFO - 2025-11-16 12:43:18 --> Output Class Initialized
INFO - 2025-11-16 12:43:18 --> Security Class Initialized
INFO - 2025-11-16 12:43:18 --> Input Class Initialized
INFO - 2025-11-16 12:43:18 --> Language Class Initialized
INFO - 2025-11-16 12:43:18 --> Loader Class Initialized
INFO - 2025-11-16 12:43:18 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:43:18 --> Helper loaded: url_helper
INFO - 2025-11-16 12:43:18 --> Helper loaded: file_helper
INFO - 2025-11-16 12:43:18 --> Helper loaded: main_helper
INFO - 2025-11-16 12:43:18 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:43:18 --> Database Driver Class Initialized
INFO - 2025-11-16 12:43:18 --> Email Class Initialized
DEBUG - 2025-11-16 12:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:43:18 --> Controller Class Initialized
INFO - 2025-11-16 12:43:18 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:43:18 --> Model "User_model" initialized
INFO - 2025-11-16 12:43:18 --> Model "Auth_model" initialized
INFO - 2025-11-16 12:43:18 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 12:43:18 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 12:43:18 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
ERROR - 2025-11-16 12:43:18 --> Severity: Warning --> Undefined property: stdClass::$date_start D:\laragon\www\acumena\application\views\subscriptions\index.php 30
ERROR - 2025-11-16 12:43:18 --> Severity: Warning --> Undefined property: stdClass::$date_end D:\laragon\www\acumena\application\views\subscriptions\index.php 30
INFO - 2025-11-16 12:43:18 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 12:43:18 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 12:43:18 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 12:43:18 --> Final output sent to browser
INFO - 2025-11-16 12:43:18 --> Total execution time: 0.0965
INFO - 2025-11-16 12:47:06 --> Config Class Initialized
INFO - 2025-11-16 12:47:06 --> Hooks Class Initialized
INFO - 2025-11-16 12:47:06 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:47:06 --> Utf8 Class Initialized
INFO - 2025-11-16 12:47:06 --> URI Class Initialized
INFO - 2025-11-16 12:47:06 --> Router Class Initialized
INFO - 2025-11-16 12:47:06 --> Output Class Initialized
INFO - 2025-11-16 12:47:06 --> Security Class Initialized
INFO - 2025-11-16 12:47:06 --> Input Class Initialized
INFO - 2025-11-16 12:47:06 --> Language Class Initialized
INFO - 2025-11-16 12:47:06 --> Loader Class Initialized
INFO - 2025-11-16 12:47:06 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:47:06 --> Helper loaded: url_helper
INFO - 2025-11-16 12:47:06 --> Helper loaded: file_helper
INFO - 2025-11-16 12:47:06 --> Helper loaded: main_helper
INFO - 2025-11-16 12:47:06 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:47:06 --> Database Driver Class Initialized
INFO - 2025-11-16 12:47:06 --> Email Class Initialized
DEBUG - 2025-11-16 12:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:47:06 --> Controller Class Initialized
INFO - 2025-11-16 12:47:06 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:47:06 --> Model "User_model" initialized
INFO - 2025-11-16 12:47:06 --> Model "Auth_model" initialized
ERROR - 2025-11-16 12:47:06 --> Query error: Unknown column 'user_subscription_history.is_active' in 'where clause' - Invalid query: SELECT `user_subscription_history`.*, `subscriptions`.`name` AS `subscription_name`
FROM `user_subscription_history`
INNER JOIN `subscriptions` ON `subscriptions`.`id` = `user_subscription_history`.`subscription_id`
WHERE `user_subscription_history`.`user_id` = '1'
AND `user_subscription_history`.`is_active` = 1
INFO - 2025-11-16 12:47:06 --> Language file loaded: language/english/db_lang.php
INFO - 2025-11-16 12:49:03 --> Config Class Initialized
INFO - 2025-11-16 12:49:03 --> Hooks Class Initialized
INFO - 2025-11-16 12:49:03 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:49:03 --> Utf8 Class Initialized
INFO - 2025-11-16 12:49:03 --> URI Class Initialized
INFO - 2025-11-16 12:49:03 --> Router Class Initialized
INFO - 2025-11-16 12:49:03 --> Output Class Initialized
INFO - 2025-11-16 12:49:03 --> Security Class Initialized
INFO - 2025-11-16 12:49:03 --> Input Class Initialized
INFO - 2025-11-16 12:49:03 --> Language Class Initialized
INFO - 2025-11-16 12:49:03 --> Loader Class Initialized
INFO - 2025-11-16 12:49:03 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:49:03 --> Helper loaded: url_helper
INFO - 2025-11-16 12:49:03 --> Helper loaded: file_helper
INFO - 2025-11-16 12:49:03 --> Helper loaded: main_helper
INFO - 2025-11-16 12:49:03 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:49:03 --> Database Driver Class Initialized
INFO - 2025-11-16 12:49:03 --> Email Class Initialized
DEBUG - 2025-11-16 12:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:49:03 --> Controller Class Initialized
INFO - 2025-11-16 12:49:03 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:49:03 --> Model "User_model" initialized
INFO - 2025-11-16 12:49:03 --> Model "Auth_model" initialized
ERROR - 2025-11-16 12:49:03 --> Query error: Unknown column 'user_subscription_history.subscription_id' in 'on clause' - Invalid query: SELECT `user_subscription_history`.*, `subscriptions`.`name` AS `subscription_name`
FROM `user_subscription_history`
INNER JOIN `subscriptions` ON `subscriptions`.`id` = `user_subscription_history`.`subscription_id`
WHERE `user_subscription_history`.`user_id` = '1'
AND `user_subscription_history`.`is_active` = 1
INFO - 2025-11-16 12:49:03 --> Language file loaded: language/english/db_lang.php
INFO - 2025-11-16 12:50:48 --> Config Class Initialized
INFO - 2025-11-16 12:50:48 --> Hooks Class Initialized
INFO - 2025-11-16 12:50:48 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:50:48 --> Utf8 Class Initialized
INFO - 2025-11-16 12:50:48 --> URI Class Initialized
INFO - 2025-11-16 12:50:48 --> Router Class Initialized
INFO - 2025-11-16 12:50:48 --> Output Class Initialized
INFO - 2025-11-16 12:50:48 --> Security Class Initialized
INFO - 2025-11-16 12:50:48 --> Input Class Initialized
INFO - 2025-11-16 12:50:48 --> Language Class Initialized
INFO - 2025-11-16 12:50:48 --> Loader Class Initialized
INFO - 2025-11-16 12:50:48 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:50:48 --> Helper loaded: url_helper
INFO - 2025-11-16 12:50:48 --> Helper loaded: file_helper
INFO - 2025-11-16 12:50:48 --> Helper loaded: main_helper
INFO - 2025-11-16 12:50:48 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:50:48 --> Database Driver Class Initialized
INFO - 2025-11-16 12:50:48 --> Email Class Initialized
DEBUG - 2025-11-16 12:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:50:48 --> Controller Class Initialized
INFO - 2025-11-16 12:50:48 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:50:48 --> Model "User_model" initialized
INFO - 2025-11-16 12:50:48 --> Model "Auth_model" initialized
INFO - 2025-11-16 12:50:48 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 12:50:48 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 12:50:48 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
ERROR - 2025-11-16 12:50:48 --> Severity: Warning --> Undefined property: stdClass::$price_monthly D:\laragon\www\acumena\application\views\subscriptions\index.php 20
INFO - 2025-11-16 12:50:48 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 12:50:48 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 12:50:48 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 12:50:48 --> Final output sent to browser
INFO - 2025-11-16 12:50:48 --> Total execution time: 0.0685
INFO - 2025-11-16 12:52:20 --> Config Class Initialized
INFO - 2025-11-16 12:52:20 --> Hooks Class Initialized
INFO - 2025-11-16 12:52:20 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:52:20 --> Utf8 Class Initialized
INFO - 2025-11-16 12:52:20 --> URI Class Initialized
INFO - 2025-11-16 12:52:20 --> Router Class Initialized
INFO - 2025-11-16 12:52:20 --> Output Class Initialized
INFO - 2025-11-16 12:52:20 --> Security Class Initialized
INFO - 2025-11-16 12:52:20 --> Input Class Initialized
INFO - 2025-11-16 12:52:20 --> Language Class Initialized
INFO - 2025-11-16 12:52:20 --> Loader Class Initialized
INFO - 2025-11-16 12:52:20 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:52:20 --> Helper loaded: url_helper
INFO - 2025-11-16 12:52:20 --> Helper loaded: file_helper
INFO - 2025-11-16 12:52:20 --> Helper loaded: main_helper
INFO - 2025-11-16 12:52:20 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:52:20 --> Database Driver Class Initialized
INFO - 2025-11-16 12:52:20 --> Email Class Initialized
DEBUG - 2025-11-16 12:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:52:20 --> Controller Class Initialized
INFO - 2025-11-16 12:52:20 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:52:20 --> Model "User_model" initialized
INFO - 2025-11-16 12:52:20 --> Model "Auth_model" initialized
INFO - 2025-11-16 12:52:20 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 12:52:20 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 12:52:20 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
ERROR - 2025-11-16 12:52:20 --> Severity: Warning --> Undefined property: stdClass::$price_monthly D:\laragon\www\acumena\application\views\subscriptions\index.php 20
INFO - 2025-11-16 12:52:20 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 12:52:20 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 12:52:20 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 12:52:20 --> Final output sent to browser
INFO - 2025-11-16 12:52:20 --> Total execution time: 0.0641
INFO - 2025-11-16 12:52:29 --> Config Class Initialized
INFO - 2025-11-16 12:52:29 --> Hooks Class Initialized
INFO - 2025-11-16 12:52:29 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:52:29 --> Utf8 Class Initialized
INFO - 2025-11-16 12:52:29 --> URI Class Initialized
INFO - 2025-11-16 12:52:29 --> Router Class Initialized
INFO - 2025-11-16 12:52:29 --> Output Class Initialized
INFO - 2025-11-16 12:52:29 --> Security Class Initialized
INFO - 2025-11-16 12:52:29 --> Input Class Initialized
INFO - 2025-11-16 12:52:29 --> Language Class Initialized
INFO - 2025-11-16 12:52:29 --> Loader Class Initialized
INFO - 2025-11-16 12:52:29 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:52:29 --> Helper loaded: url_helper
INFO - 2025-11-16 12:52:29 --> Helper loaded: file_helper
INFO - 2025-11-16 12:52:29 --> Helper loaded: main_helper
INFO - 2025-11-16 12:52:29 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:52:29 --> Database Driver Class Initialized
INFO - 2025-11-16 12:52:29 --> Email Class Initialized
DEBUG - 2025-11-16 12:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:52:29 --> Controller Class Initialized
INFO - 2025-11-16 12:52:29 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:52:29 --> Model "User_model" initialized
INFO - 2025-11-16 12:52:29 --> Model "Auth_model" initialized
INFO - 2025-11-16 12:52:29 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-16 12:52:29 --> Final output sent to browser
INFO - 2025-11-16 12:52:29 --> Total execution time: 0.1100
INFO - 2025-11-16 12:52:30 --> Config Class Initialized
INFO - 2025-11-16 12:52:30 --> Hooks Class Initialized
INFO - 2025-11-16 12:52:30 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:52:30 --> Utf8 Class Initialized
INFO - 2025-11-16 12:52:30 --> URI Class Initialized
INFO - 2025-11-16 12:52:30 --> Router Class Initialized
INFO - 2025-11-16 12:52:30 --> Output Class Initialized
INFO - 2025-11-16 12:52:30 --> Security Class Initialized
INFO - 2025-11-16 12:52:30 --> Input Class Initialized
INFO - 2025-11-16 12:52:30 --> Language Class Initialized
INFO - 2025-11-16 12:52:30 --> Loader Class Initialized
INFO - 2025-11-16 12:52:30 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:52:30 --> Helper loaded: url_helper
INFO - 2025-11-16 12:52:30 --> Helper loaded: file_helper
INFO - 2025-11-16 12:52:30 --> Helper loaded: main_helper
INFO - 2025-11-16 12:52:30 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:52:30 --> Database Driver Class Initialized
INFO - 2025-11-16 12:52:30 --> Email Class Initialized
DEBUG - 2025-11-16 12:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:52:30 --> Controller Class Initialized
INFO - 2025-11-16 12:52:30 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:52:30 --> Model "User_model" initialized
INFO - 2025-11-16 12:52:30 --> Model "Auth_model" initialized
INFO - 2025-11-16 12:52:30 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 12:52:30 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 12:52:30 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 12:52:30 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 12:52:30 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 12:52:30 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 12:52:30 --> Final output sent to browser
INFO - 2025-11-16 12:52:30 --> Total execution time: 0.1125
INFO - 2025-11-16 12:52:32 --> Config Class Initialized
INFO - 2025-11-16 12:52:32 --> Hooks Class Initialized
INFO - 2025-11-16 12:52:32 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:52:32 --> Utf8 Class Initialized
INFO - 2025-11-16 12:52:32 --> URI Class Initialized
INFO - 2025-11-16 12:52:32 --> Router Class Initialized
INFO - 2025-11-16 12:52:32 --> Output Class Initialized
INFO - 2025-11-16 12:52:32 --> Security Class Initialized
INFO - 2025-11-16 12:52:32 --> Input Class Initialized
INFO - 2025-11-16 12:52:32 --> Language Class Initialized
INFO - 2025-11-16 12:52:32 --> Loader Class Initialized
INFO - 2025-11-16 12:52:32 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:52:32 --> Helper loaded: url_helper
INFO - 2025-11-16 12:52:32 --> Helper loaded: file_helper
INFO - 2025-11-16 12:52:32 --> Helper loaded: main_helper
INFO - 2025-11-16 12:52:32 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:52:32 --> Database Driver Class Initialized
INFO - 2025-11-16 12:52:32 --> Email Class Initialized
DEBUG - 2025-11-16 12:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:52:32 --> Controller Class Initialized
INFO - 2025-11-16 12:52:32 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:52:32 --> Model "User_model" initialized
INFO - 2025-11-16 12:52:32 --> Model "Auth_model" initialized
INFO - 2025-11-16 12:52:32 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 12:52:32 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 12:52:32 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 12:52:32 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 12:52:32 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 12:52:32 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 12:52:32 --> Final output sent to browser
INFO - 2025-11-16 12:52:32 --> Total execution time: 0.0966
INFO - 2025-11-16 12:52:44 --> Config Class Initialized
INFO - 2025-11-16 12:52:44 --> Hooks Class Initialized
INFO - 2025-11-16 12:52:44 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:52:44 --> Utf8 Class Initialized
INFO - 2025-11-16 12:52:44 --> URI Class Initialized
INFO - 2025-11-16 12:52:44 --> Router Class Initialized
INFO - 2025-11-16 12:52:44 --> Output Class Initialized
INFO - 2025-11-16 12:52:44 --> Security Class Initialized
INFO - 2025-11-16 12:52:44 --> Input Class Initialized
INFO - 2025-11-16 12:52:44 --> Language Class Initialized
INFO - 2025-11-16 12:52:44 --> Loader Class Initialized
INFO - 2025-11-16 12:52:44 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:52:44 --> Helper loaded: url_helper
INFO - 2025-11-16 12:52:44 --> Helper loaded: file_helper
INFO - 2025-11-16 12:52:44 --> Helper loaded: main_helper
INFO - 2025-11-16 12:52:44 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:52:44 --> Database Driver Class Initialized
INFO - 2025-11-16 12:52:44 --> Email Class Initialized
DEBUG - 2025-11-16 12:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:52:44 --> Controller Class Initialized
INFO - 2025-11-16 12:52:44 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:52:44 --> Model "User_model" initialized
INFO - 2025-11-16 12:52:44 --> Model "Auth_model" initialized
INFO - 2025-11-16 12:52:44 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 12:52:44 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 12:52:44 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 12:52:44 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 12:52:44 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 12:52:44 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 12:52:44 --> Final output sent to browser
INFO - 2025-11-16 12:52:44 --> Total execution time: 0.0814
INFO - 2025-11-16 12:53:05 --> Config Class Initialized
INFO - 2025-11-16 12:53:05 --> Hooks Class Initialized
INFO - 2025-11-16 12:53:05 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:53:05 --> Utf8 Class Initialized
INFO - 2025-11-16 12:53:05 --> URI Class Initialized
INFO - 2025-11-16 12:53:05 --> Router Class Initialized
INFO - 2025-11-16 12:53:05 --> Output Class Initialized
INFO - 2025-11-16 12:53:05 --> Security Class Initialized
INFO - 2025-11-16 12:53:05 --> Input Class Initialized
INFO - 2025-11-16 12:53:05 --> Language Class Initialized
INFO - 2025-11-16 12:53:05 --> Loader Class Initialized
INFO - 2025-11-16 12:53:05 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:53:05 --> Helper loaded: url_helper
INFO - 2025-11-16 12:53:05 --> Helper loaded: file_helper
INFO - 2025-11-16 12:53:05 --> Helper loaded: main_helper
INFO - 2025-11-16 12:53:05 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:53:05 --> Database Driver Class Initialized
INFO - 2025-11-16 12:53:05 --> Email Class Initialized
DEBUG - 2025-11-16 12:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:53:05 --> Controller Class Initialized
INFO - 2025-11-16 12:53:05 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:53:05 --> Model "User_model" initialized
INFO - 2025-11-16 12:53:05 --> Model "Auth_model" initialized
INFO - 2025-11-16 12:53:05 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 12:53:05 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 12:53:05 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 12:53:05 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 12:53:05 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 12:53:05 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 12:53:05 --> Final output sent to browser
INFO - 2025-11-16 12:53:05 --> Total execution time: 0.0920
INFO - 2025-11-16 12:53:59 --> Config Class Initialized
INFO - 2025-11-16 12:53:59 --> Hooks Class Initialized
INFO - 2025-11-16 12:53:59 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:53:59 --> Utf8 Class Initialized
INFO - 2025-11-16 12:53:59 --> URI Class Initialized
INFO - 2025-11-16 12:53:59 --> Router Class Initialized
INFO - 2025-11-16 12:53:59 --> Output Class Initialized
INFO - 2025-11-16 12:53:59 --> Security Class Initialized
INFO - 2025-11-16 12:53:59 --> Input Class Initialized
INFO - 2025-11-16 12:53:59 --> Language Class Initialized
INFO - 2025-11-16 12:53:59 --> Loader Class Initialized
INFO - 2025-11-16 12:53:59 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:53:59 --> Helper loaded: url_helper
INFO - 2025-11-16 12:53:59 --> Helper loaded: file_helper
INFO - 2025-11-16 12:53:59 --> Helper loaded: main_helper
INFO - 2025-11-16 12:53:59 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:53:59 --> Database Driver Class Initialized
INFO - 2025-11-16 12:53:59 --> Email Class Initialized
DEBUG - 2025-11-16 12:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:53:59 --> Controller Class Initialized
INFO - 2025-11-16 12:53:59 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:53:59 --> Model "User_model" initialized
INFO - 2025-11-16 12:53:59 --> Model "Auth_model" initialized
INFO - 2025-11-16 12:53:59 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 12:53:59 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 12:53:59 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 12:53:59 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 12:53:59 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 12:53:59 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 12:53:59 --> Final output sent to browser
INFO - 2025-11-16 12:53:59 --> Total execution time: 0.0888
INFO - 2025-11-16 12:56:02 --> Config Class Initialized
INFO - 2025-11-16 12:56:02 --> Hooks Class Initialized
INFO - 2025-11-16 12:56:02 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:56:02 --> Utf8 Class Initialized
INFO - 2025-11-16 12:56:02 --> URI Class Initialized
INFO - 2025-11-16 12:56:02 --> Router Class Initialized
INFO - 2025-11-16 12:56:02 --> Output Class Initialized
INFO - 2025-11-16 12:56:02 --> Security Class Initialized
INFO - 2025-11-16 12:56:02 --> Input Class Initialized
INFO - 2025-11-16 12:56:02 --> Language Class Initialized
INFO - 2025-11-16 12:56:02 --> Loader Class Initialized
INFO - 2025-11-16 12:56:02 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:56:02 --> Helper loaded: url_helper
INFO - 2025-11-16 12:56:02 --> Helper loaded: file_helper
INFO - 2025-11-16 12:56:02 --> Helper loaded: main_helper
INFO - 2025-11-16 12:56:02 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:56:02 --> Database Driver Class Initialized
INFO - 2025-11-16 12:56:02 --> Email Class Initialized
DEBUG - 2025-11-16 12:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:56:02 --> Controller Class Initialized
INFO - 2025-11-16 12:56:02 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:56:02 --> Model "User_model" initialized
INFO - 2025-11-16 12:56:02 --> Model "Auth_model" initialized
INFO - 2025-11-16 12:56:02 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 12:56:02 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 12:56:02 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 12:56:02 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 12:56:02 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 12:56:02 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 12:56:02 --> Final output sent to browser
INFO - 2025-11-16 12:56:02 --> Total execution time: 0.1318
INFO - 2025-11-16 12:56:35 --> Config Class Initialized
INFO - 2025-11-16 12:56:35 --> Hooks Class Initialized
INFO - 2025-11-16 12:56:35 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:56:35 --> Utf8 Class Initialized
INFO - 2025-11-16 12:56:35 --> URI Class Initialized
INFO - 2025-11-16 12:56:35 --> Router Class Initialized
INFO - 2025-11-16 12:56:35 --> Output Class Initialized
INFO - 2025-11-16 12:56:35 --> Security Class Initialized
INFO - 2025-11-16 12:56:35 --> Input Class Initialized
INFO - 2025-11-16 12:56:35 --> Language Class Initialized
INFO - 2025-11-16 12:56:35 --> Loader Class Initialized
INFO - 2025-11-16 12:56:35 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:56:35 --> Helper loaded: url_helper
INFO - 2025-11-16 12:56:35 --> Helper loaded: file_helper
INFO - 2025-11-16 12:56:35 --> Helper loaded: main_helper
INFO - 2025-11-16 12:56:35 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:56:35 --> Database Driver Class Initialized
INFO - 2025-11-16 12:56:35 --> Email Class Initialized
DEBUG - 2025-11-16 12:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:56:35 --> Controller Class Initialized
INFO - 2025-11-16 12:56:35 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:56:35 --> Model "User_model" initialized
INFO - 2025-11-16 12:56:35 --> Model "Auth_model" initialized
INFO - 2025-11-16 12:56:35 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 12:56:35 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 12:56:35 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 12:56:35 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 12:56:35 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 12:56:35 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 12:56:35 --> Final output sent to browser
INFO - 2025-11-16 12:56:35 --> Total execution time: 0.1034
INFO - 2025-11-16 12:59:36 --> Config Class Initialized
INFO - 2025-11-16 12:59:36 --> Hooks Class Initialized
INFO - 2025-11-16 12:59:36 --> UTF-8 Support Enabled
INFO - 2025-11-16 12:59:36 --> Utf8 Class Initialized
INFO - 2025-11-16 12:59:36 --> URI Class Initialized
INFO - 2025-11-16 12:59:36 --> Router Class Initialized
INFO - 2025-11-16 12:59:36 --> Output Class Initialized
INFO - 2025-11-16 12:59:36 --> Security Class Initialized
INFO - 2025-11-16 12:59:36 --> Input Class Initialized
INFO - 2025-11-16 12:59:36 --> Language Class Initialized
INFO - 2025-11-16 12:59:36 --> Loader Class Initialized
INFO - 2025-11-16 12:59:36 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-16 12:59:36 --> Helper loaded: url_helper
INFO - 2025-11-16 12:59:36 --> Helper loaded: file_helper
INFO - 2025-11-16 12:59:36 --> Helper loaded: main_helper
INFO - 2025-11-16 12:59:36 --> Helper loaded: sendgrid_helper
INFO - 2025-11-16 12:59:36 --> Database Driver Class Initialized
INFO - 2025-11-16 12:59:36 --> Email Class Initialized
DEBUG - 2025-11-16 12:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 12:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 12:59:36 --> Controller Class Initialized
INFO - 2025-11-16 12:59:36 --> Model "Subscription_model" initialized
INFO - 2025-11-16 12:59:36 --> Model "User_model" initialized
INFO - 2025-11-16 12:59:36 --> Model "Auth_model" initialized
INFO - 2025-11-16 12:59:36 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-16 12:59:36 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-16 12:59:36 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-16 12:59:36 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-16 12:59:36 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-16 12:59:36 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-16 12:59:36 --> Final output sent to browser
INFO - 2025-11-16 12:59:36 --> Total execution time: 0.1143
