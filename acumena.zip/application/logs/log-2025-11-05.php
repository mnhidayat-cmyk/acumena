<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-11-05 00:00:12 --> Config Class Initialized
INFO - 2025-11-05 00:00:12 --> Hooks Class Initialized
INFO - 2025-11-05 00:00:12 --> UTF-8 Support Enabled
INFO - 2025-11-05 00:00:12 --> Utf8 Class Initialized
INFO - 2025-11-05 00:00:12 --> URI Class Initialized
INFO - 2025-11-05 00:00:12 --> Router Class Initialized
INFO - 2025-11-05 00:00:12 --> Output Class Initialized
INFO - 2025-11-05 00:00:12 --> Security Class Initialized
INFO - 2025-11-05 00:00:12 --> Input Class Initialized
INFO - 2025-11-05 00:00:12 --> Language Class Initialized
INFO - 2025-11-05 00:00:12 --> Loader Class Initialized
INFO - 2025-11-05 00:00:12 --> Helper loaded: url_helper
INFO - 2025-11-05 00:00:12 --> Helper loaded: file_helper
INFO - 2025-11-05 00:00:12 --> Helper loaded: main_helper
INFO - 2025-11-05 00:00:12 --> Database Driver Class Initialized
INFO - 2025-11-05 00:00:12 --> Email Class Initialized
DEBUG - 2025-11-05 00:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 00:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 00:00:12 --> Controller Class Initialized
INFO - 2025-11-05 00:00:12 --> API /auth/forgot_password invoked
INFO - 2025-11-05 00:00:12 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-05 00:00:12 --> Final output sent to browser
INFO - 2025-11-05 00:00:12 --> Total execution time: 0.0555
INFO - 2025-11-05 00:00:14 --> Config Class Initialized
INFO - 2025-11-05 00:00:14 --> Hooks Class Initialized
INFO - 2025-11-05 00:00:14 --> UTF-8 Support Enabled
INFO - 2025-11-05 00:00:14 --> Utf8 Class Initialized
INFO - 2025-11-05 00:00:14 --> URI Class Initialized
INFO - 2025-11-05 00:00:14 --> Router Class Initialized
INFO - 2025-11-05 00:00:14 --> Output Class Initialized
INFO - 2025-11-05 00:00:14 --> Security Class Initialized
INFO - 2025-11-05 00:00:14 --> Input Class Initialized
INFO - 2025-11-05 00:00:14 --> Language Class Initialized
INFO - 2025-11-05 00:00:14 --> Loader Class Initialized
INFO - 2025-11-05 00:00:14 --> Helper loaded: url_helper
INFO - 2025-11-05 00:00:14 --> Helper loaded: file_helper
INFO - 2025-11-05 00:00:14 --> Helper loaded: main_helper
INFO - 2025-11-05 00:00:14 --> Database Driver Class Initialized
INFO - 2025-11-05 00:00:14 --> Email Class Initialized
DEBUG - 2025-11-05 00:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 00:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 00:00:14 --> Controller Class Initialized
INFO - 2025-11-05 00:00:14 --> Model "Subscription_model" initialized
INFO - 2025-11-05 00:00:14 --> Model "User_model" initialized
INFO - 2025-11-05 00:00:14 --> Model "Auth_model" initialized
INFO - 2025-11-05 00:00:14 --> API /auth/forgot_password invoked; email payload="(empty)"
INFO - 2025-11-05 00:00:14 --> API forgot_password skipped processing due to empty email
INFO - 2025-11-05 00:00:14 --> Final output sent to browser
INFO - 2025-11-05 00:00:14 --> Total execution time: 0.0564
INFO - 2025-11-05 00:00:41 --> Config Class Initialized
INFO - 2025-11-05 00:00:41 --> Hooks Class Initialized
INFO - 2025-11-05 00:00:41 --> UTF-8 Support Enabled
INFO - 2025-11-05 00:00:41 --> Utf8 Class Initialized
INFO - 2025-11-05 00:00:41 --> URI Class Initialized
INFO - 2025-11-05 00:00:41 --> Router Class Initialized
INFO - 2025-11-05 00:00:41 --> Output Class Initialized
INFO - 2025-11-05 00:00:41 --> Security Class Initialized
INFO - 2025-11-05 00:00:41 --> Input Class Initialized
INFO - 2025-11-05 00:00:41 --> Language Class Initialized
INFO - 2025-11-05 00:00:41 --> Loader Class Initialized
INFO - 2025-11-05 00:00:41 --> Helper loaded: url_helper
INFO - 2025-11-05 00:00:41 --> Helper loaded: file_helper
INFO - 2025-11-05 00:00:41 --> Helper loaded: main_helper
INFO - 2025-11-05 00:00:41 --> Database Driver Class Initialized
INFO - 2025-11-05 00:00:41 --> Email Class Initialized
DEBUG - 2025-11-05 00:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 00:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 00:00:41 --> Controller Class Initialized
INFO - 2025-11-05 00:00:41 --> API /auth/forgot_password invoked
INFO - 2025-11-05 00:00:41 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-05 00:00:41 --> Final output sent to browser
INFO - 2025-11-05 00:00:41 --> Total execution time: 0.0661
INFO - 2025-11-05 00:00:44 --> Config Class Initialized
INFO - 2025-11-05 00:00:44 --> Hooks Class Initialized
INFO - 2025-11-05 00:00:44 --> UTF-8 Support Enabled
INFO - 2025-11-05 00:00:44 --> Utf8 Class Initialized
INFO - 2025-11-05 00:00:44 --> URI Class Initialized
INFO - 2025-11-05 00:00:44 --> Router Class Initialized
INFO - 2025-11-05 00:00:44 --> Output Class Initialized
INFO - 2025-11-05 00:00:44 --> Security Class Initialized
INFO - 2025-11-05 00:00:44 --> Input Class Initialized
INFO - 2025-11-05 00:00:44 --> Language Class Initialized
INFO - 2025-11-05 00:00:44 --> Loader Class Initialized
INFO - 2025-11-05 00:00:44 --> Helper loaded: url_helper
INFO - 2025-11-05 00:00:44 --> Helper loaded: file_helper
INFO - 2025-11-05 00:00:44 --> Helper loaded: main_helper
INFO - 2025-11-05 00:00:44 --> Database Driver Class Initialized
INFO - 2025-11-05 00:00:44 --> Email Class Initialized
DEBUG - 2025-11-05 00:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 00:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 00:00:44 --> Controller Class Initialized
INFO - 2025-11-05 00:00:44 --> Model "Subscription_model" initialized
INFO - 2025-11-05 00:00:44 --> Model "User_model" initialized
INFO - 2025-11-05 00:00:44 --> Model "Auth_model" initialized
INFO - 2025-11-05 00:00:44 --> API /auth/forgot_password invoked; email payload="(empty)"
INFO - 2025-11-05 00:00:44 --> API forgot_password skipped processing due to empty email
INFO - 2025-11-05 00:00:44 --> Final output sent to browser
INFO - 2025-11-05 00:00:44 --> Total execution time: 0.0521
INFO - 2025-11-05 00:00:57 --> Config Class Initialized
INFO - 2025-11-05 00:00:57 --> Hooks Class Initialized
INFO - 2025-11-05 00:00:57 --> UTF-8 Support Enabled
INFO - 2025-11-05 00:00:57 --> Utf8 Class Initialized
INFO - 2025-11-05 00:00:57 --> URI Class Initialized
INFO - 2025-11-05 00:00:57 --> Router Class Initialized
INFO - 2025-11-05 00:00:57 --> Output Class Initialized
INFO - 2025-11-05 00:00:57 --> Security Class Initialized
INFO - 2025-11-05 00:00:57 --> Input Class Initialized
INFO - 2025-11-05 00:00:57 --> Language Class Initialized
INFO - 2025-11-05 00:00:57 --> Loader Class Initialized
INFO - 2025-11-05 00:00:57 --> Helper loaded: url_helper
INFO - 2025-11-05 00:00:57 --> Helper loaded: file_helper
INFO - 2025-11-05 00:00:57 --> Helper loaded: main_helper
INFO - 2025-11-05 00:00:57 --> Database Driver Class Initialized
INFO - 2025-11-05 00:00:57 --> Email Class Initialized
DEBUG - 2025-11-05 00:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 00:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 00:00:57 --> Controller Class Initialized
INFO - 2025-11-05 00:00:57 --> API /auth/forgot_password invoked
INFO - 2025-11-05 00:00:57 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-05 00:00:57 --> Final output sent to browser
INFO - 2025-11-05 00:00:57 --> Total execution time: 0.0815
INFO - 2025-11-05 00:00:59 --> Config Class Initialized
INFO - 2025-11-05 00:00:59 --> Hooks Class Initialized
INFO - 2025-11-05 00:00:59 --> UTF-8 Support Enabled
INFO - 2025-11-05 00:00:59 --> Utf8 Class Initialized
INFO - 2025-11-05 00:00:59 --> URI Class Initialized
INFO - 2025-11-05 00:00:59 --> Router Class Initialized
INFO - 2025-11-05 00:00:59 --> Output Class Initialized
INFO - 2025-11-05 00:00:59 --> Security Class Initialized
INFO - 2025-11-05 00:00:59 --> Input Class Initialized
INFO - 2025-11-05 00:00:59 --> Language Class Initialized
INFO - 2025-11-05 00:00:59 --> Loader Class Initialized
INFO - 2025-11-05 00:00:59 --> Helper loaded: url_helper
INFO - 2025-11-05 00:00:59 --> Helper loaded: file_helper
INFO - 2025-11-05 00:00:59 --> Helper loaded: main_helper
INFO - 2025-11-05 00:00:59 --> Database Driver Class Initialized
INFO - 2025-11-05 00:00:59 --> Email Class Initialized
DEBUG - 2025-11-05 00:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 00:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 00:00:59 --> Controller Class Initialized
INFO - 2025-11-05 00:00:59 --> Model "Subscription_model" initialized
INFO - 2025-11-05 00:00:59 --> Model "User_model" initialized
INFO - 2025-11-05 00:00:59 --> Model "Auth_model" initialized
INFO - 2025-11-05 00:00:59 --> API /auth/forgot_password invoked; email payload="(empty)"
INFO - 2025-11-05 00:00:59 --> API forgot_password skipped processing due to empty email
INFO - 2025-11-05 00:00:59 --> Final output sent to browser
INFO - 2025-11-05 00:00:59 --> Total execution time: 0.0950
INFO - 2025-11-05 00:03:12 --> Config Class Initialized
INFO - 2025-11-05 00:03:12 --> Hooks Class Initialized
INFO - 2025-11-05 00:03:12 --> UTF-8 Support Enabled
INFO - 2025-11-05 00:03:12 --> Utf8 Class Initialized
INFO - 2025-11-05 00:03:12 --> URI Class Initialized
INFO - 2025-11-05 00:03:12 --> Router Class Initialized
INFO - 2025-11-05 00:03:12 --> Output Class Initialized
INFO - 2025-11-05 00:03:12 --> Security Class Initialized
INFO - 2025-11-05 00:03:12 --> Input Class Initialized
INFO - 2025-11-05 00:03:12 --> Language Class Initialized
INFO - 2025-11-05 00:03:12 --> Loader Class Initialized
INFO - 2025-11-05 00:03:12 --> Helper loaded: url_helper
INFO - 2025-11-05 00:03:12 --> Helper loaded: file_helper
INFO - 2025-11-05 00:03:12 --> Helper loaded: main_helper
INFO - 2025-11-05 00:03:12 --> Database Driver Class Initialized
INFO - 2025-11-05 00:03:12 --> Email Class Initialized
DEBUG - 2025-11-05 00:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 00:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 00:03:12 --> Controller Class Initialized
INFO - 2025-11-05 00:03:12 --> API /auth/forgot_password invoked
INFO - 2025-11-05 00:03:12 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-05 00:03:12 --> Final output sent to browser
INFO - 2025-11-05 00:03:12 --> Total execution time: 0.0826
INFO - 2025-11-05 00:03:17 --> Config Class Initialized
INFO - 2025-11-05 00:03:17 --> Hooks Class Initialized
INFO - 2025-11-05 00:03:17 --> UTF-8 Support Enabled
INFO - 2025-11-05 00:03:17 --> Utf8 Class Initialized
INFO - 2025-11-05 00:03:17 --> URI Class Initialized
INFO - 2025-11-05 00:03:17 --> Router Class Initialized
INFO - 2025-11-05 00:03:17 --> Output Class Initialized
INFO - 2025-11-05 00:03:17 --> Security Class Initialized
INFO - 2025-11-05 00:03:17 --> Input Class Initialized
INFO - 2025-11-05 00:03:17 --> Language Class Initialized
INFO - 2025-11-05 00:03:17 --> Loader Class Initialized
INFO - 2025-11-05 00:03:17 --> Helper loaded: url_helper
INFO - 2025-11-05 00:03:17 --> Helper loaded: file_helper
INFO - 2025-11-05 00:03:17 --> Helper loaded: main_helper
INFO - 2025-11-05 00:03:17 --> Database Driver Class Initialized
INFO - 2025-11-05 00:03:17 --> Email Class Initialized
DEBUG - 2025-11-05 00:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 00:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 00:03:17 --> Controller Class Initialized
INFO - 2025-11-05 00:03:17 --> Model "Subscription_model" initialized
INFO - 2025-11-05 00:03:17 --> Model "User_model" initialized
INFO - 2025-11-05 00:03:17 --> Model "Auth_model" initialized
INFO - 2025-11-05 00:03:17 --> API /auth/forgot_password invoked; email payload="cranam21@gmail.com"
INFO - 2025-11-05 00:03:17 --> Forgot password requested for cranam21@gmail.com but no active user found
INFO - 2025-11-05 00:03:17 --> API forgot_password processed for email: cranam21@gmail.com
INFO - 2025-11-05 00:03:17 --> Final output sent to browser
INFO - 2025-11-05 00:03:17 --> Total execution time: 0.0956
INFO - 2025-11-05 00:05:18 --> Config Class Initialized
INFO - 2025-11-05 00:05:18 --> Hooks Class Initialized
INFO - 2025-11-05 00:05:18 --> UTF-8 Support Enabled
INFO - 2025-11-05 00:05:18 --> Utf8 Class Initialized
INFO - 2025-11-05 00:05:18 --> URI Class Initialized
INFO - 2025-11-05 00:05:18 --> Router Class Initialized
INFO - 2025-11-05 00:05:18 --> Output Class Initialized
INFO - 2025-11-05 00:05:18 --> Security Class Initialized
INFO - 2025-11-05 00:05:18 --> Input Class Initialized
INFO - 2025-11-05 00:05:18 --> Language Class Initialized
INFO - 2025-11-05 00:05:18 --> Loader Class Initialized
INFO - 2025-11-05 00:05:18 --> Helper loaded: url_helper
INFO - 2025-11-05 00:05:18 --> Helper loaded: file_helper
INFO - 2025-11-05 00:05:18 --> Helper loaded: main_helper
INFO - 2025-11-05 00:05:18 --> Database Driver Class Initialized
INFO - 2025-11-05 00:05:18 --> Email Class Initialized
DEBUG - 2025-11-05 00:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 00:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 00:05:18 --> Controller Class Initialized
INFO - 2025-11-05 00:05:18 --> API /auth/forgot_password invoked
INFO - 2025-11-05 00:05:18 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-05 00:05:18 --> Final output sent to browser
INFO - 2025-11-05 00:05:18 --> Total execution time: 0.0742
INFO - 2025-11-05 00:05:21 --> Config Class Initialized
INFO - 2025-11-05 00:05:21 --> Hooks Class Initialized
INFO - 2025-11-05 00:05:21 --> UTF-8 Support Enabled
INFO - 2025-11-05 00:05:21 --> Utf8 Class Initialized
INFO - 2025-11-05 00:05:21 --> URI Class Initialized
INFO - 2025-11-05 00:05:21 --> Router Class Initialized
INFO - 2025-11-05 00:05:21 --> Output Class Initialized
INFO - 2025-11-05 00:05:21 --> Security Class Initialized
INFO - 2025-11-05 00:05:21 --> Input Class Initialized
INFO - 2025-11-05 00:05:21 --> Language Class Initialized
INFO - 2025-11-05 00:05:21 --> Loader Class Initialized
INFO - 2025-11-05 00:05:21 --> Helper loaded: url_helper
INFO - 2025-11-05 00:05:21 --> Helper loaded: file_helper
INFO - 2025-11-05 00:05:21 --> Helper loaded: main_helper
INFO - 2025-11-05 00:05:21 --> Database Driver Class Initialized
INFO - 2025-11-05 00:05:21 --> Email Class Initialized
DEBUG - 2025-11-05 00:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 00:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 00:05:21 --> Controller Class Initialized
INFO - 2025-11-05 00:05:21 --> Model "Subscription_model" initialized
INFO - 2025-11-05 00:05:21 --> Model "User_model" initialized
INFO - 2025-11-05 00:05:21 --> Model "Auth_model" initialized
INFO - 2025-11-05 00:05:21 --> API /auth/forgot_password invoked; email payload="cranam21@gmail.com"
INFO - 2025-11-05 00:05:21 --> Forgot password requested for active user cranam21@gmail.com (id=1)
DEBUG - 2025-11-05 00:05:21 --> Email class already loaded. Second attempt ignored.
INFO - 2025-11-05 00:05:32 --> Language file loaded: language/english/email_lang.php
ERROR - 2025-11-05 00:05:39 --> Mailjet send error: <br /><pre>hello: 554 5.5.0 Error: SMTP protocol synchronization
</pre>The following SMTP error was encountered: 554 5.5.0 Error: SMTP protocol synchronization
<br /><pre>starttls: </pre>The following SMTP error was encountered: <br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Wed, 5 Nov 2025 00:05:21 +0000
From: &quot;Acumena&quot; &lt;anam@sevencols.com&gt;
Return-Path: &lt;anam@sevencols.com&gt;
To: cranam21@gmail.com
Subject: =?UTF-8?Q?Reset=20Password=20Instructions?=
Reply-To: &lt;anam@sevencols.com&gt;
User-Agent: CI3-Hostinger
X-Sender: anam@sevencols.com
X-Mailer: CI3-Hostinger
X-Priority: 3 (Normal)
Message-ID: &lt;690a94c1d4646@sevencols.com&gt;
Mime-Version: 1.0

</pre>
ERROR - 2025-11-05 00:05:39 --> Reset password email failed for cranam21@gmail.com
INFO - 2025-11-05 00:05:39 --> API forgot_password processed for email: cranam21@gmail.com
INFO - 2025-11-05 00:05:39 --> Final output sent to browser
INFO - 2025-11-05 00:05:39 --> Total execution time: 18.0865
INFO - 2025-11-05 00:09:10 --> Config Class Initialized
INFO - 2025-11-05 00:09:10 --> Hooks Class Initialized
INFO - 2025-11-05 00:09:10 --> UTF-8 Support Enabled
INFO - 2025-11-05 00:09:10 --> Utf8 Class Initialized
INFO - 2025-11-05 00:09:10 --> URI Class Initialized
INFO - 2025-11-05 00:09:10 --> Router Class Initialized
INFO - 2025-11-05 00:09:10 --> Output Class Initialized
INFO - 2025-11-05 00:09:10 --> Security Class Initialized
INFO - 2025-11-05 00:09:10 --> Input Class Initialized
INFO - 2025-11-05 00:09:10 --> Language Class Initialized
INFO - 2025-11-05 00:09:10 --> Loader Class Initialized
INFO - 2025-11-05 00:09:10 --> Helper loaded: url_helper
INFO - 2025-11-05 00:09:10 --> Helper loaded: file_helper
INFO - 2025-11-05 00:09:10 --> Helper loaded: main_helper
INFO - 2025-11-05 00:09:10 --> Database Driver Class Initialized
INFO - 2025-11-05 00:09:10 --> Email Class Initialized
DEBUG - 2025-11-05 00:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 00:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 00:09:10 --> Controller Class Initialized
INFO - 2025-11-05 00:09:10 --> Model "Subscription_model" initialized
INFO - 2025-11-05 00:09:10 --> Model "User_model" initialized
INFO - 2025-11-05 00:09:10 --> Model "Auth_model" initialized
INFO - 2025-11-05 00:09:10 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-05 00:09:10 --> Final output sent to browser
INFO - 2025-11-05 00:09:10 --> Total execution time: 0.0556
INFO - 2025-11-05 00:09:14 --> Config Class Initialized
INFO - 2025-11-05 00:09:14 --> Hooks Class Initialized
INFO - 2025-11-05 00:09:14 --> UTF-8 Support Enabled
INFO - 2025-11-05 00:09:14 --> Utf8 Class Initialized
INFO - 2025-11-05 00:09:14 --> URI Class Initialized
INFO - 2025-11-05 00:09:14 --> Router Class Initialized
INFO - 2025-11-05 00:09:14 --> Output Class Initialized
INFO - 2025-11-05 00:09:14 --> Security Class Initialized
INFO - 2025-11-05 00:09:14 --> Input Class Initialized
INFO - 2025-11-05 00:09:14 --> Language Class Initialized
INFO - 2025-11-05 00:09:14 --> Loader Class Initialized
INFO - 2025-11-05 00:09:15 --> Helper loaded: url_helper
INFO - 2025-11-05 00:09:15 --> Helper loaded: file_helper
INFO - 2025-11-05 00:09:15 --> Helper loaded: main_helper
INFO - 2025-11-05 00:09:15 --> Database Driver Class Initialized
INFO - 2025-11-05 00:09:15 --> Email Class Initialized
DEBUG - 2025-11-05 00:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 00:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 00:09:15 --> Controller Class Initialized
INFO - 2025-11-05 00:09:15 --> Model "Subscription_model" initialized
INFO - 2025-11-05 00:09:15 --> Model "User_model" initialized
INFO - 2025-11-05 00:09:15 --> Model "Auth_model" initialized
INFO - 2025-11-05 00:09:15 --> File loaded: D:\laragon\www\acumena\application\views\auth/register.php
INFO - 2025-11-05 00:09:15 --> Final output sent to browser
INFO - 2025-11-05 00:09:15 --> Total execution time: 0.0683
INFO - 2025-11-05 00:09:34 --> Config Class Initialized
INFO - 2025-11-05 00:09:34 --> Hooks Class Initialized
INFO - 2025-11-05 00:09:34 --> UTF-8 Support Enabled
INFO - 2025-11-05 00:09:34 --> Utf8 Class Initialized
INFO - 2025-11-05 00:09:34 --> URI Class Initialized
INFO - 2025-11-05 00:09:35 --> Router Class Initialized
INFO - 2025-11-05 00:09:35 --> Output Class Initialized
INFO - 2025-11-05 00:09:35 --> Security Class Initialized
INFO - 2025-11-05 00:09:35 --> Input Class Initialized
INFO - 2025-11-05 00:09:35 --> Language Class Initialized
INFO - 2025-11-05 00:09:35 --> Loader Class Initialized
INFO - 2025-11-05 00:09:35 --> Helper loaded: url_helper
INFO - 2025-11-05 00:09:35 --> Helper loaded: file_helper
INFO - 2025-11-05 00:09:35 --> Helper loaded: main_helper
INFO - 2025-11-05 00:09:35 --> Database Driver Class Initialized
INFO - 2025-11-05 00:09:35 --> Email Class Initialized
DEBUG - 2025-11-05 00:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 00:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 00:09:35 --> Controller Class Initialized
INFO - 2025-11-05 00:09:35 --> Model "Subscription_model" initialized
INFO - 2025-11-05 00:09:35 --> Model "User_model" initialized
INFO - 2025-11-05 00:09:35 --> Model "Auth_model" initialized
DEBUG - 2025-11-05 00:09:35 --> Email class already loaded. Second attempt ignored.
INFO - 2025-11-05 00:09:45 --> Language file loaded: language/english/email_lang.php
ERROR - 2025-11-05 00:09:53 --> Mailjet send error: <br /><pre>hello: 554 5.5.0 Error: SMTP protocol synchronization
</pre>The following SMTP error was encountered: 554 5.5.0 Error: SMTP protocol synchronization
<br /><pre>starttls: </pre>The following SMTP error was encountered: <br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Wed, 5 Nov 2025 00:09:35 +0000
From: &quot;Acumena&quot; &lt;anam@sevencols.com&gt;
Return-Path: &lt;anam@sevencols.com&gt;
To: sevencols@gmail.com
Subject: =?UTF-8?Q?Verify=20Account?=
Reply-To: &lt;anam@sevencols.com&gt;
User-Agent: CI3-Hostinger
X-Sender: anam@sevencols.com
X-Mailer: CI3-Hostinger
X-Priority: 3 (Normal)
Message-ID: &lt;690a95bf26035@sevencols.com&gt;
Mime-Version: 1.0

</pre>
INFO - 2025-11-05 00:09:53 --> Final output sent to browser
INFO - 2025-11-05 00:09:53 --> Total execution time: 18.8767
INFO - 2025-11-05 00:09:55 --> Config Class Initialized
INFO - 2025-11-05 00:09:55 --> Hooks Class Initialized
INFO - 2025-11-05 00:09:55 --> UTF-8 Support Enabled
INFO - 2025-11-05 00:09:55 --> Utf8 Class Initialized
INFO - 2025-11-05 00:09:55 --> URI Class Initialized
INFO - 2025-11-05 00:09:55 --> Router Class Initialized
INFO - 2025-11-05 00:09:55 --> Output Class Initialized
INFO - 2025-11-05 00:09:55 --> Security Class Initialized
INFO - 2025-11-05 00:09:55 --> Input Class Initialized
INFO - 2025-11-05 00:09:55 --> Language Class Initialized
INFO - 2025-11-05 00:09:55 --> Loader Class Initialized
INFO - 2025-11-05 00:09:55 --> Helper loaded: url_helper
INFO - 2025-11-05 00:09:55 --> Helper loaded: file_helper
INFO - 2025-11-05 00:09:55 --> Helper loaded: main_helper
INFO - 2025-11-05 00:09:55 --> Database Driver Class Initialized
INFO - 2025-11-05 00:09:55 --> Email Class Initialized
DEBUG - 2025-11-05 00:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 00:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 00:09:55 --> Controller Class Initialized
INFO - 2025-11-05 00:09:55 --> Model "Subscription_model" initialized
INFO - 2025-11-05 00:09:55 --> Model "User_model" initialized
INFO - 2025-11-05 00:09:55 --> Model "Auth_model" initialized
INFO - 2025-11-05 00:09:55 --> File loaded: D:\laragon\www\acumena\application\views\auth/verify.php
INFO - 2025-11-05 00:09:55 --> Final output sent to browser
INFO - 2025-11-05 00:09:55 --> Total execution time: 0.0538
INFO - 2025-11-05 00:38:04 --> Config Class Initialized
INFO - 2025-11-05 00:38:04 --> Hooks Class Initialized
INFO - 2025-11-05 00:38:04 --> UTF-8 Support Enabled
INFO - 2025-11-05 00:38:04 --> Utf8 Class Initialized
INFO - 2025-11-05 00:38:04 --> URI Class Initialized
INFO - 2025-11-05 00:38:04 --> Router Class Initialized
INFO - 2025-11-05 00:38:04 --> Output Class Initialized
INFO - 2025-11-05 00:38:04 --> Security Class Initialized
INFO - 2025-11-05 00:38:04 --> Input Class Initialized
INFO - 2025-11-05 00:38:04 --> Language Class Initialized
INFO - 2025-11-05 00:38:04 --> Loader Class Initialized
INFO - 2025-11-05 00:38:04 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 00:38:04 --> Helper loaded: url_helper
INFO - 2025-11-05 00:38:04 --> Helper loaded: file_helper
INFO - 2025-11-05 00:38:04 --> Helper loaded: main_helper
INFO - 2025-11-05 00:38:04 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 00:38:04 --> Database Driver Class Initialized
INFO - 2025-11-05 00:38:04 --> Email Class Initialized
DEBUG - 2025-11-05 00:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 00:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 00:38:04 --> Controller Class Initialized
INFO - 2025-11-05 00:38:06 --> Final output sent to browser
INFO - 2025-11-05 00:38:06 --> Total execution time: 1.6921
INFO - 2025-11-05 01:05:32 --> Config Class Initialized
INFO - 2025-11-05 01:05:32 --> Hooks Class Initialized
INFO - 2025-11-05 01:05:33 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:05:33 --> Utf8 Class Initialized
INFO - 2025-11-05 01:05:33 --> URI Class Initialized
INFO - 2025-11-05 01:05:33 --> Router Class Initialized
INFO - 2025-11-05 01:05:33 --> Output Class Initialized
INFO - 2025-11-05 01:05:33 --> Security Class Initialized
INFO - 2025-11-05 01:05:33 --> Input Class Initialized
INFO - 2025-11-05 01:05:33 --> Language Class Initialized
INFO - 2025-11-05 01:05:33 --> Loader Class Initialized
INFO - 2025-11-05 01:05:33 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:05:33 --> Helper loaded: url_helper
INFO - 2025-11-05 01:05:33 --> Helper loaded: file_helper
INFO - 2025-11-05 01:05:33 --> Helper loaded: main_helper
INFO - 2025-11-05 01:05:33 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:05:34 --> Database Driver Class Initialized
INFO - 2025-11-05 01:05:34 --> Email Class Initialized
DEBUG - 2025-11-05 01:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:05:34 --> Controller Class Initialized
INFO - 2025-11-05 01:05:36 --> Final output sent to browser
INFO - 2025-11-05 01:05:36 --> Total execution time: 3.3713
INFO - 2025-11-05 01:07:37 --> Config Class Initialized
INFO - 2025-11-05 01:07:37 --> Hooks Class Initialized
INFO - 2025-11-05 01:07:37 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:07:37 --> Utf8 Class Initialized
INFO - 2025-11-05 01:07:37 --> URI Class Initialized
DEBUG - 2025-11-05 01:07:37 --> No URI present. Default controller set.
INFO - 2025-11-05 01:07:37 --> Router Class Initialized
INFO - 2025-11-05 01:07:37 --> Output Class Initialized
INFO - 2025-11-05 01:07:37 --> Security Class Initialized
INFO - 2025-11-05 01:07:37 --> Input Class Initialized
INFO - 2025-11-05 01:07:37 --> Language Class Initialized
INFO - 2025-11-05 01:07:37 --> Loader Class Initialized
INFO - 2025-11-05 01:07:37 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:07:37 --> Helper loaded: url_helper
INFO - 2025-11-05 01:07:37 --> Helper loaded: file_helper
INFO - 2025-11-05 01:07:37 --> Helper loaded: main_helper
INFO - 2025-11-05 01:07:37 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:07:37 --> Database Driver Class Initialized
INFO - 2025-11-05 01:07:37 --> Email Class Initialized
DEBUG - 2025-11-05 01:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:07:37 --> Controller Class Initialized
INFO - 2025-11-05 01:07:37 --> Config Class Initialized
INFO - 2025-11-05 01:07:37 --> Hooks Class Initialized
INFO - 2025-11-05 01:07:37 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:07:37 --> Utf8 Class Initialized
INFO - 2025-11-05 01:07:37 --> URI Class Initialized
INFO - 2025-11-05 01:07:37 --> Router Class Initialized
INFO - 2025-11-05 01:07:37 --> Output Class Initialized
INFO - 2025-11-05 01:07:37 --> Security Class Initialized
INFO - 2025-11-05 01:07:37 --> Input Class Initialized
INFO - 2025-11-05 01:07:37 --> Language Class Initialized
INFO - 2025-11-05 01:07:37 --> Loader Class Initialized
INFO - 2025-11-05 01:07:37 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:07:37 --> Helper loaded: url_helper
INFO - 2025-11-05 01:07:37 --> Helper loaded: file_helper
INFO - 2025-11-05 01:07:37 --> Helper loaded: main_helper
INFO - 2025-11-05 01:07:37 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:07:37 --> Database Driver Class Initialized
INFO - 2025-11-05 01:07:37 --> Email Class Initialized
DEBUG - 2025-11-05 01:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:07:37 --> Controller Class Initialized
INFO - 2025-11-05 01:07:37 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:07:37 --> Model "User_model" initialized
INFO - 2025-11-05 01:07:37 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:07:37 --> Config Class Initialized
INFO - 2025-11-05 01:07:37 --> Hooks Class Initialized
INFO - 2025-11-05 01:07:37 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:07:37 --> Utf8 Class Initialized
INFO - 2025-11-05 01:07:37 --> URI Class Initialized
INFO - 2025-11-05 01:07:37 --> Router Class Initialized
INFO - 2025-11-05 01:07:37 --> Output Class Initialized
INFO - 2025-11-05 01:07:37 --> Security Class Initialized
INFO - 2025-11-05 01:07:37 --> Input Class Initialized
INFO - 2025-11-05 01:07:37 --> Language Class Initialized
INFO - 2025-11-05 01:07:37 --> Loader Class Initialized
INFO - 2025-11-05 01:07:37 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:07:37 --> Helper loaded: url_helper
INFO - 2025-11-05 01:07:37 --> Helper loaded: file_helper
INFO - 2025-11-05 01:07:37 --> Helper loaded: main_helper
INFO - 2025-11-05 01:07:37 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:07:37 --> Database Driver Class Initialized
INFO - 2025-11-05 01:07:37 --> Email Class Initialized
DEBUG - 2025-11-05 01:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:07:37 --> Controller Class Initialized
INFO - 2025-11-05 01:07:37 --> Config Class Initialized
INFO - 2025-11-05 01:07:37 --> Hooks Class Initialized
INFO - 2025-11-05 01:07:37 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:07:37 --> Utf8 Class Initialized
INFO - 2025-11-05 01:07:37 --> URI Class Initialized
INFO - 2025-11-05 01:07:37 --> Router Class Initialized
INFO - 2025-11-05 01:07:37 --> Output Class Initialized
INFO - 2025-11-05 01:07:37 --> Security Class Initialized
INFO - 2025-11-05 01:07:37 --> Input Class Initialized
INFO - 2025-11-05 01:07:37 --> Language Class Initialized
INFO - 2025-11-05 01:07:37 --> Loader Class Initialized
INFO - 2025-11-05 01:07:37 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:07:37 --> Helper loaded: url_helper
INFO - 2025-11-05 01:07:37 --> Helper loaded: file_helper
INFO - 2025-11-05 01:07:37 --> Helper loaded: main_helper
INFO - 2025-11-05 01:07:37 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:07:37 --> Database Driver Class Initialized
INFO - 2025-11-05 01:07:37 --> Email Class Initialized
DEBUG - 2025-11-05 01:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:07:37 --> Controller Class Initialized
INFO - 2025-11-05 01:07:37 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:07:37 --> Model "User_model" initialized
INFO - 2025-11-05 01:07:37 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:07:37 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-05 01:07:37 --> Final output sent to browser
INFO - 2025-11-05 01:07:37 --> Total execution time: 0.0946
INFO - 2025-11-05 01:07:42 --> Config Class Initialized
INFO - 2025-11-05 01:07:42 --> Hooks Class Initialized
INFO - 2025-11-05 01:07:42 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:07:42 --> Utf8 Class Initialized
INFO - 2025-11-05 01:07:42 --> URI Class Initialized
INFO - 2025-11-05 01:07:42 --> Router Class Initialized
INFO - 2025-11-05 01:07:42 --> Output Class Initialized
INFO - 2025-11-05 01:07:42 --> Security Class Initialized
INFO - 2025-11-05 01:07:42 --> Input Class Initialized
INFO - 2025-11-05 01:07:42 --> Language Class Initialized
INFO - 2025-11-05 01:07:42 --> Loader Class Initialized
INFO - 2025-11-05 01:07:42 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:07:42 --> Helper loaded: url_helper
INFO - 2025-11-05 01:07:42 --> Helper loaded: file_helper
INFO - 2025-11-05 01:07:42 --> Helper loaded: main_helper
INFO - 2025-11-05 01:07:42 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:07:42 --> Database Driver Class Initialized
INFO - 2025-11-05 01:07:42 --> Email Class Initialized
DEBUG - 2025-11-05 01:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:07:42 --> Controller Class Initialized
INFO - 2025-11-05 01:07:42 --> API /auth/forgot_password invoked
INFO - 2025-11-05 01:07:42 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-05 01:07:42 --> Final output sent to browser
INFO - 2025-11-05 01:07:42 --> Total execution time: 0.1200
INFO - 2025-11-05 01:07:46 --> Config Class Initialized
INFO - 2025-11-05 01:07:46 --> Hooks Class Initialized
INFO - 2025-11-05 01:07:46 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:07:46 --> Utf8 Class Initialized
INFO - 2025-11-05 01:07:46 --> URI Class Initialized
INFO - 2025-11-05 01:07:46 --> Router Class Initialized
INFO - 2025-11-05 01:07:46 --> Output Class Initialized
INFO - 2025-11-05 01:07:46 --> Security Class Initialized
INFO - 2025-11-05 01:07:46 --> Input Class Initialized
INFO - 2025-11-05 01:07:46 --> Language Class Initialized
INFO - 2025-11-05 01:07:46 --> Loader Class Initialized
INFO - 2025-11-05 01:07:46 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:07:46 --> Helper loaded: url_helper
INFO - 2025-11-05 01:07:46 --> Helper loaded: file_helper
INFO - 2025-11-05 01:07:46 --> Helper loaded: main_helper
INFO - 2025-11-05 01:07:46 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:07:46 --> Database Driver Class Initialized
INFO - 2025-11-05 01:07:46 --> Email Class Initialized
DEBUG - 2025-11-05 01:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:07:46 --> Controller Class Initialized
INFO - 2025-11-05 01:07:46 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:07:46 --> Model "User_model" initialized
INFO - 2025-11-05 01:07:46 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:07:46 --> API /auth/forgot_password invoked; email payload="cranam21@gmail.com"
INFO - 2025-11-05 01:07:46 --> Forgot password requested for active user cranam21@gmail.com (id=1)
INFO - 2025-11-05 01:07:47 --> Reset password email sent via SendGrid to cranam21@gmail.com (code=202)
INFO - 2025-11-05 01:07:47 --> API forgot_password processed for email: cranam21@gmail.com
INFO - 2025-11-05 01:07:47 --> Final output sent to browser
INFO - 2025-11-05 01:07:47 --> Total execution time: 1.2800
INFO - 2025-11-05 01:08:05 --> Config Class Initialized
INFO - 2025-11-05 01:08:05 --> Hooks Class Initialized
INFO - 2025-11-05 01:08:05 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:08:05 --> Utf8 Class Initialized
INFO - 2025-11-05 01:08:05 --> URI Class Initialized
INFO - 2025-11-05 01:08:05 --> Router Class Initialized
INFO - 2025-11-05 01:08:05 --> Output Class Initialized
INFO - 2025-11-05 01:08:05 --> Security Class Initialized
INFO - 2025-11-05 01:08:05 --> Input Class Initialized
INFO - 2025-11-05 01:08:05 --> Language Class Initialized
INFO - 2025-11-05 01:08:05 --> Loader Class Initialized
INFO - 2025-11-05 01:08:05 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:08:05 --> Helper loaded: url_helper
INFO - 2025-11-05 01:08:05 --> Helper loaded: file_helper
INFO - 2025-11-05 01:08:05 --> Helper loaded: main_helper
INFO - 2025-11-05 01:08:05 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:08:05 --> Database Driver Class Initialized
INFO - 2025-11-05 01:08:05 --> Email Class Initialized
DEBUG - 2025-11-05 01:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:08:05 --> Controller Class Initialized
INFO - 2025-11-05 01:08:05 --> File loaded: D:\laragon\www\acumena\application\views\auth/reset_password.php
INFO - 2025-11-05 01:08:05 --> Final output sent to browser
INFO - 2025-11-05 01:08:05 --> Total execution time: 0.0596
INFO - 2025-11-05 01:09:35 --> Config Class Initialized
INFO - 2025-11-05 01:09:35 --> Hooks Class Initialized
INFO - 2025-11-05 01:09:35 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:09:35 --> Utf8 Class Initialized
INFO - 2025-11-05 01:09:35 --> URI Class Initialized
INFO - 2025-11-05 01:09:35 --> Router Class Initialized
INFO - 2025-11-05 01:09:35 --> Output Class Initialized
INFO - 2025-11-05 01:09:35 --> Security Class Initialized
INFO - 2025-11-05 01:09:35 --> Input Class Initialized
INFO - 2025-11-05 01:09:35 --> Language Class Initialized
INFO - 2025-11-05 01:09:35 --> Loader Class Initialized
INFO - 2025-11-05 01:09:35 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:09:35 --> Helper loaded: url_helper
INFO - 2025-11-05 01:09:35 --> Helper loaded: file_helper
INFO - 2025-11-05 01:09:35 --> Helper loaded: main_helper
INFO - 2025-11-05 01:09:35 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:09:35 --> Database Driver Class Initialized
INFO - 2025-11-05 01:09:35 --> Email Class Initialized
DEBUG - 2025-11-05 01:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:09:35 --> Controller Class Initialized
INFO - 2025-11-05 01:09:35 --> API /auth/forgot_password invoked
INFO - 2025-11-05 01:09:35 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-05 01:09:35 --> Final output sent to browser
INFO - 2025-11-05 01:09:35 --> Total execution time: 0.0677
INFO - 2025-11-05 01:09:41 --> Config Class Initialized
INFO - 2025-11-05 01:09:41 --> Hooks Class Initialized
INFO - 2025-11-05 01:09:41 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:09:41 --> Utf8 Class Initialized
INFO - 2025-11-05 01:09:41 --> URI Class Initialized
INFO - 2025-11-05 01:09:41 --> Router Class Initialized
INFO - 2025-11-05 01:09:41 --> Output Class Initialized
INFO - 2025-11-05 01:09:41 --> Security Class Initialized
INFO - 2025-11-05 01:09:41 --> Input Class Initialized
INFO - 2025-11-05 01:09:41 --> Language Class Initialized
INFO - 2025-11-05 01:09:41 --> Loader Class Initialized
INFO - 2025-11-05 01:09:41 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:09:41 --> Helper loaded: url_helper
INFO - 2025-11-05 01:09:41 --> Helper loaded: file_helper
INFO - 2025-11-05 01:09:41 --> Helper loaded: main_helper
INFO - 2025-11-05 01:09:41 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:09:41 --> Database Driver Class Initialized
INFO - 2025-11-05 01:09:41 --> Email Class Initialized
DEBUG - 2025-11-05 01:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:09:41 --> Controller Class Initialized
INFO - 2025-11-05 01:09:41 --> File loaded: D:\laragon\www\acumena\application\views\auth/reset_password.php
INFO - 2025-11-05 01:09:41 --> Final output sent to browser
INFO - 2025-11-05 01:09:41 --> Total execution time: 0.0453
INFO - 2025-11-05 01:10:06 --> Config Class Initialized
INFO - 2025-11-05 01:10:06 --> Hooks Class Initialized
INFO - 2025-11-05 01:10:06 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:10:06 --> Utf8 Class Initialized
INFO - 2025-11-05 01:10:06 --> URI Class Initialized
INFO - 2025-11-05 01:10:06 --> Router Class Initialized
INFO - 2025-11-05 01:10:06 --> Output Class Initialized
INFO - 2025-11-05 01:10:06 --> Security Class Initialized
INFO - 2025-11-05 01:10:06 --> Input Class Initialized
INFO - 2025-11-05 01:10:06 --> Language Class Initialized
INFO - 2025-11-05 01:10:06 --> Loader Class Initialized
INFO - 2025-11-05 01:10:06 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:10:06 --> Helper loaded: url_helper
INFO - 2025-11-05 01:10:06 --> Helper loaded: file_helper
INFO - 2025-11-05 01:10:06 --> Helper loaded: main_helper
INFO - 2025-11-05 01:10:06 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:10:06 --> Database Driver Class Initialized
INFO - 2025-11-05 01:10:06 --> Email Class Initialized
DEBUG - 2025-11-05 01:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:10:06 --> Controller Class Initialized
INFO - 2025-11-05 01:10:06 --> File loaded: D:\laragon\www\acumena\application\views\auth/reset_password.php
INFO - 2025-11-05 01:10:06 --> Final output sent to browser
INFO - 2025-11-05 01:10:06 --> Total execution time: 0.0625
INFO - 2025-11-05 01:10:30 --> Config Class Initialized
INFO - 2025-11-05 01:10:30 --> Hooks Class Initialized
INFO - 2025-11-05 01:10:30 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:10:30 --> Utf8 Class Initialized
INFO - 2025-11-05 01:10:30 --> URI Class Initialized
INFO - 2025-11-05 01:10:30 --> Router Class Initialized
INFO - 2025-11-05 01:10:30 --> Output Class Initialized
INFO - 2025-11-05 01:10:30 --> Security Class Initialized
INFO - 2025-11-05 01:10:30 --> Input Class Initialized
INFO - 2025-11-05 01:10:30 --> Language Class Initialized
INFO - 2025-11-05 01:10:30 --> Loader Class Initialized
INFO - 2025-11-05 01:10:30 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:10:30 --> Helper loaded: url_helper
INFO - 2025-11-05 01:10:30 --> Helper loaded: file_helper
INFO - 2025-11-05 01:10:30 --> Helper loaded: main_helper
INFO - 2025-11-05 01:10:30 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:10:30 --> Database Driver Class Initialized
INFO - 2025-11-05 01:10:30 --> Email Class Initialized
DEBUG - 2025-11-05 01:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:10:30 --> Controller Class Initialized
INFO - 2025-11-05 01:10:30 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:10:30 --> Model "User_model" initialized
INFO - 2025-11-05 01:10:30 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:10:30 --> Final output sent to browser
INFO - 2025-11-05 01:10:30 --> Total execution time: 0.0573
INFO - 2025-11-05 01:12:40 --> Config Class Initialized
INFO - 2025-11-05 01:12:40 --> Hooks Class Initialized
INFO - 2025-11-05 01:12:40 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:12:40 --> Utf8 Class Initialized
INFO - 2025-11-05 01:12:40 --> URI Class Initialized
INFO - 2025-11-05 01:12:40 --> Router Class Initialized
INFO - 2025-11-05 01:12:40 --> Output Class Initialized
INFO - 2025-11-05 01:12:40 --> Security Class Initialized
INFO - 2025-11-05 01:12:40 --> Input Class Initialized
INFO - 2025-11-05 01:12:40 --> Language Class Initialized
INFO - 2025-11-05 01:12:41 --> Loader Class Initialized
INFO - 2025-11-05 01:12:41 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:12:41 --> Helper loaded: url_helper
INFO - 2025-11-05 01:12:41 --> Helper loaded: file_helper
INFO - 2025-11-05 01:12:41 --> Helper loaded: main_helper
INFO - 2025-11-05 01:12:41 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:12:41 --> Database Driver Class Initialized
INFO - 2025-11-05 01:12:41 --> Email Class Initialized
DEBUG - 2025-11-05 01:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:12:41 --> Controller Class Initialized
INFO - 2025-11-05 01:12:41 --> File loaded: D:\laragon\www\acumena\application\views\auth/reset_password.php
INFO - 2025-11-05 01:12:41 --> Final output sent to browser
INFO - 2025-11-05 01:12:41 --> Total execution time: 0.1240
INFO - 2025-11-05 01:12:53 --> Config Class Initialized
INFO - 2025-11-05 01:12:53 --> Hooks Class Initialized
INFO - 2025-11-05 01:12:53 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:12:53 --> Utf8 Class Initialized
INFO - 2025-11-05 01:12:53 --> URI Class Initialized
INFO - 2025-11-05 01:12:53 --> Router Class Initialized
INFO - 2025-11-05 01:12:53 --> Output Class Initialized
INFO - 2025-11-05 01:12:53 --> Security Class Initialized
INFO - 2025-11-05 01:12:53 --> Input Class Initialized
INFO - 2025-11-05 01:12:53 --> Language Class Initialized
INFO - 2025-11-05 01:12:53 --> Loader Class Initialized
INFO - 2025-11-05 01:12:53 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:12:53 --> Helper loaded: url_helper
INFO - 2025-11-05 01:12:53 --> Helper loaded: file_helper
INFO - 2025-11-05 01:12:53 --> Helper loaded: main_helper
INFO - 2025-11-05 01:12:53 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:12:53 --> Database Driver Class Initialized
INFO - 2025-11-05 01:12:53 --> Email Class Initialized
DEBUG - 2025-11-05 01:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:12:53 --> Controller Class Initialized
INFO - 2025-11-05 01:12:53 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:12:53 --> Model "User_model" initialized
INFO - 2025-11-05 01:12:53 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:12:53 --> Final output sent to browser
INFO - 2025-11-05 01:12:53 --> Total execution time: 0.0720
INFO - 2025-11-05 01:14:47 --> Config Class Initialized
INFO - 2025-11-05 01:14:47 --> Hooks Class Initialized
INFO - 2025-11-05 01:14:47 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:14:47 --> Utf8 Class Initialized
INFO - 2025-11-05 01:14:47 --> URI Class Initialized
INFO - 2025-11-05 01:14:47 --> Router Class Initialized
INFO - 2025-11-05 01:14:47 --> Output Class Initialized
INFO - 2025-11-05 01:14:47 --> Security Class Initialized
INFO - 2025-11-05 01:14:47 --> Input Class Initialized
INFO - 2025-11-05 01:14:47 --> Language Class Initialized
INFO - 2025-11-05 01:14:47 --> Loader Class Initialized
INFO - 2025-11-05 01:14:47 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:14:47 --> Helper loaded: url_helper
INFO - 2025-11-05 01:14:47 --> Helper loaded: file_helper
INFO - 2025-11-05 01:14:47 --> Helper loaded: main_helper
INFO - 2025-11-05 01:14:47 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:14:47 --> Database Driver Class Initialized
INFO - 2025-11-05 01:14:47 --> Email Class Initialized
DEBUG - 2025-11-05 01:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:14:47 --> Controller Class Initialized
INFO - 2025-11-05 01:14:47 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:14:47 --> Model "User_model" initialized
INFO - 2025-11-05 01:14:47 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:14:47 --> Final output sent to browser
INFO - 2025-11-05 01:14:47 --> Total execution time: 0.0640
INFO - 2025-11-05 01:15:29 --> Config Class Initialized
INFO - 2025-11-05 01:15:29 --> Hooks Class Initialized
INFO - 2025-11-05 01:15:29 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:15:29 --> Utf8 Class Initialized
INFO - 2025-11-05 01:15:29 --> URI Class Initialized
INFO - 2025-11-05 01:15:29 --> Router Class Initialized
INFO - 2025-11-05 01:15:29 --> Output Class Initialized
INFO - 2025-11-05 01:15:29 --> Security Class Initialized
INFO - 2025-11-05 01:15:29 --> Input Class Initialized
INFO - 2025-11-05 01:15:29 --> Language Class Initialized
INFO - 2025-11-05 01:15:29 --> Loader Class Initialized
INFO - 2025-11-05 01:15:29 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:15:29 --> Helper loaded: url_helper
INFO - 2025-11-05 01:15:29 --> Helper loaded: file_helper
INFO - 2025-11-05 01:15:29 --> Helper loaded: main_helper
INFO - 2025-11-05 01:15:29 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:15:29 --> Database Driver Class Initialized
INFO - 2025-11-05 01:15:29 --> Email Class Initialized
DEBUG - 2025-11-05 01:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:15:29 --> Controller Class Initialized
INFO - 2025-11-05 01:15:29 --> File loaded: D:\laragon\www\acumena\application\views\auth/reset_password.php
INFO - 2025-11-05 01:15:29 --> Final output sent to browser
INFO - 2025-11-05 01:15:29 --> Total execution time: 0.0560
INFO - 2025-11-05 01:15:43 --> Config Class Initialized
INFO - 2025-11-05 01:15:43 --> Hooks Class Initialized
INFO - 2025-11-05 01:15:43 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:15:43 --> Utf8 Class Initialized
INFO - 2025-11-05 01:15:43 --> URI Class Initialized
INFO - 2025-11-05 01:15:43 --> Router Class Initialized
INFO - 2025-11-05 01:15:43 --> Output Class Initialized
INFO - 2025-11-05 01:15:43 --> Security Class Initialized
INFO - 2025-11-05 01:15:43 --> Input Class Initialized
INFO - 2025-11-05 01:15:43 --> Language Class Initialized
INFO - 2025-11-05 01:15:43 --> Loader Class Initialized
INFO - 2025-11-05 01:15:43 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:15:43 --> Helper loaded: url_helper
INFO - 2025-11-05 01:15:43 --> Helper loaded: file_helper
INFO - 2025-11-05 01:15:43 --> Helper loaded: main_helper
INFO - 2025-11-05 01:15:43 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:15:43 --> Database Driver Class Initialized
INFO - 2025-11-05 01:15:43 --> Email Class Initialized
DEBUG - 2025-11-05 01:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:15:43 --> Controller Class Initialized
INFO - 2025-11-05 01:15:43 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:15:43 --> Model "User_model" initialized
INFO - 2025-11-05 01:15:43 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:15:43 --> Final output sent to browser
INFO - 2025-11-05 01:15:43 --> Total execution time: 0.0660
INFO - 2025-11-05 01:18:41 --> Config Class Initialized
INFO - 2025-11-05 01:18:41 --> Hooks Class Initialized
INFO - 2025-11-05 01:18:41 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:18:41 --> Utf8 Class Initialized
INFO - 2025-11-05 01:18:41 --> URI Class Initialized
INFO - 2025-11-05 01:18:41 --> Router Class Initialized
INFO - 2025-11-05 01:18:41 --> Output Class Initialized
INFO - 2025-11-05 01:18:41 --> Security Class Initialized
INFO - 2025-11-05 01:18:41 --> Input Class Initialized
INFO - 2025-11-05 01:18:41 --> Language Class Initialized
INFO - 2025-11-05 01:18:41 --> Loader Class Initialized
INFO - 2025-11-05 01:18:41 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:18:41 --> Helper loaded: url_helper
INFO - 2025-11-05 01:18:41 --> Helper loaded: file_helper
INFO - 2025-11-05 01:18:41 --> Helper loaded: main_helper
INFO - 2025-11-05 01:18:41 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:18:41 --> Database Driver Class Initialized
INFO - 2025-11-05 01:18:41 --> Email Class Initialized
DEBUG - 2025-11-05 01:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:18:41 --> Controller Class Initialized
INFO - 2025-11-05 01:18:41 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:18:41 --> Model "User_model" initialized
INFO - 2025-11-05 01:18:41 --> Model "Auth_model" initialized
ERROR - 2025-11-05 01:18:41 --> Query error: Incorrect TIMESTAMP value: '' - Invalid query: SELECT *
FROM `users`
WHERE `email` = 'cranam21@gmail.com'
AND `is_active` = 1
AND (is_deleted IS NULL OR is_deleted = 0 OR is_deleted = "")
INFO - 2025-11-05 01:18:41 --> Language file loaded: language/english/db_lang.php
INFO - 2025-11-05 01:19:09 --> Config Class Initialized
INFO - 2025-11-05 01:19:09 --> Hooks Class Initialized
INFO - 2025-11-05 01:19:09 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:19:09 --> Utf8 Class Initialized
INFO - 2025-11-05 01:19:09 --> URI Class Initialized
INFO - 2025-11-05 01:19:09 --> Router Class Initialized
INFO - 2025-11-05 01:19:09 --> Output Class Initialized
INFO - 2025-11-05 01:19:09 --> Security Class Initialized
INFO - 2025-11-05 01:19:09 --> Input Class Initialized
INFO - 2025-11-05 01:19:09 --> Language Class Initialized
INFO - 2025-11-05 01:19:09 --> Loader Class Initialized
INFO - 2025-11-05 01:19:09 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:19:09 --> Helper loaded: url_helper
INFO - 2025-11-05 01:19:09 --> Helper loaded: file_helper
INFO - 2025-11-05 01:19:09 --> Helper loaded: main_helper
INFO - 2025-11-05 01:19:10 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:19:10 --> Database Driver Class Initialized
INFO - 2025-11-05 01:19:10 --> Email Class Initialized
DEBUG - 2025-11-05 01:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:19:10 --> Controller Class Initialized
INFO - 2025-11-05 01:19:10 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:19:10 --> Model "User_model" initialized
INFO - 2025-11-05 01:19:10 --> Model "Auth_model" initialized
ERROR - 2025-11-05 01:19:10 --> Query error: Unknown column 'is_delete' in 'where clause' - Invalid query: SELECT *
FROM `users`
WHERE `email` = 'cranam21@gmail.com'
AND `is_active` = 1
AND (is_delete IS NULL OR is_delete = 0 OR is_delete = "")
INFO - 2025-11-05 01:19:10 --> Language file loaded: language/english/db_lang.php
INFO - 2025-11-05 01:20:49 --> Config Class Initialized
INFO - 2025-11-05 01:20:49 --> Hooks Class Initialized
INFO - 2025-11-05 01:20:49 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:20:49 --> Utf8 Class Initialized
INFO - 2025-11-05 01:20:49 --> URI Class Initialized
INFO - 2025-11-05 01:20:49 --> Router Class Initialized
INFO - 2025-11-05 01:20:49 --> Output Class Initialized
INFO - 2025-11-05 01:20:49 --> Security Class Initialized
INFO - 2025-11-05 01:20:49 --> Input Class Initialized
INFO - 2025-11-05 01:20:49 --> Language Class Initialized
INFO - 2025-11-05 01:20:49 --> Loader Class Initialized
INFO - 2025-11-05 01:20:49 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:20:49 --> Helper loaded: url_helper
INFO - 2025-11-05 01:20:49 --> Helper loaded: file_helper
INFO - 2025-11-05 01:20:49 --> Helper loaded: main_helper
INFO - 2025-11-05 01:20:49 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:20:49 --> Database Driver Class Initialized
INFO - 2025-11-05 01:20:49 --> Email Class Initialized
DEBUG - 2025-11-05 01:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:20:49 --> Controller Class Initialized
INFO - 2025-11-05 01:20:49 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:20:49 --> Model "User_model" initialized
INFO - 2025-11-05 01:20:49 --> Model "Auth_model" initialized
DEBUG - 2025-11-05 01:20:49 --> Email class already loaded. Second attempt ignored.
INFO - 2025-11-05 01:20:59 --> Language file loaded: language/english/email_lang.php
ERROR - 2025-11-05 01:21:12 --> Mailjet send error: <br /><pre>hello: </pre>The following SMTP error was encountered: <br /><pre>starttls: 554 5.5.0 Error: SMTP protocol synchronization
</pre>The following SMTP error was encountered: 554 5.5.0 Error: SMTP protocol synchronization
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Wed, 5 Nov 2025 01:20:49 +0000
From: &quot;Acumena&quot; &lt;anam@sevencols.com&gt;
Return-Path: &lt;anam@sevencols.com&gt;
To: cranam21@gmail.com
Subject: =?UTF-8?Q?Password=20Changed?=
Reply-To: &lt;anam@sevencols.com&gt;
User-Agent: CI3-Hostinger
X-Sender: anam@sevencols.com
X-Mailer: CI3-Hostinger
X-Priority: 3 (Normal)
Message-ID: &lt;690aa67128659@sevencols.com&gt;
Mime-Version: 1.0

</pre>
INFO - 2025-11-05 01:21:12 --> Final output sent to browser
INFO - 2025-11-05 01:21:12 --> Total execution time: 23.3925
INFO - 2025-11-05 01:21:13 --> Config Class Initialized
INFO - 2025-11-05 01:21:13 --> Hooks Class Initialized
INFO - 2025-11-05 01:21:13 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:21:13 --> Utf8 Class Initialized
INFO - 2025-11-05 01:21:13 --> URI Class Initialized
INFO - 2025-11-05 01:21:13 --> Router Class Initialized
INFO - 2025-11-05 01:21:13 --> Output Class Initialized
INFO - 2025-11-05 01:21:13 --> Security Class Initialized
INFO - 2025-11-05 01:21:13 --> Input Class Initialized
INFO - 2025-11-05 01:21:13 --> Language Class Initialized
INFO - 2025-11-05 01:21:13 --> Loader Class Initialized
INFO - 2025-11-05 01:21:13 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:21:13 --> Helper loaded: url_helper
INFO - 2025-11-05 01:21:13 --> Helper loaded: file_helper
INFO - 2025-11-05 01:21:13 --> Helper loaded: main_helper
INFO - 2025-11-05 01:21:13 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:21:13 --> Database Driver Class Initialized
INFO - 2025-11-05 01:21:13 --> Email Class Initialized
DEBUG - 2025-11-05 01:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:21:14 --> Controller Class Initialized
INFO - 2025-11-05 01:21:14 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:21:14 --> Model "User_model" initialized
INFO - 2025-11-05 01:21:14 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:21:14 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-05 01:21:14 --> Final output sent to browser
INFO - 2025-11-05 01:21:14 --> Total execution time: 0.0777
INFO - 2025-11-05 01:21:27 --> Config Class Initialized
INFO - 2025-11-05 01:21:27 --> Hooks Class Initialized
INFO - 2025-11-05 01:21:27 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:21:27 --> Utf8 Class Initialized
INFO - 2025-11-05 01:21:27 --> URI Class Initialized
INFO - 2025-11-05 01:21:27 --> Router Class Initialized
INFO - 2025-11-05 01:21:27 --> Output Class Initialized
INFO - 2025-11-05 01:21:27 --> Security Class Initialized
INFO - 2025-11-05 01:21:27 --> Input Class Initialized
INFO - 2025-11-05 01:21:27 --> Language Class Initialized
INFO - 2025-11-05 01:21:27 --> Loader Class Initialized
INFO - 2025-11-05 01:21:27 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:21:27 --> Helper loaded: url_helper
INFO - 2025-11-05 01:21:27 --> Helper loaded: file_helper
INFO - 2025-11-05 01:21:27 --> Helper loaded: main_helper
INFO - 2025-11-05 01:21:27 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:21:27 --> Database Driver Class Initialized
INFO - 2025-11-05 01:21:27 --> Email Class Initialized
DEBUG - 2025-11-05 01:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:21:27 --> Controller Class Initialized
INFO - 2025-11-05 01:21:27 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:21:27 --> Model "User_model" initialized
INFO - 2025-11-05 01:21:27 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:21:27 --> Final output sent to browser
INFO - 2025-11-05 01:21:27 --> Total execution time: 0.0776
INFO - 2025-11-05 01:23:02 --> Config Class Initialized
INFO - 2025-11-05 01:23:02 --> Hooks Class Initialized
INFO - 2025-11-05 01:23:02 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:23:02 --> Utf8 Class Initialized
INFO - 2025-11-05 01:23:02 --> URI Class Initialized
INFO - 2025-11-05 01:23:02 --> Router Class Initialized
INFO - 2025-11-05 01:23:02 --> Output Class Initialized
INFO - 2025-11-05 01:23:02 --> Security Class Initialized
INFO - 2025-11-05 01:23:02 --> Input Class Initialized
INFO - 2025-11-05 01:23:02 --> Language Class Initialized
INFO - 2025-11-05 01:23:02 --> Loader Class Initialized
INFO - 2025-11-05 01:23:02 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:23:02 --> Helper loaded: url_helper
INFO - 2025-11-05 01:23:02 --> Helper loaded: file_helper
INFO - 2025-11-05 01:23:02 --> Helper loaded: main_helper
INFO - 2025-11-05 01:23:02 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:23:02 --> Database Driver Class Initialized
INFO - 2025-11-05 01:23:02 --> Email Class Initialized
DEBUG - 2025-11-05 01:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:23:02 --> Controller Class Initialized
INFO - 2025-11-05 01:23:02 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:23:02 --> Model "User_model" initialized
INFO - 2025-11-05 01:23:02 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:23:02 --> Final output sent to browser
INFO - 2025-11-05 01:23:02 --> Total execution time: 0.2346
INFO - 2025-11-05 01:23:03 --> Config Class Initialized
INFO - 2025-11-05 01:23:03 --> Hooks Class Initialized
INFO - 2025-11-05 01:23:03 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:23:03 --> Utf8 Class Initialized
INFO - 2025-11-05 01:23:03 --> URI Class Initialized
INFO - 2025-11-05 01:23:03 --> Router Class Initialized
INFO - 2025-11-05 01:23:03 --> Output Class Initialized
INFO - 2025-11-05 01:23:03 --> Security Class Initialized
INFO - 2025-11-05 01:23:03 --> Input Class Initialized
INFO - 2025-11-05 01:23:03 --> Language Class Initialized
INFO - 2025-11-05 01:23:03 --> Loader Class Initialized
INFO - 2025-11-05 01:23:03 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:23:03 --> Helper loaded: url_helper
INFO - 2025-11-05 01:23:03 --> Helper loaded: file_helper
INFO - 2025-11-05 01:23:03 --> Helper loaded: main_helper
INFO - 2025-11-05 01:23:03 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:23:03 --> Database Driver Class Initialized
INFO - 2025-11-05 01:23:04 --> Email Class Initialized
DEBUG - 2025-11-05 01:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:23:04 --> Controller Class Initialized
INFO - 2025-11-05 01:23:04 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:23:04 --> Model "User_model" initialized
INFO - 2025-11-05 01:23:04 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:23:04 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 01:23:04 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 01:23:04 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 01:23:04 --> File loaded: D:\laragon\www\acumena\application\views\dashboard.php
INFO - 2025-11-05 01:23:04 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 01:23:04 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 01:23:04 --> Final output sent to browser
INFO - 2025-11-05 01:23:04 --> Total execution time: 0.2909
INFO - 2025-11-05 01:23:04 --> Config Class Initialized
INFO - 2025-11-05 01:23:04 --> Hooks Class Initialized
INFO - 2025-11-05 01:23:04 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:23:04 --> Utf8 Class Initialized
INFO - 2025-11-05 01:23:04 --> URI Class Initialized
INFO - 2025-11-05 01:23:04 --> Router Class Initialized
INFO - 2025-11-05 01:23:04 --> Output Class Initialized
INFO - 2025-11-05 01:23:04 --> Security Class Initialized
INFO - 2025-11-05 01:23:04 --> Input Class Initialized
INFO - 2025-11-05 01:23:04 --> Language Class Initialized
INFO - 2025-11-05 01:23:04 --> Loader Class Initialized
INFO - 2025-11-05 01:23:04 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:23:04 --> Helper loaded: url_helper
INFO - 2025-11-05 01:23:04 --> Helper loaded: file_helper
INFO - 2025-11-05 01:23:04 --> Helper loaded: main_helper
INFO - 2025-11-05 01:23:04 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:23:04 --> Database Driver Class Initialized
INFO - 2025-11-05 01:23:04 --> Email Class Initialized
DEBUG - 2025-11-05 01:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:23:04 --> Controller Class Initialized
INFO - 2025-11-05 01:23:04 --> Model "User_model" initialized
INFO - 2025-11-05 01:23:04 --> Model "Project_model" initialized
INFO - 2025-11-05 01:23:04 --> Helper loaded: form_helper
INFO - 2025-11-05 01:23:04 --> Form Validation Class Initialized
INFO - 2025-11-05 01:23:04 --> Final output sent to browser
INFO - 2025-11-05 01:23:04 --> Total execution time: 0.0941
INFO - 2025-11-05 01:23:12 --> Config Class Initialized
INFO - 2025-11-05 01:23:12 --> Hooks Class Initialized
INFO - 2025-11-05 01:23:12 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:23:12 --> Utf8 Class Initialized
INFO - 2025-11-05 01:23:12 --> URI Class Initialized
INFO - 2025-11-05 01:23:12 --> Router Class Initialized
INFO - 2025-11-05 01:23:12 --> Output Class Initialized
INFO - 2025-11-05 01:23:12 --> Security Class Initialized
INFO - 2025-11-05 01:23:12 --> Input Class Initialized
INFO - 2025-11-05 01:23:12 --> Language Class Initialized
INFO - 2025-11-05 01:23:12 --> Loader Class Initialized
INFO - 2025-11-05 01:23:12 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:23:12 --> Helper loaded: url_helper
INFO - 2025-11-05 01:23:12 --> Helper loaded: file_helper
INFO - 2025-11-05 01:23:12 --> Helper loaded: main_helper
INFO - 2025-11-05 01:23:12 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:23:13 --> Database Driver Class Initialized
INFO - 2025-11-05 01:23:13 --> Email Class Initialized
DEBUG - 2025-11-05 01:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:23:13 --> Controller Class Initialized
INFO - 2025-11-05 01:23:13 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:23:13 --> Model "User_model" initialized
INFO - 2025-11-05 01:23:13 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:23:13 --> Model "Project_model" initialized
INFO - 2025-11-05 01:23:13 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 01:23:13 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 01:23:13 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 01:23:13 --> File loaded: D:\laragon\www\acumena\application\views\projects/profile.php
INFO - 2025-11-05 01:23:13 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 01:23:13 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 01:23:13 --> Final output sent to browser
INFO - 2025-11-05 01:23:13 --> Total execution time: 0.1456
INFO - 2025-11-05 01:23:13 --> Config Class Initialized
INFO - 2025-11-05 01:23:13 --> Hooks Class Initialized
INFO - 2025-11-05 01:23:13 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:23:13 --> Utf8 Class Initialized
INFO - 2025-11-05 01:23:13 --> URI Class Initialized
INFO - 2025-11-05 01:23:13 --> Router Class Initialized
INFO - 2025-11-05 01:23:13 --> Output Class Initialized
INFO - 2025-11-05 01:23:13 --> Security Class Initialized
INFO - 2025-11-05 01:23:13 --> Input Class Initialized
INFO - 2025-11-05 01:23:13 --> Language Class Initialized
INFO - 2025-11-05 01:23:13 --> Loader Class Initialized
INFO - 2025-11-05 01:23:13 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:23:13 --> Helper loaded: url_helper
INFO - 2025-11-05 01:23:13 --> Helper loaded: file_helper
INFO - 2025-11-05 01:23:13 --> Helper loaded: main_helper
INFO - 2025-11-05 01:23:13 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:23:13 --> Database Driver Class Initialized
INFO - 2025-11-05 01:23:13 --> Email Class Initialized
DEBUG - 2025-11-05 01:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:23:13 --> Controller Class Initialized
INFO - 2025-11-05 01:23:13 --> Model "User_model" initialized
INFO - 2025-11-05 01:23:13 --> Model "Project_model" initialized
INFO - 2025-11-05 01:23:13 --> Helper loaded: form_helper
INFO - 2025-11-05 01:23:13 --> Form Validation Class Initialized
INFO - 2025-11-05 01:23:13 --> Final output sent to browser
INFO - 2025-11-05 01:23:13 --> Total execution time: 0.0781
INFO - 2025-11-05 01:23:15 --> Config Class Initialized
INFO - 2025-11-05 01:23:15 --> Hooks Class Initialized
INFO - 2025-11-05 01:23:15 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:23:15 --> Utf8 Class Initialized
INFO - 2025-11-05 01:23:15 --> URI Class Initialized
INFO - 2025-11-05 01:23:15 --> Router Class Initialized
INFO - 2025-11-05 01:23:15 --> Output Class Initialized
INFO - 2025-11-05 01:23:15 --> Security Class Initialized
INFO - 2025-11-05 01:23:15 --> Input Class Initialized
INFO - 2025-11-05 01:23:15 --> Language Class Initialized
INFO - 2025-11-05 01:23:15 --> Loader Class Initialized
INFO - 2025-11-05 01:23:15 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:23:15 --> Helper loaded: url_helper
INFO - 2025-11-05 01:23:15 --> Helper loaded: file_helper
INFO - 2025-11-05 01:23:15 --> Helper loaded: main_helper
INFO - 2025-11-05 01:23:15 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:23:15 --> Database Driver Class Initialized
INFO - 2025-11-05 01:23:15 --> Email Class Initialized
DEBUG - 2025-11-05 01:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:23:15 --> Controller Class Initialized
INFO - 2025-11-05 01:23:15 --> Model "User_model" initialized
INFO - 2025-11-05 01:23:15 --> Model "Project_model" initialized
INFO - 2025-11-05 01:23:15 --> Helper loaded: form_helper
INFO - 2025-11-05 01:23:15 --> Form Validation Class Initialized
INFO - 2025-11-05 01:23:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-11-05 01:23:15 --> Final output sent to browser
INFO - 2025-11-05 01:23:15 --> Total execution time: 0.1080
INFO - 2025-11-05 01:23:15 --> Config Class Initialized
INFO - 2025-11-05 01:23:15 --> Hooks Class Initialized
INFO - 2025-11-05 01:23:15 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:23:15 --> Utf8 Class Initialized
INFO - 2025-11-05 01:23:15 --> URI Class Initialized
INFO - 2025-11-05 01:23:15 --> Router Class Initialized
INFO - 2025-11-05 01:23:15 --> Output Class Initialized
INFO - 2025-11-05 01:23:15 --> Security Class Initialized
INFO - 2025-11-05 01:23:15 --> Input Class Initialized
INFO - 2025-11-05 01:23:15 --> Language Class Initialized
INFO - 2025-11-05 01:23:15 --> Loader Class Initialized
INFO - 2025-11-05 01:23:15 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:23:15 --> Helper loaded: url_helper
INFO - 2025-11-05 01:23:15 --> Helper loaded: file_helper
INFO - 2025-11-05 01:23:15 --> Helper loaded: main_helper
INFO - 2025-11-05 01:23:15 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:23:15 --> Database Driver Class Initialized
INFO - 2025-11-05 01:23:15 --> Email Class Initialized
DEBUG - 2025-11-05 01:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:23:15 --> Controller Class Initialized
INFO - 2025-11-05 01:23:15 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:23:15 --> Model "User_model" initialized
INFO - 2025-11-05 01:23:15 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:23:15 --> Model "Project_model" initialized
INFO - 2025-11-05 01:23:15 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 01:23:15 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 01:23:15 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 01:23:15 --> File loaded: D:\laragon\www\acumena\application\views\projects/swot.php
INFO - 2025-11-05 01:23:15 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 01:23:15 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 01:23:15 --> Final output sent to browser
INFO - 2025-11-05 01:23:15 --> Total execution time: 0.2033
INFO - 2025-11-05 01:23:15 --> Config Class Initialized
INFO - 2025-11-05 01:23:15 --> Hooks Class Initialized
INFO - 2025-11-05 01:23:15 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:23:15 --> Utf8 Class Initialized
INFO - 2025-11-05 01:23:15 --> URI Class Initialized
INFO - 2025-11-05 01:23:15 --> Router Class Initialized
INFO - 2025-11-05 01:23:15 --> Output Class Initialized
INFO - 2025-11-05 01:23:15 --> Security Class Initialized
INFO - 2025-11-05 01:23:15 --> Input Class Initialized
INFO - 2025-11-05 01:23:15 --> Language Class Initialized
INFO - 2025-11-05 01:23:15 --> Loader Class Initialized
INFO - 2025-11-05 01:23:15 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:23:15 --> Helper loaded: url_helper
INFO - 2025-11-05 01:23:15 --> Helper loaded: file_helper
INFO - 2025-11-05 01:23:15 --> Helper loaded: main_helper
INFO - 2025-11-05 01:23:15 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:23:15 --> Database Driver Class Initialized
INFO - 2025-11-05 01:23:15 --> Email Class Initialized
DEBUG - 2025-11-05 01:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:23:15 --> Controller Class Initialized
INFO - 2025-11-05 01:23:15 --> Model "User_model" initialized
INFO - 2025-11-05 01:23:15 --> Model "Project_model" initialized
INFO - 2025-11-05 01:23:15 --> Helper loaded: form_helper
INFO - 2025-11-05 01:23:15 --> Form Validation Class Initialized
INFO - 2025-11-05 01:23:15 --> Final output sent to browser
INFO - 2025-11-05 01:23:15 --> Total execution time: 0.0868
INFO - 2025-11-05 01:23:18 --> Config Class Initialized
INFO - 2025-11-05 01:23:18 --> Hooks Class Initialized
INFO - 2025-11-05 01:23:18 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:23:18 --> Utf8 Class Initialized
INFO - 2025-11-05 01:23:18 --> URI Class Initialized
INFO - 2025-11-05 01:23:18 --> Router Class Initialized
INFO - 2025-11-05 01:23:18 --> Output Class Initialized
INFO - 2025-11-05 01:23:18 --> Security Class Initialized
INFO - 2025-11-05 01:23:18 --> Input Class Initialized
INFO - 2025-11-05 01:23:18 --> Language Class Initialized
INFO - 2025-11-05 01:23:18 --> Loader Class Initialized
INFO - 2025-11-05 01:23:18 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:23:18 --> Helper loaded: url_helper
INFO - 2025-11-05 01:23:18 --> Helper loaded: file_helper
INFO - 2025-11-05 01:23:18 --> Helper loaded: main_helper
INFO - 2025-11-05 01:23:18 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:23:18 --> Database Driver Class Initialized
INFO - 2025-11-05 01:23:18 --> Email Class Initialized
DEBUG - 2025-11-05 01:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:23:18 --> Controller Class Initialized
INFO - 2025-11-05 01:23:18 --> Model "User_model" initialized
INFO - 2025-11-05 01:23:18 --> Model "Project_model" initialized
INFO - 2025-11-05 01:23:18 --> Helper loaded: form_helper
INFO - 2025-11-05 01:23:18 --> Form Validation Class Initialized
INFO - 2025-11-05 01:23:18 --> Final output sent to browser
INFO - 2025-11-05 01:23:18 --> Total execution time: 0.0565
INFO - 2025-11-05 01:23:18 --> Config Class Initialized
INFO - 2025-11-05 01:23:18 --> Hooks Class Initialized
INFO - 2025-11-05 01:23:18 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:23:18 --> Utf8 Class Initialized
INFO - 2025-11-05 01:23:18 --> URI Class Initialized
INFO - 2025-11-05 01:23:18 --> Router Class Initialized
INFO - 2025-11-05 01:23:18 --> Output Class Initialized
INFO - 2025-11-05 01:23:18 --> Security Class Initialized
INFO - 2025-11-05 01:23:18 --> Input Class Initialized
INFO - 2025-11-05 01:23:18 --> Language Class Initialized
INFO - 2025-11-05 01:23:18 --> Loader Class Initialized
INFO - 2025-11-05 01:23:18 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:23:18 --> Helper loaded: url_helper
INFO - 2025-11-05 01:23:18 --> Helper loaded: file_helper
INFO - 2025-11-05 01:23:18 --> Helper loaded: main_helper
INFO - 2025-11-05 01:23:18 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:23:18 --> Database Driver Class Initialized
INFO - 2025-11-05 01:23:18 --> Email Class Initialized
DEBUG - 2025-11-05 01:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:23:18 --> Controller Class Initialized
INFO - 2025-11-05 01:23:18 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:23:18 --> Model "User_model" initialized
INFO - 2025-11-05 01:23:18 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:23:18 --> Model "Project_model" initialized
INFO - 2025-11-05 01:23:18 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 01:23:18 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 01:23:18 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 01:23:18 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ife.php
INFO - 2025-11-05 01:23:18 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 01:23:18 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 01:23:18 --> Final output sent to browser
INFO - 2025-11-05 01:23:18 --> Total execution time: 0.1067
INFO - 2025-11-05 01:23:18 --> Config Class Initialized
INFO - 2025-11-05 01:23:18 --> Hooks Class Initialized
INFO - 2025-11-05 01:23:18 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:23:18 --> Utf8 Class Initialized
INFO - 2025-11-05 01:23:18 --> URI Class Initialized
INFO - 2025-11-05 01:23:18 --> Router Class Initialized
INFO - 2025-11-05 01:23:18 --> Output Class Initialized
INFO - 2025-11-05 01:23:18 --> Security Class Initialized
INFO - 2025-11-05 01:23:18 --> Input Class Initialized
INFO - 2025-11-05 01:23:18 --> Language Class Initialized
INFO - 2025-11-05 01:23:18 --> Loader Class Initialized
INFO - 2025-11-05 01:23:18 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:23:18 --> Helper loaded: url_helper
INFO - 2025-11-05 01:23:18 --> Helper loaded: file_helper
INFO - 2025-11-05 01:23:18 --> Helper loaded: main_helper
INFO - 2025-11-05 01:23:18 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:23:18 --> Database Driver Class Initialized
INFO - 2025-11-05 01:23:18 --> Email Class Initialized
DEBUG - 2025-11-05 01:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:23:18 --> Controller Class Initialized
INFO - 2025-11-05 01:23:18 --> Model "User_model" initialized
INFO - 2025-11-05 01:23:18 --> Model "Project_model" initialized
INFO - 2025-11-05 01:23:18 --> Helper loaded: form_helper
INFO - 2025-11-05 01:23:18 --> Form Validation Class Initialized
INFO - 2025-11-05 01:23:18 --> Final output sent to browser
INFO - 2025-11-05 01:23:18 --> Total execution time: 0.0916
INFO - 2025-11-05 01:23:21 --> Config Class Initialized
INFO - 2025-11-05 01:23:21 --> Hooks Class Initialized
INFO - 2025-11-05 01:23:21 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:23:21 --> Utf8 Class Initialized
INFO - 2025-11-05 01:23:21 --> URI Class Initialized
INFO - 2025-11-05 01:23:21 --> Router Class Initialized
INFO - 2025-11-05 01:23:21 --> Output Class Initialized
INFO - 2025-11-05 01:23:21 --> Security Class Initialized
INFO - 2025-11-05 01:23:21 --> Input Class Initialized
INFO - 2025-11-05 01:23:21 --> Language Class Initialized
INFO - 2025-11-05 01:23:21 --> Loader Class Initialized
INFO - 2025-11-05 01:23:21 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:23:21 --> Helper loaded: url_helper
INFO - 2025-11-05 01:23:21 --> Helper loaded: file_helper
INFO - 2025-11-05 01:23:21 --> Helper loaded: main_helper
INFO - 2025-11-05 01:23:21 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:23:21 --> Database Driver Class Initialized
INFO - 2025-11-05 01:23:21 --> Email Class Initialized
DEBUG - 2025-11-05 01:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:23:21 --> Controller Class Initialized
INFO - 2025-11-05 01:23:21 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:23:21 --> Model "User_model" initialized
INFO - 2025-11-05 01:23:21 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:23:21 --> Model "Project_model" initialized
INFO - 2025-11-05 01:23:21 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 01:23:21 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 01:23:21 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 01:23:21 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-efe.php
INFO - 2025-11-05 01:23:21 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 01:23:21 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 01:23:21 --> Final output sent to browser
INFO - 2025-11-05 01:23:21 --> Total execution time: 0.1025
INFO - 2025-11-05 01:23:21 --> Config Class Initialized
INFO - 2025-11-05 01:23:21 --> Hooks Class Initialized
INFO - 2025-11-05 01:23:21 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:23:21 --> Utf8 Class Initialized
INFO - 2025-11-05 01:23:21 --> URI Class Initialized
INFO - 2025-11-05 01:23:21 --> Router Class Initialized
INFO - 2025-11-05 01:23:21 --> Output Class Initialized
INFO - 2025-11-05 01:23:21 --> Security Class Initialized
INFO - 2025-11-05 01:23:21 --> Input Class Initialized
INFO - 2025-11-05 01:23:21 --> Language Class Initialized
INFO - 2025-11-05 01:23:21 --> Loader Class Initialized
INFO - 2025-11-05 01:23:21 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:23:21 --> Helper loaded: url_helper
INFO - 2025-11-05 01:23:21 --> Helper loaded: file_helper
INFO - 2025-11-05 01:23:21 --> Helper loaded: main_helper
INFO - 2025-11-05 01:23:21 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:23:21 --> Database Driver Class Initialized
INFO - 2025-11-05 01:23:21 --> Email Class Initialized
DEBUG - 2025-11-05 01:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:23:21 --> Controller Class Initialized
INFO - 2025-11-05 01:23:21 --> Model "User_model" initialized
INFO - 2025-11-05 01:23:21 --> Model "Project_model" initialized
INFO - 2025-11-05 01:23:21 --> Helper loaded: form_helper
INFO - 2025-11-05 01:23:21 --> Form Validation Class Initialized
INFO - 2025-11-05 01:23:21 --> Final output sent to browser
INFO - 2025-11-05 01:23:21 --> Total execution time: 0.0659
INFO - 2025-11-05 01:23:24 --> Config Class Initialized
INFO - 2025-11-05 01:23:24 --> Hooks Class Initialized
INFO - 2025-11-05 01:23:24 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:23:24 --> Utf8 Class Initialized
INFO - 2025-11-05 01:23:24 --> URI Class Initialized
INFO - 2025-11-05 01:23:24 --> Router Class Initialized
INFO - 2025-11-05 01:23:24 --> Output Class Initialized
INFO - 2025-11-05 01:23:24 --> Security Class Initialized
INFO - 2025-11-05 01:23:24 --> Input Class Initialized
INFO - 2025-11-05 01:23:24 --> Language Class Initialized
INFO - 2025-11-05 01:23:24 --> Loader Class Initialized
INFO - 2025-11-05 01:23:24 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:23:24 --> Helper loaded: url_helper
INFO - 2025-11-05 01:23:24 --> Helper loaded: file_helper
INFO - 2025-11-05 01:23:24 --> Helper loaded: main_helper
INFO - 2025-11-05 01:23:24 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:23:24 --> Database Driver Class Initialized
INFO - 2025-11-05 01:23:24 --> Email Class Initialized
DEBUG - 2025-11-05 01:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:23:24 --> Controller Class Initialized
INFO - 2025-11-05 01:23:24 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:23:24 --> Model "User_model" initialized
INFO - 2025-11-05 01:23:24 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:23:24 --> Model "Project_model" initialized
INFO - 2025-11-05 01:23:24 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 01:23:24 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 01:23:24 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 01:23:24 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ie.php
INFO - 2025-11-05 01:23:24 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 01:23:24 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 01:23:24 --> Final output sent to browser
INFO - 2025-11-05 01:23:24 --> Total execution time: 0.0730
INFO - 2025-11-05 01:23:24 --> Config Class Initialized
INFO - 2025-11-05 01:23:24 --> Hooks Class Initialized
INFO - 2025-11-05 01:23:24 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:23:24 --> Utf8 Class Initialized
INFO - 2025-11-05 01:23:24 --> URI Class Initialized
INFO - 2025-11-05 01:23:24 --> Router Class Initialized
INFO - 2025-11-05 01:23:24 --> Output Class Initialized
INFO - 2025-11-05 01:23:24 --> Security Class Initialized
INFO - 2025-11-05 01:23:24 --> Input Class Initialized
INFO - 2025-11-05 01:23:24 --> Language Class Initialized
INFO - 2025-11-05 01:23:24 --> Loader Class Initialized
INFO - 2025-11-05 01:23:24 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:23:24 --> Helper loaded: url_helper
INFO - 2025-11-05 01:23:24 --> Helper loaded: file_helper
INFO - 2025-11-05 01:23:24 --> Helper loaded: main_helper
INFO - 2025-11-05 01:23:24 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:23:24 --> Database Driver Class Initialized
INFO - 2025-11-05 01:23:24 --> Email Class Initialized
DEBUG - 2025-11-05 01:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:23:24 --> Controller Class Initialized
INFO - 2025-11-05 01:23:24 --> Model "User_model" initialized
INFO - 2025-11-05 01:23:24 --> Model "Project_model" initialized
INFO - 2025-11-05 01:23:24 --> Helper loaded: form_helper
INFO - 2025-11-05 01:23:24 --> Form Validation Class Initialized
INFO - 2025-11-05 01:23:24 --> Final output sent to browser
INFO - 2025-11-05 01:23:24 --> Total execution time: 0.0603
INFO - 2025-11-05 01:23:25 --> Config Class Initialized
INFO - 2025-11-05 01:23:25 --> Hooks Class Initialized
INFO - 2025-11-05 01:23:25 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:23:25 --> Utf8 Class Initialized
INFO - 2025-11-05 01:23:25 --> URI Class Initialized
INFO - 2025-11-05 01:23:25 --> Router Class Initialized
INFO - 2025-11-05 01:23:25 --> Output Class Initialized
INFO - 2025-11-05 01:23:25 --> Security Class Initialized
INFO - 2025-11-05 01:23:25 --> Input Class Initialized
INFO - 2025-11-05 01:23:25 --> Language Class Initialized
INFO - 2025-11-05 01:23:25 --> Loader Class Initialized
INFO - 2025-11-05 01:23:25 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:23:25 --> Helper loaded: url_helper
INFO - 2025-11-05 01:23:25 --> Helper loaded: file_helper
INFO - 2025-11-05 01:23:25 --> Helper loaded: main_helper
INFO - 2025-11-05 01:23:25 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:23:25 --> Database Driver Class Initialized
INFO - 2025-11-05 01:23:25 --> Email Class Initialized
DEBUG - 2025-11-05 01:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:23:25 --> Controller Class Initialized
INFO - 2025-11-05 01:23:25 --> Model "User_model" initialized
INFO - 2025-11-05 01:23:25 --> Model "Project_model" initialized
INFO - 2025-11-05 01:23:25 --> Helper loaded: form_helper
INFO - 2025-11-05 01:23:25 --> Form Validation Class Initialized
INFO - 2025-11-05 01:23:25 --> Final output sent to browser
INFO - 2025-11-05 01:23:25 --> Total execution time: 0.0621
INFO - 2025-11-05 01:23:27 --> Config Class Initialized
INFO - 2025-11-05 01:23:27 --> Hooks Class Initialized
INFO - 2025-11-05 01:23:27 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:23:27 --> Utf8 Class Initialized
INFO - 2025-11-05 01:23:27 --> URI Class Initialized
INFO - 2025-11-05 01:23:27 --> Router Class Initialized
INFO - 2025-11-05 01:23:27 --> Output Class Initialized
INFO - 2025-11-05 01:23:27 --> Security Class Initialized
INFO - 2025-11-05 01:23:27 --> Input Class Initialized
INFO - 2025-11-05 01:23:27 --> Language Class Initialized
INFO - 2025-11-05 01:23:27 --> Loader Class Initialized
INFO - 2025-11-05 01:23:27 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:23:27 --> Helper loaded: url_helper
INFO - 2025-11-05 01:23:27 --> Helper loaded: file_helper
INFO - 2025-11-05 01:23:27 --> Helper loaded: main_helper
INFO - 2025-11-05 01:23:27 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:23:27 --> Database Driver Class Initialized
INFO - 2025-11-05 01:23:27 --> Email Class Initialized
DEBUG - 2025-11-05 01:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:23:27 --> Controller Class Initialized
INFO - 2025-11-05 01:23:27 --> Model "User_model" initialized
INFO - 2025-11-05 01:23:27 --> Model "Project_model" initialized
INFO - 2025-11-05 01:23:27 --> Helper loaded: form_helper
INFO - 2025-11-05 01:23:27 --> Form Validation Class Initialized
INFO - 2025-11-05 01:23:27 --> Final output sent to browser
INFO - 2025-11-05 01:23:27 --> Total execution time: 0.0576
INFO - 2025-11-05 01:23:27 --> Config Class Initialized
INFO - 2025-11-05 01:23:27 --> Hooks Class Initialized
INFO - 2025-11-05 01:23:27 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:23:27 --> Utf8 Class Initialized
INFO - 2025-11-05 01:23:27 --> URI Class Initialized
INFO - 2025-11-05 01:23:27 --> Router Class Initialized
INFO - 2025-11-05 01:23:27 --> Output Class Initialized
INFO - 2025-11-05 01:23:27 --> Security Class Initialized
INFO - 2025-11-05 01:23:27 --> Input Class Initialized
INFO - 2025-11-05 01:23:27 --> Language Class Initialized
INFO - 2025-11-05 01:23:27 --> Loader Class Initialized
INFO - 2025-11-05 01:23:27 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:23:27 --> Helper loaded: url_helper
INFO - 2025-11-05 01:23:27 --> Helper loaded: file_helper
INFO - 2025-11-05 01:23:27 --> Helper loaded: main_helper
INFO - 2025-11-05 01:23:27 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:23:27 --> Database Driver Class Initialized
INFO - 2025-11-05 01:23:27 --> Email Class Initialized
DEBUG - 2025-11-05 01:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:23:27 --> Controller Class Initialized
INFO - 2025-11-05 01:23:27 --> Model "User_model" initialized
INFO - 2025-11-05 01:23:27 --> Model "Project_model" initialized
INFO - 2025-11-05 01:23:27 --> Helper loaded: form_helper
INFO - 2025-11-05 01:23:27 --> Form Validation Class Initialized
INFO - 2025-11-05 01:23:27 --> Final output sent to browser
INFO - 2025-11-05 01:23:27 --> Total execution time: 0.0565
INFO - 2025-11-05 01:23:33 --> Config Class Initialized
INFO - 2025-11-05 01:23:33 --> Hooks Class Initialized
INFO - 2025-11-05 01:23:33 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:23:33 --> Utf8 Class Initialized
INFO - 2025-11-05 01:23:33 --> URI Class Initialized
INFO - 2025-11-05 01:23:33 --> Router Class Initialized
INFO - 2025-11-05 01:23:33 --> Output Class Initialized
INFO - 2025-11-05 01:23:33 --> Security Class Initialized
INFO - 2025-11-05 01:23:33 --> Input Class Initialized
INFO - 2025-11-05 01:23:33 --> Language Class Initialized
INFO - 2025-11-05 01:23:33 --> Loader Class Initialized
INFO - 2025-11-05 01:23:33 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:23:33 --> Helper loaded: url_helper
INFO - 2025-11-05 01:23:33 --> Helper loaded: file_helper
INFO - 2025-11-05 01:23:33 --> Helper loaded: main_helper
INFO - 2025-11-05 01:23:33 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:23:33 --> Database Driver Class Initialized
INFO - 2025-11-05 01:23:33 --> Email Class Initialized
DEBUG - 2025-11-05 01:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:23:33 --> Controller Class Initialized
INFO - 2025-11-05 01:23:33 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:23:33 --> Model "User_model" initialized
INFO - 2025-11-05 01:23:33 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:23:33 --> Model "Project_model" initialized
INFO - 2025-11-05 01:23:33 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 01:23:33 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 01:23:33 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 01:23:33 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ai.php
INFO - 2025-11-05 01:23:33 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 01:23:33 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 01:23:33 --> Final output sent to browser
INFO - 2025-11-05 01:23:33 --> Total execution time: 0.1226
INFO - 2025-11-05 01:23:47 --> Config Class Initialized
INFO - 2025-11-05 01:23:47 --> Hooks Class Initialized
INFO - 2025-11-05 01:23:47 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:23:47 --> Utf8 Class Initialized
INFO - 2025-11-05 01:23:47 --> URI Class Initialized
INFO - 2025-11-05 01:23:47 --> Router Class Initialized
INFO - 2025-11-05 01:23:47 --> Output Class Initialized
INFO - 2025-11-05 01:23:47 --> Security Class Initialized
INFO - 2025-11-05 01:23:47 --> Input Class Initialized
INFO - 2025-11-05 01:23:47 --> Language Class Initialized
INFO - 2025-11-05 01:23:47 --> Loader Class Initialized
INFO - 2025-11-05 01:23:47 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:23:47 --> Helper loaded: url_helper
INFO - 2025-11-05 01:23:47 --> Helper loaded: file_helper
INFO - 2025-11-05 01:23:47 --> Helper loaded: main_helper
INFO - 2025-11-05 01:23:47 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:23:47 --> Database Driver Class Initialized
INFO - 2025-11-05 01:23:47 --> Email Class Initialized
DEBUG - 2025-11-05 01:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:23:47 --> Controller Class Initialized
INFO - 2025-11-05 01:23:47 --> Model "User_model" initialized
INFO - 2025-11-05 01:23:47 --> Model "Project_model" initialized
INFO - 2025-11-05 01:23:47 --> Helper loaded: form_helper
INFO - 2025-11-05 01:23:47 --> Form Validation Class Initialized
ERROR - 2025-11-05 01:23:49 --> Gemini API request error: Client error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `404 Not Found` response:
{
  "error": {
    "code": 404,
    "message": "models/gemini-1.5-flash is not found for API version v1beta, or is not s (truncated...)

ERROR - 2025-11-05 01:23:49 --> Gemini API request error: Client error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `404 Not Found` response:
{
  "error": {
    "code": 404,
    "message": "models/gemini-1.5-flash is not found for API version v1beta, or is not s (truncated...)

INFO - 2025-11-05 01:23:49 --> Final output sent to browser
INFO - 2025-11-05 01:23:49 --> Total execution time: 2.8022
INFO - 2025-11-05 01:24:42 --> Config Class Initialized
INFO - 2025-11-05 01:24:42 --> Hooks Class Initialized
INFO - 2025-11-05 01:24:42 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:24:42 --> Utf8 Class Initialized
INFO - 2025-11-05 01:24:42 --> URI Class Initialized
INFO - 2025-11-05 01:24:42 --> Router Class Initialized
INFO - 2025-11-05 01:24:42 --> Output Class Initialized
INFO - 2025-11-05 01:24:42 --> Security Class Initialized
INFO - 2025-11-05 01:24:42 --> Input Class Initialized
INFO - 2025-11-05 01:24:42 --> Language Class Initialized
INFO - 2025-11-05 01:24:42 --> Loader Class Initialized
INFO - 2025-11-05 01:24:42 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:24:42 --> Helper loaded: url_helper
INFO - 2025-11-05 01:24:43 --> Helper loaded: file_helper
INFO - 2025-11-05 01:24:43 --> Helper loaded: main_helper
INFO - 2025-11-05 01:24:43 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:24:43 --> Database Driver Class Initialized
INFO - 2025-11-05 01:24:43 --> Email Class Initialized
DEBUG - 2025-11-05 01:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:24:43 --> Controller Class Initialized
INFO - 2025-11-05 01:24:43 --> Model "User_model" initialized
INFO - 2025-11-05 01:24:43 --> Model "Project_model" initialized
INFO - 2025-11-05 01:24:43 --> Helper loaded: form_helper
INFO - 2025-11-05 01:24:43 --> Form Validation Class Initialized
ERROR - 2025-11-05 01:24:43 --> Gemini API request error: Client error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `404 Not Found` response:
{
  "error": {
    "code": 404,
    "message": "models/gemini-1.5-flash is not found for API version v1beta, or is not s (truncated...)

ERROR - 2025-11-05 01:24:43 --> Gemini API request error: Client error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `404 Not Found` response:
{
  "error": {
    "code": 404,
    "message": "models/gemini-1.5-flash is not found for API version v1beta, or is not s (truncated...)

INFO - 2025-11-05 01:24:43 --> Final output sent to browser
INFO - 2025-11-05 01:24:43 --> Total execution time: 0.7468
INFO - 2025-11-05 01:27:28 --> Config Class Initialized
INFO - 2025-11-05 01:27:28 --> Hooks Class Initialized
INFO - 2025-11-05 01:27:28 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:27:28 --> Utf8 Class Initialized
INFO - 2025-11-05 01:27:28 --> URI Class Initialized
INFO - 2025-11-05 01:27:28 --> Router Class Initialized
INFO - 2025-11-05 01:27:28 --> Output Class Initialized
INFO - 2025-11-05 01:27:28 --> Security Class Initialized
INFO - 2025-11-05 01:27:28 --> Input Class Initialized
INFO - 2025-11-05 01:27:28 --> Language Class Initialized
INFO - 2025-11-05 01:27:28 --> Loader Class Initialized
INFO - 2025-11-05 01:27:28 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:27:28 --> Helper loaded: url_helper
INFO - 2025-11-05 01:27:28 --> Helper loaded: file_helper
INFO - 2025-11-05 01:27:28 --> Helper loaded: main_helper
INFO - 2025-11-05 01:27:28 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:27:28 --> Database Driver Class Initialized
INFO - 2025-11-05 01:27:28 --> Email Class Initialized
DEBUG - 2025-11-05 01:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:27:28 --> Controller Class Initialized
INFO - 2025-11-05 01:27:28 --> Model "User_model" initialized
INFO - 2025-11-05 01:27:28 --> Model "Project_model" initialized
INFO - 2025-11-05 01:27:28 --> Helper loaded: form_helper
INFO - 2025-11-05 01:27:28 --> Form Validation Class Initialized
ERROR - 2025-11-05 01:27:29 --> Gemini API request error: Client error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `404 Not Found` response:
{
  "error": {
    "code": 404,
    "message": "models/gemini-1.5-flash is not found for API version v1beta, or is not s (truncated...)

ERROR - 2025-11-05 01:27:29 --> Gemini API request error: Client error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `404 Not Found` response:
{
  "error": {
    "code": 404,
    "message": "models/gemini-1.5-flash is not found for API version v1beta, or is not s (truncated...)

INFO - 2025-11-05 01:27:29 --> Final output sent to browser
INFO - 2025-11-05 01:27:29 --> Total execution time: 0.6798
INFO - 2025-11-05 01:28:46 --> Config Class Initialized
INFO - 2025-11-05 01:28:46 --> Hooks Class Initialized
INFO - 2025-11-05 01:28:46 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:28:46 --> Utf8 Class Initialized
INFO - 2025-11-05 01:28:46 --> URI Class Initialized
INFO - 2025-11-05 01:28:46 --> Router Class Initialized
INFO - 2025-11-05 01:28:46 --> Output Class Initialized
INFO - 2025-11-05 01:28:46 --> Security Class Initialized
INFO - 2025-11-05 01:28:46 --> Input Class Initialized
INFO - 2025-11-05 01:28:46 --> Language Class Initialized
INFO - 2025-11-05 01:28:46 --> Loader Class Initialized
INFO - 2025-11-05 01:28:46 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:28:46 --> Helper loaded: url_helper
INFO - 2025-11-05 01:28:46 --> Helper loaded: file_helper
INFO - 2025-11-05 01:28:46 --> Helper loaded: main_helper
INFO - 2025-11-05 01:28:46 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:28:46 --> Database Driver Class Initialized
INFO - 2025-11-05 01:28:46 --> Email Class Initialized
DEBUG - 2025-11-05 01:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:28:46 --> Controller Class Initialized
INFO - 2025-11-05 01:28:46 --> Model "User_model" initialized
INFO - 2025-11-05 01:28:46 --> Model "Project_model" initialized
INFO - 2025-11-05 01:28:46 --> Helper loaded: form_helper
INFO - 2025-11-05 01:28:46 --> Form Validation Class Initialized
ERROR - 2025-11-05 01:28:48 --> Gemini API request error: Client error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `404 Not Found` response:
{
  "error": {
    "code": 404,
    "message": "models/gemini-1.5-flash is not found for API version v1beta, or is not s (truncated...)

ERROR - 2025-11-05 01:28:48 --> Gemini API request error: Client error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `404 Not Found` response:
{
  "error": {
    "code": 404,
    "message": "models/gemini-1.5-flash is not found for API version v1beta, or is not s (truncated...)

ERROR - 2025-11-05 01:28:48 --> Severity: error --> Exception: Call to undefined method Api_project::get_top_k_pairs() D:\laragon\www\acumena\application\controllers\Api_project.php 615
INFO - 2025-11-05 01:29:11 --> Config Class Initialized
INFO - 2025-11-05 01:29:11 --> Hooks Class Initialized
INFO - 2025-11-05 01:29:11 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:29:11 --> Utf8 Class Initialized
INFO - 2025-11-05 01:29:11 --> URI Class Initialized
INFO - 2025-11-05 01:29:11 --> Router Class Initialized
INFO - 2025-11-05 01:29:11 --> Output Class Initialized
INFO - 2025-11-05 01:29:11 --> Security Class Initialized
INFO - 2025-11-05 01:29:11 --> Input Class Initialized
INFO - 2025-11-05 01:29:11 --> Language Class Initialized
INFO - 2025-11-05 01:29:11 --> Loader Class Initialized
INFO - 2025-11-05 01:29:11 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:29:11 --> Helper loaded: url_helper
INFO - 2025-11-05 01:29:11 --> Helper loaded: file_helper
INFO - 2025-11-05 01:29:11 --> Helper loaded: main_helper
INFO - 2025-11-05 01:29:11 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:29:11 --> Database Driver Class Initialized
INFO - 2025-11-05 01:29:11 --> Email Class Initialized
DEBUG - 2025-11-05 01:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:29:11 --> Controller Class Initialized
INFO - 2025-11-05 01:29:11 --> Model "User_model" initialized
INFO - 2025-11-05 01:29:11 --> Model "Project_model" initialized
INFO - 2025-11-05 01:29:11 --> Helper loaded: form_helper
INFO - 2025-11-05 01:29:11 --> Form Validation Class Initialized
ERROR - 2025-11-05 01:29:11 --> Gemini API request error: Client error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `404 Not Found` response:
{
  "error": {
    "code": 404,
    "message": "models/gemini-1.5-flash is not found for API version v1beta, or is not s (truncated...)

ERROR - 2025-11-05 01:29:12 --> Gemini API request error: Client error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `404 Not Found` response:
{
  "error": {
    "code": 404,
    "message": "models/gemini-1.5-flash is not found for API version v1beta, or is not s (truncated...)

INFO - 2025-11-05 01:29:12 --> Final output sent to browser
INFO - 2025-11-05 01:29:12 --> Total execution time: 0.7431
INFO - 2025-11-05 01:30:04 --> Config Class Initialized
INFO - 2025-11-05 01:30:04 --> Hooks Class Initialized
INFO - 2025-11-05 01:30:04 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:30:04 --> Utf8 Class Initialized
INFO - 2025-11-05 01:30:04 --> URI Class Initialized
INFO - 2025-11-05 01:30:04 --> Router Class Initialized
INFO - 2025-11-05 01:30:04 --> Output Class Initialized
INFO - 2025-11-05 01:30:04 --> Security Class Initialized
INFO - 2025-11-05 01:30:04 --> Input Class Initialized
INFO - 2025-11-05 01:30:04 --> Language Class Initialized
INFO - 2025-11-05 01:30:04 --> Loader Class Initialized
INFO - 2025-11-05 01:30:04 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:30:04 --> Helper loaded: url_helper
INFO - 2025-11-05 01:30:04 --> Helper loaded: file_helper
INFO - 2025-11-05 01:30:04 --> Helper loaded: main_helper
INFO - 2025-11-05 01:30:04 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:30:05 --> Database Driver Class Initialized
INFO - 2025-11-05 01:30:05 --> Email Class Initialized
DEBUG - 2025-11-05 01:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:30:05 --> Controller Class Initialized
INFO - 2025-11-05 01:30:05 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:30:05 --> Model "User_model" initialized
INFO - 2025-11-05 01:30:05 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:30:05 --> Model "Project_model" initialized
INFO - 2025-11-05 01:30:05 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 01:30:05 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 01:30:05 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 01:30:05 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ie.php
INFO - 2025-11-05 01:30:05 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 01:30:05 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 01:30:05 --> Final output sent to browser
INFO - 2025-11-05 01:30:05 --> Total execution time: 0.0563
INFO - 2025-11-05 01:30:05 --> Config Class Initialized
INFO - 2025-11-05 01:30:05 --> Config Class Initialized
INFO - 2025-11-05 01:30:05 --> Hooks Class Initialized
INFO - 2025-11-05 01:30:05 --> Hooks Class Initialized
INFO - 2025-11-05 01:30:05 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:30:05 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:30:05 --> Utf8 Class Initialized
INFO - 2025-11-05 01:30:05 --> Utf8 Class Initialized
INFO - 2025-11-05 01:30:05 --> URI Class Initialized
INFO - 2025-11-05 01:30:05 --> URI Class Initialized
INFO - 2025-11-05 01:30:05 --> Router Class Initialized
INFO - 2025-11-05 01:30:05 --> Router Class Initialized
INFO - 2025-11-05 01:30:05 --> Output Class Initialized
INFO - 2025-11-05 01:30:05 --> Output Class Initialized
INFO - 2025-11-05 01:30:05 --> Security Class Initialized
INFO - 2025-11-05 01:30:05 --> Security Class Initialized
INFO - 2025-11-05 01:30:05 --> Input Class Initialized
INFO - 2025-11-05 01:30:05 --> Input Class Initialized
INFO - 2025-11-05 01:30:05 --> Language Class Initialized
INFO - 2025-11-05 01:30:05 --> Language Class Initialized
INFO - 2025-11-05 01:30:05 --> Loader Class Initialized
INFO - 2025-11-05 01:30:05 --> Loader Class Initialized
INFO - 2025-11-05 01:30:05 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:30:05 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:30:05 --> Helper loaded: url_helper
INFO - 2025-11-05 01:30:05 --> Helper loaded: url_helper
INFO - 2025-11-05 01:30:05 --> Helper loaded: file_helper
INFO - 2025-11-05 01:30:05 --> Helper loaded: file_helper
INFO - 2025-11-05 01:30:05 --> Helper loaded: main_helper
INFO - 2025-11-05 01:30:05 --> Helper loaded: main_helper
INFO - 2025-11-05 01:30:05 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:30:05 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:30:05 --> Database Driver Class Initialized
INFO - 2025-11-05 01:30:05 --> Database Driver Class Initialized
INFO - 2025-11-05 01:30:05 --> Email Class Initialized
INFO - 2025-11-05 01:30:05 --> Email Class Initialized
DEBUG - 2025-11-05 01:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:30:05 --> Controller Class Initialized
INFO - 2025-11-05 01:30:05 --> Model "User_model" initialized
INFO - 2025-11-05 01:30:05 --> Model "Project_model" initialized
DEBUG - 2025-11-05 01:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:30:05 --> Helper loaded: form_helper
INFO - 2025-11-05 01:30:05 --> Form Validation Class Initialized
INFO - 2025-11-05 01:30:05 --> Final output sent to browser
INFO - 2025-11-05 01:30:05 --> Total execution time: 0.0619
INFO - 2025-11-05 01:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:30:05 --> Controller Class Initialized
INFO - 2025-11-05 01:30:05 --> Model "User_model" initialized
INFO - 2025-11-05 01:30:05 --> Model "Project_model" initialized
INFO - 2025-11-05 01:30:05 --> Helper loaded: form_helper
INFO - 2025-11-05 01:30:05 --> Form Validation Class Initialized
INFO - 2025-11-05 01:30:05 --> Final output sent to browser
INFO - 2025-11-05 01:30:05 --> Total execution time: 0.0720
INFO - 2025-11-05 01:30:06 --> Config Class Initialized
INFO - 2025-11-05 01:30:06 --> Hooks Class Initialized
INFO - 2025-11-05 01:30:06 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:30:06 --> Utf8 Class Initialized
INFO - 2025-11-05 01:30:06 --> URI Class Initialized
INFO - 2025-11-05 01:30:06 --> Router Class Initialized
INFO - 2025-11-05 01:30:06 --> Output Class Initialized
INFO - 2025-11-05 01:30:06 --> Security Class Initialized
INFO - 2025-11-05 01:30:06 --> Input Class Initialized
INFO - 2025-11-05 01:30:06 --> Language Class Initialized
INFO - 2025-11-05 01:30:06 --> Loader Class Initialized
INFO - 2025-11-05 01:30:06 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:30:06 --> Helper loaded: url_helper
INFO - 2025-11-05 01:30:06 --> Helper loaded: file_helper
INFO - 2025-11-05 01:30:06 --> Helper loaded: main_helper
INFO - 2025-11-05 01:30:06 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:30:06 --> Database Driver Class Initialized
INFO - 2025-11-05 01:30:06 --> Email Class Initialized
DEBUG - 2025-11-05 01:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:30:06 --> Controller Class Initialized
INFO - 2025-11-05 01:30:06 --> Model "User_model" initialized
INFO - 2025-11-05 01:30:06 --> Model "Project_model" initialized
INFO - 2025-11-05 01:30:06 --> Helper loaded: form_helper
INFO - 2025-11-05 01:30:06 --> Form Validation Class Initialized
INFO - 2025-11-05 01:30:06 --> Final output sent to browser
INFO - 2025-11-05 01:30:06 --> Total execution time: 0.0548
INFO - 2025-11-05 01:30:06 --> Config Class Initialized
INFO - 2025-11-05 01:30:06 --> Hooks Class Initialized
INFO - 2025-11-05 01:30:06 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:30:06 --> Utf8 Class Initialized
INFO - 2025-11-05 01:30:06 --> URI Class Initialized
INFO - 2025-11-05 01:30:06 --> Router Class Initialized
INFO - 2025-11-05 01:30:06 --> Output Class Initialized
INFO - 2025-11-05 01:30:06 --> Security Class Initialized
INFO - 2025-11-05 01:30:06 --> Input Class Initialized
INFO - 2025-11-05 01:30:06 --> Language Class Initialized
INFO - 2025-11-05 01:30:06 --> Loader Class Initialized
INFO - 2025-11-05 01:30:06 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:30:06 --> Helper loaded: url_helper
INFO - 2025-11-05 01:30:06 --> Helper loaded: file_helper
INFO - 2025-11-05 01:30:06 --> Helper loaded: main_helper
INFO - 2025-11-05 01:30:06 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:30:06 --> Database Driver Class Initialized
INFO - 2025-11-05 01:30:06 --> Email Class Initialized
DEBUG - 2025-11-05 01:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:30:06 --> Controller Class Initialized
INFO - 2025-11-05 01:30:06 --> Model "User_model" initialized
INFO - 2025-11-05 01:30:06 --> Model "Project_model" initialized
INFO - 2025-11-05 01:30:06 --> Helper loaded: form_helper
INFO - 2025-11-05 01:30:06 --> Form Validation Class Initialized
INFO - 2025-11-05 01:30:06 --> Final output sent to browser
INFO - 2025-11-05 01:30:06 --> Total execution time: 0.0527
INFO - 2025-11-05 01:30:10 --> Config Class Initialized
INFO - 2025-11-05 01:30:10 --> Hooks Class Initialized
INFO - 2025-11-05 01:30:10 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:30:10 --> Utf8 Class Initialized
INFO - 2025-11-05 01:30:10 --> URI Class Initialized
INFO - 2025-11-05 01:30:10 --> Router Class Initialized
INFO - 2025-11-05 01:30:10 --> Output Class Initialized
INFO - 2025-11-05 01:30:10 --> Security Class Initialized
INFO - 2025-11-05 01:30:10 --> Input Class Initialized
INFO - 2025-11-05 01:30:10 --> Language Class Initialized
INFO - 2025-11-05 01:30:10 --> Loader Class Initialized
INFO - 2025-11-05 01:30:10 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:30:10 --> Helper loaded: url_helper
INFO - 2025-11-05 01:30:10 --> Helper loaded: file_helper
INFO - 2025-11-05 01:30:10 --> Helper loaded: main_helper
INFO - 2025-11-05 01:30:10 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:30:10 --> Database Driver Class Initialized
INFO - 2025-11-05 01:30:10 --> Email Class Initialized
DEBUG - 2025-11-05 01:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:30:10 --> Controller Class Initialized
INFO - 2025-11-05 01:30:10 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:30:10 --> Model "User_model" initialized
INFO - 2025-11-05 01:30:10 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:30:10 --> Model "Project_model" initialized
INFO - 2025-11-05 01:30:10 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 01:30:10 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 01:30:10 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 01:30:10 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-efe.php
INFO - 2025-11-05 01:30:10 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 01:30:10 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 01:30:10 --> Final output sent to browser
INFO - 2025-11-05 01:30:10 --> Total execution time: 0.0586
INFO - 2025-11-05 01:30:10 --> Config Class Initialized
INFO - 2025-11-05 01:30:10 --> Hooks Class Initialized
INFO - 2025-11-05 01:30:10 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:30:10 --> Utf8 Class Initialized
INFO - 2025-11-05 01:30:10 --> URI Class Initialized
INFO - 2025-11-05 01:30:10 --> Router Class Initialized
INFO - 2025-11-05 01:30:10 --> Output Class Initialized
INFO - 2025-11-05 01:30:10 --> Security Class Initialized
INFO - 2025-11-05 01:30:10 --> Input Class Initialized
INFO - 2025-11-05 01:30:10 --> Language Class Initialized
INFO - 2025-11-05 01:30:10 --> Loader Class Initialized
INFO - 2025-11-05 01:30:10 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:30:10 --> Helper loaded: url_helper
INFO - 2025-11-05 01:30:10 --> Helper loaded: file_helper
INFO - 2025-11-05 01:30:10 --> Helper loaded: main_helper
INFO - 2025-11-05 01:30:10 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:30:10 --> Database Driver Class Initialized
INFO - 2025-11-05 01:30:10 --> Email Class Initialized
DEBUG - 2025-11-05 01:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:30:10 --> Controller Class Initialized
INFO - 2025-11-05 01:30:10 --> Model "User_model" initialized
INFO - 2025-11-05 01:30:10 --> Model "Project_model" initialized
INFO - 2025-11-05 01:30:10 --> Helper loaded: form_helper
INFO - 2025-11-05 01:30:10 --> Form Validation Class Initialized
INFO - 2025-11-05 01:30:10 --> Final output sent to browser
INFO - 2025-11-05 01:30:10 --> Total execution time: 0.0878
INFO - 2025-11-05 01:30:11 --> Config Class Initialized
INFO - 2025-11-05 01:30:11 --> Hooks Class Initialized
INFO - 2025-11-05 01:30:11 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:30:11 --> Utf8 Class Initialized
INFO - 2025-11-05 01:30:11 --> URI Class Initialized
INFO - 2025-11-05 01:30:11 --> Router Class Initialized
INFO - 2025-11-05 01:30:11 --> Output Class Initialized
INFO - 2025-11-05 01:30:11 --> Security Class Initialized
INFO - 2025-11-05 01:30:11 --> Input Class Initialized
INFO - 2025-11-05 01:30:11 --> Language Class Initialized
INFO - 2025-11-05 01:30:11 --> Loader Class Initialized
INFO - 2025-11-05 01:30:11 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:30:11 --> Helper loaded: url_helper
INFO - 2025-11-05 01:30:11 --> Helper loaded: file_helper
INFO - 2025-11-05 01:30:11 --> Helper loaded: main_helper
INFO - 2025-11-05 01:30:11 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:30:11 --> Database Driver Class Initialized
INFO - 2025-11-05 01:30:11 --> Email Class Initialized
DEBUG - 2025-11-05 01:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:30:11 --> Controller Class Initialized
INFO - 2025-11-05 01:30:11 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:30:11 --> Model "User_model" initialized
INFO - 2025-11-05 01:30:11 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:30:11 --> Model "Project_model" initialized
INFO - 2025-11-05 01:30:11 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 01:30:11 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 01:30:11 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 01:30:11 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ife.php
INFO - 2025-11-05 01:30:11 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 01:30:11 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 01:30:11 --> Final output sent to browser
INFO - 2025-11-05 01:30:11 --> Total execution time: 0.2280
INFO - 2025-11-05 01:30:11 --> Config Class Initialized
INFO - 2025-11-05 01:30:11 --> Hooks Class Initialized
INFO - 2025-11-05 01:30:11 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:30:11 --> Utf8 Class Initialized
INFO - 2025-11-05 01:30:11 --> URI Class Initialized
INFO - 2025-11-05 01:30:11 --> Router Class Initialized
INFO - 2025-11-05 01:30:11 --> Output Class Initialized
INFO - 2025-11-05 01:30:11 --> Security Class Initialized
INFO - 2025-11-05 01:30:11 --> Input Class Initialized
INFO - 2025-11-05 01:30:11 --> Language Class Initialized
INFO - 2025-11-05 01:30:11 --> Loader Class Initialized
INFO - 2025-11-05 01:30:11 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:30:11 --> Helper loaded: url_helper
INFO - 2025-11-05 01:30:11 --> Helper loaded: file_helper
INFO - 2025-11-05 01:30:11 --> Helper loaded: main_helper
INFO - 2025-11-05 01:30:11 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:30:11 --> Database Driver Class Initialized
INFO - 2025-11-05 01:30:11 --> Email Class Initialized
DEBUG - 2025-11-05 01:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:30:11 --> Controller Class Initialized
INFO - 2025-11-05 01:30:11 --> Model "User_model" initialized
INFO - 2025-11-05 01:30:11 --> Model "Project_model" initialized
INFO - 2025-11-05 01:30:11 --> Helper loaded: form_helper
INFO - 2025-11-05 01:30:11 --> Form Validation Class Initialized
INFO - 2025-11-05 01:30:11 --> Final output sent to browser
INFO - 2025-11-05 01:30:11 --> Total execution time: 0.0860
INFO - 2025-11-05 01:30:12 --> Config Class Initialized
INFO - 2025-11-05 01:30:12 --> Hooks Class Initialized
INFO - 2025-11-05 01:30:12 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:30:12 --> Utf8 Class Initialized
INFO - 2025-11-05 01:30:12 --> URI Class Initialized
INFO - 2025-11-05 01:30:12 --> Router Class Initialized
INFO - 2025-11-05 01:30:12 --> Output Class Initialized
INFO - 2025-11-05 01:30:12 --> Security Class Initialized
INFO - 2025-11-05 01:30:12 --> Input Class Initialized
INFO - 2025-11-05 01:30:12 --> Language Class Initialized
INFO - 2025-11-05 01:30:12 --> Loader Class Initialized
INFO - 2025-11-05 01:30:12 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:30:12 --> Helper loaded: url_helper
INFO - 2025-11-05 01:30:12 --> Helper loaded: file_helper
INFO - 2025-11-05 01:30:12 --> Helper loaded: main_helper
INFO - 2025-11-05 01:30:12 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:30:12 --> Database Driver Class Initialized
INFO - 2025-11-05 01:30:12 --> Email Class Initialized
DEBUG - 2025-11-05 01:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:30:12 --> Controller Class Initialized
INFO - 2025-11-05 01:30:12 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:30:12 --> Model "User_model" initialized
INFO - 2025-11-05 01:30:12 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:30:12 --> Model "Project_model" initialized
INFO - 2025-11-05 01:30:12 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 01:30:12 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 01:30:12 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 01:30:12 --> File loaded: D:\laragon\www\acumena\application\views\projects/swot.php
INFO - 2025-11-05 01:30:12 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 01:30:12 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 01:30:12 --> Final output sent to browser
INFO - 2025-11-05 01:30:12 --> Total execution time: 0.0818
INFO - 2025-11-05 01:30:12 --> Config Class Initialized
INFO - 2025-11-05 01:30:12 --> Hooks Class Initialized
INFO - 2025-11-05 01:30:12 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:30:12 --> Utf8 Class Initialized
INFO - 2025-11-05 01:30:12 --> URI Class Initialized
INFO - 2025-11-05 01:30:12 --> Router Class Initialized
INFO - 2025-11-05 01:30:12 --> Output Class Initialized
INFO - 2025-11-05 01:30:12 --> Security Class Initialized
INFO - 2025-11-05 01:30:12 --> Input Class Initialized
INFO - 2025-11-05 01:30:12 --> Language Class Initialized
INFO - 2025-11-05 01:30:12 --> Loader Class Initialized
INFO - 2025-11-05 01:30:12 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:30:12 --> Helper loaded: url_helper
INFO - 2025-11-05 01:30:12 --> Helper loaded: file_helper
INFO - 2025-11-05 01:30:12 --> Helper loaded: main_helper
INFO - 2025-11-05 01:30:12 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:30:12 --> Database Driver Class Initialized
INFO - 2025-11-05 01:30:12 --> Email Class Initialized
DEBUG - 2025-11-05 01:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:30:12 --> Controller Class Initialized
INFO - 2025-11-05 01:30:12 --> Model "User_model" initialized
INFO - 2025-11-05 01:30:12 --> Model "Project_model" initialized
INFO - 2025-11-05 01:30:12 --> Helper loaded: form_helper
INFO - 2025-11-05 01:30:12 --> Form Validation Class Initialized
INFO - 2025-11-05 01:30:12 --> Final output sent to browser
INFO - 2025-11-05 01:30:12 --> Total execution time: 0.0676
INFO - 2025-11-05 01:30:36 --> Config Class Initialized
INFO - 2025-11-05 01:30:36 --> Hooks Class Initialized
INFO - 2025-11-05 01:30:36 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:30:36 --> Utf8 Class Initialized
INFO - 2025-11-05 01:30:36 --> URI Class Initialized
INFO - 2025-11-05 01:30:36 --> Router Class Initialized
INFO - 2025-11-05 01:30:36 --> Output Class Initialized
INFO - 2025-11-05 01:30:36 --> Security Class Initialized
INFO - 2025-11-05 01:30:36 --> Input Class Initialized
INFO - 2025-11-05 01:30:36 --> Language Class Initialized
INFO - 2025-11-05 01:30:36 --> Loader Class Initialized
INFO - 2025-11-05 01:30:36 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:30:36 --> Helper loaded: url_helper
INFO - 2025-11-05 01:30:36 --> Helper loaded: file_helper
INFO - 2025-11-05 01:30:36 --> Helper loaded: main_helper
INFO - 2025-11-05 01:30:36 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:30:36 --> Database Driver Class Initialized
INFO - 2025-11-05 01:30:36 --> Email Class Initialized
DEBUG - 2025-11-05 01:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:30:36 --> Controller Class Initialized
INFO - 2025-11-05 01:30:36 --> Model "User_model" initialized
INFO - 2025-11-05 01:30:36 --> Model "Project_model" initialized
INFO - 2025-11-05 01:30:36 --> Helper loaded: form_helper
INFO - 2025-11-05 01:30:36 --> Form Validation Class Initialized
ERROR - 2025-11-05 01:30:36 --> Gemini API request error: Client error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `404 Not Found` response:
{
  "error": {
    "code": 404,
    "message": "models/gemini-1.5-flash is not found for API version v1beta, or is not s (truncated...)

ERROR - 2025-11-05 01:30:36 --> Gemini API request error: Client error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `404 Not Found` response:
{
  "error": {
    "code": 404,
    "message": "models/gemini-1.5-flash is not found for API version v1beta, or is not s (truncated...)

INFO - 2025-11-05 01:30:36 --> Final output sent to browser
INFO - 2025-11-05 01:30:36 --> Total execution time: 0.6238
INFO - 2025-11-05 01:31:57 --> Config Class Initialized
INFO - 2025-11-05 01:31:57 --> Hooks Class Initialized
INFO - 2025-11-05 01:31:57 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:31:57 --> Utf8 Class Initialized
INFO - 2025-11-05 01:31:57 --> URI Class Initialized
INFO - 2025-11-05 01:31:57 --> Router Class Initialized
INFO - 2025-11-05 01:31:57 --> Output Class Initialized
INFO - 2025-11-05 01:31:57 --> Security Class Initialized
INFO - 2025-11-05 01:31:57 --> Input Class Initialized
INFO - 2025-11-05 01:31:57 --> Language Class Initialized
INFO - 2025-11-05 01:31:57 --> Loader Class Initialized
INFO - 2025-11-05 01:31:57 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:31:57 --> Helper loaded: url_helper
INFO - 2025-11-05 01:31:57 --> Helper loaded: file_helper
INFO - 2025-11-05 01:31:57 --> Helper loaded: main_helper
INFO - 2025-11-05 01:31:57 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:31:57 --> Database Driver Class Initialized
INFO - 2025-11-05 01:31:57 --> Email Class Initialized
DEBUG - 2025-11-05 01:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:31:57 --> Controller Class Initialized
INFO - 2025-11-05 01:31:57 --> Model "User_model" initialized
INFO - 2025-11-05 01:31:57 --> Model "Project_model" initialized
INFO - 2025-11-05 01:31:57 --> Helper loaded: form_helper
INFO - 2025-11-05 01:31:57 --> Form Validation Class Initialized
ERROR - 2025-11-05 01:32:02 --> Gemini API request error: Client error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `404 Not Found` response:
{
  "error": {
    "code": 404,
    "message": "models/gemini-1.5-flash is not found for API version v1beta, or is not s (truncated...)

ERROR - 2025-11-05 01:32:02 --> Gemini API request error: Client error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `404 Not Found` response:
{
  "error": {
    "code": 404,
    "message": "models/gemini-1.5-flash is not found for API version v1beta, or is not s (truncated...)

INFO - 2025-11-05 01:32:02 --> Final output sent to browser
INFO - 2025-11-05 01:32:02 --> Total execution time: 5.2834
INFO - 2025-11-05 01:32:55 --> Config Class Initialized
INFO - 2025-11-05 01:32:55 --> Hooks Class Initialized
INFO - 2025-11-05 01:32:55 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:32:55 --> Utf8 Class Initialized
INFO - 2025-11-05 01:32:55 --> URI Class Initialized
INFO - 2025-11-05 01:32:55 --> Router Class Initialized
INFO - 2025-11-05 01:32:55 --> Output Class Initialized
INFO - 2025-11-05 01:32:55 --> Security Class Initialized
INFO - 2025-11-05 01:32:55 --> Input Class Initialized
INFO - 2025-11-05 01:32:55 --> Language Class Initialized
INFO - 2025-11-05 01:32:55 --> Loader Class Initialized
INFO - 2025-11-05 01:32:55 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:32:55 --> Helper loaded: url_helper
INFO - 2025-11-05 01:32:55 --> Helper loaded: file_helper
INFO - 2025-11-05 01:32:55 --> Helper loaded: main_helper
INFO - 2025-11-05 01:32:55 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:32:55 --> Database Driver Class Initialized
INFO - 2025-11-05 01:32:55 --> Email Class Initialized
DEBUG - 2025-11-05 01:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:32:55 --> Controller Class Initialized
INFO - 2025-11-05 01:32:55 --> Model "User_model" initialized
INFO - 2025-11-05 01:32:55 --> Model "Project_model" initialized
INFO - 2025-11-05 01:32:55 --> Helper loaded: form_helper
INFO - 2025-11-05 01:32:55 --> Form Validation Class Initialized
ERROR - 2025-11-05 01:32:56 --> Gemini API request error: Client error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `404 Not Found` response:
{
  "error": {
    "code": 404,
    "message": "models/gemini-1.5-flash is not found for API version v1beta, or is not s (truncated...)

ERROR - 2025-11-05 01:32:56 --> Gemini API request error: Client error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `404 Not Found` response:
{
  "error": {
    "code": 404,
    "message": "models/gemini-1.5-flash is not found for API version v1beta, or is not s (truncated...)

INFO - 2025-11-05 01:32:56 --> Final output sent to browser
INFO - 2025-11-05 01:32:56 --> Total execution time: 0.7670
INFO - 2025-11-05 01:33:01 --> Config Class Initialized
INFO - 2025-11-05 01:33:01 --> Hooks Class Initialized
INFO - 2025-11-05 01:33:01 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:33:01 --> Utf8 Class Initialized
INFO - 2025-11-05 01:33:01 --> URI Class Initialized
INFO - 2025-11-05 01:33:01 --> Router Class Initialized
INFO - 2025-11-05 01:33:01 --> Output Class Initialized
INFO - 2025-11-05 01:33:01 --> Security Class Initialized
INFO - 2025-11-05 01:33:01 --> Input Class Initialized
INFO - 2025-11-05 01:33:01 --> Language Class Initialized
INFO - 2025-11-05 01:33:01 --> Loader Class Initialized
INFO - 2025-11-05 01:33:01 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:33:01 --> Helper loaded: url_helper
INFO - 2025-11-05 01:33:01 --> Helper loaded: file_helper
INFO - 2025-11-05 01:33:01 --> Helper loaded: main_helper
INFO - 2025-11-05 01:33:01 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:33:01 --> Database Driver Class Initialized
INFO - 2025-11-05 01:33:01 --> Email Class Initialized
DEBUG - 2025-11-05 01:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:33:01 --> Controller Class Initialized
INFO - 2025-11-05 01:33:01 --> Model "User_model" initialized
INFO - 2025-11-05 01:33:01 --> Model "Project_model" initialized
INFO - 2025-11-05 01:33:01 --> Helper loaded: form_helper
INFO - 2025-11-05 01:33:01 --> Form Validation Class Initialized
ERROR - 2025-11-05 01:33:02 --> Gemini API request error: Client error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `404 Not Found` response:
{
  "error": {
    "code": 404,
    "message": "models/gemini-1.5-flash is not found for API version v1beta, or is not s (truncated...)

ERROR - 2025-11-05 01:33:02 --> Gemini API request error: Client error: `POST https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyCMgDbQDxeZtmL-SRLOHXcCM4BuNJ2S9RY` resulted in a `404 Not Found` response:
{
  "error": {
    "code": 404,
    "message": "models/gemini-1.5-flash is not found for API version v1beta, or is not s (truncated...)

INFO - 2025-11-05 01:33:02 --> Final output sent to browser
INFO - 2025-11-05 01:33:02 --> Total execution time: 0.6414
INFO - 2025-11-05 01:33:13 --> Config Class Initialized
INFO - 2025-11-05 01:33:13 --> Hooks Class Initialized
INFO - 2025-11-05 01:33:13 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:33:13 --> Utf8 Class Initialized
INFO - 2025-11-05 01:33:13 --> URI Class Initialized
INFO - 2025-11-05 01:33:13 --> Router Class Initialized
INFO - 2025-11-05 01:33:13 --> Output Class Initialized
INFO - 2025-11-05 01:33:13 --> Security Class Initialized
INFO - 2025-11-05 01:33:13 --> Input Class Initialized
INFO - 2025-11-05 01:33:13 --> Language Class Initialized
INFO - 2025-11-05 01:33:13 --> Loader Class Initialized
INFO - 2025-11-05 01:33:13 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:33:13 --> Helper loaded: url_helper
INFO - 2025-11-05 01:33:13 --> Helper loaded: file_helper
INFO - 2025-11-05 01:33:13 --> Helper loaded: main_helper
INFO - 2025-11-05 01:33:13 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:33:13 --> Database Driver Class Initialized
INFO - 2025-11-05 01:33:13 --> Email Class Initialized
DEBUG - 2025-11-05 01:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:33:13 --> Controller Class Initialized
INFO - 2025-11-05 01:33:13 --> Model "User_model" initialized
INFO - 2025-11-05 01:33:13 --> Model "Project_model" initialized
INFO - 2025-11-05 01:33:13 --> Helper loaded: form_helper
INFO - 2025-11-05 01:33:13 --> Form Validation Class Initialized
INFO - 2025-11-05 01:33:19 --> Final output sent to browser
INFO - 2025-11-05 01:33:19 --> Total execution time: 6.4767
INFO - 2025-11-05 01:33:59 --> Config Class Initialized
INFO - 2025-11-05 01:33:59 --> Hooks Class Initialized
INFO - 2025-11-05 01:33:59 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:33:59 --> Utf8 Class Initialized
INFO - 2025-11-05 01:33:59 --> URI Class Initialized
INFO - 2025-11-05 01:33:59 --> Router Class Initialized
INFO - 2025-11-05 01:33:59 --> Output Class Initialized
INFO - 2025-11-05 01:33:59 --> Security Class Initialized
INFO - 2025-11-05 01:33:59 --> Input Class Initialized
INFO - 2025-11-05 01:33:59 --> Language Class Initialized
INFO - 2025-11-05 01:33:59 --> Loader Class Initialized
INFO - 2025-11-05 01:33:59 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:33:59 --> Helper loaded: url_helper
INFO - 2025-11-05 01:33:59 --> Helper loaded: file_helper
INFO - 2025-11-05 01:33:59 --> Helper loaded: main_helper
INFO - 2025-11-05 01:33:59 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:33:59 --> Database Driver Class Initialized
INFO - 2025-11-05 01:33:59 --> Email Class Initialized
DEBUG - 2025-11-05 01:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:33:59 --> Controller Class Initialized
INFO - 2025-11-05 01:33:59 --> Model "User_model" initialized
INFO - 2025-11-05 01:33:59 --> Model "Project_model" initialized
INFO - 2025-11-05 01:33:59 --> Helper loaded: form_helper
INFO - 2025-11-05 01:33:59 --> Form Validation Class Initialized
ERROR - 2025-11-05 01:34:07 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 276,
    "totalTokenCount": 1475,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 276
      }
    ],
    "thoughtsTokenCount": 1199
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "iqkKadr1Leq9qfkPzauf8QY"
}

INFO - 2025-11-05 01:34:07 --> Final output sent to browser
INFO - 2025-11-05 01:34:07 --> Total execution time: 7.3735
INFO - 2025-11-05 01:38:21 --> Config Class Initialized
INFO - 2025-11-05 01:38:21 --> Hooks Class Initialized
INFO - 2025-11-05 01:38:21 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:38:21 --> Utf8 Class Initialized
INFO - 2025-11-05 01:38:21 --> URI Class Initialized
INFO - 2025-11-05 01:38:21 --> Router Class Initialized
INFO - 2025-11-05 01:38:21 --> Output Class Initialized
INFO - 2025-11-05 01:38:21 --> Security Class Initialized
INFO - 2025-11-05 01:38:21 --> Input Class Initialized
INFO - 2025-11-05 01:38:21 --> Language Class Initialized
INFO - 2025-11-05 01:38:21 --> Loader Class Initialized
INFO - 2025-11-05 01:38:21 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:38:21 --> Helper loaded: url_helper
INFO - 2025-11-05 01:38:21 --> Helper loaded: file_helper
INFO - 2025-11-05 01:38:21 --> Helper loaded: main_helper
INFO - 2025-11-05 01:38:21 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:38:21 --> Database Driver Class Initialized
INFO - 2025-11-05 01:38:22 --> Email Class Initialized
DEBUG - 2025-11-05 01:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:38:22 --> Controller Class Initialized
INFO - 2025-11-05 01:38:22 --> Model "User_model" initialized
INFO - 2025-11-05 01:38:22 --> Model "Project_model" initialized
INFO - 2025-11-05 01:38:22 --> Helper loaded: form_helper
INFO - 2025-11-05 01:38:22 --> Form Validation Class Initialized
INFO - 2025-11-05 01:38:22 --> Final output sent to browser
INFO - 2025-11-05 01:38:22 --> Total execution time: 0.0630
INFO - 2025-11-05 01:38:22 --> Config Class Initialized
INFO - 2025-11-05 01:38:22 --> Hooks Class Initialized
INFO - 2025-11-05 01:38:22 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:38:22 --> Utf8 Class Initialized
INFO - 2025-11-05 01:38:22 --> URI Class Initialized
INFO - 2025-11-05 01:38:22 --> Router Class Initialized
INFO - 2025-11-05 01:38:22 --> Output Class Initialized
INFO - 2025-11-05 01:38:22 --> Security Class Initialized
INFO - 2025-11-05 01:38:22 --> Input Class Initialized
INFO - 2025-11-05 01:38:22 --> Language Class Initialized
INFO - 2025-11-05 01:38:22 --> Loader Class Initialized
INFO - 2025-11-05 01:38:22 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:38:22 --> Helper loaded: url_helper
INFO - 2025-11-05 01:38:22 --> Helper loaded: file_helper
INFO - 2025-11-05 01:38:22 --> Helper loaded: main_helper
INFO - 2025-11-05 01:38:22 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:38:22 --> Database Driver Class Initialized
INFO - 2025-11-05 01:38:22 --> Email Class Initialized
DEBUG - 2025-11-05 01:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:38:22 --> Controller Class Initialized
INFO - 2025-11-05 01:38:22 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:38:22 --> Model "User_model" initialized
INFO - 2025-11-05 01:38:22 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:38:22 --> Model "Project_model" initialized
INFO - 2025-11-05 01:38:22 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 01:38:22 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 01:38:22 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 01:38:22 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ife.php
INFO - 2025-11-05 01:38:22 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 01:38:22 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 01:38:22 --> Final output sent to browser
INFO - 2025-11-05 01:38:22 --> Total execution time: 0.0612
INFO - 2025-11-05 01:38:22 --> Config Class Initialized
INFO - 2025-11-05 01:38:22 --> Hooks Class Initialized
INFO - 2025-11-05 01:38:22 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:38:22 --> Utf8 Class Initialized
INFO - 2025-11-05 01:38:22 --> URI Class Initialized
INFO - 2025-11-05 01:38:22 --> Router Class Initialized
INFO - 2025-11-05 01:38:22 --> Output Class Initialized
INFO - 2025-11-05 01:38:22 --> Security Class Initialized
INFO - 2025-11-05 01:38:22 --> Input Class Initialized
INFO - 2025-11-05 01:38:22 --> Language Class Initialized
INFO - 2025-11-05 01:38:22 --> Loader Class Initialized
INFO - 2025-11-05 01:38:22 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:38:22 --> Helper loaded: url_helper
INFO - 2025-11-05 01:38:22 --> Helper loaded: file_helper
INFO - 2025-11-05 01:38:22 --> Helper loaded: main_helper
INFO - 2025-11-05 01:38:22 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:38:22 --> Database Driver Class Initialized
INFO - 2025-11-05 01:38:22 --> Email Class Initialized
DEBUG - 2025-11-05 01:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:38:22 --> Controller Class Initialized
INFO - 2025-11-05 01:38:22 --> Model "User_model" initialized
INFO - 2025-11-05 01:38:22 --> Model "Project_model" initialized
INFO - 2025-11-05 01:38:22 --> Helper loaded: form_helper
INFO - 2025-11-05 01:38:22 --> Form Validation Class Initialized
INFO - 2025-11-05 01:38:22 --> Final output sent to browser
INFO - 2025-11-05 01:38:22 --> Total execution time: 0.0726
INFO - 2025-11-05 01:38:33 --> Config Class Initialized
INFO - 2025-11-05 01:38:33 --> Hooks Class Initialized
INFO - 2025-11-05 01:38:33 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:38:33 --> Utf8 Class Initialized
INFO - 2025-11-05 01:38:33 --> URI Class Initialized
INFO - 2025-11-05 01:38:33 --> Router Class Initialized
INFO - 2025-11-05 01:38:33 --> Output Class Initialized
INFO - 2025-11-05 01:38:33 --> Security Class Initialized
INFO - 2025-11-05 01:38:33 --> Input Class Initialized
INFO - 2025-11-05 01:38:33 --> Language Class Initialized
INFO - 2025-11-05 01:38:33 --> Loader Class Initialized
INFO - 2025-11-05 01:38:33 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:38:33 --> Helper loaded: url_helper
INFO - 2025-11-05 01:38:33 --> Helper loaded: file_helper
INFO - 2025-11-05 01:38:33 --> Helper loaded: main_helper
INFO - 2025-11-05 01:38:33 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:38:33 --> Database Driver Class Initialized
INFO - 2025-11-05 01:38:33 --> Email Class Initialized
DEBUG - 2025-11-05 01:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:38:33 --> Controller Class Initialized
INFO - 2025-11-05 01:38:33 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:38:33 --> Model "User_model" initialized
INFO - 2025-11-05 01:38:33 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:38:33 --> Model "Project_model" initialized
INFO - 2025-11-05 01:38:33 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 01:38:33 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 01:38:33 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 01:38:33 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ai.php
INFO - 2025-11-05 01:38:33 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 01:38:33 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 01:38:33 --> Final output sent to browser
INFO - 2025-11-05 01:38:33 --> Total execution time: 0.0796
INFO - 2025-11-05 01:49:27 --> Config Class Initialized
INFO - 2025-11-05 01:49:27 --> Hooks Class Initialized
INFO - 2025-11-05 01:49:27 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:49:27 --> Utf8 Class Initialized
INFO - 2025-11-05 01:49:27 --> URI Class Initialized
INFO - 2025-11-05 01:49:27 --> Router Class Initialized
INFO - 2025-11-05 01:49:27 --> Output Class Initialized
INFO - 2025-11-05 01:49:27 --> Security Class Initialized
INFO - 2025-11-05 01:49:27 --> Input Class Initialized
INFO - 2025-11-05 01:49:27 --> Language Class Initialized
INFO - 2025-11-05 01:49:27 --> Loader Class Initialized
INFO - 2025-11-05 01:49:27 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:49:28 --> Helper loaded: url_helper
INFO - 2025-11-05 01:49:28 --> Helper loaded: file_helper
INFO - 2025-11-05 01:49:28 --> Helper loaded: main_helper
INFO - 2025-11-05 01:49:28 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:49:28 --> Database Driver Class Initialized
INFO - 2025-11-05 01:49:28 --> Email Class Initialized
DEBUG - 2025-11-05 01:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:49:28 --> Controller Class Initialized
INFO - 2025-11-05 01:49:28 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:49:28 --> Model "User_model" initialized
INFO - 2025-11-05 01:49:28 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:49:28 --> Model "Project_model" initialized
INFO - 2025-11-05 01:49:28 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 01:49:28 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 01:49:28 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 01:49:28 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ife.php
INFO - 2025-11-05 01:49:28 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 01:49:28 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 01:49:28 --> Final output sent to browser
INFO - 2025-11-05 01:49:28 --> Total execution time: 0.0624
INFO - 2025-11-05 01:49:28 --> Config Class Initialized
INFO - 2025-11-05 01:49:28 --> Hooks Class Initialized
INFO - 2025-11-05 01:49:28 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:49:28 --> Utf8 Class Initialized
INFO - 2025-11-05 01:49:28 --> URI Class Initialized
INFO - 2025-11-05 01:49:28 --> Router Class Initialized
INFO - 2025-11-05 01:49:28 --> Output Class Initialized
INFO - 2025-11-05 01:49:28 --> Security Class Initialized
INFO - 2025-11-05 01:49:28 --> Input Class Initialized
INFO - 2025-11-05 01:49:28 --> Language Class Initialized
INFO - 2025-11-05 01:49:28 --> Loader Class Initialized
INFO - 2025-11-05 01:49:28 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:49:28 --> Helper loaded: url_helper
INFO - 2025-11-05 01:49:28 --> Helper loaded: file_helper
INFO - 2025-11-05 01:49:28 --> Helper loaded: main_helper
INFO - 2025-11-05 01:49:28 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:49:28 --> Database Driver Class Initialized
INFO - 2025-11-05 01:49:28 --> Email Class Initialized
DEBUG - 2025-11-05 01:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:49:28 --> Controller Class Initialized
INFO - 2025-11-05 01:49:28 --> Model "User_model" initialized
INFO - 2025-11-05 01:49:28 --> Model "Project_model" initialized
INFO - 2025-11-05 01:49:28 --> Helper loaded: form_helper
INFO - 2025-11-05 01:49:28 --> Form Validation Class Initialized
INFO - 2025-11-05 01:49:28 --> Final output sent to browser
INFO - 2025-11-05 01:49:28 --> Total execution time: 0.0513
INFO - 2025-11-05 01:49:58 --> Config Class Initialized
INFO - 2025-11-05 01:49:58 --> Hooks Class Initialized
INFO - 2025-11-05 01:49:58 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:49:58 --> Utf8 Class Initialized
INFO - 2025-11-05 01:49:58 --> URI Class Initialized
INFO - 2025-11-05 01:49:58 --> Router Class Initialized
INFO - 2025-11-05 01:49:58 --> Output Class Initialized
INFO - 2025-11-05 01:49:58 --> Security Class Initialized
INFO - 2025-11-05 01:49:58 --> Input Class Initialized
INFO - 2025-11-05 01:49:58 --> Language Class Initialized
INFO - 2025-11-05 01:49:58 --> Loader Class Initialized
INFO - 2025-11-05 01:49:58 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:49:58 --> Helper loaded: url_helper
INFO - 2025-11-05 01:49:58 --> Helper loaded: file_helper
INFO - 2025-11-05 01:49:58 --> Helper loaded: main_helper
INFO - 2025-11-05 01:49:58 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:49:58 --> Database Driver Class Initialized
INFO - 2025-11-05 01:49:58 --> Email Class Initialized
DEBUG - 2025-11-05 01:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:49:58 --> Controller Class Initialized
INFO - 2025-11-05 01:49:58 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:49:58 --> Model "User_model" initialized
INFO - 2025-11-05 01:49:58 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:49:58 --> Model "Project_model" initialized
INFO - 2025-11-05 01:49:58 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 01:49:58 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 01:49:58 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 01:49:58 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-efe.php
INFO - 2025-11-05 01:49:58 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 01:49:58 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 01:49:58 --> Final output sent to browser
INFO - 2025-11-05 01:49:58 --> Total execution time: 0.0703
INFO - 2025-11-05 01:49:58 --> Config Class Initialized
INFO - 2025-11-05 01:49:58 --> Hooks Class Initialized
INFO - 2025-11-05 01:49:58 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:49:58 --> Utf8 Class Initialized
INFO - 2025-11-05 01:49:58 --> URI Class Initialized
INFO - 2025-11-05 01:49:58 --> Router Class Initialized
INFO - 2025-11-05 01:49:58 --> Output Class Initialized
INFO - 2025-11-05 01:49:58 --> Security Class Initialized
INFO - 2025-11-05 01:49:58 --> Input Class Initialized
INFO - 2025-11-05 01:49:58 --> Language Class Initialized
INFO - 2025-11-05 01:49:58 --> Loader Class Initialized
INFO - 2025-11-05 01:49:58 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:49:58 --> Helper loaded: url_helper
INFO - 2025-11-05 01:49:58 --> Helper loaded: file_helper
INFO - 2025-11-05 01:49:58 --> Helper loaded: main_helper
INFO - 2025-11-05 01:49:58 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:49:58 --> Database Driver Class Initialized
INFO - 2025-11-05 01:49:58 --> Email Class Initialized
DEBUG - 2025-11-05 01:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:49:58 --> Controller Class Initialized
INFO - 2025-11-05 01:49:58 --> Model "User_model" initialized
INFO - 2025-11-05 01:49:58 --> Model "Project_model" initialized
INFO - 2025-11-05 01:49:58 --> Helper loaded: form_helper
INFO - 2025-11-05 01:49:58 --> Form Validation Class Initialized
INFO - 2025-11-05 01:49:58 --> Final output sent to browser
INFO - 2025-11-05 01:49:58 --> Total execution time: 0.0592
INFO - 2025-11-05 01:50:01 --> Config Class Initialized
INFO - 2025-11-05 01:50:01 --> Hooks Class Initialized
INFO - 2025-11-05 01:50:01 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:50:01 --> Utf8 Class Initialized
INFO - 2025-11-05 01:50:01 --> URI Class Initialized
INFO - 2025-11-05 01:50:01 --> Router Class Initialized
INFO - 2025-11-05 01:50:01 --> Output Class Initialized
INFO - 2025-11-05 01:50:01 --> Security Class Initialized
INFO - 2025-11-05 01:50:01 --> Input Class Initialized
INFO - 2025-11-05 01:50:01 --> Language Class Initialized
INFO - 2025-11-05 01:50:01 --> Loader Class Initialized
INFO - 2025-11-05 01:50:01 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:50:01 --> Helper loaded: url_helper
INFO - 2025-11-05 01:50:01 --> Helper loaded: file_helper
INFO - 2025-11-05 01:50:01 --> Helper loaded: main_helper
INFO - 2025-11-05 01:50:01 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:50:01 --> Database Driver Class Initialized
INFO - 2025-11-05 01:50:01 --> Email Class Initialized
DEBUG - 2025-11-05 01:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:50:01 --> Controller Class Initialized
INFO - 2025-11-05 01:50:01 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:50:01 --> Model "User_model" initialized
INFO - 2025-11-05 01:50:01 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:50:01 --> Model "Project_model" initialized
INFO - 2025-11-05 01:50:01 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 01:50:01 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 01:50:01 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 01:50:01 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ie.php
INFO - 2025-11-05 01:50:01 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 01:50:01 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 01:50:01 --> Final output sent to browser
INFO - 2025-11-05 01:50:01 --> Total execution time: 0.0591
INFO - 2025-11-05 01:50:01 --> Config Class Initialized
INFO - 2025-11-05 01:50:01 --> Config Class Initialized
INFO - 2025-11-05 01:50:01 --> Hooks Class Initialized
INFO - 2025-11-05 01:50:01 --> Hooks Class Initialized
INFO - 2025-11-05 01:50:01 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:50:01 --> Utf8 Class Initialized
INFO - 2025-11-05 01:50:01 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:50:01 --> URI Class Initialized
INFO - 2025-11-05 01:50:01 --> Utf8 Class Initialized
INFO - 2025-11-05 01:50:01 --> URI Class Initialized
INFO - 2025-11-05 01:50:01 --> Router Class Initialized
INFO - 2025-11-05 01:50:01 --> Router Class Initialized
INFO - 2025-11-05 01:50:01 --> Output Class Initialized
INFO - 2025-11-05 01:50:01 --> Output Class Initialized
INFO - 2025-11-05 01:50:01 --> Security Class Initialized
INFO - 2025-11-05 01:50:01 --> Security Class Initialized
INFO - 2025-11-05 01:50:01 --> Input Class Initialized
INFO - 2025-11-05 01:50:01 --> Input Class Initialized
INFO - 2025-11-05 01:50:01 --> Language Class Initialized
INFO - 2025-11-05 01:50:01 --> Language Class Initialized
INFO - 2025-11-05 01:50:01 --> Loader Class Initialized
INFO - 2025-11-05 01:50:01 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:50:01 --> Loader Class Initialized
INFO - 2025-11-05 01:50:01 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:50:01 --> Helper loaded: url_helper
INFO - 2025-11-05 01:50:01 --> Helper loaded: url_helper
INFO - 2025-11-05 01:50:01 --> Helper loaded: file_helper
INFO - 2025-11-05 01:50:01 --> Helper loaded: file_helper
INFO - 2025-11-05 01:50:01 --> Helper loaded: main_helper
INFO - 2025-11-05 01:50:01 --> Helper loaded: main_helper
INFO - 2025-11-05 01:50:01 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:50:01 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:50:01 --> Database Driver Class Initialized
INFO - 2025-11-05 01:50:01 --> Database Driver Class Initialized
INFO - 2025-11-05 01:50:01 --> Email Class Initialized
INFO - 2025-11-05 01:50:01 --> Email Class Initialized
DEBUG - 2025-11-05 01:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-11-05 01:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:50:01 --> Controller Class Initialized
INFO - 2025-11-05 01:50:01 --> Model "User_model" initialized
INFO - 2025-11-05 01:50:01 --> Model "Project_model" initialized
INFO - 2025-11-05 01:50:01 --> Helper loaded: form_helper
INFO - 2025-11-05 01:50:01 --> Form Validation Class Initialized
INFO - 2025-11-05 01:50:01 --> Final output sent to browser
INFO - 2025-11-05 01:50:01 --> Total execution time: 0.0736
INFO - 2025-11-05 01:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:50:01 --> Controller Class Initialized
INFO - 2025-11-05 01:50:01 --> Model "User_model" initialized
INFO - 2025-11-05 01:50:01 --> Model "Project_model" initialized
INFO - 2025-11-05 01:50:01 --> Helper loaded: form_helper
INFO - 2025-11-05 01:50:01 --> Form Validation Class Initialized
INFO - 2025-11-05 01:50:01 --> Final output sent to browser
INFO - 2025-11-05 01:50:01 --> Total execution time: 0.0841
INFO - 2025-11-05 01:50:02 --> Config Class Initialized
INFO - 2025-11-05 01:50:02 --> Hooks Class Initialized
INFO - 2025-11-05 01:50:02 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:50:02 --> Utf8 Class Initialized
INFO - 2025-11-05 01:50:02 --> URI Class Initialized
INFO - 2025-11-05 01:50:02 --> Router Class Initialized
INFO - 2025-11-05 01:50:02 --> Output Class Initialized
INFO - 2025-11-05 01:50:02 --> Security Class Initialized
INFO - 2025-11-05 01:50:02 --> Input Class Initialized
INFO - 2025-11-05 01:50:02 --> Language Class Initialized
INFO - 2025-11-05 01:50:02 --> Loader Class Initialized
INFO - 2025-11-05 01:50:02 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:50:02 --> Helper loaded: url_helper
INFO - 2025-11-05 01:50:02 --> Helper loaded: file_helper
INFO - 2025-11-05 01:50:02 --> Helper loaded: main_helper
INFO - 2025-11-05 01:50:02 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:50:02 --> Database Driver Class Initialized
INFO - 2025-11-05 01:50:02 --> Email Class Initialized
DEBUG - 2025-11-05 01:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:50:02 --> Controller Class Initialized
INFO - 2025-11-05 01:50:02 --> Model "User_model" initialized
INFO - 2025-11-05 01:50:02 --> Model "Project_model" initialized
INFO - 2025-11-05 01:50:02 --> Helper loaded: form_helper
INFO - 2025-11-05 01:50:02 --> Form Validation Class Initialized
INFO - 2025-11-05 01:50:02 --> Final output sent to browser
INFO - 2025-11-05 01:50:02 --> Total execution time: 0.0766
INFO - 2025-11-05 01:50:02 --> Config Class Initialized
INFO - 2025-11-05 01:50:02 --> Hooks Class Initialized
INFO - 2025-11-05 01:50:02 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:50:02 --> Utf8 Class Initialized
INFO - 2025-11-05 01:50:02 --> URI Class Initialized
INFO - 2025-11-05 01:50:02 --> Router Class Initialized
INFO - 2025-11-05 01:50:02 --> Output Class Initialized
INFO - 2025-11-05 01:50:02 --> Security Class Initialized
INFO - 2025-11-05 01:50:02 --> Input Class Initialized
INFO - 2025-11-05 01:50:02 --> Language Class Initialized
INFO - 2025-11-05 01:50:02 --> Loader Class Initialized
INFO - 2025-11-05 01:50:02 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:50:02 --> Helper loaded: url_helper
INFO - 2025-11-05 01:50:02 --> Helper loaded: file_helper
INFO - 2025-11-05 01:50:02 --> Helper loaded: main_helper
INFO - 2025-11-05 01:50:02 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:50:02 --> Database Driver Class Initialized
INFO - 2025-11-05 01:50:02 --> Email Class Initialized
DEBUG - 2025-11-05 01:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:50:02 --> Controller Class Initialized
INFO - 2025-11-05 01:50:02 --> Model "User_model" initialized
INFO - 2025-11-05 01:50:02 --> Model "Project_model" initialized
INFO - 2025-11-05 01:50:02 --> Helper loaded: form_helper
INFO - 2025-11-05 01:50:02 --> Form Validation Class Initialized
INFO - 2025-11-05 01:50:02 --> Final output sent to browser
INFO - 2025-11-05 01:50:02 --> Total execution time: 0.0543
INFO - 2025-11-05 01:50:38 --> Config Class Initialized
INFO - 2025-11-05 01:50:38 --> Hooks Class Initialized
INFO - 2025-11-05 01:50:38 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:50:38 --> Utf8 Class Initialized
INFO - 2025-11-05 01:50:38 --> URI Class Initialized
INFO - 2025-11-05 01:50:38 --> Router Class Initialized
INFO - 2025-11-05 01:50:38 --> Output Class Initialized
INFO - 2025-11-05 01:50:38 --> Security Class Initialized
INFO - 2025-11-05 01:50:38 --> Input Class Initialized
INFO - 2025-11-05 01:50:38 --> Language Class Initialized
INFO - 2025-11-05 01:50:38 --> Loader Class Initialized
INFO - 2025-11-05 01:50:38 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:50:38 --> Helper loaded: url_helper
INFO - 2025-11-05 01:50:38 --> Helper loaded: file_helper
INFO - 2025-11-05 01:50:38 --> Helper loaded: main_helper
INFO - 2025-11-05 01:50:38 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:50:38 --> Database Driver Class Initialized
INFO - 2025-11-05 01:50:38 --> Email Class Initialized
DEBUG - 2025-11-05 01:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:50:38 --> Controller Class Initialized
INFO - 2025-11-05 01:50:38 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:50:38 --> Model "User_model" initialized
INFO - 2025-11-05 01:50:38 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:50:38 --> Model "Project_model" initialized
INFO - 2025-11-05 01:50:38 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 01:50:38 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 01:50:38 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 01:50:38 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ife.php
INFO - 2025-11-05 01:50:38 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 01:50:38 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 01:50:38 --> Final output sent to browser
INFO - 2025-11-05 01:50:38 --> Total execution time: 0.0815
INFO - 2025-11-05 01:50:38 --> Config Class Initialized
INFO - 2025-11-05 01:50:38 --> Hooks Class Initialized
INFO - 2025-11-05 01:50:38 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:50:38 --> Utf8 Class Initialized
INFO - 2025-11-05 01:50:38 --> URI Class Initialized
INFO - 2025-11-05 01:50:38 --> Router Class Initialized
INFO - 2025-11-05 01:50:38 --> Output Class Initialized
INFO - 2025-11-05 01:50:38 --> Security Class Initialized
INFO - 2025-11-05 01:50:38 --> Input Class Initialized
INFO - 2025-11-05 01:50:38 --> Language Class Initialized
INFO - 2025-11-05 01:50:38 --> Loader Class Initialized
INFO - 2025-11-05 01:50:38 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:50:38 --> Helper loaded: url_helper
INFO - 2025-11-05 01:50:38 --> Helper loaded: file_helper
INFO - 2025-11-05 01:50:38 --> Helper loaded: main_helper
INFO - 2025-11-05 01:50:38 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:50:38 --> Database Driver Class Initialized
INFO - 2025-11-05 01:50:38 --> Email Class Initialized
DEBUG - 2025-11-05 01:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:50:38 --> Controller Class Initialized
INFO - 2025-11-05 01:50:38 --> Model "User_model" initialized
INFO - 2025-11-05 01:50:38 --> Model "Project_model" initialized
INFO - 2025-11-05 01:50:38 --> Helper loaded: form_helper
INFO - 2025-11-05 01:50:38 --> Form Validation Class Initialized
INFO - 2025-11-05 01:50:38 --> Final output sent to browser
INFO - 2025-11-05 01:50:38 --> Total execution time: 0.0606
INFO - 2025-11-05 01:51:08 --> Config Class Initialized
INFO - 2025-11-05 01:51:08 --> Hooks Class Initialized
INFO - 2025-11-05 01:51:08 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:51:08 --> Utf8 Class Initialized
INFO - 2025-11-05 01:51:08 --> URI Class Initialized
INFO - 2025-11-05 01:51:08 --> Router Class Initialized
INFO - 2025-11-05 01:51:08 --> Output Class Initialized
INFO - 2025-11-05 01:51:08 --> Security Class Initialized
INFO - 2025-11-05 01:51:08 --> Input Class Initialized
INFO - 2025-11-05 01:51:08 --> Language Class Initialized
INFO - 2025-11-05 01:51:08 --> Loader Class Initialized
INFO - 2025-11-05 01:51:08 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:51:09 --> Helper loaded: url_helper
INFO - 2025-11-05 01:51:09 --> Helper loaded: file_helper
INFO - 2025-11-05 01:51:09 --> Helper loaded: main_helper
INFO - 2025-11-05 01:51:09 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:51:09 --> Database Driver Class Initialized
INFO - 2025-11-05 01:51:09 --> Email Class Initialized
DEBUG - 2025-11-05 01:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:51:09 --> Controller Class Initialized
INFO - 2025-11-05 01:51:09 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:51:09 --> Model "User_model" initialized
INFO - 2025-11-05 01:51:09 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:51:09 --> Model "Project_model" initialized
INFO - 2025-11-05 01:51:09 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 01:51:09 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 01:51:09 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 01:51:09 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-efe.php
INFO - 2025-11-05 01:51:09 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 01:51:09 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 01:51:09 --> Final output sent to browser
INFO - 2025-11-05 01:51:09 --> Total execution time: 0.0819
INFO - 2025-11-05 01:51:09 --> Config Class Initialized
INFO - 2025-11-05 01:51:09 --> Hooks Class Initialized
INFO - 2025-11-05 01:51:09 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:51:09 --> Utf8 Class Initialized
INFO - 2025-11-05 01:51:09 --> URI Class Initialized
INFO - 2025-11-05 01:51:09 --> Router Class Initialized
INFO - 2025-11-05 01:51:09 --> Output Class Initialized
INFO - 2025-11-05 01:51:09 --> Security Class Initialized
INFO - 2025-11-05 01:51:09 --> Input Class Initialized
INFO - 2025-11-05 01:51:09 --> Language Class Initialized
INFO - 2025-11-05 01:51:09 --> Loader Class Initialized
INFO - 2025-11-05 01:51:09 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:51:09 --> Helper loaded: url_helper
INFO - 2025-11-05 01:51:09 --> Helper loaded: file_helper
INFO - 2025-11-05 01:51:09 --> Helper loaded: main_helper
INFO - 2025-11-05 01:51:09 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:51:09 --> Database Driver Class Initialized
INFO - 2025-11-05 01:51:09 --> Email Class Initialized
DEBUG - 2025-11-05 01:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:51:09 --> Controller Class Initialized
INFO - 2025-11-05 01:51:09 --> Model "User_model" initialized
INFO - 2025-11-05 01:51:09 --> Model "Project_model" initialized
INFO - 2025-11-05 01:51:09 --> Helper loaded: form_helper
INFO - 2025-11-05 01:51:09 --> Form Validation Class Initialized
INFO - 2025-11-05 01:51:09 --> Final output sent to browser
INFO - 2025-11-05 01:51:09 --> Total execution time: 0.0574
INFO - 2025-11-05 01:59:51 --> Config Class Initialized
INFO - 2025-11-05 01:59:51 --> Hooks Class Initialized
INFO - 2025-11-05 01:59:51 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:59:51 --> Utf8 Class Initialized
INFO - 2025-11-05 01:59:51 --> URI Class Initialized
INFO - 2025-11-05 01:59:51 --> Config Class Initialized
INFO - 2025-11-05 01:59:51 --> Router Class Initialized
INFO - 2025-11-05 01:59:51 --> Hooks Class Initialized
INFO - 2025-11-05 01:59:51 --> Output Class Initialized
INFO - 2025-11-05 01:59:51 --> Security Class Initialized
INFO - 2025-11-05 01:59:51 --> Input Class Initialized
INFO - 2025-11-05 01:59:51 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:59:51 --> Language Class Initialized
INFO - 2025-11-05 01:59:51 --> Utf8 Class Initialized
INFO - 2025-11-05 01:59:51 --> URI Class Initialized
INFO - 2025-11-05 01:59:51 --> Loader Class Initialized
INFO - 2025-11-05 01:59:51 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:59:51 --> Router Class Initialized
INFO - 2025-11-05 01:59:51 --> Helper loaded: url_helper
INFO - 2025-11-05 01:59:51 --> Output Class Initialized
INFO - 2025-11-05 01:59:51 --> Helper loaded: file_helper
INFO - 2025-11-05 01:59:51 --> Helper loaded: main_helper
INFO - 2025-11-05 01:59:51 --> Security Class Initialized
INFO - 2025-11-05 01:59:51 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:59:51 --> Input Class Initialized
INFO - 2025-11-05 01:59:51 --> Language Class Initialized
INFO - 2025-11-05 01:59:51 --> Loader Class Initialized
INFO - 2025-11-05 01:59:51 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:59:51 --> Helper loaded: url_helper
INFO - 2025-11-05 01:59:51 --> Helper loaded: file_helper
INFO - 2025-11-05 01:59:51 --> Helper loaded: main_helper
INFO - 2025-11-05 01:59:51 --> Database Driver Class Initialized
INFO - 2025-11-05 01:59:51 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:59:51 --> Email Class Initialized
INFO - 2025-11-05 01:59:51 --> Database Driver Class Initialized
DEBUG - 2025-11-05 01:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:59:51 --> Email Class Initialized
INFO - 2025-11-05 01:59:51 --> Controller Class Initialized
DEBUG - 2025-11-05 01:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:59:51 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:59:51 --> Model "User_model" initialized
INFO - 2025-11-05 01:59:51 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:59:51 --> Model "Project_model" initialized
INFO - 2025-11-05 01:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:59:51 --> Controller Class Initialized
INFO - 2025-11-05 01:59:51 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:59:51 --> Model "User_model" initialized
INFO - 2025-11-05 01:59:51 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:59:51 --> Model "Project_model" initialized
INFO - 2025-11-05 01:59:51 --> Config Class Initialized
INFO - 2025-11-05 01:59:51 --> Hooks Class Initialized
INFO - 2025-11-05 01:59:51 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:59:51 --> Utf8 Class Initialized
INFO - 2025-11-05 01:59:51 --> URI Class Initialized
INFO - 2025-11-05 01:59:51 --> Router Class Initialized
INFO - 2025-11-05 01:59:51 --> Output Class Initialized
INFO - 2025-11-05 01:59:51 --> Security Class Initialized
INFO - 2025-11-05 01:59:51 --> Input Class Initialized
INFO - 2025-11-05 01:59:51 --> Language Class Initialized
INFO - 2025-11-05 01:59:51 --> Loader Class Initialized
INFO - 2025-11-05 01:59:51 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:59:51 --> Helper loaded: url_helper
INFO - 2025-11-05 01:59:51 --> Helper loaded: file_helper
INFO - 2025-11-05 01:59:51 --> Helper loaded: main_helper
INFO - 2025-11-05 01:59:51 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:59:51 --> Database Driver Class Initialized
INFO - 2025-11-05 01:59:51 --> Email Class Initialized
DEBUG - 2025-11-05 01:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:59:51 --> Controller Class Initialized
INFO - 2025-11-05 01:59:51 --> Config Class Initialized
INFO - 2025-11-05 01:59:51 --> Hooks Class Initialized
INFO - 2025-11-05 01:59:51 --> Config Class Initialized
INFO - 2025-11-05 01:59:51 --> Hooks Class Initialized
INFO - 2025-11-05 01:59:51 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:59:51 --> Utf8 Class Initialized
INFO - 2025-11-05 01:59:51 --> URI Class Initialized
INFO - 2025-11-05 01:59:51 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:59:51 --> Utf8 Class Initialized
INFO - 2025-11-05 01:59:51 --> Router Class Initialized
INFO - 2025-11-05 01:59:51 --> URI Class Initialized
INFO - 2025-11-05 01:59:51 --> Output Class Initialized
INFO - 2025-11-05 01:59:51 --> Router Class Initialized
INFO - 2025-11-05 01:59:51 --> Security Class Initialized
INFO - 2025-11-05 01:59:51 --> Output Class Initialized
INFO - 2025-11-05 01:59:51 --> Input Class Initialized
INFO - 2025-11-05 01:59:51 --> Security Class Initialized
INFO - 2025-11-05 01:59:51 --> Language Class Initialized
INFO - 2025-11-05 01:59:51 --> Input Class Initialized
INFO - 2025-11-05 01:59:51 --> Language Class Initialized
INFO - 2025-11-05 01:59:51 --> Loader Class Initialized
INFO - 2025-11-05 01:59:51 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:59:51 --> Loader Class Initialized
INFO - 2025-11-05 01:59:51 --> Helper loaded: url_helper
INFO - 2025-11-05 01:59:51 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:59:51 --> Helper loaded: file_helper
INFO - 2025-11-05 01:59:51 --> Helper loaded: url_helper
INFO - 2025-11-05 01:59:51 --> Helper loaded: main_helper
INFO - 2025-11-05 01:59:51 --> Helper loaded: file_helper
INFO - 2025-11-05 01:59:51 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:59:51 --> Helper loaded: main_helper
INFO - 2025-11-05 01:59:51 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:59:51 --> Database Driver Class Initialized
INFO - 2025-11-05 01:59:51 --> Database Driver Class Initialized
INFO - 2025-11-05 01:59:51 --> Email Class Initialized
INFO - 2025-11-05 01:59:51 --> Email Class Initialized
DEBUG - 2025-11-05 01:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-11-05 01:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:59:51 --> Controller Class Initialized
INFO - 2025-11-05 01:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:59:51 --> Controller Class Initialized
INFO - 2025-11-05 01:59:51 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:59:51 --> Model "User_model" initialized
INFO - 2025-11-05 01:59:51 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:59:51 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-05 01:59:51 --> Final output sent to browser
INFO - 2025-11-05 01:59:51 --> Total execution time: 0.0483
INFO - 2025-11-05 01:59:51 --> Config Class Initialized
INFO - 2025-11-05 01:59:51 --> Hooks Class Initialized
INFO - 2025-11-05 01:59:51 --> UTF-8 Support Enabled
INFO - 2025-11-05 01:59:51 --> Utf8 Class Initialized
INFO - 2025-11-05 01:59:51 --> URI Class Initialized
INFO - 2025-11-05 01:59:51 --> Router Class Initialized
INFO - 2025-11-05 01:59:51 --> Output Class Initialized
INFO - 2025-11-05 01:59:51 --> Security Class Initialized
INFO - 2025-11-05 01:59:51 --> Input Class Initialized
INFO - 2025-11-05 01:59:51 --> Language Class Initialized
INFO - 2025-11-05 01:59:51 --> Loader Class Initialized
INFO - 2025-11-05 01:59:51 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 01:59:51 --> Helper loaded: url_helper
INFO - 2025-11-05 01:59:51 --> Helper loaded: file_helper
INFO - 2025-11-05 01:59:51 --> Helper loaded: main_helper
INFO - 2025-11-05 01:59:51 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 01:59:51 --> Database Driver Class Initialized
INFO - 2025-11-05 01:59:51 --> Email Class Initialized
DEBUG - 2025-11-05 01:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 01:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 01:59:51 --> Controller Class Initialized
INFO - 2025-11-05 01:59:51 --> Model "Subscription_model" initialized
INFO - 2025-11-05 01:59:51 --> Model "User_model" initialized
INFO - 2025-11-05 01:59:51 --> Model "Auth_model" initialized
INFO - 2025-11-05 01:59:51 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-05 01:59:51 --> Final output sent to browser
INFO - 2025-11-05 01:59:51 --> Total execution time: 0.0694
INFO - 2025-11-05 02:09:43 --> Config Class Initialized
INFO - 2025-11-05 02:09:43 --> Hooks Class Initialized
INFO - 2025-11-05 02:09:43 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:09:43 --> Utf8 Class Initialized
INFO - 2025-11-05 02:09:43 --> URI Class Initialized
INFO - 2025-11-05 02:09:43 --> Router Class Initialized
INFO - 2025-11-05 02:09:43 --> Output Class Initialized
INFO - 2025-11-05 02:09:43 --> Security Class Initialized
INFO - 2025-11-05 02:09:43 --> Input Class Initialized
INFO - 2025-11-05 02:09:43 --> Language Class Initialized
INFO - 2025-11-05 02:09:43 --> Loader Class Initialized
INFO - 2025-11-05 02:09:43 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:09:43 --> Helper loaded: url_helper
INFO - 2025-11-05 02:09:43 --> Helper loaded: file_helper
INFO - 2025-11-05 02:09:43 --> Helper loaded: main_helper
INFO - 2025-11-05 02:09:43 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:09:43 --> Database Driver Class Initialized
INFO - 2025-11-05 02:09:43 --> Email Class Initialized
DEBUG - 2025-11-05 02:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:09:43 --> Controller Class Initialized
INFO - 2025-11-05 02:09:43 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:09:43 --> Model "User_model" initialized
INFO - 2025-11-05 02:09:43 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:09:43 --> Model "Project_model" initialized
INFO - 2025-11-05 02:09:43 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 02:09:43 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 02:09:43 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 02:09:43 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-efe.php
INFO - 2025-11-05 02:09:43 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 02:09:43 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 02:09:43 --> Final output sent to browser
INFO - 2025-11-05 02:09:43 --> Total execution time: 0.0700
INFO - 2025-11-05 02:09:43 --> Config Class Initialized
INFO - 2025-11-05 02:09:43 --> Hooks Class Initialized
INFO - 2025-11-05 02:09:43 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:09:43 --> Utf8 Class Initialized
INFO - 2025-11-05 02:09:43 --> URI Class Initialized
INFO - 2025-11-05 02:09:43 --> Router Class Initialized
INFO - 2025-11-05 02:09:43 --> Output Class Initialized
INFO - 2025-11-05 02:09:43 --> Security Class Initialized
INFO - 2025-11-05 02:09:43 --> Input Class Initialized
INFO - 2025-11-05 02:09:43 --> Language Class Initialized
INFO - 2025-11-05 02:09:43 --> Loader Class Initialized
INFO - 2025-11-05 02:09:43 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:09:43 --> Helper loaded: url_helper
INFO - 2025-11-05 02:09:43 --> Helper loaded: file_helper
INFO - 2025-11-05 02:09:43 --> Helper loaded: main_helper
INFO - 2025-11-05 02:09:43 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:09:43 --> Database Driver Class Initialized
INFO - 2025-11-05 02:09:43 --> Email Class Initialized
DEBUG - 2025-11-05 02:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:09:43 --> Controller Class Initialized
INFO - 2025-11-05 02:09:43 --> Model "User_model" initialized
INFO - 2025-11-05 02:09:43 --> Model "Project_model" initialized
INFO - 2025-11-05 02:09:43 --> Helper loaded: form_helper
INFO - 2025-11-05 02:09:43 --> Form Validation Class Initialized
INFO - 2025-11-05 02:09:43 --> Final output sent to browser
INFO - 2025-11-05 02:09:43 --> Total execution time: 0.0555
INFO - 2025-11-05 02:09:55 --> Config Class Initialized
INFO - 2025-11-05 02:09:55 --> Hooks Class Initialized
INFO - 2025-11-05 02:09:55 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:09:55 --> Utf8 Class Initialized
INFO - 2025-11-05 02:09:55 --> URI Class Initialized
INFO - 2025-11-05 02:09:55 --> Router Class Initialized
INFO - 2025-11-05 02:09:55 --> Output Class Initialized
INFO - 2025-11-05 02:09:55 --> Security Class Initialized
INFO - 2025-11-05 02:09:55 --> Input Class Initialized
INFO - 2025-11-05 02:09:55 --> Language Class Initialized
INFO - 2025-11-05 02:09:55 --> Loader Class Initialized
INFO - 2025-11-05 02:09:55 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:09:55 --> Helper loaded: url_helper
INFO - 2025-11-05 02:09:55 --> Helper loaded: file_helper
INFO - 2025-11-05 02:09:55 --> Helper loaded: main_helper
INFO - 2025-11-05 02:09:55 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:09:55 --> Database Driver Class Initialized
INFO - 2025-11-05 02:09:55 --> Email Class Initialized
DEBUG - 2025-11-05 02:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:09:55 --> Controller Class Initialized
INFO - 2025-11-05 02:09:55 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:09:55 --> Model "User_model" initialized
INFO - 2025-11-05 02:09:55 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:09:55 --> Model "Project_model" initialized
INFO - 2025-11-05 02:09:55 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 02:09:55 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 02:09:55 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 02:09:55 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ie.php
INFO - 2025-11-05 02:09:55 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 02:09:55 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 02:09:55 --> Final output sent to browser
INFO - 2025-11-05 02:09:55 --> Total execution time: 0.0617
INFO - 2025-11-05 02:09:55 --> Config Class Initialized
INFO - 2025-11-05 02:09:55 --> Config Class Initialized
INFO - 2025-11-05 02:09:55 --> Hooks Class Initialized
INFO - 2025-11-05 02:09:55 --> Hooks Class Initialized
INFO - 2025-11-05 02:09:55 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:09:55 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:09:55 --> Utf8 Class Initialized
INFO - 2025-11-05 02:09:55 --> Utf8 Class Initialized
INFO - 2025-11-05 02:09:55 --> URI Class Initialized
INFO - 2025-11-05 02:09:55 --> URI Class Initialized
INFO - 2025-11-05 02:09:55 --> Router Class Initialized
INFO - 2025-11-05 02:09:55 --> Router Class Initialized
INFO - 2025-11-05 02:09:55 --> Output Class Initialized
INFO - 2025-11-05 02:09:55 --> Output Class Initialized
INFO - 2025-11-05 02:09:55 --> Security Class Initialized
INFO - 2025-11-05 02:09:55 --> Security Class Initialized
INFO - 2025-11-05 02:09:55 --> Input Class Initialized
INFO - 2025-11-05 02:09:55 --> Input Class Initialized
INFO - 2025-11-05 02:09:55 --> Language Class Initialized
INFO - 2025-11-05 02:09:55 --> Language Class Initialized
INFO - 2025-11-05 02:09:55 --> Loader Class Initialized
INFO - 2025-11-05 02:09:55 --> Loader Class Initialized
INFO - 2025-11-05 02:09:55 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:09:55 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:09:55 --> Helper loaded: url_helper
INFO - 2025-11-05 02:09:55 --> Helper loaded: url_helper
INFO - 2025-11-05 02:09:55 --> Helper loaded: file_helper
INFO - 2025-11-05 02:09:55 --> Helper loaded: file_helper
INFO - 2025-11-05 02:09:55 --> Helper loaded: main_helper
INFO - 2025-11-05 02:09:55 --> Helper loaded: main_helper
INFO - 2025-11-05 02:09:55 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:09:55 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:09:55 --> Database Driver Class Initialized
INFO - 2025-11-05 02:09:55 --> Database Driver Class Initialized
INFO - 2025-11-05 02:09:55 --> Email Class Initialized
DEBUG - 2025-11-05 02:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:09:55 --> Controller Class Initialized
INFO - 2025-11-05 02:09:55 --> Email Class Initialized
INFO - 2025-11-05 02:09:55 --> Model "User_model" initialized
INFO - 2025-11-05 02:09:55 --> Model "Project_model" initialized
DEBUG - 2025-11-05 02:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:09:55 --> Helper loaded: form_helper
INFO - 2025-11-05 02:09:55 --> Form Validation Class Initialized
INFO - 2025-11-05 02:09:55 --> Final output sent to browser
INFO - 2025-11-05 02:09:55 --> Total execution time: 0.0549
INFO - 2025-11-05 02:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:09:55 --> Controller Class Initialized
INFO - 2025-11-05 02:09:55 --> Model "User_model" initialized
INFO - 2025-11-05 02:09:55 --> Model "Project_model" initialized
INFO - 2025-11-05 02:09:55 --> Helper loaded: form_helper
INFO - 2025-11-05 02:09:55 --> Form Validation Class Initialized
INFO - 2025-11-05 02:09:55 --> Final output sent to browser
INFO - 2025-11-05 02:09:55 --> Total execution time: 0.0654
INFO - 2025-11-05 02:09:56 --> Config Class Initialized
INFO - 2025-11-05 02:09:56 --> Hooks Class Initialized
INFO - 2025-11-05 02:09:56 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:09:56 --> Utf8 Class Initialized
INFO - 2025-11-05 02:09:56 --> URI Class Initialized
INFO - 2025-11-05 02:09:56 --> Router Class Initialized
INFO - 2025-11-05 02:09:56 --> Output Class Initialized
INFO - 2025-11-05 02:09:56 --> Security Class Initialized
INFO - 2025-11-05 02:09:56 --> Input Class Initialized
INFO - 2025-11-05 02:09:56 --> Language Class Initialized
INFO - 2025-11-05 02:09:56 --> Loader Class Initialized
INFO - 2025-11-05 02:09:56 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:09:56 --> Helper loaded: url_helper
INFO - 2025-11-05 02:09:56 --> Helper loaded: file_helper
INFO - 2025-11-05 02:09:56 --> Helper loaded: main_helper
INFO - 2025-11-05 02:09:56 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:09:56 --> Database Driver Class Initialized
INFO - 2025-11-05 02:09:56 --> Email Class Initialized
DEBUG - 2025-11-05 02:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:09:56 --> Controller Class Initialized
INFO - 2025-11-05 02:09:56 --> Model "User_model" initialized
INFO - 2025-11-05 02:09:56 --> Model "Project_model" initialized
INFO - 2025-11-05 02:09:56 --> Helper loaded: form_helper
INFO - 2025-11-05 02:09:56 --> Form Validation Class Initialized
INFO - 2025-11-05 02:09:56 --> Final output sent to browser
INFO - 2025-11-05 02:09:56 --> Total execution time: 0.0799
INFO - 2025-11-05 02:09:56 --> Config Class Initialized
INFO - 2025-11-05 02:09:56 --> Hooks Class Initialized
INFO - 2025-11-05 02:09:56 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:09:56 --> Utf8 Class Initialized
INFO - 2025-11-05 02:09:56 --> URI Class Initialized
INFO - 2025-11-05 02:09:56 --> Router Class Initialized
INFO - 2025-11-05 02:09:56 --> Output Class Initialized
INFO - 2025-11-05 02:09:56 --> Security Class Initialized
INFO - 2025-11-05 02:09:56 --> Input Class Initialized
INFO - 2025-11-05 02:09:56 --> Language Class Initialized
INFO - 2025-11-05 02:09:56 --> Loader Class Initialized
INFO - 2025-11-05 02:09:56 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:09:56 --> Helper loaded: url_helper
INFO - 2025-11-05 02:09:56 --> Helper loaded: file_helper
INFO - 2025-11-05 02:09:56 --> Helper loaded: main_helper
INFO - 2025-11-05 02:09:56 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:09:56 --> Database Driver Class Initialized
INFO - 2025-11-05 02:09:56 --> Email Class Initialized
DEBUG - 2025-11-05 02:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:09:56 --> Controller Class Initialized
INFO - 2025-11-05 02:09:56 --> Model "User_model" initialized
INFO - 2025-11-05 02:09:56 --> Model "Project_model" initialized
INFO - 2025-11-05 02:09:56 --> Helper loaded: form_helper
INFO - 2025-11-05 02:09:56 --> Form Validation Class Initialized
INFO - 2025-11-05 02:09:56 --> Final output sent to browser
INFO - 2025-11-05 02:09:56 --> Total execution time: 0.0892
INFO - 2025-11-05 02:09:58 --> Config Class Initialized
INFO - 2025-11-05 02:09:58 --> Hooks Class Initialized
INFO - 2025-11-05 02:09:58 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:09:58 --> Utf8 Class Initialized
INFO - 2025-11-05 02:09:58 --> URI Class Initialized
INFO - 2025-11-05 02:09:58 --> Router Class Initialized
INFO - 2025-11-05 02:09:58 --> Output Class Initialized
INFO - 2025-11-05 02:09:58 --> Security Class Initialized
INFO - 2025-11-05 02:09:58 --> Input Class Initialized
INFO - 2025-11-05 02:09:58 --> Language Class Initialized
INFO - 2025-11-05 02:09:58 --> Loader Class Initialized
INFO - 2025-11-05 02:09:58 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:09:58 --> Helper loaded: url_helper
INFO - 2025-11-05 02:09:58 --> Helper loaded: file_helper
INFO - 2025-11-05 02:09:58 --> Helper loaded: main_helper
INFO - 2025-11-05 02:09:58 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:09:58 --> Database Driver Class Initialized
INFO - 2025-11-05 02:09:58 --> Email Class Initialized
DEBUG - 2025-11-05 02:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:09:58 --> Controller Class Initialized
INFO - 2025-11-05 02:09:58 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:09:58 --> Model "User_model" initialized
INFO - 2025-11-05 02:09:58 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:09:58 --> Model "Project_model" initialized
INFO - 2025-11-05 02:09:58 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 02:09:58 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 02:09:58 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 02:09:58 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ife.php
INFO - 2025-11-05 02:09:58 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 02:09:58 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 02:09:58 --> Final output sent to browser
INFO - 2025-11-05 02:09:58 --> Total execution time: 0.0587
INFO - 2025-11-05 02:09:58 --> Config Class Initialized
INFO - 2025-11-05 02:09:58 --> Hooks Class Initialized
INFO - 2025-11-05 02:09:58 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:09:58 --> Utf8 Class Initialized
INFO - 2025-11-05 02:09:58 --> URI Class Initialized
INFO - 2025-11-05 02:09:58 --> Router Class Initialized
INFO - 2025-11-05 02:09:58 --> Output Class Initialized
INFO - 2025-11-05 02:09:58 --> Security Class Initialized
INFO - 2025-11-05 02:09:58 --> Input Class Initialized
INFO - 2025-11-05 02:09:58 --> Language Class Initialized
INFO - 2025-11-05 02:09:58 --> Loader Class Initialized
INFO - 2025-11-05 02:09:58 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:09:58 --> Helper loaded: url_helper
INFO - 2025-11-05 02:09:58 --> Helper loaded: file_helper
INFO - 2025-11-05 02:09:58 --> Helper loaded: main_helper
INFO - 2025-11-05 02:09:58 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:09:58 --> Database Driver Class Initialized
INFO - 2025-11-05 02:09:58 --> Email Class Initialized
DEBUG - 2025-11-05 02:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:09:58 --> Controller Class Initialized
INFO - 2025-11-05 02:09:58 --> Model "User_model" initialized
INFO - 2025-11-05 02:09:58 --> Model "Project_model" initialized
INFO - 2025-11-05 02:09:58 --> Helper loaded: form_helper
INFO - 2025-11-05 02:09:58 --> Form Validation Class Initialized
INFO - 2025-11-05 02:09:58 --> Final output sent to browser
INFO - 2025-11-05 02:09:58 --> Total execution time: 0.0606
INFO - 2025-11-05 02:10:10 --> Config Class Initialized
INFO - 2025-11-05 02:10:10 --> Hooks Class Initialized
INFO - 2025-11-05 02:10:10 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:10:10 --> Utf8 Class Initialized
INFO - 2025-11-05 02:10:10 --> URI Class Initialized
INFO - 2025-11-05 02:10:10 --> Router Class Initialized
INFO - 2025-11-05 02:10:10 --> Output Class Initialized
INFO - 2025-11-05 02:10:10 --> Security Class Initialized
INFO - 2025-11-05 02:10:10 --> Input Class Initialized
INFO - 2025-11-05 02:10:10 --> Language Class Initialized
INFO - 2025-11-05 02:10:10 --> Loader Class Initialized
INFO - 2025-11-05 02:10:10 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:10:10 --> Helper loaded: url_helper
INFO - 2025-11-05 02:10:10 --> Helper loaded: file_helper
INFO - 2025-11-05 02:10:10 --> Helper loaded: main_helper
INFO - 2025-11-05 02:10:10 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:10:10 --> Database Driver Class Initialized
INFO - 2025-11-05 02:10:10 --> Email Class Initialized
DEBUG - 2025-11-05 02:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:10:10 --> Controller Class Initialized
INFO - 2025-11-05 02:10:10 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:10:10 --> Model "User_model" initialized
INFO - 2025-11-05 02:10:10 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:10:10 --> Model "Project_model" initialized
INFO - 2025-11-05 02:10:10 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 02:10:10 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 02:10:10 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 02:10:10 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-efe.php
INFO - 2025-11-05 02:10:10 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 02:10:10 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 02:10:10 --> Final output sent to browser
INFO - 2025-11-05 02:10:10 --> Total execution time: 0.0642
INFO - 2025-11-05 02:10:10 --> Config Class Initialized
INFO - 2025-11-05 02:10:10 --> Hooks Class Initialized
INFO - 2025-11-05 02:10:10 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:10:10 --> Utf8 Class Initialized
INFO - 2025-11-05 02:10:10 --> URI Class Initialized
INFO - 2025-11-05 02:10:10 --> Router Class Initialized
INFO - 2025-11-05 02:10:10 --> Output Class Initialized
INFO - 2025-11-05 02:10:10 --> Security Class Initialized
INFO - 2025-11-05 02:10:10 --> Input Class Initialized
INFO - 2025-11-05 02:10:10 --> Language Class Initialized
INFO - 2025-11-05 02:10:10 --> Loader Class Initialized
INFO - 2025-11-05 02:10:10 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:10:10 --> Helper loaded: url_helper
INFO - 2025-11-05 02:10:10 --> Helper loaded: file_helper
INFO - 2025-11-05 02:10:10 --> Helper loaded: main_helper
INFO - 2025-11-05 02:10:10 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:10:10 --> Database Driver Class Initialized
INFO - 2025-11-05 02:10:10 --> Email Class Initialized
DEBUG - 2025-11-05 02:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:10:10 --> Controller Class Initialized
INFO - 2025-11-05 02:10:10 --> Model "User_model" initialized
INFO - 2025-11-05 02:10:10 --> Model "Project_model" initialized
INFO - 2025-11-05 02:10:10 --> Helper loaded: form_helper
INFO - 2025-11-05 02:10:10 --> Form Validation Class Initialized
INFO - 2025-11-05 02:10:10 --> Final output sent to browser
INFO - 2025-11-05 02:10:10 --> Total execution time: 0.0913
INFO - 2025-11-05 02:12:32 --> Config Class Initialized
INFO - 2025-11-05 02:12:32 --> Hooks Class Initialized
INFO - 2025-11-05 02:12:32 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:12:32 --> Utf8 Class Initialized
INFO - 2025-11-05 02:12:32 --> URI Class Initialized
DEBUG - 2025-11-05 02:12:32 --> No URI present. Default controller set.
INFO - 2025-11-05 02:12:32 --> Router Class Initialized
INFO - 2025-11-05 02:12:32 --> Output Class Initialized
INFO - 2025-11-05 02:12:32 --> Security Class Initialized
INFO - 2025-11-05 02:12:32 --> Input Class Initialized
INFO - 2025-11-05 02:12:32 --> Language Class Initialized
INFO - 2025-11-05 02:12:32 --> Loader Class Initialized
INFO - 2025-11-05 02:12:32 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:12:32 --> Helper loaded: url_helper
INFO - 2025-11-05 02:12:32 --> Helper loaded: file_helper
INFO - 2025-11-05 02:12:32 --> Helper loaded: main_helper
INFO - 2025-11-05 02:12:32 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:12:32 --> Database Driver Class Initialized
INFO - 2025-11-05 02:12:32 --> Email Class Initialized
DEBUG - 2025-11-05 02:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:12:32 --> Controller Class Initialized
INFO - 2025-11-05 02:12:32 --> Config Class Initialized
INFO - 2025-11-05 02:12:32 --> Hooks Class Initialized
INFO - 2025-11-05 02:12:32 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:12:32 --> Utf8 Class Initialized
INFO - 2025-11-05 02:12:32 --> URI Class Initialized
INFO - 2025-11-05 02:12:32 --> Router Class Initialized
INFO - 2025-11-05 02:12:32 --> Output Class Initialized
INFO - 2025-11-05 02:12:32 --> Security Class Initialized
INFO - 2025-11-05 02:12:32 --> Input Class Initialized
INFO - 2025-11-05 02:12:32 --> Language Class Initialized
INFO - 2025-11-05 02:12:32 --> Loader Class Initialized
INFO - 2025-11-05 02:12:32 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:12:32 --> Helper loaded: url_helper
INFO - 2025-11-05 02:12:32 --> Helper loaded: file_helper
INFO - 2025-11-05 02:12:32 --> Helper loaded: main_helper
INFO - 2025-11-05 02:12:32 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:12:32 --> Database Driver Class Initialized
INFO - 2025-11-05 02:12:32 --> Email Class Initialized
DEBUG - 2025-11-05 02:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:12:32 --> Controller Class Initialized
INFO - 2025-11-05 02:12:32 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:12:32 --> Model "User_model" initialized
INFO - 2025-11-05 02:12:32 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:12:32 --> Config Class Initialized
INFO - 2025-11-05 02:12:32 --> Hooks Class Initialized
INFO - 2025-11-05 02:12:32 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:12:32 --> Utf8 Class Initialized
INFO - 2025-11-05 02:12:32 --> URI Class Initialized
INFO - 2025-11-05 02:12:32 --> Router Class Initialized
INFO - 2025-11-05 02:12:32 --> Output Class Initialized
INFO - 2025-11-05 02:12:32 --> Security Class Initialized
INFO - 2025-11-05 02:12:32 --> Input Class Initialized
INFO - 2025-11-05 02:12:32 --> Language Class Initialized
INFO - 2025-11-05 02:12:32 --> Loader Class Initialized
INFO - 2025-11-05 02:12:32 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:12:32 --> Helper loaded: url_helper
INFO - 2025-11-05 02:12:32 --> Helper loaded: file_helper
INFO - 2025-11-05 02:12:32 --> Helper loaded: main_helper
INFO - 2025-11-05 02:12:32 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:12:32 --> Database Driver Class Initialized
INFO - 2025-11-05 02:12:32 --> Email Class Initialized
DEBUG - 2025-11-05 02:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:12:32 --> Controller Class Initialized
INFO - 2025-11-05 02:12:32 --> Config Class Initialized
INFO - 2025-11-05 02:12:32 --> Hooks Class Initialized
INFO - 2025-11-05 02:12:32 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:12:32 --> Utf8 Class Initialized
INFO - 2025-11-05 02:12:32 --> URI Class Initialized
INFO - 2025-11-05 02:12:32 --> Router Class Initialized
INFO - 2025-11-05 02:12:32 --> Output Class Initialized
INFO - 2025-11-05 02:12:32 --> Security Class Initialized
INFO - 2025-11-05 02:12:32 --> Input Class Initialized
INFO - 2025-11-05 02:12:32 --> Language Class Initialized
INFO - 2025-11-05 02:12:32 --> Loader Class Initialized
INFO - 2025-11-05 02:12:32 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:12:32 --> Helper loaded: url_helper
INFO - 2025-11-05 02:12:32 --> Helper loaded: file_helper
INFO - 2025-11-05 02:12:32 --> Helper loaded: main_helper
INFO - 2025-11-05 02:12:32 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:12:32 --> Database Driver Class Initialized
INFO - 2025-11-05 02:12:32 --> Email Class Initialized
DEBUG - 2025-11-05 02:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:12:32 --> Controller Class Initialized
INFO - 2025-11-05 02:12:32 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:12:32 --> Model "User_model" initialized
INFO - 2025-11-05 02:12:32 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:12:32 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-05 02:12:32 --> Final output sent to browser
INFO - 2025-11-05 02:12:32 --> Total execution time: 0.0750
INFO - 2025-11-05 02:12:33 --> Config Class Initialized
INFO - 2025-11-05 02:12:33 --> Hooks Class Initialized
INFO - 2025-11-05 02:12:33 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:12:33 --> Utf8 Class Initialized
INFO - 2025-11-05 02:13:28 --> Config Class Initialized
INFO - 2025-11-05 02:13:28 --> Hooks Class Initialized
INFO - 2025-11-05 02:13:28 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:13:28 --> Utf8 Class Initialized
INFO - 2025-11-05 02:13:28 --> URI Class Initialized
INFO - 2025-11-05 02:13:28 --> Router Class Initialized
INFO - 2025-11-05 02:13:28 --> Output Class Initialized
INFO - 2025-11-05 02:13:28 --> Security Class Initialized
INFO - 2025-11-05 02:13:28 --> Input Class Initialized
INFO - 2025-11-05 02:13:28 --> Language Class Initialized
INFO - 2025-11-05 02:13:28 --> Loader Class Initialized
INFO - 2025-11-05 02:13:28 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:13:28 --> Helper loaded: url_helper
INFO - 2025-11-05 02:13:28 --> Helper loaded: file_helper
INFO - 2025-11-05 02:13:28 --> Helper loaded: main_helper
INFO - 2025-11-05 02:13:28 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:13:28 --> Database Driver Class Initialized
INFO - 2025-11-05 02:13:28 --> Email Class Initialized
DEBUG - 2025-11-05 02:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:13:28 --> Controller Class Initialized
INFO - 2025-11-05 02:13:28 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:13:28 --> Model "User_model" initialized
INFO - 2025-11-05 02:13:28 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:13:28 --> Model "Project_model" initialized
INFO - 2025-11-05 02:13:28 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 02:13:28 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 02:13:28 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 02:13:28 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-efe.php
INFO - 2025-11-05 02:13:28 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 02:13:28 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 02:13:28 --> Final output sent to browser
INFO - 2025-11-05 02:13:28 --> Total execution time: 0.2429
INFO - 2025-11-05 02:13:28 --> Config Class Initialized
INFO - 2025-11-05 02:13:28 --> Hooks Class Initialized
INFO - 2025-11-05 02:13:28 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:13:28 --> Utf8 Class Initialized
INFO - 2025-11-05 02:13:28 --> URI Class Initialized
INFO - 2025-11-05 02:13:28 --> Router Class Initialized
INFO - 2025-11-05 02:13:28 --> Output Class Initialized
INFO - 2025-11-05 02:13:28 --> Security Class Initialized
INFO - 2025-11-05 02:13:28 --> Input Class Initialized
INFO - 2025-11-05 02:13:28 --> Language Class Initialized
INFO - 2025-11-05 02:13:28 --> Loader Class Initialized
INFO - 2025-11-05 02:13:28 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:13:28 --> Helper loaded: url_helper
INFO - 2025-11-05 02:13:28 --> Helper loaded: file_helper
INFO - 2025-11-05 02:13:28 --> Helper loaded: main_helper
INFO - 2025-11-05 02:13:28 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:13:28 --> Database Driver Class Initialized
INFO - 2025-11-05 02:13:28 --> Email Class Initialized
DEBUG - 2025-11-05 02:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:13:28 --> Controller Class Initialized
INFO - 2025-11-05 02:13:28 --> Model "User_model" initialized
INFO - 2025-11-05 02:13:28 --> Model "Project_model" initialized
INFO - 2025-11-05 02:13:28 --> Helper loaded: form_helper
INFO - 2025-11-05 02:13:28 --> Form Validation Class Initialized
INFO - 2025-11-05 02:13:28 --> Final output sent to browser
INFO - 2025-11-05 02:13:28 --> Total execution time: 0.2889
INFO - 2025-11-05 02:13:34 --> Config Class Initialized
INFO - 2025-11-05 02:13:34 --> Hooks Class Initialized
INFO - 2025-11-05 02:13:34 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:13:35 --> Utf8 Class Initialized
INFO - 2025-11-05 02:13:35 --> URI Class Initialized
INFO - 2025-11-05 02:13:35 --> Router Class Initialized
INFO - 2025-11-05 02:13:35 --> Output Class Initialized
INFO - 2025-11-05 02:13:35 --> Security Class Initialized
INFO - 2025-11-05 02:13:35 --> Input Class Initialized
INFO - 2025-11-05 02:13:35 --> Language Class Initialized
INFO - 2025-11-05 02:13:35 --> Loader Class Initialized
INFO - 2025-11-05 02:13:35 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:13:35 --> Helper loaded: url_helper
INFO - 2025-11-05 02:13:35 --> Helper loaded: file_helper
INFO - 2025-11-05 02:13:35 --> Helper loaded: main_helper
INFO - 2025-11-05 02:13:35 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:13:35 --> Database Driver Class Initialized
INFO - 2025-11-05 02:13:35 --> Email Class Initialized
DEBUG - 2025-11-05 02:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:13:35 --> Controller Class Initialized
INFO - 2025-11-05 02:13:35 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:13:35 --> Model "User_model" initialized
INFO - 2025-11-05 02:13:35 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:13:35 --> Model "Project_model" initialized
INFO - 2025-11-05 02:13:35 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 02:13:35 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 02:13:35 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 02:13:35 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ie.php
INFO - 2025-11-05 02:13:35 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 02:13:35 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 02:13:35 --> Final output sent to browser
INFO - 2025-11-05 02:13:35 --> Total execution time: 0.0643
INFO - 2025-11-05 02:13:35 --> Config Class Initialized
INFO - 2025-11-05 02:13:35 --> Config Class Initialized
INFO - 2025-11-05 02:13:35 --> Hooks Class Initialized
INFO - 2025-11-05 02:13:35 --> Hooks Class Initialized
INFO - 2025-11-05 02:13:35 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:13:35 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:13:35 --> Utf8 Class Initialized
INFO - 2025-11-05 02:13:35 --> Utf8 Class Initialized
INFO - 2025-11-05 02:13:35 --> URI Class Initialized
INFO - 2025-11-05 02:13:35 --> URI Class Initialized
INFO - 2025-11-05 02:13:35 --> Router Class Initialized
INFO - 2025-11-05 02:13:35 --> Router Class Initialized
INFO - 2025-11-05 02:13:35 --> Output Class Initialized
INFO - 2025-11-05 02:13:35 --> Output Class Initialized
INFO - 2025-11-05 02:13:35 --> Security Class Initialized
INFO - 2025-11-05 02:13:35 --> Security Class Initialized
INFO - 2025-11-05 02:13:35 --> Input Class Initialized
INFO - 2025-11-05 02:13:35 --> Input Class Initialized
INFO - 2025-11-05 02:13:35 --> Language Class Initialized
INFO - 2025-11-05 02:13:35 --> Language Class Initialized
INFO - 2025-11-05 02:13:35 --> Loader Class Initialized
INFO - 2025-11-05 02:13:35 --> Loader Class Initialized
INFO - 2025-11-05 02:13:35 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:13:35 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:13:35 --> Helper loaded: url_helper
INFO - 2025-11-05 02:13:35 --> Helper loaded: url_helper
INFO - 2025-11-05 02:13:35 --> Helper loaded: file_helper
INFO - 2025-11-05 02:13:35 --> Helper loaded: file_helper
INFO - 2025-11-05 02:13:35 --> Helper loaded: main_helper
INFO - 2025-11-05 02:13:35 --> Helper loaded: main_helper
INFO - 2025-11-05 02:13:35 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:13:35 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:13:35 --> Database Driver Class Initialized
INFO - 2025-11-05 02:13:35 --> Database Driver Class Initialized
INFO - 2025-11-05 02:13:35 --> Email Class Initialized
INFO - 2025-11-05 02:13:35 --> Email Class Initialized
DEBUG - 2025-11-05 02:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-11-05 02:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:13:35 --> Controller Class Initialized
INFO - 2025-11-05 02:13:35 --> Model "User_model" initialized
INFO - 2025-11-05 02:13:35 --> Model "Project_model" initialized
INFO - 2025-11-05 02:13:35 --> Helper loaded: form_helper
INFO - 2025-11-05 02:13:35 --> Form Validation Class Initialized
INFO - 2025-11-05 02:13:35 --> Final output sent to browser
INFO - 2025-11-05 02:13:35 --> Total execution time: 0.0567
INFO - 2025-11-05 02:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:13:35 --> Controller Class Initialized
INFO - 2025-11-05 02:13:35 --> Model "User_model" initialized
INFO - 2025-11-05 02:13:35 --> Model "Project_model" initialized
INFO - 2025-11-05 02:13:35 --> Helper loaded: form_helper
INFO - 2025-11-05 02:13:35 --> Form Validation Class Initialized
INFO - 2025-11-05 02:13:35 --> Final output sent to browser
INFO - 2025-11-05 02:13:35 --> Total execution time: 0.0682
INFO - 2025-11-05 02:13:36 --> Config Class Initialized
INFO - 2025-11-05 02:13:36 --> Hooks Class Initialized
INFO - 2025-11-05 02:13:36 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:13:36 --> Utf8 Class Initialized
INFO - 2025-11-05 02:13:36 --> URI Class Initialized
INFO - 2025-11-05 02:13:36 --> Router Class Initialized
INFO - 2025-11-05 02:13:36 --> Output Class Initialized
INFO - 2025-11-05 02:13:36 --> Security Class Initialized
INFO - 2025-11-05 02:13:36 --> Input Class Initialized
INFO - 2025-11-05 02:13:36 --> Language Class Initialized
INFO - 2025-11-05 02:13:36 --> Loader Class Initialized
INFO - 2025-11-05 02:13:36 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:13:36 --> Helper loaded: url_helper
INFO - 2025-11-05 02:13:36 --> Helper loaded: file_helper
INFO - 2025-11-05 02:13:36 --> Helper loaded: main_helper
INFO - 2025-11-05 02:13:36 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:13:36 --> Database Driver Class Initialized
INFO - 2025-11-05 02:13:36 --> Email Class Initialized
DEBUG - 2025-11-05 02:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:13:36 --> Controller Class Initialized
INFO - 2025-11-05 02:13:36 --> Model "User_model" initialized
INFO - 2025-11-05 02:13:36 --> Model "Project_model" initialized
INFO - 2025-11-05 02:13:36 --> Helper loaded: form_helper
INFO - 2025-11-05 02:13:36 --> Form Validation Class Initialized
INFO - 2025-11-05 02:13:36 --> Final output sent to browser
INFO - 2025-11-05 02:13:36 --> Total execution time: 0.0711
INFO - 2025-11-05 02:13:36 --> Config Class Initialized
INFO - 2025-11-05 02:13:36 --> Hooks Class Initialized
INFO - 2025-11-05 02:13:36 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:13:36 --> Utf8 Class Initialized
INFO - 2025-11-05 02:13:36 --> URI Class Initialized
INFO - 2025-11-05 02:13:36 --> Router Class Initialized
INFO - 2025-11-05 02:13:36 --> Output Class Initialized
INFO - 2025-11-05 02:13:36 --> Security Class Initialized
INFO - 2025-11-05 02:13:36 --> Input Class Initialized
INFO - 2025-11-05 02:13:36 --> Language Class Initialized
INFO - 2025-11-05 02:13:36 --> Loader Class Initialized
INFO - 2025-11-05 02:13:36 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:13:36 --> Helper loaded: url_helper
INFO - 2025-11-05 02:13:36 --> Helper loaded: file_helper
INFO - 2025-11-05 02:13:36 --> Helper loaded: main_helper
INFO - 2025-11-05 02:13:36 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:13:36 --> Database Driver Class Initialized
INFO - 2025-11-05 02:13:36 --> Email Class Initialized
DEBUG - 2025-11-05 02:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:13:36 --> Controller Class Initialized
INFO - 2025-11-05 02:13:36 --> Model "User_model" initialized
INFO - 2025-11-05 02:13:36 --> Model "Project_model" initialized
INFO - 2025-11-05 02:13:36 --> Helper loaded: form_helper
INFO - 2025-11-05 02:13:36 --> Form Validation Class Initialized
INFO - 2025-11-05 02:13:36 --> Final output sent to browser
INFO - 2025-11-05 02:13:36 --> Total execution time: 0.0562
INFO - 2025-11-05 02:13:39 --> Config Class Initialized
INFO - 2025-11-05 02:13:39 --> Hooks Class Initialized
INFO - 2025-11-05 02:13:39 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:13:39 --> Utf8 Class Initialized
INFO - 2025-11-05 02:13:39 --> URI Class Initialized
INFO - 2025-11-05 02:13:39 --> Router Class Initialized
INFO - 2025-11-05 02:13:39 --> Output Class Initialized
INFO - 2025-11-05 02:13:39 --> Security Class Initialized
INFO - 2025-11-05 02:13:39 --> Input Class Initialized
INFO - 2025-11-05 02:13:39 --> Language Class Initialized
INFO - 2025-11-05 02:13:39 --> Loader Class Initialized
INFO - 2025-11-05 02:13:39 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:13:39 --> Helper loaded: url_helper
INFO - 2025-11-05 02:13:39 --> Helper loaded: file_helper
INFO - 2025-11-05 02:13:39 --> Helper loaded: main_helper
INFO - 2025-11-05 02:13:39 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:13:39 --> Database Driver Class Initialized
INFO - 2025-11-05 02:13:39 --> Email Class Initialized
DEBUG - 2025-11-05 02:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:13:39 --> Controller Class Initialized
INFO - 2025-11-05 02:13:39 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:13:39 --> Model "User_model" initialized
INFO - 2025-11-05 02:13:39 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:13:39 --> Model "Project_model" initialized
INFO - 2025-11-05 02:13:39 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 02:13:39 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 02:13:39 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 02:13:39 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-efe.php
INFO - 2025-11-05 02:13:39 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 02:13:39 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 02:13:39 --> Final output sent to browser
INFO - 2025-11-05 02:13:39 --> Total execution time: 0.0954
INFO - 2025-11-05 02:13:39 --> Config Class Initialized
INFO - 2025-11-05 02:13:39 --> Hooks Class Initialized
INFO - 2025-11-05 02:13:39 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:13:39 --> Utf8 Class Initialized
INFO - 2025-11-05 02:13:39 --> URI Class Initialized
INFO - 2025-11-05 02:13:39 --> Router Class Initialized
INFO - 2025-11-05 02:13:39 --> Output Class Initialized
INFO - 2025-11-05 02:13:39 --> Security Class Initialized
INFO - 2025-11-05 02:13:39 --> Input Class Initialized
INFO - 2025-11-05 02:13:39 --> Language Class Initialized
INFO - 2025-11-05 02:13:39 --> Loader Class Initialized
INFO - 2025-11-05 02:13:39 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:13:39 --> Helper loaded: url_helper
INFO - 2025-11-05 02:13:39 --> Helper loaded: file_helper
INFO - 2025-11-05 02:13:39 --> Helper loaded: main_helper
INFO - 2025-11-05 02:13:39 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:13:39 --> Database Driver Class Initialized
INFO - 2025-11-05 02:13:39 --> Email Class Initialized
DEBUG - 2025-11-05 02:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:13:39 --> Controller Class Initialized
INFO - 2025-11-05 02:13:39 --> Model "User_model" initialized
INFO - 2025-11-05 02:13:39 --> Model "Project_model" initialized
INFO - 2025-11-05 02:13:39 --> Helper loaded: form_helper
INFO - 2025-11-05 02:13:39 --> Form Validation Class Initialized
INFO - 2025-11-05 02:13:39 --> Final output sent to browser
INFO - 2025-11-05 02:13:39 --> Total execution time: 0.0535
INFO - 2025-11-05 02:13:42 --> Config Class Initialized
INFO - 2025-11-05 02:13:42 --> Hooks Class Initialized
INFO - 2025-11-05 02:13:42 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:13:42 --> Utf8 Class Initialized
INFO - 2025-11-05 02:13:42 --> URI Class Initialized
INFO - 2025-11-05 02:13:42 --> Router Class Initialized
INFO - 2025-11-05 02:13:42 --> Output Class Initialized
INFO - 2025-11-05 02:13:42 --> Security Class Initialized
INFO - 2025-11-05 02:13:42 --> Input Class Initialized
INFO - 2025-11-05 02:13:42 --> Language Class Initialized
INFO - 2025-11-05 02:13:42 --> Loader Class Initialized
INFO - 2025-11-05 02:13:42 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:13:42 --> Helper loaded: url_helper
INFO - 2025-11-05 02:13:42 --> Helper loaded: file_helper
INFO - 2025-11-05 02:13:42 --> Helper loaded: main_helper
INFO - 2025-11-05 02:13:42 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:13:42 --> Database Driver Class Initialized
INFO - 2025-11-05 02:13:43 --> Email Class Initialized
DEBUG - 2025-11-05 02:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:13:43 --> Controller Class Initialized
INFO - 2025-11-05 02:13:43 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:13:43 --> Model "User_model" initialized
INFO - 2025-11-05 02:13:43 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:13:43 --> Model "Project_model" initialized
INFO - 2025-11-05 02:13:43 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 02:13:43 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 02:13:43 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 02:13:43 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ife.php
INFO - 2025-11-05 02:13:43 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 02:13:43 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 02:13:43 --> Final output sent to browser
INFO - 2025-11-05 02:13:43 --> Total execution time: 0.2488
INFO - 2025-11-05 02:13:43 --> Config Class Initialized
INFO - 2025-11-05 02:13:43 --> Hooks Class Initialized
INFO - 2025-11-05 02:13:43 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:13:43 --> Utf8 Class Initialized
INFO - 2025-11-05 02:13:43 --> URI Class Initialized
INFO - 2025-11-05 02:13:43 --> Router Class Initialized
INFO - 2025-11-05 02:13:43 --> Output Class Initialized
INFO - 2025-11-05 02:13:43 --> Security Class Initialized
INFO - 2025-11-05 02:13:43 --> Input Class Initialized
INFO - 2025-11-05 02:13:43 --> Language Class Initialized
INFO - 2025-11-05 02:13:43 --> Loader Class Initialized
INFO - 2025-11-05 02:13:43 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:13:43 --> Helper loaded: url_helper
INFO - 2025-11-05 02:13:43 --> Helper loaded: file_helper
INFO - 2025-11-05 02:13:43 --> Helper loaded: main_helper
INFO - 2025-11-05 02:13:43 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:13:43 --> Database Driver Class Initialized
INFO - 2025-11-05 02:13:43 --> Email Class Initialized
DEBUG - 2025-11-05 02:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:13:43 --> Controller Class Initialized
INFO - 2025-11-05 02:13:43 --> Model "User_model" initialized
INFO - 2025-11-05 02:13:43 --> Model "Project_model" initialized
INFO - 2025-11-05 02:13:43 --> Helper loaded: form_helper
INFO - 2025-11-05 02:13:43 --> Form Validation Class Initialized
INFO - 2025-11-05 02:13:43 --> Final output sent to browser
INFO - 2025-11-05 02:13:43 --> Total execution time: 0.0631
INFO - 2025-11-05 02:13:52 --> Config Class Initialized
INFO - 2025-11-05 02:13:52 --> Hooks Class Initialized
INFO - 2025-11-05 02:13:52 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:13:52 --> Utf8 Class Initialized
INFO - 2025-11-05 02:13:52 --> URI Class Initialized
INFO - 2025-11-05 02:13:52 --> Router Class Initialized
INFO - 2025-11-05 02:13:52 --> Output Class Initialized
INFO - 2025-11-05 02:13:52 --> Security Class Initialized
INFO - 2025-11-05 02:13:52 --> Input Class Initialized
INFO - 2025-11-05 02:13:52 --> Language Class Initialized
INFO - 2025-11-05 02:13:52 --> Loader Class Initialized
INFO - 2025-11-05 02:13:52 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:13:52 --> Helper loaded: url_helper
INFO - 2025-11-05 02:13:52 --> Helper loaded: file_helper
INFO - 2025-11-05 02:13:52 --> Helper loaded: main_helper
INFO - 2025-11-05 02:13:52 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:13:52 --> Database Driver Class Initialized
INFO - 2025-11-05 02:13:52 --> Email Class Initialized
DEBUG - 2025-11-05 02:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:13:52 --> Controller Class Initialized
INFO - 2025-11-05 02:13:52 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:13:52 --> Model "User_model" initialized
INFO - 2025-11-05 02:13:52 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:13:52 --> Model "Project_model" initialized
INFO - 2025-11-05 02:13:52 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 02:13:52 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 02:13:52 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 02:13:52 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-efe.php
INFO - 2025-11-05 02:13:52 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 02:13:52 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 02:13:52 --> Final output sent to browser
INFO - 2025-11-05 02:13:52 --> Total execution time: 0.0603
INFO - 2025-11-05 02:13:52 --> Config Class Initialized
INFO - 2025-11-05 02:13:52 --> Hooks Class Initialized
INFO - 2025-11-05 02:13:52 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:13:52 --> Utf8 Class Initialized
INFO - 2025-11-05 02:13:52 --> URI Class Initialized
INFO - 2025-11-05 02:13:52 --> Router Class Initialized
INFO - 2025-11-05 02:13:52 --> Output Class Initialized
INFO - 2025-11-05 02:13:52 --> Security Class Initialized
INFO - 2025-11-05 02:13:52 --> Input Class Initialized
INFO - 2025-11-05 02:13:52 --> Language Class Initialized
INFO - 2025-11-05 02:13:52 --> Loader Class Initialized
INFO - 2025-11-05 02:13:52 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:13:52 --> Helper loaded: url_helper
INFO - 2025-11-05 02:13:52 --> Helper loaded: file_helper
INFO - 2025-11-05 02:13:52 --> Helper loaded: main_helper
INFO - 2025-11-05 02:13:52 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:13:52 --> Database Driver Class Initialized
INFO - 2025-11-05 02:13:52 --> Email Class Initialized
DEBUG - 2025-11-05 02:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:13:52 --> Controller Class Initialized
INFO - 2025-11-05 02:13:52 --> Model "User_model" initialized
INFO - 2025-11-05 02:13:52 --> Model "Project_model" initialized
INFO - 2025-11-05 02:13:52 --> Helper loaded: form_helper
INFO - 2025-11-05 02:13:52 --> Form Validation Class Initialized
INFO - 2025-11-05 02:13:52 --> Final output sent to browser
INFO - 2025-11-05 02:13:52 --> Total execution time: 0.0582
INFO - 2025-11-05 02:13:56 --> Config Class Initialized
INFO - 2025-11-05 02:13:56 --> Hooks Class Initialized
INFO - 2025-11-05 02:13:56 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:13:56 --> Utf8 Class Initialized
INFO - 2025-11-05 02:13:56 --> URI Class Initialized
INFO - 2025-11-05 02:13:56 --> Router Class Initialized
INFO - 2025-11-05 02:13:56 --> Output Class Initialized
INFO - 2025-11-05 02:13:56 --> Security Class Initialized
INFO - 2025-11-05 02:13:56 --> Input Class Initialized
INFO - 2025-11-05 02:13:56 --> Language Class Initialized
INFO - 2025-11-05 02:13:56 --> Loader Class Initialized
INFO - 2025-11-05 02:13:56 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:13:56 --> Helper loaded: url_helper
INFO - 2025-11-05 02:13:56 --> Helper loaded: file_helper
INFO - 2025-11-05 02:13:56 --> Helper loaded: main_helper
INFO - 2025-11-05 02:13:56 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:13:57 --> Database Driver Class Initialized
INFO - 2025-11-05 02:13:57 --> Email Class Initialized
DEBUG - 2025-11-05 02:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:13:57 --> Controller Class Initialized
INFO - 2025-11-05 02:13:57 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:13:57 --> Model "User_model" initialized
INFO - 2025-11-05 02:13:57 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:13:57 --> Model "Project_model" initialized
INFO - 2025-11-05 02:13:57 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 02:13:57 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 02:13:57 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 02:13:57 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ife.php
INFO - 2025-11-05 02:13:57 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 02:13:57 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 02:13:57 --> Final output sent to browser
INFO - 2025-11-05 02:13:57 --> Total execution time: 0.0717
INFO - 2025-11-05 02:13:57 --> Config Class Initialized
INFO - 2025-11-05 02:13:57 --> Hooks Class Initialized
INFO - 2025-11-05 02:13:57 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:13:57 --> Utf8 Class Initialized
INFO - 2025-11-05 02:13:57 --> URI Class Initialized
INFO - 2025-11-05 02:13:57 --> Router Class Initialized
INFO - 2025-11-05 02:13:57 --> Output Class Initialized
INFO - 2025-11-05 02:13:57 --> Security Class Initialized
INFO - 2025-11-05 02:13:57 --> Input Class Initialized
INFO - 2025-11-05 02:13:57 --> Language Class Initialized
INFO - 2025-11-05 02:13:57 --> Loader Class Initialized
INFO - 2025-11-05 02:13:57 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:13:57 --> Helper loaded: url_helper
INFO - 2025-11-05 02:13:57 --> Helper loaded: file_helper
INFO - 2025-11-05 02:13:57 --> Helper loaded: main_helper
INFO - 2025-11-05 02:13:57 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:13:57 --> Database Driver Class Initialized
INFO - 2025-11-05 02:13:57 --> Email Class Initialized
DEBUG - 2025-11-05 02:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:13:57 --> Controller Class Initialized
INFO - 2025-11-05 02:13:57 --> Model "User_model" initialized
INFO - 2025-11-05 02:13:57 --> Model "Project_model" initialized
INFO - 2025-11-05 02:13:57 --> Helper loaded: form_helper
INFO - 2025-11-05 02:13:57 --> Form Validation Class Initialized
INFO - 2025-11-05 02:13:57 --> Final output sent to browser
INFO - 2025-11-05 02:13:57 --> Total execution time: 0.0775
INFO - 2025-11-05 02:13:59 --> Config Class Initialized
INFO - 2025-11-05 02:13:59 --> Hooks Class Initialized
INFO - 2025-11-05 02:13:59 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:13:59 --> Utf8 Class Initialized
INFO - 2025-11-05 02:13:59 --> URI Class Initialized
INFO - 2025-11-05 02:13:59 --> Router Class Initialized
INFO - 2025-11-05 02:13:59 --> Output Class Initialized
INFO - 2025-11-05 02:13:59 --> Security Class Initialized
INFO - 2025-11-05 02:13:59 --> Input Class Initialized
INFO - 2025-11-05 02:13:59 --> Language Class Initialized
INFO - 2025-11-05 02:13:59 --> Loader Class Initialized
INFO - 2025-11-05 02:13:59 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:13:59 --> Helper loaded: url_helper
INFO - 2025-11-05 02:13:59 --> Helper loaded: file_helper
INFO - 2025-11-05 02:13:59 --> Helper loaded: main_helper
INFO - 2025-11-05 02:13:59 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:13:59 --> Database Driver Class Initialized
INFO - 2025-11-05 02:13:59 --> Email Class Initialized
DEBUG - 2025-11-05 02:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:13:59 --> Controller Class Initialized
INFO - 2025-11-05 02:13:59 --> Model "User_model" initialized
INFO - 2025-11-05 02:13:59 --> Model "Project_model" initialized
INFO - 2025-11-05 02:13:59 --> Helper loaded: form_helper
INFO - 2025-11-05 02:13:59 --> Form Validation Class Initialized
INFO - 2025-11-05 02:13:59 --> Final output sent to browser
INFO - 2025-11-05 02:13:59 --> Total execution time: 0.0912
INFO - 2025-11-05 02:14:03 --> Config Class Initialized
INFO - 2025-11-05 02:14:03 --> Hooks Class Initialized
INFO - 2025-11-05 02:14:03 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:14:03 --> Utf8 Class Initialized
INFO - 2025-11-05 02:14:03 --> URI Class Initialized
INFO - 2025-11-05 02:14:03 --> Router Class Initialized
INFO - 2025-11-05 02:14:03 --> Output Class Initialized
INFO - 2025-11-05 02:14:03 --> Security Class Initialized
INFO - 2025-11-05 02:14:03 --> Input Class Initialized
INFO - 2025-11-05 02:14:03 --> Language Class Initialized
INFO - 2025-11-05 02:14:03 --> Loader Class Initialized
INFO - 2025-11-05 02:14:03 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:14:03 --> Helper loaded: url_helper
INFO - 2025-11-05 02:14:03 --> Helper loaded: file_helper
INFO - 2025-11-05 02:14:03 --> Helper loaded: main_helper
INFO - 2025-11-05 02:14:03 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:14:03 --> Database Driver Class Initialized
INFO - 2025-11-05 02:14:03 --> Email Class Initialized
DEBUG - 2025-11-05 02:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:14:03 --> Controller Class Initialized
INFO - 2025-11-05 02:14:03 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:14:03 --> Model "User_model" initialized
INFO - 2025-11-05 02:14:03 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:14:03 --> Model "Project_model" initialized
INFO - 2025-11-05 02:14:03 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 02:14:03 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 02:14:03 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 02:14:03 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-efe.php
INFO - 2025-11-05 02:14:03 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 02:14:03 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 02:14:03 --> Final output sent to browser
INFO - 2025-11-05 02:14:03 --> Total execution time: 0.0618
INFO - 2025-11-05 02:14:03 --> Config Class Initialized
INFO - 2025-11-05 02:14:03 --> Hooks Class Initialized
INFO - 2025-11-05 02:14:03 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:14:03 --> Utf8 Class Initialized
INFO - 2025-11-05 02:14:03 --> URI Class Initialized
INFO - 2025-11-05 02:14:03 --> Router Class Initialized
INFO - 2025-11-05 02:14:03 --> Output Class Initialized
INFO - 2025-11-05 02:14:03 --> Security Class Initialized
INFO - 2025-11-05 02:14:03 --> Input Class Initialized
INFO - 2025-11-05 02:14:03 --> Language Class Initialized
INFO - 2025-11-05 02:14:03 --> Loader Class Initialized
INFO - 2025-11-05 02:14:03 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:14:03 --> Helper loaded: url_helper
INFO - 2025-11-05 02:14:03 --> Helper loaded: file_helper
INFO - 2025-11-05 02:14:03 --> Helper loaded: main_helper
INFO - 2025-11-05 02:14:03 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:14:03 --> Database Driver Class Initialized
INFO - 2025-11-05 02:14:03 --> Email Class Initialized
DEBUG - 2025-11-05 02:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:14:04 --> Controller Class Initialized
INFO - 2025-11-05 02:14:04 --> Model "User_model" initialized
INFO - 2025-11-05 02:14:04 --> Model "Project_model" initialized
INFO - 2025-11-05 02:14:04 --> Helper loaded: form_helper
INFO - 2025-11-05 02:14:04 --> Form Validation Class Initialized
INFO - 2025-11-05 02:14:04 --> Final output sent to browser
INFO - 2025-11-05 02:14:04 --> Total execution time: 0.0849
INFO - 2025-11-05 02:14:08 --> Config Class Initialized
INFO - 2025-11-05 02:14:08 --> Hooks Class Initialized
INFO - 2025-11-05 02:14:08 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:14:08 --> Utf8 Class Initialized
INFO - 2025-11-05 02:14:08 --> URI Class Initialized
INFO - 2025-11-05 02:14:08 --> Router Class Initialized
INFO - 2025-11-05 02:14:08 --> Output Class Initialized
INFO - 2025-11-05 02:14:08 --> Security Class Initialized
INFO - 2025-11-05 02:14:08 --> Input Class Initialized
INFO - 2025-11-05 02:14:08 --> Language Class Initialized
INFO - 2025-11-05 02:14:08 --> Loader Class Initialized
INFO - 2025-11-05 02:14:08 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:14:08 --> Helper loaded: url_helper
INFO - 2025-11-05 02:14:08 --> Helper loaded: file_helper
INFO - 2025-11-05 02:14:08 --> Helper loaded: main_helper
INFO - 2025-11-05 02:14:08 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:14:08 --> Database Driver Class Initialized
INFO - 2025-11-05 02:14:08 --> Email Class Initialized
DEBUG - 2025-11-05 02:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:14:08 --> Controller Class Initialized
INFO - 2025-11-05 02:14:08 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:14:08 --> Model "User_model" initialized
INFO - 2025-11-05 02:14:08 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:14:08 --> Model "Project_model" initialized
INFO - 2025-11-05 02:14:08 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 02:14:08 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 02:14:08 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 02:14:08 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ife.php
INFO - 2025-11-05 02:14:08 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 02:14:08 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 02:14:08 --> Final output sent to browser
INFO - 2025-11-05 02:14:08 --> Total execution time: 0.0592
INFO - 2025-11-05 02:14:08 --> Config Class Initialized
INFO - 2025-11-05 02:14:08 --> Hooks Class Initialized
INFO - 2025-11-05 02:14:08 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:14:08 --> Utf8 Class Initialized
INFO - 2025-11-05 02:14:08 --> URI Class Initialized
INFO - 2025-11-05 02:14:08 --> Router Class Initialized
INFO - 2025-11-05 02:14:08 --> Output Class Initialized
INFO - 2025-11-05 02:14:08 --> Security Class Initialized
INFO - 2025-11-05 02:14:08 --> Input Class Initialized
INFO - 2025-11-05 02:14:08 --> Language Class Initialized
INFO - 2025-11-05 02:14:08 --> Loader Class Initialized
INFO - 2025-11-05 02:14:08 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:14:08 --> Helper loaded: url_helper
INFO - 2025-11-05 02:14:08 --> Helper loaded: file_helper
INFO - 2025-11-05 02:14:08 --> Helper loaded: main_helper
INFO - 2025-11-05 02:14:08 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:14:08 --> Database Driver Class Initialized
INFO - 2025-11-05 02:14:08 --> Email Class Initialized
DEBUG - 2025-11-05 02:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:14:08 --> Controller Class Initialized
INFO - 2025-11-05 02:14:08 --> Model "User_model" initialized
INFO - 2025-11-05 02:14:08 --> Model "Project_model" initialized
INFO - 2025-11-05 02:14:08 --> Helper loaded: form_helper
INFO - 2025-11-05 02:14:08 --> Form Validation Class Initialized
INFO - 2025-11-05 02:14:08 --> Final output sent to browser
INFO - 2025-11-05 02:14:08 --> Total execution time: 0.0853
INFO - 2025-11-05 02:15:47 --> Config Class Initialized
INFO - 2025-11-05 02:15:47 --> Hooks Class Initialized
INFO - 2025-11-05 02:15:47 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:15:47 --> Utf8 Class Initialized
INFO - 2025-11-05 02:15:47 --> URI Class Initialized
INFO - 2025-11-05 02:15:47 --> Router Class Initialized
INFO - 2025-11-05 02:15:47 --> Output Class Initialized
INFO - 2025-11-05 02:15:47 --> Security Class Initialized
INFO - 2025-11-05 02:15:47 --> Input Class Initialized
INFO - 2025-11-05 02:15:47 --> Language Class Initialized
INFO - 2025-11-05 02:15:47 --> Loader Class Initialized
INFO - 2025-11-05 02:15:47 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:15:47 --> Helper loaded: url_helper
INFO - 2025-11-05 02:15:47 --> Helper loaded: file_helper
INFO - 2025-11-05 02:15:47 --> Helper loaded: main_helper
INFO - 2025-11-05 02:15:47 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:15:47 --> Database Driver Class Initialized
INFO - 2025-11-05 02:15:47 --> Email Class Initialized
DEBUG - 2025-11-05 02:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:15:47 --> Controller Class Initialized
INFO - 2025-11-05 02:15:47 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:15:47 --> Model "User_model" initialized
INFO - 2025-11-05 02:15:47 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:15:47 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-05 02:15:47 --> Final output sent to browser
INFO - 2025-11-05 02:15:47 --> Total execution time: 0.1811
INFO - 2025-11-05 02:15:47 --> Config Class Initialized
INFO - 2025-11-05 02:15:47 --> Hooks Class Initialized
INFO - 2025-11-05 02:15:47 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:15:47 --> Utf8 Class Initialized
INFO - 2025-11-05 02:15:47 --> URI Class Initialized
INFO - 2025-11-05 02:15:47 --> Router Class Initialized
INFO - 2025-11-05 02:15:47 --> Output Class Initialized
INFO - 2025-11-05 02:15:47 --> Security Class Initialized
INFO - 2025-11-05 02:15:47 --> Input Class Initialized
INFO - 2025-11-05 02:15:47 --> Language Class Initialized
INFO - 2025-11-05 02:15:47 --> Loader Class Initialized
INFO - 2025-11-05 02:15:47 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:15:47 --> Helper loaded: url_helper
INFO - 2025-11-05 02:15:47 --> Helper loaded: file_helper
INFO - 2025-11-05 02:15:47 --> Helper loaded: main_helper
INFO - 2025-11-05 02:15:47 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:15:47 --> Database Driver Class Initialized
INFO - 2025-11-05 02:15:47 --> Email Class Initialized
DEBUG - 2025-11-05 02:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:15:47 --> Controller Class Initialized
INFO - 2025-11-05 02:15:47 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:15:47 --> Model "User_model" initialized
INFO - 2025-11-05 02:15:47 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:15:47 --> Model "Project_model" initialized
INFO - 2025-11-05 02:15:47 --> Config Class Initialized
INFO - 2025-11-05 02:15:47 --> Hooks Class Initialized
INFO - 2025-11-05 02:15:47 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:15:47 --> Utf8 Class Initialized
INFO - 2025-11-05 02:15:47 --> URI Class Initialized
INFO - 2025-11-05 02:15:47 --> Router Class Initialized
INFO - 2025-11-05 02:15:47 --> Output Class Initialized
INFO - 2025-11-05 02:15:47 --> Security Class Initialized
INFO - 2025-11-05 02:15:47 --> Input Class Initialized
INFO - 2025-11-05 02:15:47 --> Language Class Initialized
INFO - 2025-11-05 02:15:47 --> Loader Class Initialized
INFO - 2025-11-05 02:15:47 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:15:47 --> Helper loaded: url_helper
INFO - 2025-11-05 02:15:47 --> Helper loaded: file_helper
INFO - 2025-11-05 02:15:47 --> Helper loaded: main_helper
INFO - 2025-11-05 02:15:47 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:15:47 --> Database Driver Class Initialized
INFO - 2025-11-05 02:15:47 --> Email Class Initialized
DEBUG - 2025-11-05 02:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:15:47 --> Controller Class Initialized
INFO - 2025-11-05 02:15:48 --> Config Class Initialized
INFO - 2025-11-05 02:15:48 --> Hooks Class Initialized
INFO - 2025-11-05 02:15:48 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:15:48 --> Utf8 Class Initialized
INFO - 2025-11-05 02:15:48 --> URI Class Initialized
INFO - 2025-11-05 02:15:48 --> Router Class Initialized
INFO - 2025-11-05 02:15:48 --> Output Class Initialized
INFO - 2025-11-05 02:15:48 --> Security Class Initialized
INFO - 2025-11-05 02:15:48 --> Input Class Initialized
INFO - 2025-11-05 02:15:48 --> Language Class Initialized
INFO - 2025-11-05 02:15:48 --> Loader Class Initialized
INFO - 2025-11-05 02:15:48 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:15:48 --> Helper loaded: url_helper
INFO - 2025-11-05 02:15:48 --> Helper loaded: file_helper
INFO - 2025-11-05 02:15:48 --> Helper loaded: main_helper
INFO - 2025-11-05 02:15:48 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:15:48 --> Database Driver Class Initialized
INFO - 2025-11-05 02:15:48 --> Email Class Initialized
DEBUG - 2025-11-05 02:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:15:48 --> Controller Class Initialized
INFO - 2025-11-05 02:15:48 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:15:48 --> Model "User_model" initialized
INFO - 2025-11-05 02:15:48 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:15:48 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-05 02:15:48 --> Final output sent to browser
INFO - 2025-11-05 02:15:48 --> Total execution time: 0.0855
INFO - 2025-11-05 02:15:48 --> Config Class Initialized
INFO - 2025-11-05 02:15:48 --> Hooks Class Initialized
INFO - 2025-11-05 02:15:48 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:15:48 --> Utf8 Class Initialized
INFO - 2025-11-05 02:17:22 --> Config Class Initialized
INFO - 2025-11-05 02:17:22 --> Hooks Class Initialized
INFO - 2025-11-05 02:17:22 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:17:22 --> Utf8 Class Initialized
INFO - 2025-11-05 02:17:22 --> URI Class Initialized
INFO - 2025-11-05 02:17:22 --> Router Class Initialized
INFO - 2025-11-05 02:17:22 --> Output Class Initialized
INFO - 2025-11-05 02:17:22 --> Security Class Initialized
INFO - 2025-11-05 02:17:22 --> Input Class Initialized
INFO - 2025-11-05 02:17:22 --> Language Class Initialized
INFO - 2025-11-05 02:17:22 --> Loader Class Initialized
INFO - 2025-11-05 02:17:22 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:17:22 --> Helper loaded: url_helper
INFO - 2025-11-05 02:17:22 --> Helper loaded: file_helper
INFO - 2025-11-05 02:17:22 --> Helper loaded: main_helper
INFO - 2025-11-05 02:17:22 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:17:22 --> Database Driver Class Initialized
INFO - 2025-11-05 02:17:22 --> Email Class Initialized
DEBUG - 2025-11-05 02:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:17:22 --> Controller Class Initialized
INFO - 2025-11-05 02:17:22 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:17:22 --> Model "User_model" initialized
INFO - 2025-11-05 02:17:22 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:17:22 --> Model "Project_model" initialized
INFO - 2025-11-05 02:17:22 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 02:17:22 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 02:17:22 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 02:17:22 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ife.php
INFO - 2025-11-05 02:17:22 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 02:17:22 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 02:17:22 --> Final output sent to browser
INFO - 2025-11-05 02:17:22 --> Total execution time: 0.0767
INFO - 2025-11-05 02:17:22 --> Config Class Initialized
INFO - 2025-11-05 02:17:22 --> Hooks Class Initialized
INFO - 2025-11-05 02:17:22 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:17:22 --> Utf8 Class Initialized
INFO - 2025-11-05 02:17:22 --> URI Class Initialized
INFO - 2025-11-05 02:17:22 --> Router Class Initialized
INFO - 2025-11-05 02:17:22 --> Output Class Initialized
INFO - 2025-11-05 02:17:22 --> Security Class Initialized
INFO - 2025-11-05 02:17:22 --> Input Class Initialized
INFO - 2025-11-05 02:17:22 --> Language Class Initialized
INFO - 2025-11-05 02:17:22 --> Loader Class Initialized
INFO - 2025-11-05 02:17:22 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:17:22 --> Helper loaded: url_helper
INFO - 2025-11-05 02:17:22 --> Helper loaded: file_helper
INFO - 2025-11-05 02:17:22 --> Helper loaded: main_helper
INFO - 2025-11-05 02:17:22 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:17:22 --> Database Driver Class Initialized
INFO - 2025-11-05 02:17:22 --> Email Class Initialized
DEBUG - 2025-11-05 02:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:17:22 --> Controller Class Initialized
INFO - 2025-11-05 02:17:22 --> Model "User_model" initialized
INFO - 2025-11-05 02:17:22 --> Model "Project_model" initialized
INFO - 2025-11-05 02:17:22 --> Helper loaded: form_helper
INFO - 2025-11-05 02:17:22 --> Form Validation Class Initialized
INFO - 2025-11-05 02:17:22 --> Final output sent to browser
INFO - 2025-11-05 02:17:22 --> Total execution time: 0.0690
INFO - 2025-11-05 02:17:31 --> Config Class Initialized
INFO - 2025-11-05 02:17:31 --> Hooks Class Initialized
INFO - 2025-11-05 02:17:31 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:17:31 --> Utf8 Class Initialized
INFO - 2025-11-05 02:17:31 --> URI Class Initialized
INFO - 2025-11-05 02:17:31 --> Router Class Initialized
INFO - 2025-11-05 02:17:31 --> Output Class Initialized
INFO - 2025-11-05 02:17:31 --> Security Class Initialized
INFO - 2025-11-05 02:17:31 --> Input Class Initialized
INFO - 2025-11-05 02:17:31 --> Language Class Initialized
INFO - 2025-11-05 02:17:31 --> Loader Class Initialized
INFO - 2025-11-05 02:17:31 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:17:31 --> Helper loaded: url_helper
INFO - 2025-11-05 02:17:31 --> Helper loaded: file_helper
INFO - 2025-11-05 02:17:31 --> Helper loaded: main_helper
INFO - 2025-11-05 02:17:31 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:17:31 --> Database Driver Class Initialized
INFO - 2025-11-05 02:17:31 --> Email Class Initialized
DEBUG - 2025-11-05 02:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:17:31 --> Controller Class Initialized
INFO - 2025-11-05 02:17:31 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:17:31 --> Model "User_model" initialized
INFO - 2025-11-05 02:17:31 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:17:31 --> Model "Project_model" initialized
INFO - 2025-11-05 02:17:31 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 02:17:31 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 02:17:31 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 02:17:31 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ife.php
INFO - 2025-11-05 02:17:31 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 02:17:31 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 02:17:31 --> Final output sent to browser
INFO - 2025-11-05 02:17:31 --> Total execution time: 0.0634
INFO - 2025-11-05 02:17:32 --> Config Class Initialized
INFO - 2025-11-05 02:17:32 --> Hooks Class Initialized
INFO - 2025-11-05 02:17:32 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:17:32 --> Utf8 Class Initialized
INFO - 2025-11-05 02:17:32 --> URI Class Initialized
INFO - 2025-11-05 02:17:32 --> Router Class Initialized
INFO - 2025-11-05 02:17:32 --> Output Class Initialized
INFO - 2025-11-05 02:17:32 --> Security Class Initialized
INFO - 2025-11-05 02:17:32 --> Input Class Initialized
INFO - 2025-11-05 02:17:32 --> Language Class Initialized
INFO - 2025-11-05 02:17:32 --> Loader Class Initialized
INFO - 2025-11-05 02:17:32 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:17:32 --> Helper loaded: url_helper
INFO - 2025-11-05 02:17:32 --> Helper loaded: file_helper
INFO - 2025-11-05 02:17:32 --> Helper loaded: main_helper
INFO - 2025-11-05 02:17:32 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:17:32 --> Database Driver Class Initialized
INFO - 2025-11-05 02:17:32 --> Email Class Initialized
DEBUG - 2025-11-05 02:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:17:32 --> Controller Class Initialized
INFO - 2025-11-05 02:17:32 --> Model "User_model" initialized
INFO - 2025-11-05 02:17:32 --> Model "Project_model" initialized
INFO - 2025-11-05 02:17:32 --> Helper loaded: form_helper
INFO - 2025-11-05 02:17:32 --> Form Validation Class Initialized
INFO - 2025-11-05 02:17:32 --> Final output sent to browser
INFO - 2025-11-05 02:17:32 --> Total execution time: 0.0595
INFO - 2025-11-05 02:17:38 --> Config Class Initialized
INFO - 2025-11-05 02:17:38 --> Hooks Class Initialized
INFO - 2025-11-05 02:17:38 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:17:38 --> Utf8 Class Initialized
INFO - 2025-11-05 02:17:38 --> URI Class Initialized
INFO - 2025-11-05 02:17:38 --> Router Class Initialized
INFO - 2025-11-05 02:17:38 --> Output Class Initialized
INFO - 2025-11-05 02:17:38 --> Security Class Initialized
INFO - 2025-11-05 02:17:38 --> Input Class Initialized
INFO - 2025-11-05 02:17:38 --> Language Class Initialized
INFO - 2025-11-05 02:17:38 --> Loader Class Initialized
INFO - 2025-11-05 02:17:38 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:17:38 --> Helper loaded: url_helper
INFO - 2025-11-05 02:17:38 --> Helper loaded: file_helper
INFO - 2025-11-05 02:17:38 --> Helper loaded: main_helper
INFO - 2025-11-05 02:17:38 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:17:38 --> Database Driver Class Initialized
INFO - 2025-11-05 02:17:38 --> Email Class Initialized
DEBUG - 2025-11-05 02:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:17:39 --> Controller Class Initialized
INFO - 2025-11-05 02:17:39 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:17:39 --> Model "User_model" initialized
INFO - 2025-11-05 02:17:39 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:17:39 --> Model "Project_model" initialized
INFO - 2025-11-05 02:17:39 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 02:17:39 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 02:17:39 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 02:17:39 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-efe.php
INFO - 2025-11-05 02:17:39 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 02:17:39 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 02:17:39 --> Final output sent to browser
INFO - 2025-11-05 02:17:39 --> Total execution time: 0.0684
INFO - 2025-11-05 02:17:39 --> Config Class Initialized
INFO - 2025-11-05 02:17:39 --> Hooks Class Initialized
INFO - 2025-11-05 02:17:39 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:17:39 --> Utf8 Class Initialized
INFO - 2025-11-05 02:17:39 --> URI Class Initialized
INFO - 2025-11-05 02:17:39 --> Router Class Initialized
INFO - 2025-11-05 02:17:39 --> Output Class Initialized
INFO - 2025-11-05 02:17:39 --> Security Class Initialized
INFO - 2025-11-05 02:17:39 --> Input Class Initialized
INFO - 2025-11-05 02:17:39 --> Language Class Initialized
INFO - 2025-11-05 02:17:39 --> Loader Class Initialized
INFO - 2025-11-05 02:17:39 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:17:39 --> Helper loaded: url_helper
INFO - 2025-11-05 02:17:39 --> Helper loaded: file_helper
INFO - 2025-11-05 02:17:39 --> Helper loaded: main_helper
INFO - 2025-11-05 02:17:39 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:17:39 --> Database Driver Class Initialized
INFO - 2025-11-05 02:17:39 --> Email Class Initialized
DEBUG - 2025-11-05 02:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:17:39 --> Controller Class Initialized
INFO - 2025-11-05 02:17:39 --> Model "User_model" initialized
INFO - 2025-11-05 02:17:39 --> Model "Project_model" initialized
INFO - 2025-11-05 02:17:39 --> Helper loaded: form_helper
INFO - 2025-11-05 02:17:39 --> Form Validation Class Initialized
INFO - 2025-11-05 02:17:39 --> Final output sent to browser
INFO - 2025-11-05 02:17:39 --> Total execution time: 0.0666
INFO - 2025-11-05 02:17:43 --> Config Class Initialized
INFO - 2025-11-05 02:17:43 --> Hooks Class Initialized
INFO - 2025-11-05 02:17:43 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:17:43 --> Utf8 Class Initialized
INFO - 2025-11-05 02:17:43 --> URI Class Initialized
INFO - 2025-11-05 02:17:43 --> Router Class Initialized
INFO - 2025-11-05 02:17:43 --> Output Class Initialized
INFO - 2025-11-05 02:17:43 --> Security Class Initialized
INFO - 2025-11-05 02:17:43 --> Input Class Initialized
INFO - 2025-11-05 02:17:43 --> Language Class Initialized
INFO - 2025-11-05 02:17:43 --> Loader Class Initialized
INFO - 2025-11-05 02:17:43 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:17:43 --> Helper loaded: url_helper
INFO - 2025-11-05 02:17:43 --> Helper loaded: file_helper
INFO - 2025-11-05 02:17:43 --> Helper loaded: main_helper
INFO - 2025-11-05 02:17:43 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:17:43 --> Database Driver Class Initialized
INFO - 2025-11-05 02:17:43 --> Email Class Initialized
DEBUG - 2025-11-05 02:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:17:43 --> Controller Class Initialized
INFO - 2025-11-05 02:17:43 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:17:43 --> Model "User_model" initialized
INFO - 2025-11-05 02:17:43 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:17:43 --> Model "Project_model" initialized
INFO - 2025-11-05 02:17:43 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 02:17:43 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 02:17:43 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 02:17:43 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ife.php
INFO - 2025-11-05 02:17:43 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 02:17:43 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 02:17:43 --> Final output sent to browser
INFO - 2025-11-05 02:17:43 --> Total execution time: 0.0650
INFO - 2025-11-05 02:17:43 --> Config Class Initialized
INFO - 2025-11-05 02:17:43 --> Hooks Class Initialized
INFO - 2025-11-05 02:17:43 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:17:43 --> Utf8 Class Initialized
INFO - 2025-11-05 02:17:43 --> URI Class Initialized
INFO - 2025-11-05 02:17:43 --> Router Class Initialized
INFO - 2025-11-05 02:17:43 --> Output Class Initialized
INFO - 2025-11-05 02:17:43 --> Security Class Initialized
INFO - 2025-11-05 02:17:43 --> Input Class Initialized
INFO - 2025-11-05 02:17:43 --> Language Class Initialized
INFO - 2025-11-05 02:17:43 --> Loader Class Initialized
INFO - 2025-11-05 02:17:43 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:17:43 --> Helper loaded: url_helper
INFO - 2025-11-05 02:17:43 --> Helper loaded: file_helper
INFO - 2025-11-05 02:17:43 --> Helper loaded: main_helper
INFO - 2025-11-05 02:17:43 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:17:43 --> Database Driver Class Initialized
INFO - 2025-11-05 02:17:43 --> Email Class Initialized
DEBUG - 2025-11-05 02:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:17:43 --> Controller Class Initialized
INFO - 2025-11-05 02:17:43 --> Model "User_model" initialized
INFO - 2025-11-05 02:17:43 --> Model "Project_model" initialized
INFO - 2025-11-05 02:17:43 --> Helper loaded: form_helper
INFO - 2025-11-05 02:17:43 --> Form Validation Class Initialized
INFO - 2025-11-05 02:17:43 --> Final output sent to browser
INFO - 2025-11-05 02:17:43 --> Total execution time: 0.0573
INFO - 2025-11-05 02:18:01 --> Config Class Initialized
INFO - 2025-11-05 02:18:01 --> Hooks Class Initialized
INFO - 2025-11-05 02:18:01 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:18:01 --> Utf8 Class Initialized
INFO - 2025-11-05 02:18:01 --> URI Class Initialized
INFO - 2025-11-05 02:18:01 --> Router Class Initialized
INFO - 2025-11-05 02:18:01 --> Output Class Initialized
INFO - 2025-11-05 02:18:01 --> Security Class Initialized
INFO - 2025-11-05 02:18:01 --> Input Class Initialized
INFO - 2025-11-05 02:18:01 --> Language Class Initialized
INFO - 2025-11-05 02:18:01 --> Loader Class Initialized
INFO - 2025-11-05 02:18:01 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:18:01 --> Helper loaded: url_helper
INFO - 2025-11-05 02:18:01 --> Helper loaded: file_helper
INFO - 2025-11-05 02:18:01 --> Helper loaded: main_helper
INFO - 2025-11-05 02:18:01 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:18:01 --> Database Driver Class Initialized
INFO - 2025-11-05 02:18:01 --> Email Class Initialized
DEBUG - 2025-11-05 02:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:18:01 --> Controller Class Initialized
INFO - 2025-11-05 02:18:01 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:18:01 --> Model "User_model" initialized
INFO - 2025-11-05 02:18:01 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:18:01 --> Model "Project_model" initialized
INFO - 2025-11-05 02:18:01 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 02:18:01 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 02:18:01 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 02:18:01 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ife.php
INFO - 2025-11-05 02:18:01 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 02:18:01 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 02:18:01 --> Final output sent to browser
INFO - 2025-11-05 02:18:01 --> Total execution time: 0.0610
INFO - 2025-11-05 02:18:01 --> Config Class Initialized
INFO - 2025-11-05 02:18:01 --> Hooks Class Initialized
INFO - 2025-11-05 02:18:01 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:18:01 --> Utf8 Class Initialized
INFO - 2025-11-05 02:18:01 --> URI Class Initialized
INFO - 2025-11-05 02:18:01 --> Router Class Initialized
INFO - 2025-11-05 02:18:01 --> Output Class Initialized
INFO - 2025-11-05 02:18:01 --> Security Class Initialized
INFO - 2025-11-05 02:18:01 --> Input Class Initialized
INFO - 2025-11-05 02:18:01 --> Language Class Initialized
INFO - 2025-11-05 02:18:01 --> Loader Class Initialized
INFO - 2025-11-05 02:18:01 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:18:01 --> Helper loaded: url_helper
INFO - 2025-11-05 02:18:01 --> Helper loaded: file_helper
INFO - 2025-11-05 02:18:01 --> Helper loaded: main_helper
INFO - 2025-11-05 02:18:01 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:18:01 --> Database Driver Class Initialized
INFO - 2025-11-05 02:18:01 --> Email Class Initialized
DEBUG - 2025-11-05 02:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:18:01 --> Controller Class Initialized
INFO - 2025-11-05 02:18:01 --> Model "User_model" initialized
INFO - 2025-11-05 02:18:01 --> Model "Project_model" initialized
INFO - 2025-11-05 02:18:01 --> Helper loaded: form_helper
INFO - 2025-11-05 02:18:01 --> Form Validation Class Initialized
INFO - 2025-11-05 02:18:01 --> Final output sent to browser
INFO - 2025-11-05 02:18:01 --> Total execution time: 0.0643
INFO - 2025-11-05 02:18:02 --> Config Class Initialized
INFO - 2025-11-05 02:18:02 --> Hooks Class Initialized
INFO - 2025-11-05 02:18:02 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:18:02 --> Utf8 Class Initialized
INFO - 2025-11-05 02:18:02 --> URI Class Initialized
INFO - 2025-11-05 02:18:02 --> Router Class Initialized
INFO - 2025-11-05 02:18:02 --> Output Class Initialized
INFO - 2025-11-05 02:18:02 --> Security Class Initialized
INFO - 2025-11-05 02:18:02 --> Input Class Initialized
INFO - 2025-11-05 02:18:02 --> Language Class Initialized
INFO - 2025-11-05 02:18:02 --> Loader Class Initialized
INFO - 2025-11-05 02:18:02 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:18:02 --> Helper loaded: url_helper
INFO - 2025-11-05 02:18:02 --> Helper loaded: file_helper
INFO - 2025-11-05 02:18:02 --> Helper loaded: main_helper
INFO - 2025-11-05 02:18:02 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:18:02 --> Database Driver Class Initialized
INFO - 2025-11-05 02:18:02 --> Email Class Initialized
DEBUG - 2025-11-05 02:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:18:02 --> Controller Class Initialized
INFO - 2025-11-05 02:18:02 --> Model "User_model" initialized
INFO - 2025-11-05 02:18:02 --> Model "Project_model" initialized
INFO - 2025-11-05 02:18:02 --> Helper loaded: form_helper
INFO - 2025-11-05 02:18:02 --> Form Validation Class Initialized
INFO - 2025-11-05 02:18:02 --> Final output sent to browser
INFO - 2025-11-05 02:18:02 --> Total execution time: 0.1005
INFO - 2025-11-05 02:18:05 --> Config Class Initialized
INFO - 2025-11-05 02:18:05 --> Hooks Class Initialized
INFO - 2025-11-05 02:18:05 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:18:05 --> Utf8 Class Initialized
INFO - 2025-11-05 02:18:05 --> URI Class Initialized
INFO - 2025-11-05 02:18:05 --> Router Class Initialized
INFO - 2025-11-05 02:18:05 --> Output Class Initialized
INFO - 2025-11-05 02:18:05 --> Security Class Initialized
INFO - 2025-11-05 02:18:05 --> Input Class Initialized
INFO - 2025-11-05 02:18:05 --> Language Class Initialized
INFO - 2025-11-05 02:18:05 --> Loader Class Initialized
INFO - 2025-11-05 02:18:05 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:18:05 --> Helper loaded: url_helper
INFO - 2025-11-05 02:18:05 --> Helper loaded: file_helper
INFO - 2025-11-05 02:18:05 --> Helper loaded: main_helper
INFO - 2025-11-05 02:18:05 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:18:05 --> Database Driver Class Initialized
INFO - 2025-11-05 02:18:05 --> Email Class Initialized
DEBUG - 2025-11-05 02:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:18:05 --> Controller Class Initialized
INFO - 2025-11-05 02:18:05 --> Model "User_model" initialized
INFO - 2025-11-05 02:18:05 --> Model "Project_model" initialized
INFO - 2025-11-05 02:18:05 --> Helper loaded: form_helper
INFO - 2025-11-05 02:18:05 --> Form Validation Class Initialized
INFO - 2025-11-05 02:18:05 --> Final output sent to browser
INFO - 2025-11-05 02:18:05 --> Total execution time: 0.0678
INFO - 2025-11-05 02:18:11 --> Config Class Initialized
INFO - 2025-11-05 02:18:11 --> Hooks Class Initialized
INFO - 2025-11-05 02:18:11 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:18:11 --> Utf8 Class Initialized
INFO - 2025-11-05 02:18:11 --> URI Class Initialized
INFO - 2025-11-05 02:18:11 --> Router Class Initialized
INFO - 2025-11-05 02:18:11 --> Output Class Initialized
INFO - 2025-11-05 02:18:11 --> Security Class Initialized
INFO - 2025-11-05 02:18:11 --> Input Class Initialized
INFO - 2025-11-05 02:18:11 --> Language Class Initialized
INFO - 2025-11-05 02:18:11 --> Loader Class Initialized
INFO - 2025-11-05 02:18:11 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:18:11 --> Helper loaded: url_helper
INFO - 2025-11-05 02:18:11 --> Helper loaded: file_helper
INFO - 2025-11-05 02:18:11 --> Helper loaded: main_helper
INFO - 2025-11-05 02:18:11 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:18:11 --> Database Driver Class Initialized
INFO - 2025-11-05 02:18:11 --> Email Class Initialized
DEBUG - 2025-11-05 02:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:18:11 --> Controller Class Initialized
INFO - 2025-11-05 02:18:11 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:18:11 --> Model "User_model" initialized
INFO - 2025-11-05 02:18:11 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:18:11 --> Model "Project_model" initialized
INFO - 2025-11-05 02:18:11 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 02:18:11 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 02:18:11 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 02:18:11 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-efe.php
INFO - 2025-11-05 02:18:11 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 02:18:11 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 02:18:11 --> Final output sent to browser
INFO - 2025-11-05 02:18:11 --> Total execution time: 0.0978
INFO - 2025-11-05 02:18:12 --> Config Class Initialized
INFO - 2025-11-05 02:18:12 --> Hooks Class Initialized
INFO - 2025-11-05 02:18:12 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:18:12 --> Utf8 Class Initialized
INFO - 2025-11-05 02:18:12 --> URI Class Initialized
INFO - 2025-11-05 02:18:12 --> Router Class Initialized
INFO - 2025-11-05 02:18:12 --> Output Class Initialized
INFO - 2025-11-05 02:18:12 --> Security Class Initialized
INFO - 2025-11-05 02:18:12 --> Input Class Initialized
INFO - 2025-11-05 02:18:12 --> Language Class Initialized
INFO - 2025-11-05 02:18:12 --> Loader Class Initialized
INFO - 2025-11-05 02:18:12 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:18:12 --> Helper loaded: url_helper
INFO - 2025-11-05 02:18:12 --> Helper loaded: file_helper
INFO - 2025-11-05 02:18:12 --> Helper loaded: main_helper
INFO - 2025-11-05 02:18:12 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:18:12 --> Database Driver Class Initialized
INFO - 2025-11-05 02:18:12 --> Email Class Initialized
DEBUG - 2025-11-05 02:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:18:12 --> Controller Class Initialized
INFO - 2025-11-05 02:18:12 --> Model "User_model" initialized
INFO - 2025-11-05 02:18:12 --> Model "Project_model" initialized
INFO - 2025-11-05 02:18:12 --> Helper loaded: form_helper
INFO - 2025-11-05 02:18:12 --> Form Validation Class Initialized
INFO - 2025-11-05 02:18:12 --> Final output sent to browser
INFO - 2025-11-05 02:18:12 --> Total execution time: 0.0578
INFO - 2025-11-05 02:18:14 --> Config Class Initialized
INFO - 2025-11-05 02:18:14 --> Hooks Class Initialized
INFO - 2025-11-05 02:18:14 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:18:14 --> Utf8 Class Initialized
INFO - 2025-11-05 02:18:14 --> URI Class Initialized
INFO - 2025-11-05 02:18:14 --> Router Class Initialized
INFO - 2025-11-05 02:18:14 --> Output Class Initialized
INFO - 2025-11-05 02:18:14 --> Security Class Initialized
INFO - 2025-11-05 02:18:14 --> Input Class Initialized
INFO - 2025-11-05 02:18:14 --> Language Class Initialized
INFO - 2025-11-05 02:18:14 --> Loader Class Initialized
INFO - 2025-11-05 02:18:14 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:18:14 --> Helper loaded: url_helper
INFO - 2025-11-05 02:18:14 --> Helper loaded: file_helper
INFO - 2025-11-05 02:18:14 --> Helper loaded: main_helper
INFO - 2025-11-05 02:18:14 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:18:14 --> Database Driver Class Initialized
INFO - 2025-11-05 02:18:14 --> Email Class Initialized
DEBUG - 2025-11-05 02:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:18:14 --> Controller Class Initialized
INFO - 2025-11-05 02:18:14 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:18:14 --> Model "User_model" initialized
INFO - 2025-11-05 02:18:14 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:18:14 --> Model "Project_model" initialized
INFO - 2025-11-05 02:18:14 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 02:18:14 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 02:18:14 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 02:18:14 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ife.php
INFO - 2025-11-05 02:18:14 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 02:18:14 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 02:18:14 --> Final output sent to browser
INFO - 2025-11-05 02:18:14 --> Total execution time: 0.0677
INFO - 2025-11-05 02:18:14 --> Config Class Initialized
INFO - 2025-11-05 02:18:14 --> Hooks Class Initialized
INFO - 2025-11-05 02:18:14 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:18:14 --> Utf8 Class Initialized
INFO - 2025-11-05 02:18:14 --> URI Class Initialized
INFO - 2025-11-05 02:18:14 --> Router Class Initialized
INFO - 2025-11-05 02:18:14 --> Output Class Initialized
INFO - 2025-11-05 02:18:14 --> Security Class Initialized
INFO - 2025-11-05 02:18:14 --> Input Class Initialized
INFO - 2025-11-05 02:18:14 --> Language Class Initialized
INFO - 2025-11-05 02:18:14 --> Loader Class Initialized
INFO - 2025-11-05 02:18:14 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:18:14 --> Helper loaded: url_helper
INFO - 2025-11-05 02:18:14 --> Helper loaded: file_helper
INFO - 2025-11-05 02:18:14 --> Helper loaded: main_helper
INFO - 2025-11-05 02:18:14 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:18:14 --> Database Driver Class Initialized
INFO - 2025-11-05 02:18:14 --> Email Class Initialized
DEBUG - 2025-11-05 02:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:18:14 --> Controller Class Initialized
INFO - 2025-11-05 02:18:14 --> Model "User_model" initialized
INFO - 2025-11-05 02:18:14 --> Model "Project_model" initialized
INFO - 2025-11-05 02:18:14 --> Helper loaded: form_helper
INFO - 2025-11-05 02:18:14 --> Form Validation Class Initialized
INFO - 2025-11-05 02:18:14 --> Final output sent to browser
INFO - 2025-11-05 02:18:14 --> Total execution time: 0.0602
INFO - 2025-11-05 02:18:16 --> Config Class Initialized
INFO - 2025-11-05 02:18:16 --> Hooks Class Initialized
INFO - 2025-11-05 02:18:16 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:18:16 --> Utf8 Class Initialized
INFO - 2025-11-05 02:18:16 --> URI Class Initialized
INFO - 2025-11-05 02:18:16 --> Router Class Initialized
INFO - 2025-11-05 02:18:16 --> Output Class Initialized
INFO - 2025-11-05 02:18:16 --> Security Class Initialized
INFO - 2025-11-05 02:18:16 --> Input Class Initialized
INFO - 2025-11-05 02:18:16 --> Language Class Initialized
INFO - 2025-11-05 02:18:16 --> Loader Class Initialized
INFO - 2025-11-05 02:18:16 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:18:16 --> Helper loaded: url_helper
INFO - 2025-11-05 02:18:16 --> Helper loaded: file_helper
INFO - 2025-11-05 02:18:16 --> Helper loaded: main_helper
INFO - 2025-11-05 02:18:16 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:18:16 --> Database Driver Class Initialized
INFO - 2025-11-05 02:18:16 --> Email Class Initialized
DEBUG - 2025-11-05 02:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:18:16 --> Controller Class Initialized
INFO - 2025-11-05 02:18:16 --> Model "User_model" initialized
INFO - 2025-11-05 02:18:16 --> Model "Project_model" initialized
INFO - 2025-11-05 02:18:16 --> Helper loaded: form_helper
INFO - 2025-11-05 02:18:16 --> Form Validation Class Initialized
INFO - 2025-11-05 02:18:16 --> Final output sent to browser
INFO - 2025-11-05 02:18:16 --> Total execution time: 0.0875
INFO - 2025-11-05 02:18:25 --> Config Class Initialized
INFO - 2025-11-05 02:18:25 --> Hooks Class Initialized
INFO - 2025-11-05 02:18:25 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:18:25 --> Utf8 Class Initialized
INFO - 2025-11-05 02:18:25 --> URI Class Initialized
INFO - 2025-11-05 02:18:25 --> Router Class Initialized
INFO - 2025-11-05 02:18:25 --> Output Class Initialized
INFO - 2025-11-05 02:18:25 --> Security Class Initialized
INFO - 2025-11-05 02:18:25 --> Input Class Initialized
INFO - 2025-11-05 02:18:25 --> Language Class Initialized
INFO - 2025-11-05 02:18:25 --> Loader Class Initialized
INFO - 2025-11-05 02:18:25 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:18:25 --> Helper loaded: url_helper
INFO - 2025-11-05 02:18:25 --> Helper loaded: file_helper
INFO - 2025-11-05 02:18:25 --> Helper loaded: main_helper
INFO - 2025-11-05 02:18:25 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:18:25 --> Database Driver Class Initialized
INFO - 2025-11-05 02:18:25 --> Email Class Initialized
DEBUG - 2025-11-05 02:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:18:25 --> Controller Class Initialized
INFO - 2025-11-05 02:18:25 --> Model "User_model" initialized
INFO - 2025-11-05 02:18:25 --> Model "Project_model" initialized
INFO - 2025-11-05 02:18:25 --> Helper loaded: form_helper
INFO - 2025-11-05 02:18:25 --> Form Validation Class Initialized
INFO - 2025-11-05 02:18:25 --> Final output sent to browser
INFO - 2025-11-05 02:18:25 --> Total execution time: 0.0909
INFO - 2025-11-05 02:18:25 --> Config Class Initialized
INFO - 2025-11-05 02:18:25 --> Hooks Class Initialized
INFO - 2025-11-05 02:18:25 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:18:25 --> Utf8 Class Initialized
INFO - 2025-11-05 02:18:25 --> URI Class Initialized
INFO - 2025-11-05 02:18:25 --> Router Class Initialized
INFO - 2025-11-05 02:18:25 --> Output Class Initialized
INFO - 2025-11-05 02:18:25 --> Security Class Initialized
INFO - 2025-11-05 02:18:25 --> Input Class Initialized
INFO - 2025-11-05 02:18:25 --> Language Class Initialized
INFO - 2025-11-05 02:18:25 --> Loader Class Initialized
INFO - 2025-11-05 02:18:25 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:18:25 --> Helper loaded: url_helper
INFO - 2025-11-05 02:18:25 --> Helper loaded: file_helper
INFO - 2025-11-05 02:18:25 --> Helper loaded: main_helper
INFO - 2025-11-05 02:18:25 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:18:25 --> Database Driver Class Initialized
INFO - 2025-11-05 02:18:25 --> Email Class Initialized
DEBUG - 2025-11-05 02:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:18:25 --> Controller Class Initialized
INFO - 2025-11-05 02:18:25 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:18:25 --> Model "User_model" initialized
INFO - 2025-11-05 02:18:25 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:18:25 --> Model "Project_model" initialized
INFO - 2025-11-05 02:18:25 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 02:18:25 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 02:18:25 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 02:18:25 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-efe.php
INFO - 2025-11-05 02:18:25 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 02:18:25 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 02:18:25 --> Final output sent to browser
INFO - 2025-11-05 02:18:25 --> Total execution time: 0.0522
INFO - 2025-11-05 02:18:25 --> Config Class Initialized
INFO - 2025-11-05 02:18:25 --> Hooks Class Initialized
INFO - 2025-11-05 02:18:25 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:18:25 --> Utf8 Class Initialized
INFO - 2025-11-05 02:18:25 --> URI Class Initialized
INFO - 2025-11-05 02:18:25 --> Router Class Initialized
INFO - 2025-11-05 02:18:25 --> Output Class Initialized
INFO - 2025-11-05 02:18:25 --> Security Class Initialized
INFO - 2025-11-05 02:18:25 --> Input Class Initialized
INFO - 2025-11-05 02:18:25 --> Language Class Initialized
INFO - 2025-11-05 02:18:25 --> Loader Class Initialized
INFO - 2025-11-05 02:18:25 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:18:25 --> Helper loaded: url_helper
INFO - 2025-11-05 02:18:25 --> Helper loaded: file_helper
INFO - 2025-11-05 02:18:25 --> Helper loaded: main_helper
INFO - 2025-11-05 02:18:25 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:18:25 --> Database Driver Class Initialized
INFO - 2025-11-05 02:18:25 --> Email Class Initialized
DEBUG - 2025-11-05 02:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:18:25 --> Controller Class Initialized
INFO - 2025-11-05 02:18:25 --> Model "User_model" initialized
INFO - 2025-11-05 02:18:25 --> Model "Project_model" initialized
INFO - 2025-11-05 02:18:25 --> Helper loaded: form_helper
INFO - 2025-11-05 02:18:25 --> Form Validation Class Initialized
INFO - 2025-11-05 02:18:25 --> Final output sent to browser
INFO - 2025-11-05 02:18:25 --> Total execution time: 0.0520
INFO - 2025-11-05 02:21:11 --> Config Class Initialized
INFO - 2025-11-05 02:21:11 --> Hooks Class Initialized
INFO - 2025-11-05 02:21:11 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:21:11 --> Utf8 Class Initialized
INFO - 2025-11-05 02:21:11 --> URI Class Initialized
INFO - 2025-11-05 02:21:11 --> Router Class Initialized
INFO - 2025-11-05 02:21:11 --> Output Class Initialized
INFO - 2025-11-05 02:21:11 --> Security Class Initialized
INFO - 2025-11-05 02:21:11 --> Input Class Initialized
INFO - 2025-11-05 02:21:11 --> Language Class Initialized
INFO - 2025-11-05 02:21:11 --> Loader Class Initialized
INFO - 2025-11-05 02:21:11 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:21:11 --> Helper loaded: url_helper
INFO - 2025-11-05 02:21:11 --> Helper loaded: file_helper
INFO - 2025-11-05 02:21:11 --> Helper loaded: main_helper
INFO - 2025-11-05 02:21:11 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:21:11 --> Database Driver Class Initialized
INFO - 2025-11-05 02:21:11 --> Email Class Initialized
DEBUG - 2025-11-05 02:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:21:11 --> Controller Class Initialized
INFO - 2025-11-05 02:21:11 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:21:11 --> Model "User_model" initialized
INFO - 2025-11-05 02:21:11 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:21:11 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-05 02:21:11 --> Final output sent to browser
INFO - 2025-11-05 02:21:11 --> Total execution time: 0.0624
INFO - 2025-11-05 02:21:12 --> Config Class Initialized
INFO - 2025-11-05 02:21:12 --> Hooks Class Initialized
INFO - 2025-11-05 02:21:12 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:21:12 --> Utf8 Class Initialized
INFO - 2025-11-05 02:21:12 --> URI Class Initialized
DEBUG - 2025-11-05 02:21:12 --> No URI present. Default controller set.
INFO - 2025-11-05 02:21:12 --> Router Class Initialized
INFO - 2025-11-05 02:21:12 --> Output Class Initialized
INFO - 2025-11-05 02:21:12 --> Security Class Initialized
INFO - 2025-11-05 02:21:12 --> Input Class Initialized
INFO - 2025-11-05 02:21:12 --> Language Class Initialized
INFO - 2025-11-05 02:21:12 --> Loader Class Initialized
INFO - 2025-11-05 02:21:12 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:21:12 --> Helper loaded: url_helper
INFO - 2025-11-05 02:21:12 --> Helper loaded: file_helper
INFO - 2025-11-05 02:21:12 --> Helper loaded: main_helper
INFO - 2025-11-05 02:21:12 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:21:12 --> Database Driver Class Initialized
INFO - 2025-11-05 02:21:12 --> Email Class Initialized
DEBUG - 2025-11-05 02:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:21:12 --> Controller Class Initialized
INFO - 2025-11-05 02:21:12 --> Config Class Initialized
INFO - 2025-11-05 02:21:12 --> Hooks Class Initialized
INFO - 2025-11-05 02:21:12 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:21:12 --> Utf8 Class Initialized
INFO - 2025-11-05 02:21:12 --> URI Class Initialized
INFO - 2025-11-05 02:21:12 --> Router Class Initialized
INFO - 2025-11-05 02:21:12 --> Output Class Initialized
INFO - 2025-11-05 02:21:12 --> Security Class Initialized
INFO - 2025-11-05 02:21:12 --> Input Class Initialized
INFO - 2025-11-05 02:21:12 --> Language Class Initialized
INFO - 2025-11-05 02:21:12 --> Loader Class Initialized
INFO - 2025-11-05 02:21:12 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:21:12 --> Helper loaded: url_helper
INFO - 2025-11-05 02:21:12 --> Helper loaded: file_helper
INFO - 2025-11-05 02:21:12 --> Helper loaded: main_helper
INFO - 2025-11-05 02:21:12 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:21:12 --> Database Driver Class Initialized
INFO - 2025-11-05 02:21:12 --> Email Class Initialized
DEBUG - 2025-11-05 02:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:21:12 --> Controller Class Initialized
INFO - 2025-11-05 02:21:12 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:21:12 --> Model "User_model" initialized
INFO - 2025-11-05 02:21:12 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:21:12 --> Config Class Initialized
INFO - 2025-11-05 02:21:12 --> Hooks Class Initialized
INFO - 2025-11-05 02:21:12 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:21:12 --> Utf8 Class Initialized
INFO - 2025-11-05 02:21:12 --> URI Class Initialized
INFO - 2025-11-05 02:21:12 --> Router Class Initialized
INFO - 2025-11-05 02:21:12 --> Output Class Initialized
INFO - 2025-11-05 02:21:12 --> Security Class Initialized
INFO - 2025-11-05 02:21:12 --> Input Class Initialized
INFO - 2025-11-05 02:21:12 --> Language Class Initialized
INFO - 2025-11-05 02:21:12 --> Loader Class Initialized
INFO - 2025-11-05 02:21:12 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:21:12 --> Helper loaded: url_helper
INFO - 2025-11-05 02:21:12 --> Helper loaded: file_helper
INFO - 2025-11-05 02:21:12 --> Helper loaded: main_helper
INFO - 2025-11-05 02:21:12 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:21:12 --> Database Driver Class Initialized
INFO - 2025-11-05 02:21:12 --> Email Class Initialized
DEBUG - 2025-11-05 02:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:21:12 --> Controller Class Initialized
INFO - 2025-11-05 02:21:12 --> Config Class Initialized
INFO - 2025-11-05 02:21:12 --> Hooks Class Initialized
INFO - 2025-11-05 02:21:12 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:21:12 --> Utf8 Class Initialized
INFO - 2025-11-05 02:21:12 --> URI Class Initialized
INFO - 2025-11-05 02:21:12 --> Router Class Initialized
INFO - 2025-11-05 02:21:12 --> Output Class Initialized
INFO - 2025-11-05 02:21:12 --> Security Class Initialized
INFO - 2025-11-05 02:21:12 --> Input Class Initialized
INFO - 2025-11-05 02:21:12 --> Language Class Initialized
INFO - 2025-11-05 02:21:12 --> Loader Class Initialized
INFO - 2025-11-05 02:21:12 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 02:21:12 --> Helper loaded: url_helper
INFO - 2025-11-05 02:21:12 --> Helper loaded: file_helper
INFO - 2025-11-05 02:21:12 --> Helper loaded: main_helper
INFO - 2025-11-05 02:21:12 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 02:21:12 --> Database Driver Class Initialized
INFO - 2025-11-05 02:21:12 --> Email Class Initialized
DEBUG - 2025-11-05 02:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 02:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 02:21:12 --> Controller Class Initialized
INFO - 2025-11-05 02:21:12 --> Model "Subscription_model" initialized
INFO - 2025-11-05 02:21:12 --> Model "User_model" initialized
INFO - 2025-11-05 02:21:12 --> Model "Auth_model" initialized
INFO - 2025-11-05 02:21:12 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-05 02:21:12 --> Final output sent to browser
INFO - 2025-11-05 02:21:12 --> Total execution time: 0.0587
INFO - 2025-11-05 02:21:12 --> Config Class Initialized
INFO - 2025-11-05 02:21:12 --> Hooks Class Initialized
INFO - 2025-11-05 02:21:12 --> UTF-8 Support Enabled
INFO - 2025-11-05 02:21:12 --> Utf8 Class Initialized
INFO - 2025-11-05 11:18:12 --> Config Class Initialized
INFO - 2025-11-05 11:18:12 --> Hooks Class Initialized
INFO - 2025-11-05 11:18:12 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:18:12 --> Utf8 Class Initialized
INFO - 2025-11-05 11:18:12 --> URI Class Initialized
DEBUG - 2025-11-05 11:18:12 --> No URI present. Default controller set.
INFO - 2025-11-05 11:18:12 --> Router Class Initialized
INFO - 2025-11-05 11:18:12 --> Output Class Initialized
INFO - 2025-11-05 11:18:12 --> Security Class Initialized
INFO - 2025-11-05 11:18:12 --> Input Class Initialized
INFO - 2025-11-05 11:18:12 --> Language Class Initialized
INFO - 2025-11-05 11:18:12 --> Loader Class Initialized
INFO - 2025-11-05 11:18:12 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 11:18:12 --> Helper loaded: url_helper
INFO - 2025-11-05 11:18:12 --> Helper loaded: file_helper
INFO - 2025-11-05 11:18:12 --> Helper loaded: main_helper
INFO - 2025-11-05 11:18:12 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 11:18:12 --> Database Driver Class Initialized
INFO - 2025-11-05 11:18:12 --> Email Class Initialized
DEBUG - 2025-11-05 11:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 11:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 11:18:12 --> Controller Class Initialized
INFO - 2025-11-05 11:18:12 --> Config Class Initialized
INFO - 2025-11-05 11:18:12 --> Hooks Class Initialized
INFO - 2025-11-05 11:18:12 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:18:12 --> Utf8 Class Initialized
INFO - 2025-11-05 11:18:12 --> URI Class Initialized
INFO - 2025-11-05 11:18:12 --> Router Class Initialized
INFO - 2025-11-05 11:18:12 --> Output Class Initialized
INFO - 2025-11-05 11:18:12 --> Security Class Initialized
INFO - 2025-11-05 11:18:12 --> Input Class Initialized
INFO - 2025-11-05 11:18:12 --> Language Class Initialized
INFO - 2025-11-05 11:18:12 --> Loader Class Initialized
INFO - 2025-11-05 11:18:12 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 11:18:12 --> Helper loaded: url_helper
INFO - 2025-11-05 11:18:12 --> Helper loaded: file_helper
INFO - 2025-11-05 11:18:12 --> Helper loaded: main_helper
INFO - 2025-11-05 11:18:12 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 11:18:12 --> Database Driver Class Initialized
INFO - 2025-11-05 11:18:12 --> Email Class Initialized
DEBUG - 2025-11-05 11:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 11:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 11:18:12 --> Controller Class Initialized
INFO - 2025-11-05 11:18:12 --> Model "Subscription_model" initialized
INFO - 2025-11-05 11:18:12 --> Model "User_model" initialized
INFO - 2025-11-05 11:18:12 --> Model "Auth_model" initialized
INFO - 2025-11-05 11:18:12 --> Config Class Initialized
INFO - 2025-11-05 11:18:12 --> Hooks Class Initialized
INFO - 2025-11-05 11:18:12 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:18:12 --> Utf8 Class Initialized
INFO - 2025-11-05 11:18:12 --> URI Class Initialized
INFO - 2025-11-05 11:18:12 --> Router Class Initialized
INFO - 2025-11-05 11:18:12 --> Output Class Initialized
INFO - 2025-11-05 11:18:12 --> Security Class Initialized
INFO - 2025-11-05 11:18:12 --> Input Class Initialized
INFO - 2025-11-05 11:18:12 --> Language Class Initialized
INFO - 2025-11-05 11:18:12 --> Loader Class Initialized
INFO - 2025-11-05 11:18:12 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 11:18:12 --> Helper loaded: url_helper
INFO - 2025-11-05 11:18:12 --> Helper loaded: file_helper
INFO - 2025-11-05 11:18:12 --> Helper loaded: main_helper
INFO - 2025-11-05 11:18:12 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 11:18:12 --> Database Driver Class Initialized
INFO - 2025-11-05 11:18:12 --> Email Class Initialized
DEBUG - 2025-11-05 11:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 11:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 11:18:12 --> Controller Class Initialized
INFO - 2025-11-05 11:18:12 --> Config Class Initialized
INFO - 2025-11-05 11:18:12 --> Hooks Class Initialized
INFO - 2025-11-05 11:18:12 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:18:12 --> Utf8 Class Initialized
INFO - 2025-11-05 11:18:12 --> URI Class Initialized
INFO - 2025-11-05 11:18:12 --> Router Class Initialized
INFO - 2025-11-05 11:18:12 --> Output Class Initialized
INFO - 2025-11-05 11:18:12 --> Security Class Initialized
INFO - 2025-11-05 11:18:12 --> Input Class Initialized
INFO - 2025-11-05 11:18:12 --> Language Class Initialized
INFO - 2025-11-05 11:18:12 --> Loader Class Initialized
INFO - 2025-11-05 11:18:12 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 11:18:12 --> Helper loaded: url_helper
INFO - 2025-11-05 11:18:12 --> Helper loaded: file_helper
INFO - 2025-11-05 11:18:12 --> Helper loaded: main_helper
INFO - 2025-11-05 11:18:12 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 11:18:12 --> Database Driver Class Initialized
INFO - 2025-11-05 11:18:12 --> Email Class Initialized
DEBUG - 2025-11-05 11:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 11:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 11:18:12 --> Controller Class Initialized
INFO - 2025-11-05 11:18:12 --> Model "Subscription_model" initialized
INFO - 2025-11-05 11:18:12 --> Model "User_model" initialized
INFO - 2025-11-05 11:18:12 --> Model "Auth_model" initialized
INFO - 2025-11-05 11:18:12 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-05 11:18:12 --> Final output sent to browser
INFO - 2025-11-05 11:18:12 --> Total execution time: 0.0381
INFO - 2025-11-05 11:18:23 --> Config Class Initialized
INFO - 2025-11-05 11:18:23 --> Hooks Class Initialized
INFO - 2025-11-05 11:18:23 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:18:23 --> Utf8 Class Initialized
INFO - 2025-11-05 11:18:23 --> URI Class Initialized
INFO - 2025-11-05 11:18:23 --> Router Class Initialized
INFO - 2025-11-05 11:18:23 --> Output Class Initialized
INFO - 2025-11-05 11:18:23 --> Security Class Initialized
INFO - 2025-11-05 11:18:23 --> Input Class Initialized
INFO - 2025-11-05 11:18:23 --> Language Class Initialized
INFO - 2025-11-05 11:18:23 --> Loader Class Initialized
INFO - 2025-11-05 11:18:23 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 11:18:23 --> Helper loaded: url_helper
INFO - 2025-11-05 11:18:23 --> Helper loaded: file_helper
INFO - 2025-11-05 11:18:23 --> Helper loaded: main_helper
INFO - 2025-11-05 11:18:23 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 11:18:23 --> Database Driver Class Initialized
INFO - 2025-11-05 11:18:23 --> Email Class Initialized
DEBUG - 2025-11-05 11:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 11:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 11:18:23 --> Controller Class Initialized
INFO - 2025-11-05 11:18:23 --> Model "Subscription_model" initialized
INFO - 2025-11-05 11:18:23 --> Model "User_model" initialized
INFO - 2025-11-05 11:18:23 --> Model "Auth_model" initialized
INFO - 2025-11-05 11:18:23 --> Final output sent to browser
INFO - 2025-11-05 11:18:23 --> Total execution time: 0.1620
INFO - 2025-11-05 11:18:24 --> Config Class Initialized
INFO - 2025-11-05 11:18:24 --> Hooks Class Initialized
INFO - 2025-11-05 11:18:24 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:18:24 --> Utf8 Class Initialized
INFO - 2025-11-05 11:18:24 --> URI Class Initialized
INFO - 2025-11-05 11:18:24 --> Router Class Initialized
INFO - 2025-11-05 11:18:24 --> Output Class Initialized
INFO - 2025-11-05 11:18:24 --> Security Class Initialized
INFO - 2025-11-05 11:18:24 --> Input Class Initialized
INFO - 2025-11-05 11:18:24 --> Language Class Initialized
INFO - 2025-11-05 11:18:24 --> Loader Class Initialized
INFO - 2025-11-05 11:18:24 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 11:18:24 --> Helper loaded: url_helper
INFO - 2025-11-05 11:18:24 --> Helper loaded: file_helper
INFO - 2025-11-05 11:18:24 --> Helper loaded: main_helper
INFO - 2025-11-05 11:18:24 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 11:18:24 --> Database Driver Class Initialized
INFO - 2025-11-05 11:18:24 --> Email Class Initialized
DEBUG - 2025-11-05 11:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 11:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 11:18:24 --> Controller Class Initialized
INFO - 2025-11-05 11:18:24 --> Model "Subscription_model" initialized
INFO - 2025-11-05 11:18:24 --> Model "User_model" initialized
INFO - 2025-11-05 11:18:24 --> Model "Auth_model" initialized
INFO - 2025-11-05 11:18:24 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 11:18:24 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 11:18:24 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 11:18:24 --> File loaded: D:\laragon\www\acumena\application\views\dashboard.php
INFO - 2025-11-05 11:18:24 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 11:18:24 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 11:18:24 --> Final output sent to browser
INFO - 2025-11-05 11:18:24 --> Total execution time: 0.0490
INFO - 2025-11-05 11:18:24 --> Config Class Initialized
INFO - 2025-11-05 11:18:24 --> Hooks Class Initialized
INFO - 2025-11-05 11:18:24 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:18:24 --> Utf8 Class Initialized
INFO - 2025-11-05 11:18:24 --> URI Class Initialized
INFO - 2025-11-05 11:18:24 --> Router Class Initialized
INFO - 2025-11-05 11:18:24 --> Output Class Initialized
INFO - 2025-11-05 11:18:24 --> Security Class Initialized
INFO - 2025-11-05 11:18:24 --> Input Class Initialized
INFO - 2025-11-05 11:18:24 --> Language Class Initialized
INFO - 2025-11-05 11:18:24 --> Loader Class Initialized
INFO - 2025-11-05 11:18:24 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 11:18:24 --> Helper loaded: url_helper
INFO - 2025-11-05 11:18:24 --> Helper loaded: file_helper
INFO - 2025-11-05 11:18:24 --> Helper loaded: main_helper
INFO - 2025-11-05 11:18:24 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 11:18:24 --> Database Driver Class Initialized
INFO - 2025-11-05 11:18:24 --> Email Class Initialized
DEBUG - 2025-11-05 11:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 11:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 11:18:24 --> Controller Class Initialized
INFO - 2025-11-05 11:18:24 --> Model "User_model" initialized
INFO - 2025-11-05 11:18:24 --> Model "Project_model" initialized
INFO - 2025-11-05 11:18:24 --> Helper loaded: form_helper
INFO - 2025-11-05 11:18:24 --> Form Validation Class Initialized
INFO - 2025-11-05 11:18:24 --> Final output sent to browser
INFO - 2025-11-05 11:18:24 --> Total execution time: 0.0501
INFO - 2025-11-05 11:18:34 --> Config Class Initialized
INFO - 2025-11-05 11:18:34 --> Hooks Class Initialized
INFO - 2025-11-05 11:18:34 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:18:34 --> Utf8 Class Initialized
INFO - 2025-11-05 11:18:34 --> URI Class Initialized
INFO - 2025-11-05 11:18:34 --> Router Class Initialized
INFO - 2025-11-05 11:18:34 --> Output Class Initialized
INFO - 2025-11-05 11:18:34 --> Security Class Initialized
INFO - 2025-11-05 11:18:34 --> Input Class Initialized
INFO - 2025-11-05 11:18:34 --> Language Class Initialized
INFO - 2025-11-05 11:18:34 --> Loader Class Initialized
INFO - 2025-11-05 11:18:34 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 11:18:34 --> Helper loaded: url_helper
INFO - 2025-11-05 11:18:34 --> Helper loaded: file_helper
INFO - 2025-11-05 11:18:34 --> Helper loaded: main_helper
INFO - 2025-11-05 11:18:34 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 11:18:34 --> Database Driver Class Initialized
INFO - 2025-11-05 11:18:34 --> Email Class Initialized
DEBUG - 2025-11-05 11:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 11:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 11:18:34 --> Controller Class Initialized
INFO - 2025-11-05 11:18:34 --> Model "Subscription_model" initialized
INFO - 2025-11-05 11:18:34 --> Model "User_model" initialized
INFO - 2025-11-05 11:18:34 --> Model "Auth_model" initialized
INFO - 2025-11-05 11:18:34 --> Model "Project_model" initialized
INFO - 2025-11-05 11:18:34 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 11:18:34 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 11:18:34 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 11:18:34 --> File loaded: D:\laragon\www\acumena\application\views\projects/profile.php
INFO - 2025-11-05 11:18:34 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 11:18:34 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 11:18:34 --> Final output sent to browser
INFO - 2025-11-05 11:18:34 --> Total execution time: 0.0555
INFO - 2025-11-05 11:18:34 --> Config Class Initialized
INFO - 2025-11-05 11:18:34 --> Hooks Class Initialized
INFO - 2025-11-05 11:18:34 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:18:34 --> Utf8 Class Initialized
INFO - 2025-11-05 11:18:34 --> URI Class Initialized
INFO - 2025-11-05 11:18:34 --> Router Class Initialized
INFO - 2025-11-05 11:18:34 --> Output Class Initialized
INFO - 2025-11-05 11:18:34 --> Security Class Initialized
INFO - 2025-11-05 11:18:34 --> Input Class Initialized
INFO - 2025-11-05 11:18:34 --> Language Class Initialized
INFO - 2025-11-05 11:18:34 --> Loader Class Initialized
INFO - 2025-11-05 11:18:34 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 11:18:34 --> Helper loaded: url_helper
INFO - 2025-11-05 11:18:34 --> Helper loaded: file_helper
INFO - 2025-11-05 11:18:34 --> Helper loaded: main_helper
INFO - 2025-11-05 11:18:34 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 11:18:34 --> Database Driver Class Initialized
INFO - 2025-11-05 11:18:34 --> Email Class Initialized
DEBUG - 2025-11-05 11:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 11:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 11:18:34 --> Controller Class Initialized
INFO - 2025-11-05 11:18:34 --> Model "User_model" initialized
INFO - 2025-11-05 11:18:34 --> Model "Project_model" initialized
INFO - 2025-11-05 11:18:34 --> Helper loaded: form_helper
INFO - 2025-11-05 11:18:34 --> Form Validation Class Initialized
INFO - 2025-11-05 11:18:34 --> Final output sent to browser
INFO - 2025-11-05 11:18:34 --> Total execution time: 0.0587
INFO - 2025-11-05 11:18:37 --> Config Class Initialized
INFO - 2025-11-05 11:18:37 --> Hooks Class Initialized
INFO - 2025-11-05 11:18:37 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:18:37 --> Utf8 Class Initialized
INFO - 2025-11-05 11:18:37 --> URI Class Initialized
INFO - 2025-11-05 11:18:37 --> Router Class Initialized
INFO - 2025-11-05 11:18:37 --> Output Class Initialized
INFO - 2025-11-05 11:18:37 --> Security Class Initialized
INFO - 2025-11-05 11:18:37 --> Input Class Initialized
INFO - 2025-11-05 11:18:37 --> Language Class Initialized
INFO - 2025-11-05 11:18:37 --> Loader Class Initialized
INFO - 2025-11-05 11:18:37 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 11:18:37 --> Helper loaded: url_helper
INFO - 2025-11-05 11:18:37 --> Helper loaded: file_helper
INFO - 2025-11-05 11:18:37 --> Helper loaded: main_helper
INFO - 2025-11-05 11:18:37 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 11:18:37 --> Database Driver Class Initialized
INFO - 2025-11-05 11:18:37 --> Email Class Initialized
DEBUG - 2025-11-05 11:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 11:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 11:18:37 --> Controller Class Initialized
INFO - 2025-11-05 11:18:37 --> Model "User_model" initialized
INFO - 2025-11-05 11:18:37 --> Model "Project_model" initialized
INFO - 2025-11-05 11:18:37 --> Helper loaded: form_helper
INFO - 2025-11-05 11:18:37 --> Form Validation Class Initialized
INFO - 2025-11-05 11:18:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-11-05 11:18:37 --> Final output sent to browser
INFO - 2025-11-05 11:18:37 --> Total execution time: 0.0501
INFO - 2025-11-05 11:18:37 --> Config Class Initialized
INFO - 2025-11-05 11:18:37 --> Hooks Class Initialized
INFO - 2025-11-05 11:18:37 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:18:37 --> Utf8 Class Initialized
INFO - 2025-11-05 11:18:37 --> URI Class Initialized
INFO - 2025-11-05 11:18:37 --> Router Class Initialized
INFO - 2025-11-05 11:18:37 --> Output Class Initialized
INFO - 2025-11-05 11:18:37 --> Security Class Initialized
INFO - 2025-11-05 11:18:37 --> Input Class Initialized
INFO - 2025-11-05 11:18:37 --> Language Class Initialized
INFO - 2025-11-05 11:18:37 --> Loader Class Initialized
INFO - 2025-11-05 11:18:37 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 11:18:37 --> Helper loaded: url_helper
INFO - 2025-11-05 11:18:37 --> Helper loaded: file_helper
INFO - 2025-11-05 11:18:37 --> Helper loaded: main_helper
INFO - 2025-11-05 11:18:37 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 11:18:37 --> Database Driver Class Initialized
INFO - 2025-11-05 11:18:37 --> Email Class Initialized
DEBUG - 2025-11-05 11:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 11:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 11:18:37 --> Controller Class Initialized
INFO - 2025-11-05 11:18:37 --> Model "Subscription_model" initialized
INFO - 2025-11-05 11:18:37 --> Model "User_model" initialized
INFO - 2025-11-05 11:18:37 --> Model "Auth_model" initialized
INFO - 2025-11-05 11:18:37 --> Model "Project_model" initialized
INFO - 2025-11-05 11:18:37 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 11:18:37 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 11:18:37 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 11:18:37 --> File loaded: D:\laragon\www\acumena\application\views\projects/swot.php
INFO - 2025-11-05 11:18:37 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 11:18:37 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 11:18:37 --> Final output sent to browser
INFO - 2025-11-05 11:18:37 --> Total execution time: 0.0375
INFO - 2025-11-05 11:18:37 --> Config Class Initialized
INFO - 2025-11-05 11:18:37 --> Hooks Class Initialized
INFO - 2025-11-05 11:18:37 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:18:37 --> Utf8 Class Initialized
INFO - 2025-11-05 11:18:37 --> URI Class Initialized
INFO - 2025-11-05 11:18:37 --> Router Class Initialized
INFO - 2025-11-05 11:18:37 --> Output Class Initialized
INFO - 2025-11-05 11:18:37 --> Security Class Initialized
INFO - 2025-11-05 11:18:37 --> Input Class Initialized
INFO - 2025-11-05 11:18:37 --> Language Class Initialized
INFO - 2025-11-05 11:18:37 --> Loader Class Initialized
INFO - 2025-11-05 11:18:37 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 11:18:37 --> Helper loaded: url_helper
INFO - 2025-11-05 11:18:37 --> Helper loaded: file_helper
INFO - 2025-11-05 11:18:37 --> Helper loaded: main_helper
INFO - 2025-11-05 11:18:37 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 11:18:37 --> Database Driver Class Initialized
INFO - 2025-11-05 11:18:37 --> Email Class Initialized
DEBUG - 2025-11-05 11:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 11:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 11:18:37 --> Controller Class Initialized
INFO - 2025-11-05 11:18:37 --> Model "User_model" initialized
INFO - 2025-11-05 11:18:37 --> Model "Project_model" initialized
INFO - 2025-11-05 11:18:37 --> Helper loaded: form_helper
INFO - 2025-11-05 11:18:37 --> Form Validation Class Initialized
INFO - 2025-11-05 11:18:37 --> Final output sent to browser
INFO - 2025-11-05 11:18:37 --> Total execution time: 0.0420
INFO - 2025-11-05 11:18:40 --> Config Class Initialized
INFO - 2025-11-05 11:18:40 --> Hooks Class Initialized
INFO - 2025-11-05 11:18:40 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:18:40 --> Utf8 Class Initialized
INFO - 2025-11-05 11:18:40 --> URI Class Initialized
INFO - 2025-11-05 11:18:40 --> Router Class Initialized
INFO - 2025-11-05 11:18:40 --> Output Class Initialized
INFO - 2025-11-05 11:18:40 --> Security Class Initialized
INFO - 2025-11-05 11:18:40 --> Input Class Initialized
INFO - 2025-11-05 11:18:40 --> Language Class Initialized
INFO - 2025-11-05 11:18:40 --> Loader Class Initialized
INFO - 2025-11-05 11:18:40 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 11:18:40 --> Helper loaded: url_helper
INFO - 2025-11-05 11:18:40 --> Helper loaded: file_helper
INFO - 2025-11-05 11:18:40 --> Helper loaded: main_helper
INFO - 2025-11-05 11:18:40 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 11:18:40 --> Database Driver Class Initialized
INFO - 2025-11-05 11:18:40 --> Email Class Initialized
DEBUG - 2025-11-05 11:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 11:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 11:18:40 --> Controller Class Initialized
INFO - 2025-11-05 11:18:40 --> Model "User_model" initialized
INFO - 2025-11-05 11:18:40 --> Model "Project_model" initialized
INFO - 2025-11-05 11:18:40 --> Helper loaded: form_helper
INFO - 2025-11-05 11:18:40 --> Form Validation Class Initialized
INFO - 2025-11-05 11:18:40 --> Final output sent to browser
INFO - 2025-11-05 11:18:40 --> Total execution time: 0.0377
INFO - 2025-11-05 11:18:40 --> Config Class Initialized
INFO - 2025-11-05 11:18:40 --> Hooks Class Initialized
INFO - 2025-11-05 11:18:40 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:18:40 --> Utf8 Class Initialized
INFO - 2025-11-05 11:18:40 --> URI Class Initialized
INFO - 2025-11-05 11:18:40 --> Router Class Initialized
INFO - 2025-11-05 11:18:40 --> Output Class Initialized
INFO - 2025-11-05 11:18:40 --> Security Class Initialized
INFO - 2025-11-05 11:18:40 --> Input Class Initialized
INFO - 2025-11-05 11:18:40 --> Language Class Initialized
INFO - 2025-11-05 11:18:40 --> Loader Class Initialized
INFO - 2025-11-05 11:18:40 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 11:18:40 --> Helper loaded: url_helper
INFO - 2025-11-05 11:18:40 --> Helper loaded: file_helper
INFO - 2025-11-05 11:18:40 --> Helper loaded: main_helper
INFO - 2025-11-05 11:18:40 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 11:18:40 --> Database Driver Class Initialized
INFO - 2025-11-05 11:18:40 --> Email Class Initialized
DEBUG - 2025-11-05 11:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 11:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 11:18:40 --> Controller Class Initialized
INFO - 2025-11-05 11:18:40 --> Model "Subscription_model" initialized
INFO - 2025-11-05 11:18:40 --> Model "User_model" initialized
INFO - 2025-11-05 11:18:40 --> Model "Auth_model" initialized
INFO - 2025-11-05 11:18:40 --> Model "Project_model" initialized
INFO - 2025-11-05 11:18:40 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 11:18:40 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 11:18:40 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 11:18:40 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ife.php
INFO - 2025-11-05 11:18:40 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 11:18:40 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 11:18:40 --> Final output sent to browser
INFO - 2025-11-05 11:18:40 --> Total execution time: 0.0401
INFO - 2025-11-05 11:18:40 --> Config Class Initialized
INFO - 2025-11-05 11:18:40 --> Hooks Class Initialized
INFO - 2025-11-05 11:18:40 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:18:40 --> Utf8 Class Initialized
INFO - 2025-11-05 11:18:40 --> URI Class Initialized
INFO - 2025-11-05 11:18:40 --> Router Class Initialized
INFO - 2025-11-05 11:18:40 --> Output Class Initialized
INFO - 2025-11-05 11:18:40 --> Security Class Initialized
INFO - 2025-11-05 11:18:40 --> Input Class Initialized
INFO - 2025-11-05 11:18:40 --> Language Class Initialized
INFO - 2025-11-05 11:18:40 --> Loader Class Initialized
INFO - 2025-11-05 11:18:40 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 11:18:40 --> Helper loaded: url_helper
INFO - 2025-11-05 11:18:40 --> Helper loaded: file_helper
INFO - 2025-11-05 11:18:40 --> Helper loaded: main_helper
INFO - 2025-11-05 11:18:40 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 11:18:40 --> Database Driver Class Initialized
INFO - 2025-11-05 11:18:40 --> Email Class Initialized
DEBUG - 2025-11-05 11:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 11:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 11:18:40 --> Controller Class Initialized
INFO - 2025-11-05 11:18:40 --> Model "User_model" initialized
INFO - 2025-11-05 11:18:40 --> Model "Project_model" initialized
INFO - 2025-11-05 11:18:40 --> Helper loaded: form_helper
INFO - 2025-11-05 11:18:40 --> Form Validation Class Initialized
INFO - 2025-11-05 11:18:40 --> Final output sent to browser
INFO - 2025-11-05 11:18:40 --> Total execution time: 0.0514
INFO - 2025-11-05 11:18:46 --> Config Class Initialized
INFO - 2025-11-05 11:18:46 --> Hooks Class Initialized
INFO - 2025-11-05 11:18:46 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:18:46 --> Utf8 Class Initialized
INFO - 2025-11-05 11:18:46 --> URI Class Initialized
INFO - 2025-11-05 11:18:46 --> Router Class Initialized
INFO - 2025-11-05 11:18:46 --> Output Class Initialized
INFO - 2025-11-05 11:18:46 --> Security Class Initialized
INFO - 2025-11-05 11:18:46 --> Input Class Initialized
INFO - 2025-11-05 11:18:46 --> Language Class Initialized
INFO - 2025-11-05 11:18:46 --> Loader Class Initialized
INFO - 2025-11-05 11:18:46 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 11:18:46 --> Helper loaded: url_helper
INFO - 2025-11-05 11:18:46 --> Helper loaded: file_helper
INFO - 2025-11-05 11:18:46 --> Helper loaded: main_helper
INFO - 2025-11-05 11:18:46 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 11:18:46 --> Database Driver Class Initialized
INFO - 2025-11-05 11:18:46 --> Email Class Initialized
DEBUG - 2025-11-05 11:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 11:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 11:18:46 --> Controller Class Initialized
INFO - 2025-11-05 11:18:46 --> Model "User_model" initialized
INFO - 2025-11-05 11:18:46 --> Model "Project_model" initialized
INFO - 2025-11-05 11:18:46 --> Helper loaded: form_helper
INFO - 2025-11-05 11:18:46 --> Form Validation Class Initialized
INFO - 2025-11-05 11:18:46 --> Final output sent to browser
INFO - 2025-11-05 11:18:46 --> Total execution time: 0.0423
INFO - 2025-11-05 11:18:46 --> Config Class Initialized
INFO - 2025-11-05 11:18:46 --> Hooks Class Initialized
INFO - 2025-11-05 11:18:46 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:18:46 --> Utf8 Class Initialized
INFO - 2025-11-05 11:18:46 --> URI Class Initialized
INFO - 2025-11-05 11:18:46 --> Router Class Initialized
INFO - 2025-11-05 11:18:46 --> Output Class Initialized
INFO - 2025-11-05 11:18:46 --> Security Class Initialized
INFO - 2025-11-05 11:18:46 --> Input Class Initialized
INFO - 2025-11-05 11:18:46 --> Language Class Initialized
INFO - 2025-11-05 11:18:46 --> Loader Class Initialized
INFO - 2025-11-05 11:18:46 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 11:18:46 --> Helper loaded: url_helper
INFO - 2025-11-05 11:18:46 --> Helper loaded: file_helper
INFO - 2025-11-05 11:18:46 --> Helper loaded: main_helper
INFO - 2025-11-05 11:18:46 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 11:18:46 --> Database Driver Class Initialized
INFO - 2025-11-05 11:18:46 --> Email Class Initialized
DEBUG - 2025-11-05 11:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 11:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 11:18:46 --> Controller Class Initialized
INFO - 2025-11-05 11:18:46 --> Model "Subscription_model" initialized
INFO - 2025-11-05 11:18:46 --> Model "User_model" initialized
INFO - 2025-11-05 11:18:46 --> Model "Auth_model" initialized
INFO - 2025-11-05 11:18:46 --> Model "Project_model" initialized
INFO - 2025-11-05 11:18:46 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 11:18:46 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 11:18:46 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 11:18:46 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-efe.php
INFO - 2025-11-05 11:18:46 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 11:18:46 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 11:18:46 --> Final output sent to browser
INFO - 2025-11-05 11:18:46 --> Total execution time: 0.0421
INFO - 2025-11-05 11:18:46 --> Config Class Initialized
INFO - 2025-11-05 11:18:46 --> Hooks Class Initialized
INFO - 2025-11-05 11:18:46 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:18:46 --> Utf8 Class Initialized
INFO - 2025-11-05 11:18:46 --> URI Class Initialized
INFO - 2025-11-05 11:18:46 --> Router Class Initialized
INFO - 2025-11-05 11:18:46 --> Output Class Initialized
INFO - 2025-11-05 11:18:46 --> Security Class Initialized
INFO - 2025-11-05 11:18:46 --> Input Class Initialized
INFO - 2025-11-05 11:18:46 --> Language Class Initialized
INFO - 2025-11-05 11:18:46 --> Loader Class Initialized
INFO - 2025-11-05 11:18:46 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 11:18:46 --> Helper loaded: url_helper
INFO - 2025-11-05 11:18:46 --> Helper loaded: file_helper
INFO - 2025-11-05 11:18:46 --> Helper loaded: main_helper
INFO - 2025-11-05 11:18:46 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 11:18:46 --> Database Driver Class Initialized
INFO - 2025-11-05 11:18:46 --> Email Class Initialized
DEBUG - 2025-11-05 11:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 11:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 11:18:46 --> Controller Class Initialized
INFO - 2025-11-05 11:18:46 --> Model "User_model" initialized
INFO - 2025-11-05 11:18:46 --> Model "Project_model" initialized
INFO - 2025-11-05 11:18:46 --> Helper loaded: form_helper
INFO - 2025-11-05 11:18:46 --> Form Validation Class Initialized
INFO - 2025-11-05 11:18:46 --> Final output sent to browser
INFO - 2025-11-05 11:18:46 --> Total execution time: 0.0411
INFO - 2025-11-05 11:18:52 --> Config Class Initialized
INFO - 2025-11-05 11:18:52 --> Hooks Class Initialized
INFO - 2025-11-05 11:18:53 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:18:53 --> Utf8 Class Initialized
INFO - 2025-11-05 11:18:53 --> URI Class Initialized
INFO - 2025-11-05 11:18:53 --> Router Class Initialized
INFO - 2025-11-05 11:18:53 --> Output Class Initialized
INFO - 2025-11-05 11:18:53 --> Security Class Initialized
INFO - 2025-11-05 11:18:53 --> Input Class Initialized
INFO - 2025-11-05 11:18:53 --> Language Class Initialized
INFO - 2025-11-05 11:18:53 --> Loader Class Initialized
INFO - 2025-11-05 11:18:53 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 11:18:53 --> Helper loaded: url_helper
INFO - 2025-11-05 11:18:53 --> Helper loaded: file_helper
INFO - 2025-11-05 11:18:53 --> Helper loaded: main_helper
INFO - 2025-11-05 11:18:53 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 11:18:53 --> Database Driver Class Initialized
INFO - 2025-11-05 11:18:53 --> Email Class Initialized
DEBUG - 2025-11-05 11:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 11:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 11:18:53 --> Controller Class Initialized
INFO - 2025-11-05 11:18:53 --> Model "User_model" initialized
INFO - 2025-11-05 11:18:53 --> Model "Project_model" initialized
INFO - 2025-11-05 11:18:53 --> Helper loaded: form_helper
INFO - 2025-11-05 11:18:53 --> Form Validation Class Initialized
INFO - 2025-11-05 11:18:53 --> Final output sent to browser
INFO - 2025-11-05 11:18:53 --> Total execution time: 0.0964
INFO - 2025-11-05 11:18:53 --> Config Class Initialized
INFO - 2025-11-05 11:18:53 --> Hooks Class Initialized
INFO - 2025-11-05 11:18:53 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:18:53 --> Utf8 Class Initialized
INFO - 2025-11-05 11:18:53 --> URI Class Initialized
INFO - 2025-11-05 11:18:53 --> Router Class Initialized
INFO - 2025-11-05 11:18:53 --> Output Class Initialized
INFO - 2025-11-05 11:18:53 --> Security Class Initialized
INFO - 2025-11-05 11:18:53 --> Input Class Initialized
INFO - 2025-11-05 11:18:53 --> Language Class Initialized
INFO - 2025-11-05 11:18:53 --> Loader Class Initialized
INFO - 2025-11-05 11:18:53 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 11:18:53 --> Helper loaded: url_helper
INFO - 2025-11-05 11:18:53 --> Helper loaded: file_helper
INFO - 2025-11-05 11:18:53 --> Helper loaded: main_helper
INFO - 2025-11-05 11:18:53 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 11:18:53 --> Database Driver Class Initialized
INFO - 2025-11-05 11:18:53 --> Email Class Initialized
DEBUG - 2025-11-05 11:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 11:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 11:18:53 --> Controller Class Initialized
INFO - 2025-11-05 11:18:53 --> Model "Subscription_model" initialized
INFO - 2025-11-05 11:18:53 --> Model "User_model" initialized
INFO - 2025-11-05 11:18:53 --> Model "Auth_model" initialized
INFO - 2025-11-05 11:18:53 --> Model "Project_model" initialized
INFO - 2025-11-05 11:18:53 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 11:18:53 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 11:18:53 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 11:18:53 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ie.php
INFO - 2025-11-05 11:18:53 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 11:18:53 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 11:18:53 --> Final output sent to browser
INFO - 2025-11-05 11:18:53 --> Total execution time: 0.1198
INFO - 2025-11-05 11:18:53 --> Config Class Initialized
INFO - 2025-11-05 11:18:53 --> Hooks Class Initialized
INFO - 2025-11-05 11:18:53 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:18:53 --> Utf8 Class Initialized
INFO - 2025-11-05 11:18:53 --> URI Class Initialized
INFO - 2025-11-05 11:18:53 --> Router Class Initialized
INFO - 2025-11-05 11:18:53 --> Output Class Initialized
INFO - 2025-11-05 11:18:53 --> Security Class Initialized
INFO - 2025-11-05 11:18:53 --> Input Class Initialized
INFO - 2025-11-05 11:18:53 --> Language Class Initialized
INFO - 2025-11-05 11:18:53 --> Loader Class Initialized
INFO - 2025-11-05 11:18:53 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 11:18:53 --> Helper loaded: url_helper
INFO - 2025-11-05 11:18:53 --> Helper loaded: file_helper
INFO - 2025-11-05 11:18:53 --> Helper loaded: main_helper
INFO - 2025-11-05 11:18:53 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 11:18:53 --> Database Driver Class Initialized
INFO - 2025-11-05 11:18:53 --> Email Class Initialized
DEBUG - 2025-11-05 11:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 11:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 11:18:53 --> Controller Class Initialized
INFO - 2025-11-05 11:18:53 --> Model "User_model" initialized
INFO - 2025-11-05 11:18:53 --> Model "Project_model" initialized
INFO - 2025-11-05 11:18:53 --> Helper loaded: form_helper
INFO - 2025-11-05 11:18:53 --> Form Validation Class Initialized
INFO - 2025-11-05 11:18:53 --> Final output sent to browser
INFO - 2025-11-05 11:18:53 --> Total execution time: 0.1050
INFO - 2025-11-05 11:18:54 --> Config Class Initialized
INFO - 2025-11-05 11:18:54 --> Hooks Class Initialized
INFO - 2025-11-05 11:18:54 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:18:54 --> Utf8 Class Initialized
INFO - 2025-11-05 11:18:54 --> URI Class Initialized
INFO - 2025-11-05 11:18:54 --> Router Class Initialized
INFO - 2025-11-05 11:18:54 --> Output Class Initialized
INFO - 2025-11-05 11:18:54 --> Security Class Initialized
INFO - 2025-11-05 11:18:54 --> Input Class Initialized
INFO - 2025-11-05 11:18:54 --> Language Class Initialized
INFO - 2025-11-05 11:18:54 --> Loader Class Initialized
INFO - 2025-11-05 11:18:54 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 11:18:54 --> Helper loaded: url_helper
INFO - 2025-11-05 11:18:54 --> Helper loaded: file_helper
INFO - 2025-11-05 11:18:54 --> Helper loaded: main_helper
INFO - 2025-11-05 11:18:54 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 11:18:54 --> Database Driver Class Initialized
INFO - 2025-11-05 11:18:54 --> Email Class Initialized
DEBUG - 2025-11-05 11:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 11:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 11:18:54 --> Controller Class Initialized
INFO - 2025-11-05 11:18:54 --> Model "User_model" initialized
INFO - 2025-11-05 11:18:54 --> Model "Project_model" initialized
INFO - 2025-11-05 11:18:54 --> Helper loaded: form_helper
INFO - 2025-11-05 11:18:54 --> Form Validation Class Initialized
INFO - 2025-11-05 11:18:54 --> Final output sent to browser
INFO - 2025-11-05 11:18:54 --> Total execution time: 0.1229
INFO - 2025-11-05 11:18:54 --> Config Class Initialized
INFO - 2025-11-05 11:18:54 --> Hooks Class Initialized
INFO - 2025-11-05 11:18:54 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:18:54 --> Utf8 Class Initialized
INFO - 2025-11-05 11:18:54 --> URI Class Initialized
INFO - 2025-11-05 11:18:54 --> Router Class Initialized
INFO - 2025-11-05 11:18:54 --> Output Class Initialized
INFO - 2025-11-05 11:18:54 --> Security Class Initialized
INFO - 2025-11-05 11:18:54 --> Input Class Initialized
INFO - 2025-11-05 11:18:54 --> Language Class Initialized
INFO - 2025-11-05 11:18:54 --> Loader Class Initialized
INFO - 2025-11-05 11:18:54 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 11:18:54 --> Helper loaded: url_helper
INFO - 2025-11-05 11:18:54 --> Helper loaded: file_helper
INFO - 2025-11-05 11:18:54 --> Helper loaded: main_helper
INFO - 2025-11-05 11:18:54 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 11:18:54 --> Database Driver Class Initialized
INFO - 2025-11-05 11:18:54 --> Email Class Initialized
DEBUG - 2025-11-05 11:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 11:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 11:18:54 --> Controller Class Initialized
INFO - 2025-11-05 11:18:54 --> Model "User_model" initialized
INFO - 2025-11-05 11:18:54 --> Model "Project_model" initialized
INFO - 2025-11-05 11:18:54 --> Helper loaded: form_helper
INFO - 2025-11-05 11:18:54 --> Form Validation Class Initialized
INFO - 2025-11-05 11:18:54 --> Final output sent to browser
INFO - 2025-11-05 11:18:54 --> Total execution time: 0.1073
INFO - 2025-11-05 11:18:54 --> Config Class Initialized
INFO - 2025-11-05 11:18:54 --> Hooks Class Initialized
INFO - 2025-11-05 11:18:54 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:18:54 --> Utf8 Class Initialized
INFO - 2025-11-05 11:18:54 --> URI Class Initialized
INFO - 2025-11-05 11:18:54 --> Router Class Initialized
INFO - 2025-11-05 11:18:54 --> Output Class Initialized
INFO - 2025-11-05 11:18:54 --> Security Class Initialized
INFO - 2025-11-05 11:18:54 --> Input Class Initialized
INFO - 2025-11-05 11:18:54 --> Language Class Initialized
INFO - 2025-11-05 11:18:54 --> Loader Class Initialized
INFO - 2025-11-05 11:18:54 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 11:18:54 --> Helper loaded: url_helper
INFO - 2025-11-05 11:18:54 --> Helper loaded: file_helper
INFO - 2025-11-05 11:18:54 --> Helper loaded: main_helper
INFO - 2025-11-05 11:18:54 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 11:18:54 --> Database Driver Class Initialized
INFO - 2025-11-05 11:18:54 --> Email Class Initialized
DEBUG - 2025-11-05 11:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 11:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 11:18:54 --> Controller Class Initialized
INFO - 2025-11-05 11:18:54 --> Model "User_model" initialized
INFO - 2025-11-05 11:18:54 --> Model "Project_model" initialized
INFO - 2025-11-05 11:18:54 --> Helper loaded: form_helper
INFO - 2025-11-05 11:18:54 --> Form Validation Class Initialized
INFO - 2025-11-05 11:18:54 --> Final output sent to browser
INFO - 2025-11-05 11:18:54 --> Total execution time: 0.1229
INFO - 2025-11-05 11:20:16 --> Config Class Initialized
INFO - 2025-11-05 11:20:16 --> Hooks Class Initialized
INFO - 2025-11-05 11:20:16 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:20:16 --> Utf8 Class Initialized
INFO - 2025-11-05 11:20:16 --> URI Class Initialized
INFO - 2025-11-05 11:20:16 --> Router Class Initialized
INFO - 2025-11-05 11:20:16 --> Output Class Initialized
INFO - 2025-11-05 11:20:16 --> Security Class Initialized
INFO - 2025-11-05 11:20:16 --> Input Class Initialized
INFO - 2025-11-05 11:20:16 --> Language Class Initialized
INFO - 2025-11-05 11:20:16 --> Loader Class Initialized
INFO - 2025-11-05 11:20:16 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 11:20:16 --> Helper loaded: url_helper
INFO - 2025-11-05 11:20:16 --> Helper loaded: file_helper
INFO - 2025-11-05 11:20:16 --> Helper loaded: main_helper
INFO - 2025-11-05 11:20:16 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 11:20:16 --> Database Driver Class Initialized
INFO - 2025-11-05 11:20:16 --> Email Class Initialized
DEBUG - 2025-11-05 11:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 11:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 11:20:16 --> Controller Class Initialized
INFO - 2025-11-05 11:20:16 --> Model "Subscription_model" initialized
INFO - 2025-11-05 11:20:16 --> Model "User_model" initialized
INFO - 2025-11-05 11:20:16 --> Model "Auth_model" initialized
INFO - 2025-11-05 11:20:16 --> Model "Project_model" initialized
INFO - 2025-11-05 11:20:16 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-05 11:20:16 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-05 11:20:16 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-05 11:20:16 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ai.php
INFO - 2025-11-05 11:20:16 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-05 11:20:16 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-05 11:20:16 --> Final output sent to browser
INFO - 2025-11-05 11:20:16 --> Total execution time: 0.1195
INFO - 2025-11-05 11:33:07 --> Config Class Initialized
INFO - 2025-11-05 11:33:07 --> Hooks Class Initialized
INFO - 2025-11-05 11:33:07 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:33:07 --> Utf8 Class Initialized
INFO - 2025-11-05 11:33:07 --> URI Class Initialized
INFO - 2025-11-05 11:33:07 --> Router Class Initialized
INFO - 2025-11-05 11:33:07 --> Output Class Initialized
INFO - 2025-11-05 11:33:07 --> Security Class Initialized
INFO - 2025-11-05 11:33:07 --> Input Class Initialized
INFO - 2025-11-05 11:33:07 --> Language Class Initialized
INFO - 2025-11-05 11:33:07 --> Loader Class Initialized
INFO - 2025-11-05 11:33:07 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-05 11:33:07 --> Helper loaded: url_helper
INFO - 2025-11-05 11:33:07 --> Helper loaded: file_helper
INFO - 2025-11-05 11:33:07 --> Helper loaded: main_helper
INFO - 2025-11-05 11:33:07 --> Helper loaded: sendgrid_helper
INFO - 2025-11-05 11:33:07 --> Database Driver Class Initialized
INFO - 2025-11-05 11:33:07 --> Email Class Initialized
DEBUG - 2025-11-05 11:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-05 11:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-05 11:33:07 --> Controller Class Initialized
INFO - 2025-11-05 11:33:07 --> Model "User_model" initialized
INFO - 2025-11-05 11:33:07 --> Model "Project_model" initialized
INFO - 2025-11-05 11:33:07 --> Helper loaded: form_helper
INFO - 2025-11-05 11:33:07 --> Form Validation Class Initialized
ERROR - 2025-11-05 11:33:15 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 276,
    "totalTokenCount": 1475,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 276
      }
    ],
    "thoughtsTokenCount": 1199
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "9jULaaqnD5y6qfkPhrbX2QY"
}

INFO - 2025-11-05 11:33:15 --> Final output sent to browser
INFO - 2025-11-05 11:33:15 --> Total execution time: 7.4641
INFO - 2025-11-05 11:33:15 --> Config Class Initialized
INFO - 2025-11-05 11:33:15 --> Hooks Class Initialized
INFO - 2025-11-05 11:33:15 --> UTF-8 Support Enabled
INFO - 2025-11-05 11:33:15 --> Utf8 Class Initialized
INFO - 2025-11-05 11:33:15 --> URI Class Initialized
INFO - 2025-11-05 11:33:15 --> Router Class Initialized
INFO - 2025-11-05 11:33:15 --> Output Class Initialized
INFO - 2025-11-05 11:33:15 --> Security Class Initialized
INFO - 2025-11-05 11:33:15 --> Input Class Initialized
INFO - 2025-11-05 11:33:15 --> Language Class Initialized
ERROR - 2025-11-05 11:33:15 --> 404 Page Not Found: Faviconico/index
