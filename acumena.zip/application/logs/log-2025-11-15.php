<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-11-15 12:38:09 --> Config Class Initialized
INFO - 2025-11-15 12:38:09 --> Hooks Class Initialized
INFO - 2025-11-15 12:38:10 --> UTF-8 Support Enabled
INFO - 2025-11-15 12:38:10 --> Utf8 Class Initialized
INFO - 2025-11-15 12:38:10 --> URI Class Initialized
DEBUG - 2025-11-15 12:38:10 --> No URI present. Default controller set.
INFO - 2025-11-15 12:38:10 --> Router Class Initialized
INFO - 2025-11-15 12:38:10 --> Output Class Initialized
INFO - 2025-11-15 12:38:10 --> Security Class Initialized
INFO - 2025-11-15 12:38:10 --> Input Class Initialized
INFO - 2025-11-15 12:38:10 --> Language Class Initialized
INFO - 2025-11-15 12:38:10 --> Loader Class Initialized
INFO - 2025-11-15 12:38:10 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-15 12:38:10 --> Helper loaded: url_helper
INFO - 2025-11-15 12:38:10 --> Helper loaded: file_helper
INFO - 2025-11-15 12:38:10 --> Helper loaded: main_helper
INFO - 2025-11-15 12:38:10 --> Helper loaded: sendgrid_helper
INFO - 2025-11-15 12:38:11 --> Database Driver Class Initialized
INFO - 2025-11-15 12:38:11 --> Email Class Initialized
DEBUG - 2025-11-15 12:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 12:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 12:38:11 --> Controller Class Initialized
INFO - 2025-11-15 12:38:11 --> Config Class Initialized
INFO - 2025-11-15 12:38:11 --> Hooks Class Initialized
INFO - 2025-11-15 12:38:11 --> UTF-8 Support Enabled
INFO - 2025-11-15 12:38:11 --> Utf8 Class Initialized
INFO - 2025-11-15 12:38:11 --> URI Class Initialized
INFO - 2025-11-15 12:38:11 --> Router Class Initialized
INFO - 2025-11-15 12:38:11 --> Output Class Initialized
INFO - 2025-11-15 12:38:11 --> Security Class Initialized
INFO - 2025-11-15 12:38:11 --> Input Class Initialized
INFO - 2025-11-15 12:38:11 --> Language Class Initialized
INFO - 2025-11-15 12:38:11 --> Loader Class Initialized
INFO - 2025-11-15 12:38:11 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-15 12:38:11 --> Helper loaded: url_helper
INFO - 2025-11-15 12:38:11 --> Helper loaded: file_helper
INFO - 2025-11-15 12:38:11 --> Helper loaded: main_helper
INFO - 2025-11-15 12:38:11 --> Helper loaded: sendgrid_helper
INFO - 2025-11-15 12:38:11 --> Database Driver Class Initialized
INFO - 2025-11-15 12:38:11 --> Email Class Initialized
DEBUG - 2025-11-15 12:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 12:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 12:38:11 --> Controller Class Initialized
INFO - 2025-11-15 12:38:12 --> Model "Subscription_model" initialized
INFO - 2025-11-15 12:38:12 --> Model "User_model" initialized
INFO - 2025-11-15 12:38:12 --> Model "Auth_model" initialized
INFO - 2025-11-15 12:38:12 --> Config Class Initialized
INFO - 2025-11-15 12:38:12 --> Hooks Class Initialized
INFO - 2025-11-15 12:38:12 --> UTF-8 Support Enabled
INFO - 2025-11-15 12:38:12 --> Utf8 Class Initialized
INFO - 2025-11-15 12:38:12 --> URI Class Initialized
INFO - 2025-11-15 12:38:12 --> Router Class Initialized
INFO - 2025-11-15 12:38:12 --> Output Class Initialized
INFO - 2025-11-15 12:38:12 --> Security Class Initialized
INFO - 2025-11-15 12:38:12 --> Input Class Initialized
INFO - 2025-11-15 12:38:12 --> Language Class Initialized
INFO - 2025-11-15 12:38:12 --> Loader Class Initialized
INFO - 2025-11-15 12:38:12 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-15 12:38:12 --> Helper loaded: url_helper
INFO - 2025-11-15 12:38:12 --> Helper loaded: file_helper
INFO - 2025-11-15 12:38:12 --> Helper loaded: main_helper
INFO - 2025-11-15 12:38:12 --> Helper loaded: sendgrid_helper
INFO - 2025-11-15 12:38:12 --> Database Driver Class Initialized
INFO - 2025-11-15 12:38:12 --> Email Class Initialized
DEBUG - 2025-11-15 12:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 12:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 12:38:12 --> Controller Class Initialized
INFO - 2025-11-15 12:38:12 --> Config Class Initialized
INFO - 2025-11-15 12:38:12 --> Hooks Class Initialized
INFO - 2025-11-15 12:38:12 --> UTF-8 Support Enabled
INFO - 2025-11-15 12:38:12 --> Utf8 Class Initialized
INFO - 2025-11-15 12:38:12 --> URI Class Initialized
INFO - 2025-11-15 12:38:12 --> Router Class Initialized
INFO - 2025-11-15 12:38:12 --> Output Class Initialized
INFO - 2025-11-15 12:38:12 --> Security Class Initialized
INFO - 2025-11-15 12:38:12 --> Input Class Initialized
INFO - 2025-11-15 12:38:12 --> Language Class Initialized
INFO - 2025-11-15 12:38:12 --> Loader Class Initialized
INFO - 2025-11-15 12:38:12 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-15 12:38:12 --> Helper loaded: url_helper
INFO - 2025-11-15 12:38:12 --> Helper loaded: file_helper
INFO - 2025-11-15 12:38:12 --> Helper loaded: main_helper
INFO - 2025-11-15 12:38:12 --> Helper loaded: sendgrid_helper
INFO - 2025-11-15 12:38:12 --> Database Driver Class Initialized
INFO - 2025-11-15 12:38:12 --> Email Class Initialized
DEBUG - 2025-11-15 12:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 12:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 12:38:12 --> Controller Class Initialized
INFO - 2025-11-15 12:38:12 --> Model "Subscription_model" initialized
INFO - 2025-11-15 12:38:12 --> Model "User_model" initialized
INFO - 2025-11-15 12:38:12 --> Model "Auth_model" initialized
INFO - 2025-11-15 12:38:12 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-15 12:38:12 --> Final output sent to browser
INFO - 2025-11-15 12:38:12 --> Total execution time: 0.1310
INFO - 2025-11-15 12:58:20 --> Config Class Initialized
INFO - 2025-11-15 12:58:20 --> Hooks Class Initialized
INFO - 2025-11-15 12:58:20 --> UTF-8 Support Enabled
INFO - 2025-11-15 12:58:20 --> Utf8 Class Initialized
INFO - 2025-11-15 12:58:20 --> URI Class Initialized
INFO - 2025-11-15 12:58:20 --> Router Class Initialized
INFO - 2025-11-15 12:58:20 --> Output Class Initialized
INFO - 2025-11-15 12:58:20 --> Security Class Initialized
INFO - 2025-11-15 12:58:20 --> Input Class Initialized
INFO - 2025-11-15 12:58:20 --> Language Class Initialized
ERROR - 2025-11-15 12:58:20 --> 404 Page Not Found: Public/avatar
INFO - 2025-11-15 12:58:24 --> Config Class Initialized
INFO - 2025-11-15 12:58:24 --> Hooks Class Initialized
INFO - 2025-11-15 12:58:24 --> UTF-8 Support Enabled
INFO - 2025-11-15 12:58:24 --> Utf8 Class Initialized
INFO - 2025-11-15 12:58:24 --> URI Class Initialized
INFO - 2025-11-15 12:58:24 --> Router Class Initialized
INFO - 2025-11-15 12:58:24 --> Output Class Initialized
INFO - 2025-11-15 12:58:24 --> Security Class Initialized
INFO - 2025-11-15 12:58:24 --> Input Class Initialized
INFO - 2025-11-15 12:58:24 --> Language Class Initialized
ERROR - 2025-11-15 12:58:24 --> 404 Page Not Found: Public/avatar
INFO - 2025-11-15 12:58:24 --> Config Class Initialized
INFO - 2025-11-15 12:58:24 --> Hooks Class Initialized
INFO - 2025-11-15 12:58:24 --> UTF-8 Support Enabled
INFO - 2025-11-15 12:58:24 --> Utf8 Class Initialized
INFO - 2025-11-15 12:58:24 --> URI Class Initialized
INFO - 2025-11-15 12:58:24 --> Router Class Initialized
INFO - 2025-11-15 12:58:24 --> Output Class Initialized
INFO - 2025-11-15 12:58:24 --> Security Class Initialized
INFO - 2025-11-15 12:58:24 --> Input Class Initialized
INFO - 2025-11-15 12:58:24 --> Language Class Initialized
ERROR - 2025-11-15 12:58:24 --> 404 Page Not Found: Faviconico/index
INFO - 2025-11-15 12:58:46 --> Config Class Initialized
INFO - 2025-11-15 12:58:46 --> Hooks Class Initialized
INFO - 2025-11-15 12:58:46 --> UTF-8 Support Enabled
INFO - 2025-11-15 12:58:46 --> Utf8 Class Initialized
INFO - 2025-11-15 12:58:46 --> URI Class Initialized
INFO - 2025-11-15 12:58:46 --> Router Class Initialized
INFO - 2025-11-15 12:58:46 --> Output Class Initialized
INFO - 2025-11-15 12:58:46 --> Security Class Initialized
INFO - 2025-11-15 12:58:46 --> Input Class Initialized
INFO - 2025-11-15 12:58:46 --> Language Class Initialized
ERROR - 2025-11-15 12:58:46 --> 404 Page Not Found: Public/avatar
INFO - 2025-11-15 22:24:13 --> Config Class Initialized
INFO - 2025-11-15 22:24:13 --> Hooks Class Initialized
INFO - 2025-11-15 22:24:13 --> UTF-8 Support Enabled
INFO - 2025-11-15 22:24:13 --> Utf8 Class Initialized
INFO - 2025-11-15 22:24:13 --> URI Class Initialized
DEBUG - 2025-11-15 22:24:13 --> No URI present. Default controller set.
INFO - 2025-11-15 22:24:13 --> Router Class Initialized
INFO - 2025-11-15 22:24:13 --> Output Class Initialized
INFO - 2025-11-15 22:24:13 --> Security Class Initialized
INFO - 2025-11-15 22:24:13 --> Input Class Initialized
INFO - 2025-11-15 22:24:13 --> Language Class Initialized
INFO - 2025-11-15 22:24:14 --> Loader Class Initialized
INFO - 2025-11-15 22:24:14 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-15 22:24:14 --> Helper loaded: url_helper
INFO - 2025-11-15 22:24:14 --> Helper loaded: file_helper
INFO - 2025-11-15 22:24:14 --> Helper loaded: main_helper
INFO - 2025-11-15 22:24:14 --> Helper loaded: sendgrid_helper
INFO - 2025-11-15 22:24:14 --> Database Driver Class Initialized
INFO - 2025-11-15 22:24:14 --> Email Class Initialized
DEBUG - 2025-11-15 22:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 22:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 22:24:14 --> Controller Class Initialized
INFO - 2025-11-15 22:24:14 --> Config Class Initialized
INFO - 2025-11-15 22:24:14 --> Hooks Class Initialized
INFO - 2025-11-15 22:24:14 --> UTF-8 Support Enabled
INFO - 2025-11-15 22:24:14 --> Utf8 Class Initialized
INFO - 2025-11-15 22:24:14 --> URI Class Initialized
INFO - 2025-11-15 22:24:14 --> Router Class Initialized
INFO - 2025-11-15 22:24:14 --> Output Class Initialized
INFO - 2025-11-15 22:24:14 --> Security Class Initialized
INFO - 2025-11-15 22:24:14 --> Input Class Initialized
INFO - 2025-11-15 22:24:14 --> Language Class Initialized
INFO - 2025-11-15 22:24:14 --> Loader Class Initialized
INFO - 2025-11-15 22:24:14 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-15 22:24:14 --> Helper loaded: url_helper
INFO - 2025-11-15 22:24:14 --> Helper loaded: file_helper
INFO - 2025-11-15 22:24:14 --> Helper loaded: main_helper
INFO - 2025-11-15 22:24:14 --> Helper loaded: sendgrid_helper
INFO - 2025-11-15 22:24:14 --> Database Driver Class Initialized
INFO - 2025-11-15 22:24:14 --> Email Class Initialized
DEBUG - 2025-11-15 22:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 22:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 22:24:14 --> Controller Class Initialized
INFO - 2025-11-15 22:24:15 --> Model "Subscription_model" initialized
INFO - 2025-11-15 22:24:15 --> Model "User_model" initialized
INFO - 2025-11-15 22:24:15 --> Model "Auth_model" initialized
INFO - 2025-11-15 22:24:15 --> Config Class Initialized
INFO - 2025-11-15 22:24:15 --> Hooks Class Initialized
INFO - 2025-11-15 22:24:15 --> UTF-8 Support Enabled
INFO - 2025-11-15 22:24:15 --> Utf8 Class Initialized
INFO - 2025-11-15 22:24:15 --> URI Class Initialized
INFO - 2025-11-15 22:24:15 --> Router Class Initialized
INFO - 2025-11-15 22:24:15 --> Output Class Initialized
INFO - 2025-11-15 22:24:15 --> Security Class Initialized
INFO - 2025-11-15 22:24:15 --> Input Class Initialized
INFO - 2025-11-15 22:24:15 --> Language Class Initialized
INFO - 2025-11-15 22:24:15 --> Loader Class Initialized
INFO - 2025-11-15 22:24:15 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-15 22:24:15 --> Helper loaded: url_helper
INFO - 2025-11-15 22:24:15 --> Helper loaded: file_helper
INFO - 2025-11-15 22:24:15 --> Helper loaded: main_helper
INFO - 2025-11-15 22:24:15 --> Helper loaded: sendgrid_helper
INFO - 2025-11-15 22:24:15 --> Database Driver Class Initialized
INFO - 2025-11-15 22:24:15 --> Email Class Initialized
DEBUG - 2025-11-15 22:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 22:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 22:24:15 --> Controller Class Initialized
INFO - 2025-11-15 22:24:15 --> Config Class Initialized
INFO - 2025-11-15 22:24:15 --> Hooks Class Initialized
INFO - 2025-11-15 22:24:15 --> UTF-8 Support Enabled
INFO - 2025-11-15 22:24:15 --> Utf8 Class Initialized
INFO - 2025-11-15 22:24:15 --> URI Class Initialized
INFO - 2025-11-15 22:24:15 --> Router Class Initialized
INFO - 2025-11-15 22:24:15 --> Output Class Initialized
INFO - 2025-11-15 22:24:15 --> Security Class Initialized
INFO - 2025-11-15 22:24:15 --> Input Class Initialized
INFO - 2025-11-15 22:24:15 --> Language Class Initialized
INFO - 2025-11-15 22:24:15 --> Loader Class Initialized
INFO - 2025-11-15 22:24:15 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-15 22:24:15 --> Helper loaded: url_helper
INFO - 2025-11-15 22:24:15 --> Helper loaded: file_helper
INFO - 2025-11-15 22:24:15 --> Helper loaded: main_helper
INFO - 2025-11-15 22:24:15 --> Helper loaded: sendgrid_helper
INFO - 2025-11-15 22:24:15 --> Database Driver Class Initialized
INFO - 2025-11-15 22:24:15 --> Email Class Initialized
DEBUG - 2025-11-15 22:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 22:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 22:24:15 --> Controller Class Initialized
INFO - 2025-11-15 22:24:15 --> Model "Subscription_model" initialized
INFO - 2025-11-15 22:24:15 --> Model "User_model" initialized
INFO - 2025-11-15 22:24:15 --> Model "Auth_model" initialized
INFO - 2025-11-15 22:24:15 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-15 22:24:15 --> Final output sent to browser
INFO - 2025-11-15 22:24:15 --> Total execution time: 0.1750
INFO - 2025-11-15 22:24:23 --> Config Class Initialized
INFO - 2025-11-15 22:24:23 --> Hooks Class Initialized
INFO - 2025-11-15 22:24:23 --> UTF-8 Support Enabled
INFO - 2025-11-15 22:24:23 --> Utf8 Class Initialized
INFO - 2025-11-15 22:24:23 --> URI Class Initialized
INFO - 2025-11-15 22:24:23 --> Router Class Initialized
INFO - 2025-11-15 22:24:23 --> Output Class Initialized
INFO - 2025-11-15 22:24:23 --> Security Class Initialized
INFO - 2025-11-15 22:24:23 --> Input Class Initialized
INFO - 2025-11-15 22:24:23 --> Language Class Initialized
INFO - 2025-11-15 22:24:24 --> Loader Class Initialized
INFO - 2025-11-15 22:24:24 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-15 22:24:24 --> Helper loaded: url_helper
INFO - 2025-11-15 22:24:24 --> Helper loaded: file_helper
INFO - 2025-11-15 22:24:24 --> Helper loaded: main_helper
INFO - 2025-11-15 22:24:24 --> Helper loaded: sendgrid_helper
INFO - 2025-11-15 22:24:24 --> Database Driver Class Initialized
INFO - 2025-11-15 22:24:24 --> Email Class Initialized
DEBUG - 2025-11-15 22:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 22:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 22:24:24 --> Controller Class Initialized
INFO - 2025-11-15 22:24:24 --> Model "Subscription_model" initialized
INFO - 2025-11-15 22:24:24 --> Model "User_model" initialized
INFO - 2025-11-15 22:24:24 --> Model "Auth_model" initialized
INFO - 2025-11-15 22:24:24 --> Final output sent to browser
INFO - 2025-11-15 22:24:24 --> Total execution time: 0.3283
INFO - 2025-11-15 22:24:25 --> Config Class Initialized
INFO - 2025-11-15 22:24:25 --> Hooks Class Initialized
INFO - 2025-11-15 22:24:25 --> UTF-8 Support Enabled
INFO - 2025-11-15 22:24:25 --> Utf8 Class Initialized
INFO - 2025-11-15 22:24:25 --> URI Class Initialized
INFO - 2025-11-15 22:24:25 --> Router Class Initialized
INFO - 2025-11-15 22:24:25 --> Output Class Initialized
INFO - 2025-11-15 22:24:25 --> Security Class Initialized
INFO - 2025-11-15 22:24:25 --> Input Class Initialized
INFO - 2025-11-15 22:24:25 --> Language Class Initialized
INFO - 2025-11-15 22:24:25 --> Loader Class Initialized
INFO - 2025-11-15 22:24:25 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-15 22:24:25 --> Helper loaded: url_helper
INFO - 2025-11-15 22:24:25 --> Helper loaded: file_helper
INFO - 2025-11-15 22:24:25 --> Helper loaded: main_helper
INFO - 2025-11-15 22:24:25 --> Helper loaded: sendgrid_helper
INFO - 2025-11-15 22:24:25 --> Database Driver Class Initialized
INFO - 2025-11-15 22:24:25 --> Email Class Initialized
DEBUG - 2025-11-15 22:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 22:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 22:24:25 --> Controller Class Initialized
INFO - 2025-11-15 22:24:25 --> Model "Subscription_model" initialized
INFO - 2025-11-15 22:24:25 --> Model "User_model" initialized
INFO - 2025-11-15 22:24:25 --> Model "Auth_model" initialized
INFO - 2025-11-15 22:24:26 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-15 22:24:26 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-15 22:24:26 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-15 22:24:26 --> File loaded: D:\laragon\www\acumena\application\views\dashboard.php
INFO - 2025-11-15 22:24:26 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-15 22:24:26 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-15 22:24:26 --> Final output sent to browser
INFO - 2025-11-15 22:24:26 --> Total execution time: 0.3652
INFO - 2025-11-15 22:24:26 --> Config Class Initialized
INFO - 2025-11-15 22:24:26 --> Hooks Class Initialized
INFO - 2025-11-15 22:24:26 --> UTF-8 Support Enabled
INFO - 2025-11-15 22:24:26 --> Utf8 Class Initialized
INFO - 2025-11-15 22:24:26 --> URI Class Initialized
INFO - 2025-11-15 22:24:26 --> Router Class Initialized
INFO - 2025-11-15 22:24:26 --> Output Class Initialized
INFO - 2025-11-15 22:24:26 --> Security Class Initialized
INFO - 2025-11-15 22:24:26 --> Input Class Initialized
INFO - 2025-11-15 22:24:26 --> Language Class Initialized
INFO - 2025-11-15 22:24:26 --> Loader Class Initialized
INFO - 2025-11-15 22:24:26 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-15 22:24:26 --> Helper loaded: url_helper
INFO - 2025-11-15 22:24:26 --> Helper loaded: file_helper
INFO - 2025-11-15 22:24:26 --> Helper loaded: main_helper
INFO - 2025-11-15 22:24:26 --> Helper loaded: sendgrid_helper
INFO - 2025-11-15 22:24:26 --> Database Driver Class Initialized
INFO - 2025-11-15 22:24:26 --> Email Class Initialized
DEBUG - 2025-11-15 22:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 22:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 22:24:26 --> Controller Class Initialized
INFO - 2025-11-15 22:24:26 --> Model "User_model" initialized
INFO - 2025-11-15 22:24:26 --> Model "Project_model" initialized
INFO - 2025-11-15 22:24:26 --> Helper loaded: form_helper
INFO - 2025-11-15 22:24:26 --> Form Validation Class Initialized
INFO - 2025-11-15 22:24:26 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-15 22:24:26 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-15 22:24:26 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-15 22:24:26 --> Model "Swot_model" initialized
INFO - 2025-11-15 22:24:26 --> Model "Swot_model" initialized
INFO - 2025-11-15 22:24:26 --> Model "Topk_service_model" initialized
INFO - 2025-11-15 22:24:26 --> Final output sent to browser
INFO - 2025-11-15 22:24:26 --> Total execution time: 0.5808
INFO - 2025-11-15 22:24:29 --> Config Class Initialized
INFO - 2025-11-15 22:24:29 --> Hooks Class Initialized
INFO - 2025-11-15 22:24:29 --> UTF-8 Support Enabled
INFO - 2025-11-15 22:24:29 --> Utf8 Class Initialized
INFO - 2025-11-15 22:24:29 --> URI Class Initialized
INFO - 2025-11-15 22:24:29 --> Router Class Initialized
INFO - 2025-11-15 22:24:29 --> Output Class Initialized
INFO - 2025-11-15 22:24:29 --> Security Class Initialized
INFO - 2025-11-15 22:24:29 --> Input Class Initialized
INFO - 2025-11-15 22:24:29 --> Language Class Initialized
INFO - 2025-11-15 22:24:29 --> Loader Class Initialized
INFO - 2025-11-15 22:24:29 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-15 22:24:29 --> Helper loaded: url_helper
INFO - 2025-11-15 22:24:29 --> Helper loaded: file_helper
INFO - 2025-11-15 22:24:29 --> Helper loaded: main_helper
INFO - 2025-11-15 22:24:29 --> Helper loaded: sendgrid_helper
INFO - 2025-11-15 22:24:29 --> Database Driver Class Initialized
INFO - 2025-11-15 22:24:29 --> Email Class Initialized
DEBUG - 2025-11-15 22:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 22:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 22:24:29 --> Controller Class Initialized
INFO - 2025-11-15 22:24:29 --> Model "Subscription_model" initialized
INFO - 2025-11-15 22:24:29 --> Model "User_model" initialized
INFO - 2025-11-15 22:24:29 --> Model "Auth_model" initialized
INFO - 2025-11-15 22:24:29 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-15 22:24:29 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-15 22:24:29 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-15 22:24:29 --> File loaded: D:\laragon\www\acumena\application\views\settings/index.php
INFO - 2025-11-15 22:24:29 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-15 22:24:29 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-15 22:24:29 --> Final output sent to browser
INFO - 2025-11-15 22:24:29 --> Total execution time: 0.1980
INFO - 2025-11-15 22:24:29 --> Config Class Initialized
INFO - 2025-11-15 22:24:29 --> Hooks Class Initialized
INFO - 2025-11-15 22:24:29 --> UTF-8 Support Enabled
INFO - 2025-11-15 22:24:29 --> Utf8 Class Initialized
INFO - 2025-11-15 22:24:29 --> URI Class Initialized
INFO - 2025-11-15 22:24:29 --> Router Class Initialized
INFO - 2025-11-15 22:24:29 --> Output Class Initialized
INFO - 2025-11-15 22:24:29 --> Security Class Initialized
INFO - 2025-11-15 22:24:29 --> Input Class Initialized
INFO - 2025-11-15 22:24:29 --> Language Class Initialized
INFO - 2025-11-15 22:24:29 --> Loader Class Initialized
INFO - 2025-11-15 22:24:29 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-15 22:24:29 --> Helper loaded: url_helper
INFO - 2025-11-15 22:24:29 --> Helper loaded: file_helper
INFO - 2025-11-15 22:24:29 --> Helper loaded: main_helper
INFO - 2025-11-15 22:24:29 --> Helper loaded: sendgrid_helper
INFO - 2025-11-15 22:24:29 --> Database Driver Class Initialized
INFO - 2025-11-15 22:24:29 --> Email Class Initialized
DEBUG - 2025-11-15 22:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 22:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 22:24:29 --> Controller Class Initialized
INFO - 2025-11-15 22:24:29 --> Model "Subscription_model" initialized
INFO - 2025-11-15 22:24:29 --> Model "User_model" initialized
INFO - 2025-11-15 22:24:29 --> Model "Auth_model" initialized
INFO - 2025-11-15 22:24:29 --> Final output sent to browser
INFO - 2025-11-15 22:24:29 --> Total execution time: 0.1368
