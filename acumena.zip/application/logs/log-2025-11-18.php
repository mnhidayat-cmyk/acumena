<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-11-18 05:11:10 --> Config Class Initialized
INFO - 2025-11-18 05:11:10 --> Hooks Class Initialized
INFO - 2025-11-18 05:11:10 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:11:10 --> Utf8 Class Initialized
INFO - 2025-11-18 05:11:10 --> URI Class Initialized
DEBUG - 2025-11-18 05:11:10 --> No URI present. Default controller set.
INFO - 2025-11-18 05:11:10 --> Router Class Initialized
INFO - 2025-11-18 05:11:11 --> Output Class Initialized
INFO - 2025-11-18 05:11:11 --> Security Class Initialized
INFO - 2025-11-18 05:11:11 --> Input Class Initialized
INFO - 2025-11-18 05:11:11 --> Language Class Initialized
INFO - 2025-11-18 05:11:11 --> Loader Class Initialized
INFO - 2025-11-18 05:11:11 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:11:11 --> Helper loaded: url_helper
INFO - 2025-11-18 05:11:11 --> Helper loaded: file_helper
INFO - 2025-11-18 05:11:11 --> Helper loaded: main_helper
INFO - 2025-11-18 05:11:11 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:11:11 --> Database Driver Class Initialized
INFO - 2025-11-18 05:11:11 --> Email Class Initialized
DEBUG - 2025-11-18 05:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:11:11 --> Controller Class Initialized
INFO - 2025-11-18 05:11:11 --> Config Class Initialized
INFO - 2025-11-18 05:11:11 --> Hooks Class Initialized
INFO - 2025-11-18 05:11:11 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:11:11 --> Utf8 Class Initialized
INFO - 2025-11-18 05:11:11 --> URI Class Initialized
INFO - 2025-11-18 05:11:11 --> Router Class Initialized
INFO - 2025-11-18 05:11:11 --> Output Class Initialized
INFO - 2025-11-18 05:11:11 --> Security Class Initialized
INFO - 2025-11-18 05:11:11 --> Input Class Initialized
INFO - 2025-11-18 05:11:11 --> Language Class Initialized
INFO - 2025-11-18 05:11:11 --> Loader Class Initialized
INFO - 2025-11-18 05:11:11 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:11:11 --> Helper loaded: url_helper
INFO - 2025-11-18 05:11:11 --> Helper loaded: file_helper
INFO - 2025-11-18 05:11:11 --> Helper loaded: main_helper
INFO - 2025-11-18 05:11:11 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:11:11 --> Database Driver Class Initialized
INFO - 2025-11-18 05:11:11 --> Email Class Initialized
DEBUG - 2025-11-18 05:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:11:11 --> Controller Class Initialized
INFO - 2025-11-18 05:11:11 --> Model "Subscription_model" initialized
INFO - 2025-11-18 05:11:11 --> Model "User_model" initialized
INFO - 2025-11-18 05:11:11 --> Model "Auth_model" initialized
INFO - 2025-11-18 05:11:11 --> Config Class Initialized
INFO - 2025-11-18 05:11:11 --> Hooks Class Initialized
INFO - 2025-11-18 05:11:11 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:11:11 --> Utf8 Class Initialized
INFO - 2025-11-18 05:11:11 --> URI Class Initialized
INFO - 2025-11-18 05:11:11 --> Router Class Initialized
INFO - 2025-11-18 05:11:11 --> Output Class Initialized
INFO - 2025-11-18 05:11:11 --> Security Class Initialized
INFO - 2025-11-18 05:11:11 --> Input Class Initialized
INFO - 2025-11-18 05:11:11 --> Language Class Initialized
INFO - 2025-11-18 05:11:11 --> Loader Class Initialized
INFO - 2025-11-18 05:11:11 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:11:11 --> Helper loaded: url_helper
INFO - 2025-11-18 05:11:11 --> Helper loaded: file_helper
INFO - 2025-11-18 05:11:11 --> Helper loaded: main_helper
INFO - 2025-11-18 05:11:11 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:11:11 --> Database Driver Class Initialized
INFO - 2025-11-18 05:11:11 --> Email Class Initialized
DEBUG - 2025-11-18 05:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:11:11 --> Controller Class Initialized
INFO - 2025-11-18 05:11:11 --> Config Class Initialized
INFO - 2025-11-18 05:11:11 --> Hooks Class Initialized
INFO - 2025-11-18 05:11:11 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:11:11 --> Utf8 Class Initialized
INFO - 2025-11-18 05:11:11 --> URI Class Initialized
INFO - 2025-11-18 05:11:11 --> Router Class Initialized
INFO - 2025-11-18 05:11:11 --> Output Class Initialized
INFO - 2025-11-18 05:11:11 --> Security Class Initialized
INFO - 2025-11-18 05:11:11 --> Input Class Initialized
INFO - 2025-11-18 05:11:11 --> Language Class Initialized
INFO - 2025-11-18 05:11:11 --> Loader Class Initialized
INFO - 2025-11-18 05:11:11 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:11:11 --> Helper loaded: url_helper
INFO - 2025-11-18 05:11:11 --> Helper loaded: file_helper
INFO - 2025-11-18 05:11:11 --> Helper loaded: main_helper
INFO - 2025-11-18 05:11:11 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:11:11 --> Database Driver Class Initialized
INFO - 2025-11-18 05:11:11 --> Email Class Initialized
DEBUG - 2025-11-18 05:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:11:11 --> Controller Class Initialized
INFO - 2025-11-18 05:11:11 --> Model "Subscription_model" initialized
INFO - 2025-11-18 05:11:11 --> Model "User_model" initialized
INFO - 2025-11-18 05:11:11 --> Model "Auth_model" initialized
INFO - 2025-11-18 05:11:11 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-18 05:11:11 --> Final output sent to browser
INFO - 2025-11-18 05:11:11 --> Total execution time: 0.0856
INFO - 2025-11-18 05:11:26 --> Config Class Initialized
INFO - 2025-11-18 05:11:26 --> Hooks Class Initialized
INFO - 2025-11-18 05:11:26 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:11:26 --> Utf8 Class Initialized
INFO - 2025-11-18 05:11:26 --> URI Class Initialized
INFO - 2025-11-18 05:11:26 --> Router Class Initialized
INFO - 2025-11-18 05:11:26 --> Output Class Initialized
INFO - 2025-11-18 05:11:26 --> Security Class Initialized
INFO - 2025-11-18 05:11:26 --> Input Class Initialized
INFO - 2025-11-18 05:11:26 --> Language Class Initialized
INFO - 2025-11-18 05:11:26 --> Loader Class Initialized
INFO - 2025-11-18 05:11:26 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:11:26 --> Helper loaded: url_helper
INFO - 2025-11-18 05:11:26 --> Helper loaded: file_helper
INFO - 2025-11-18 05:11:26 --> Helper loaded: main_helper
INFO - 2025-11-18 05:11:26 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:11:26 --> Database Driver Class Initialized
INFO - 2025-11-18 05:11:26 --> Email Class Initialized
DEBUG - 2025-11-18 05:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:11:26 --> Controller Class Initialized
INFO - 2025-11-18 05:11:26 --> Model "Subscription_model" initialized
INFO - 2025-11-18 05:11:26 --> Model "User_model" initialized
INFO - 2025-11-18 05:11:26 --> Model "Auth_model" initialized
INFO - 2025-11-18 05:11:26 --> Final output sent to browser
INFO - 2025-11-18 05:11:26 --> Total execution time: 0.3875
INFO - 2025-11-18 05:11:28 --> Config Class Initialized
INFO - 2025-11-18 05:11:28 --> Hooks Class Initialized
INFO - 2025-11-18 05:11:28 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:11:28 --> Utf8 Class Initialized
INFO - 2025-11-18 05:11:28 --> URI Class Initialized
INFO - 2025-11-18 05:11:28 --> Router Class Initialized
INFO - 2025-11-18 05:11:28 --> Output Class Initialized
INFO - 2025-11-18 05:11:28 --> Security Class Initialized
INFO - 2025-11-18 05:11:28 --> Input Class Initialized
INFO - 2025-11-18 05:11:28 --> Language Class Initialized
INFO - 2025-11-18 05:11:28 --> Loader Class Initialized
INFO - 2025-11-18 05:11:28 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:11:28 --> Helper loaded: url_helper
INFO - 2025-11-18 05:11:28 --> Helper loaded: file_helper
INFO - 2025-11-18 05:11:28 --> Helper loaded: main_helper
INFO - 2025-11-18 05:11:28 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:11:28 --> Database Driver Class Initialized
INFO - 2025-11-18 05:11:28 --> Email Class Initialized
DEBUG - 2025-11-18 05:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:11:28 --> Controller Class Initialized
INFO - 2025-11-18 05:11:28 --> Model "Subscription_model" initialized
INFO - 2025-11-18 05:11:28 --> Model "User_model" initialized
INFO - 2025-11-18 05:11:28 --> Model "Auth_model" initialized
INFO - 2025-11-18 05:11:28 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-18 05:11:28 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-18 05:11:28 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-18 05:11:28 --> File loaded: D:\laragon\www\acumena\application\views\dashboard.php
INFO - 2025-11-18 05:11:28 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-18 05:11:28 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-18 05:11:28 --> Final output sent to browser
INFO - 2025-11-18 05:11:28 --> Total execution time: 0.4485
INFO - 2025-11-18 05:11:28 --> Config Class Initialized
INFO - 2025-11-18 05:11:28 --> Hooks Class Initialized
INFO - 2025-11-18 05:11:28 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:11:28 --> Utf8 Class Initialized
INFO - 2025-11-18 05:11:28 --> URI Class Initialized
INFO - 2025-11-18 05:11:28 --> Router Class Initialized
INFO - 2025-11-18 05:11:28 --> Output Class Initialized
INFO - 2025-11-18 05:11:28 --> Security Class Initialized
INFO - 2025-11-18 05:11:28 --> Input Class Initialized
INFO - 2025-11-18 05:11:28 --> Language Class Initialized
INFO - 2025-11-18 05:11:28 --> Loader Class Initialized
INFO - 2025-11-18 05:11:28 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:11:28 --> Helper loaded: url_helper
INFO - 2025-11-18 05:11:28 --> Helper loaded: file_helper
INFO - 2025-11-18 05:11:28 --> Helper loaded: main_helper
INFO - 2025-11-18 05:11:28 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:11:28 --> Database Driver Class Initialized
INFO - 2025-11-18 05:11:28 --> Email Class Initialized
DEBUG - 2025-11-18 05:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:11:28 --> Controller Class Initialized
INFO - 2025-11-18 05:11:29 --> Model "User_model" initialized
INFO - 2025-11-18 05:11:29 --> Model "Project_model" initialized
INFO - 2025-11-18 05:11:29 --> Helper loaded: form_helper
INFO - 2025-11-18 05:11:29 --> Form Validation Class Initialized
INFO - 2025-11-18 05:11:29 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:11:29 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:11:29 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:11:29 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:11:29 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:11:29 --> Model "Topk_service_model" initialized
INFO - 2025-11-18 05:11:29 --> Final output sent to browser
INFO - 2025-11-18 05:11:29 --> Total execution time: 0.5167
INFO - 2025-11-18 05:11:33 --> Config Class Initialized
INFO - 2025-11-18 05:11:33 --> Hooks Class Initialized
INFO - 2025-11-18 05:11:33 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:11:33 --> Utf8 Class Initialized
INFO - 2025-11-18 05:11:33 --> URI Class Initialized
INFO - 2025-11-18 05:11:33 --> Router Class Initialized
INFO - 2025-11-18 05:11:33 --> Output Class Initialized
INFO - 2025-11-18 05:11:33 --> Security Class Initialized
INFO - 2025-11-18 05:11:33 --> Input Class Initialized
INFO - 2025-11-18 05:11:33 --> Language Class Initialized
INFO - 2025-11-18 05:11:33 --> Loader Class Initialized
INFO - 2025-11-18 05:11:33 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:11:33 --> Helper loaded: url_helper
INFO - 2025-11-18 05:11:33 --> Helper loaded: file_helper
INFO - 2025-11-18 05:11:33 --> Helper loaded: main_helper
INFO - 2025-11-18 05:11:33 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:11:33 --> Database Driver Class Initialized
INFO - 2025-11-18 05:11:33 --> Email Class Initialized
DEBUG - 2025-11-18 05:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:11:33 --> Controller Class Initialized
INFO - 2025-11-18 05:11:33 --> Model "Subscription_model" initialized
INFO - 2025-11-18 05:11:33 --> Model "User_model" initialized
INFO - 2025-11-18 05:11:33 --> Model "Auth_model" initialized
INFO - 2025-11-18 05:11:33 --> Model "Project_model" initialized
INFO - 2025-11-18 05:11:33 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-18 05:11:33 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-18 05:11:33 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-18 05:11:33 --> File loaded: D:\laragon\www\acumena\application\views\projects/index.php
INFO - 2025-11-18 05:11:33 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-18 05:11:33 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-18 05:11:33 --> Final output sent to browser
INFO - 2025-11-18 05:11:33 --> Total execution time: 0.0938
INFO - 2025-11-18 05:11:33 --> Config Class Initialized
INFO - 2025-11-18 05:11:33 --> Hooks Class Initialized
INFO - 2025-11-18 05:11:33 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:11:33 --> Utf8 Class Initialized
INFO - 2025-11-18 05:11:33 --> URI Class Initialized
INFO - 2025-11-18 05:11:33 --> Router Class Initialized
INFO - 2025-11-18 05:11:33 --> Output Class Initialized
INFO - 2025-11-18 05:11:33 --> Security Class Initialized
INFO - 2025-11-18 05:11:33 --> Input Class Initialized
INFO - 2025-11-18 05:11:33 --> Language Class Initialized
INFO - 2025-11-18 05:11:33 --> Loader Class Initialized
INFO - 2025-11-18 05:11:33 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:11:33 --> Helper loaded: url_helper
INFO - 2025-11-18 05:11:33 --> Helper loaded: file_helper
INFO - 2025-11-18 05:11:33 --> Helper loaded: main_helper
INFO - 2025-11-18 05:11:33 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:11:33 --> Database Driver Class Initialized
INFO - 2025-11-18 05:11:33 --> Email Class Initialized
DEBUG - 2025-11-18 05:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:11:33 --> Controller Class Initialized
INFO - 2025-11-18 05:11:33 --> Model "User_model" initialized
INFO - 2025-11-18 05:11:33 --> Model "Project_model" initialized
INFO - 2025-11-18 05:11:33 --> Helper loaded: form_helper
INFO - 2025-11-18 05:11:33 --> Form Validation Class Initialized
INFO - 2025-11-18 05:11:33 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:11:33 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:11:33 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:11:33 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:11:33 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:11:33 --> Model "Topk_service_model" initialized
INFO - 2025-11-18 05:11:33 --> Final output sent to browser
INFO - 2025-11-18 05:11:33 --> Total execution time: 0.0550
INFO - 2025-11-18 05:11:34 --> Config Class Initialized
INFO - 2025-11-18 05:11:34 --> Hooks Class Initialized
INFO - 2025-11-18 05:11:34 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:11:34 --> Utf8 Class Initialized
INFO - 2025-11-18 05:11:34 --> URI Class Initialized
INFO - 2025-11-18 05:11:34 --> Router Class Initialized
INFO - 2025-11-18 05:11:34 --> Output Class Initialized
INFO - 2025-11-18 05:11:34 --> Security Class Initialized
INFO - 2025-11-18 05:11:34 --> Input Class Initialized
INFO - 2025-11-18 05:11:34 --> Language Class Initialized
INFO - 2025-11-18 05:11:34 --> Loader Class Initialized
INFO - 2025-11-18 05:11:34 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:11:34 --> Helper loaded: url_helper
INFO - 2025-11-18 05:11:34 --> Helper loaded: file_helper
INFO - 2025-11-18 05:11:34 --> Helper loaded: main_helper
INFO - 2025-11-18 05:11:34 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:11:34 --> Database Driver Class Initialized
INFO - 2025-11-18 05:11:34 --> Email Class Initialized
DEBUG - 2025-11-18 05:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:11:34 --> Controller Class Initialized
INFO - 2025-11-18 05:11:34 --> Model "Subscription_model" initialized
INFO - 2025-11-18 05:11:34 --> Model "User_model" initialized
INFO - 2025-11-18 05:11:34 --> Model "Auth_model" initialized
INFO - 2025-11-18 05:11:35 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-18 05:11:35 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-18 05:11:35 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-18 05:11:35 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-18 05:11:35 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-18 05:11:35 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-18 05:11:35 --> Final output sent to browser
INFO - 2025-11-18 05:11:35 --> Total execution time: 0.0813
INFO - 2025-11-18 05:12:21 --> Config Class Initialized
INFO - 2025-11-18 05:12:21 --> Hooks Class Initialized
INFO - 2025-11-18 05:12:21 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:12:21 --> Utf8 Class Initialized
INFO - 2025-11-18 05:12:21 --> URI Class Initialized
INFO - 2025-11-18 05:12:21 --> Router Class Initialized
INFO - 2025-11-18 05:12:21 --> Output Class Initialized
INFO - 2025-11-18 05:12:21 --> Security Class Initialized
INFO - 2025-11-18 05:12:21 --> Input Class Initialized
INFO - 2025-11-18 05:12:21 --> Language Class Initialized
INFO - 2025-11-18 05:12:21 --> Loader Class Initialized
INFO - 2025-11-18 05:12:21 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:12:21 --> Helper loaded: url_helper
INFO - 2025-11-18 05:12:21 --> Helper loaded: file_helper
INFO - 2025-11-18 05:12:21 --> Helper loaded: main_helper
INFO - 2025-11-18 05:12:21 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:12:21 --> Database Driver Class Initialized
INFO - 2025-11-18 05:12:21 --> Email Class Initialized
DEBUG - 2025-11-18 05:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:12:21 --> Controller Class Initialized
INFO - 2025-11-18 05:12:21 --> Model "Subscription_model" initialized
INFO - 2025-11-18 05:12:21 --> Model "User_model" initialized
INFO - 2025-11-18 05:12:21 --> Model "Auth_model" initialized
INFO - 2025-11-18 05:12:21 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-18 05:12:21 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-18 05:12:21 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-18 05:12:21 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/package.php
INFO - 2025-11-18 05:12:21 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-18 05:12:21 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-18 05:12:21 --> Final output sent to browser
INFO - 2025-11-18 05:12:21 --> Total execution time: 0.1001
INFO - 2025-11-18 05:12:24 --> Config Class Initialized
INFO - 2025-11-18 05:12:24 --> Hooks Class Initialized
INFO - 2025-11-18 05:12:24 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:12:24 --> Utf8 Class Initialized
INFO - 2025-11-18 05:12:24 --> URI Class Initialized
INFO - 2025-11-18 05:12:24 --> Router Class Initialized
INFO - 2025-11-18 05:12:24 --> Output Class Initialized
INFO - 2025-11-18 05:12:24 --> Security Class Initialized
INFO - 2025-11-18 05:12:24 --> Input Class Initialized
INFO - 2025-11-18 05:12:24 --> Language Class Initialized
INFO - 2025-11-18 05:12:24 --> Loader Class Initialized
INFO - 2025-11-18 05:12:24 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:12:24 --> Helper loaded: url_helper
INFO - 2025-11-18 05:12:24 --> Helper loaded: file_helper
INFO - 2025-11-18 05:12:24 --> Helper loaded: main_helper
INFO - 2025-11-18 05:12:24 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:12:24 --> Database Driver Class Initialized
INFO - 2025-11-18 05:12:24 --> Email Class Initialized
DEBUG - 2025-11-18 05:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:12:24 --> Controller Class Initialized
INFO - 2025-11-18 05:12:24 --> Model "Subscription_model" initialized
INFO - 2025-11-18 05:12:24 --> Model "User_model" initialized
INFO - 2025-11-18 05:12:24 --> Model "Auth_model" initialized
INFO - 2025-11-18 05:12:24 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-18 05:12:24 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-18 05:12:24 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-18 05:12:24 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-18 05:12:24 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-18 05:12:24 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-18 05:12:24 --> Final output sent to browser
INFO - 2025-11-18 05:12:24 --> Total execution time: 0.0910
INFO - 2025-11-18 05:24:10 --> Config Class Initialized
INFO - 2025-11-18 05:24:10 --> Hooks Class Initialized
INFO - 2025-11-18 05:24:10 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:24:10 --> Utf8 Class Initialized
INFO - 2025-11-18 05:24:10 --> URI Class Initialized
INFO - 2025-11-18 05:24:10 --> Router Class Initialized
INFO - 2025-11-18 05:24:10 --> Output Class Initialized
INFO - 2025-11-18 05:24:10 --> Security Class Initialized
INFO - 2025-11-18 05:24:10 --> Input Class Initialized
INFO - 2025-11-18 05:24:10 --> Language Class Initialized
ERROR - 2025-11-18 05:24:10 --> 404 Page Not Found: Cronjob/index
INFO - 2025-11-18 05:24:10 --> Config Class Initialized
INFO - 2025-11-18 05:24:10 --> Hooks Class Initialized
INFO - 2025-11-18 05:24:10 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:24:10 --> Utf8 Class Initialized
INFO - 2025-11-18 05:24:10 --> URI Class Initialized
INFO - 2025-11-18 05:24:10 --> Router Class Initialized
INFO - 2025-11-18 05:24:10 --> Output Class Initialized
INFO - 2025-11-18 05:24:10 --> Security Class Initialized
INFO - 2025-11-18 05:24:10 --> Input Class Initialized
INFO - 2025-11-18 05:24:10 --> Language Class Initialized
ERROR - 2025-11-18 05:24:10 --> 404 Page Not Found: Faviconico/index
INFO - 2025-11-18 05:24:15 --> Config Class Initialized
INFO - 2025-11-18 05:24:15 --> Hooks Class Initialized
INFO - 2025-11-18 05:24:15 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:24:15 --> Utf8 Class Initialized
INFO - 2025-11-18 05:24:15 --> URI Class Initialized
INFO - 2025-11-18 05:24:15 --> Router Class Initialized
INFO - 2025-11-18 05:24:15 --> Output Class Initialized
INFO - 2025-11-18 05:24:15 --> Security Class Initialized
INFO - 2025-11-18 05:24:15 --> Input Class Initialized
INFO - 2025-11-18 05:24:15 --> Language Class Initialized
INFO - 2025-11-18 05:24:15 --> Loader Class Initialized
INFO - 2025-11-18 05:24:15 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:24:15 --> Helper loaded: url_helper
INFO - 2025-11-18 05:24:15 --> Helper loaded: file_helper
INFO - 2025-11-18 05:24:15 --> Helper loaded: main_helper
INFO - 2025-11-18 05:24:15 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:24:15 --> Database Driver Class Initialized
INFO - 2025-11-18 05:24:15 --> Email Class Initialized
DEBUG - 2025-11-18 05:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:24:15 --> Controller Class Initialized
INFO - 2025-11-18 05:24:15 --> Final output sent to browser
INFO - 2025-11-18 05:24:15 --> Total execution time: 0.2149
INFO - 2025-11-18 05:24:48 --> Config Class Initialized
INFO - 2025-11-18 05:24:48 --> Hooks Class Initialized
INFO - 2025-11-18 05:24:48 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:24:48 --> Utf8 Class Initialized
INFO - 2025-11-18 05:24:48 --> URI Class Initialized
INFO - 2025-11-18 05:24:48 --> Router Class Initialized
INFO - 2025-11-18 05:24:48 --> Output Class Initialized
INFO - 2025-11-18 05:24:48 --> Security Class Initialized
INFO - 2025-11-18 05:24:48 --> Input Class Initialized
INFO - 2025-11-18 05:24:48 --> Language Class Initialized
INFO - 2025-11-18 05:24:48 --> Loader Class Initialized
INFO - 2025-11-18 05:24:48 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:24:48 --> Helper loaded: url_helper
INFO - 2025-11-18 05:24:48 --> Helper loaded: file_helper
INFO - 2025-11-18 05:24:48 --> Helper loaded: main_helper
INFO - 2025-11-18 05:24:48 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:24:48 --> Database Driver Class Initialized
INFO - 2025-11-18 05:24:48 --> Email Class Initialized
DEBUG - 2025-11-18 05:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:24:48 --> Controller Class Initialized
INFO - 2025-11-18 05:24:48 --> Final output sent to browser
INFO - 2025-11-18 05:24:48 --> Total execution time: 0.0857
INFO - 2025-11-18 05:25:08 --> Config Class Initialized
INFO - 2025-11-18 05:25:08 --> Hooks Class Initialized
INFO - 2025-11-18 05:25:08 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:25:08 --> Utf8 Class Initialized
INFO - 2025-11-18 05:25:08 --> URI Class Initialized
INFO - 2025-11-18 05:25:08 --> Router Class Initialized
INFO - 2025-11-18 05:25:08 --> Output Class Initialized
INFO - 2025-11-18 05:25:08 --> Security Class Initialized
INFO - 2025-11-18 05:25:08 --> Input Class Initialized
INFO - 2025-11-18 05:25:08 --> Language Class Initialized
INFO - 2025-11-18 05:25:08 --> Loader Class Initialized
INFO - 2025-11-18 05:25:08 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:25:08 --> Helper loaded: url_helper
INFO - 2025-11-18 05:25:08 --> Helper loaded: file_helper
INFO - 2025-11-18 05:25:08 --> Helper loaded: main_helper
INFO - 2025-11-18 05:25:08 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:25:08 --> Database Driver Class Initialized
INFO - 2025-11-18 05:25:08 --> Email Class Initialized
DEBUG - 2025-11-18 05:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:25:08 --> Controller Class Initialized
INFO - 2025-11-18 05:25:08 --> Model "Subscription_model" initialized
INFO - 2025-11-18 05:25:08 --> Model "User_model" initialized
INFO - 2025-11-18 05:25:08 --> Model "Auth_model" initialized
INFO - 2025-11-18 05:25:08 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-18 05:25:08 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-18 05:25:08 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-18 05:25:08 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-18 05:25:08 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-18 05:25:08 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-18 05:25:08 --> Final output sent to browser
INFO - 2025-11-18 05:25:08 --> Total execution time: 0.0983
INFO - 2025-11-18 05:25:41 --> Config Class Initialized
INFO - 2025-11-18 05:25:41 --> Hooks Class Initialized
INFO - 2025-11-18 05:25:41 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:25:41 --> Utf8 Class Initialized
INFO - 2025-11-18 05:25:41 --> URI Class Initialized
INFO - 2025-11-18 05:25:41 --> Router Class Initialized
INFO - 2025-11-18 05:25:41 --> Output Class Initialized
INFO - 2025-11-18 05:25:41 --> Security Class Initialized
INFO - 2025-11-18 05:25:41 --> Input Class Initialized
INFO - 2025-11-18 05:25:41 --> Language Class Initialized
INFO - 2025-11-18 05:25:41 --> Loader Class Initialized
INFO - 2025-11-18 05:25:41 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:25:41 --> Helper loaded: url_helper
INFO - 2025-11-18 05:25:41 --> Helper loaded: file_helper
INFO - 2025-11-18 05:25:41 --> Helper loaded: main_helper
INFO - 2025-11-18 05:25:41 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:25:41 --> Database Driver Class Initialized
INFO - 2025-11-18 05:25:41 --> Email Class Initialized
DEBUG - 2025-11-18 05:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:25:41 --> Controller Class Initialized
INFO - 2025-11-18 05:25:41 --> Model "Subscription_model" initialized
INFO - 2025-11-18 05:25:42 --> Model "User_model" initialized
INFO - 2025-11-18 05:25:42 --> Model "Auth_model" initialized
INFO - 2025-11-18 05:25:42 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-18 05:25:42 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-18 05:25:42 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-18 05:25:42 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/index.php
INFO - 2025-11-18 05:25:42 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-18 05:25:42 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-18 05:25:42 --> Final output sent to browser
INFO - 2025-11-18 05:25:42 --> Total execution time: 0.0980
INFO - 2025-11-18 05:25:46 --> Config Class Initialized
INFO - 2025-11-18 05:25:46 --> Hooks Class Initialized
INFO - 2025-11-18 05:25:46 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:25:46 --> Utf8 Class Initialized
INFO - 2025-11-18 05:25:46 --> URI Class Initialized
INFO - 2025-11-18 05:25:46 --> Router Class Initialized
INFO - 2025-11-18 05:25:46 --> Output Class Initialized
INFO - 2025-11-18 05:25:46 --> Security Class Initialized
INFO - 2025-11-18 05:25:46 --> Input Class Initialized
INFO - 2025-11-18 05:25:46 --> Language Class Initialized
INFO - 2025-11-18 05:25:46 --> Loader Class Initialized
INFO - 2025-11-18 05:25:46 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:25:46 --> Helper loaded: url_helper
INFO - 2025-11-18 05:25:46 --> Helper loaded: file_helper
INFO - 2025-11-18 05:25:46 --> Helper loaded: main_helper
INFO - 2025-11-18 05:25:46 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:25:46 --> Database Driver Class Initialized
INFO - 2025-11-18 05:25:46 --> Email Class Initialized
DEBUG - 2025-11-18 05:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:25:46 --> Controller Class Initialized
INFO - 2025-11-18 05:25:46 --> Model "Subscription_model" initialized
INFO - 2025-11-18 05:25:46 --> Model "User_model" initialized
INFO - 2025-11-18 05:25:46 --> Model "Auth_model" initialized
INFO - 2025-11-18 05:25:46 --> File loaded: D:\laragon\www\acumena\application\views\subscriptions/invoice.php
INFO - 2025-11-18 05:25:46 --> Final output sent to browser
INFO - 2025-11-18 05:25:46 --> Total execution time: 0.1073
INFO - 2025-11-18 05:33:00 --> Config Class Initialized
INFO - 2025-11-18 05:33:00 --> Hooks Class Initialized
INFO - 2025-11-18 05:33:00 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:33:00 --> Utf8 Class Initialized
INFO - 2025-11-18 05:33:00 --> URI Class Initialized
INFO - 2025-11-18 05:33:00 --> Router Class Initialized
INFO - 2025-11-18 05:33:00 --> Output Class Initialized
INFO - 2025-11-18 05:33:00 --> Security Class Initialized
INFO - 2025-11-18 05:33:00 --> Input Class Initialized
INFO - 2025-11-18 05:33:00 --> Language Class Initialized
INFO - 2025-11-18 05:33:00 --> Loader Class Initialized
INFO - 2025-11-18 05:33:00 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:33:00 --> Helper loaded: url_helper
INFO - 2025-11-18 05:33:00 --> Helper loaded: file_helper
INFO - 2025-11-18 05:33:00 --> Helper loaded: main_helper
INFO - 2025-11-18 05:33:00 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:33:00 --> Database Driver Class Initialized
INFO - 2025-11-18 05:33:01 --> Email Class Initialized
DEBUG - 2025-11-18 05:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:33:01 --> Controller Class Initialized
INFO - 2025-11-18 05:33:01 --> Model "Subscription_model" initialized
INFO - 2025-11-18 05:33:01 --> Model "User_model" initialized
INFO - 2025-11-18 05:33:01 --> Model "Auth_model" initialized
INFO - 2025-11-18 05:33:01 --> Model "Project_model" initialized
INFO - 2025-11-18 05:33:01 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-18 05:33:01 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-18 05:33:01 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-18 05:33:01 --> File loaded: D:\laragon\www\acumena\application\views\projects/index.php
INFO - 2025-11-18 05:33:01 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-18 05:33:01 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-18 05:33:01 --> Final output sent to browser
INFO - 2025-11-18 05:33:01 --> Total execution time: 0.1198
INFO - 2025-11-18 05:33:01 --> Config Class Initialized
INFO - 2025-11-18 05:33:01 --> Hooks Class Initialized
INFO - 2025-11-18 05:33:01 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:33:01 --> Utf8 Class Initialized
INFO - 2025-11-18 05:33:01 --> URI Class Initialized
INFO - 2025-11-18 05:33:01 --> Router Class Initialized
INFO - 2025-11-18 05:33:01 --> Output Class Initialized
INFO - 2025-11-18 05:33:01 --> Security Class Initialized
INFO - 2025-11-18 05:33:01 --> Input Class Initialized
INFO - 2025-11-18 05:33:01 --> Language Class Initialized
INFO - 2025-11-18 05:33:01 --> Loader Class Initialized
INFO - 2025-11-18 05:33:01 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:33:01 --> Helper loaded: url_helper
INFO - 2025-11-18 05:33:01 --> Helper loaded: file_helper
INFO - 2025-11-18 05:33:01 --> Helper loaded: main_helper
INFO - 2025-11-18 05:33:01 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:33:01 --> Database Driver Class Initialized
INFO - 2025-11-18 05:33:01 --> Email Class Initialized
DEBUG - 2025-11-18 05:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:33:01 --> Controller Class Initialized
INFO - 2025-11-18 05:33:01 --> Model "User_model" initialized
INFO - 2025-11-18 05:33:01 --> Model "Project_model" initialized
INFO - 2025-11-18 05:33:01 --> Helper loaded: form_helper
INFO - 2025-11-18 05:33:01 --> Form Validation Class Initialized
INFO - 2025-11-18 05:33:01 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:33:01 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:33:01 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:33:01 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:01 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:01 --> Model "Topk_service_model" initialized
INFO - 2025-11-18 05:33:01 --> Final output sent to browser
INFO - 2025-11-18 05:33:01 --> Total execution time: 0.1033
INFO - 2025-11-18 05:33:02 --> Config Class Initialized
INFO - 2025-11-18 05:33:02 --> Hooks Class Initialized
INFO - 2025-11-18 05:33:02 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:33:02 --> Utf8 Class Initialized
INFO - 2025-11-18 05:33:02 --> URI Class Initialized
INFO - 2025-11-18 05:33:02 --> Router Class Initialized
INFO - 2025-11-18 05:33:02 --> Output Class Initialized
INFO - 2025-11-18 05:33:02 --> Security Class Initialized
INFO - 2025-11-18 05:33:02 --> Input Class Initialized
INFO - 2025-11-18 05:33:02 --> Language Class Initialized
INFO - 2025-11-18 05:33:02 --> Loader Class Initialized
INFO - 2025-11-18 05:33:02 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:33:02 --> Helper loaded: url_helper
INFO - 2025-11-18 05:33:02 --> Helper loaded: file_helper
INFO - 2025-11-18 05:33:02 --> Helper loaded: main_helper
INFO - 2025-11-18 05:33:02 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:33:02 --> Database Driver Class Initialized
INFO - 2025-11-18 05:33:02 --> Email Class Initialized
DEBUG - 2025-11-18 05:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:33:02 --> Controller Class Initialized
INFO - 2025-11-18 05:33:02 --> Model "Subscription_model" initialized
INFO - 2025-11-18 05:33:02 --> Model "User_model" initialized
INFO - 2025-11-18 05:33:02 --> Model "Auth_model" initialized
INFO - 2025-11-18 05:33:02 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-18 05:33:02 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-18 05:33:02 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-18 05:33:02 --> File loaded: D:\laragon\www\acumena\application\views\dashboard.php
INFO - 2025-11-18 05:33:02 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-18 05:33:02 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-18 05:33:02 --> Final output sent to browser
INFO - 2025-11-18 05:33:02 --> Total execution time: 0.1149
INFO - 2025-11-18 05:33:02 --> Config Class Initialized
INFO - 2025-11-18 05:33:02 --> Hooks Class Initialized
INFO - 2025-11-18 05:33:02 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:33:02 --> Utf8 Class Initialized
INFO - 2025-11-18 05:33:02 --> URI Class Initialized
INFO - 2025-11-18 05:33:02 --> Router Class Initialized
INFO - 2025-11-18 05:33:02 --> Output Class Initialized
INFO - 2025-11-18 05:33:02 --> Security Class Initialized
INFO - 2025-11-18 05:33:02 --> Input Class Initialized
INFO - 2025-11-18 05:33:02 --> Language Class Initialized
INFO - 2025-11-18 05:33:02 --> Loader Class Initialized
INFO - 2025-11-18 05:33:02 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:33:02 --> Helper loaded: url_helper
INFO - 2025-11-18 05:33:02 --> Helper loaded: file_helper
INFO - 2025-11-18 05:33:02 --> Helper loaded: main_helper
INFO - 2025-11-18 05:33:02 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:33:02 --> Database Driver Class Initialized
INFO - 2025-11-18 05:33:02 --> Email Class Initialized
DEBUG - 2025-11-18 05:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:33:02 --> Controller Class Initialized
INFO - 2025-11-18 05:33:02 --> Model "User_model" initialized
INFO - 2025-11-18 05:33:02 --> Model "Project_model" initialized
INFO - 2025-11-18 05:33:02 --> Helper loaded: form_helper
INFO - 2025-11-18 05:33:02 --> Form Validation Class Initialized
INFO - 2025-11-18 05:33:02 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:33:02 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:33:02 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:33:02 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:02 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:02 --> Model "Topk_service_model" initialized
INFO - 2025-11-18 05:33:02 --> Final output sent to browser
INFO - 2025-11-18 05:33:02 --> Total execution time: 0.1004
INFO - 2025-11-18 05:33:04 --> Config Class Initialized
INFO - 2025-11-18 05:33:04 --> Hooks Class Initialized
INFO - 2025-11-18 05:33:04 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:33:04 --> Utf8 Class Initialized
INFO - 2025-11-18 05:33:04 --> URI Class Initialized
INFO - 2025-11-18 05:33:04 --> Router Class Initialized
INFO - 2025-11-18 05:33:04 --> Output Class Initialized
INFO - 2025-11-18 05:33:04 --> Security Class Initialized
INFO - 2025-11-18 05:33:04 --> Input Class Initialized
INFO - 2025-11-18 05:33:04 --> Language Class Initialized
INFO - 2025-11-18 05:33:04 --> Loader Class Initialized
INFO - 2025-11-18 05:33:04 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:33:04 --> Helper loaded: url_helper
INFO - 2025-11-18 05:33:04 --> Helper loaded: file_helper
INFO - 2025-11-18 05:33:04 --> Helper loaded: main_helper
INFO - 2025-11-18 05:33:04 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:33:04 --> Database Driver Class Initialized
INFO - 2025-11-18 05:33:04 --> Email Class Initialized
DEBUG - 2025-11-18 05:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:33:05 --> Controller Class Initialized
INFO - 2025-11-18 05:33:05 --> Model "Subscription_model" initialized
INFO - 2025-11-18 05:33:05 --> Model "User_model" initialized
INFO - 2025-11-18 05:33:05 --> Model "Auth_model" initialized
INFO - 2025-11-18 05:33:05 --> Model "Project_model" initialized
INFO - 2025-11-18 05:33:05 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-18 05:33:05 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-18 05:33:05 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-18 05:33:05 --> File loaded: D:\laragon\www\acumena\application\views\projects/profile.php
INFO - 2025-11-18 05:33:05 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-18 05:33:05 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-18 05:33:05 --> Final output sent to browser
INFO - 2025-11-18 05:33:05 --> Total execution time: 0.1175
INFO - 2025-11-18 05:33:05 --> Config Class Initialized
INFO - 2025-11-18 05:33:05 --> Hooks Class Initialized
INFO - 2025-11-18 05:33:05 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:33:05 --> Utf8 Class Initialized
INFO - 2025-11-18 05:33:05 --> URI Class Initialized
INFO - 2025-11-18 05:33:05 --> Router Class Initialized
INFO - 2025-11-18 05:33:05 --> Output Class Initialized
INFO - 2025-11-18 05:33:05 --> Security Class Initialized
INFO - 2025-11-18 05:33:05 --> Input Class Initialized
INFO - 2025-11-18 05:33:05 --> Language Class Initialized
INFO - 2025-11-18 05:33:05 --> Loader Class Initialized
INFO - 2025-11-18 05:33:05 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:33:05 --> Helper loaded: url_helper
INFO - 2025-11-18 05:33:05 --> Helper loaded: file_helper
INFO - 2025-11-18 05:33:05 --> Helper loaded: main_helper
INFO - 2025-11-18 05:33:05 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:33:05 --> Database Driver Class Initialized
INFO - 2025-11-18 05:33:05 --> Email Class Initialized
DEBUG - 2025-11-18 05:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:33:05 --> Controller Class Initialized
INFO - 2025-11-18 05:33:05 --> Model "User_model" initialized
INFO - 2025-11-18 05:33:05 --> Model "Project_model" initialized
INFO - 2025-11-18 05:33:05 --> Helper loaded: form_helper
INFO - 2025-11-18 05:33:05 --> Form Validation Class Initialized
INFO - 2025-11-18 05:33:05 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:33:05 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:33:05 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:33:05 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:05 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:05 --> Model "Topk_service_model" initialized
INFO - 2025-11-18 05:33:05 --> Final output sent to browser
INFO - 2025-11-18 05:33:05 --> Total execution time: 0.1202
INFO - 2025-11-18 05:33:07 --> Config Class Initialized
INFO - 2025-11-18 05:33:07 --> Hooks Class Initialized
INFO - 2025-11-18 05:33:07 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:33:07 --> Utf8 Class Initialized
INFO - 2025-11-18 05:33:07 --> URI Class Initialized
INFO - 2025-11-18 05:33:07 --> Router Class Initialized
INFO - 2025-11-18 05:33:07 --> Output Class Initialized
INFO - 2025-11-18 05:33:07 --> Security Class Initialized
INFO - 2025-11-18 05:33:07 --> Input Class Initialized
INFO - 2025-11-18 05:33:07 --> Language Class Initialized
INFO - 2025-11-18 05:33:07 --> Loader Class Initialized
INFO - 2025-11-18 05:33:07 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:33:07 --> Helper loaded: url_helper
INFO - 2025-11-18 05:33:07 --> Helper loaded: file_helper
INFO - 2025-11-18 05:33:07 --> Helper loaded: main_helper
INFO - 2025-11-18 05:33:07 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:33:07 --> Database Driver Class Initialized
INFO - 2025-11-18 05:33:07 --> Email Class Initialized
DEBUG - 2025-11-18 05:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:33:07 --> Controller Class Initialized
INFO - 2025-11-18 05:33:07 --> Model "User_model" initialized
INFO - 2025-11-18 05:33:07 --> Model "Project_model" initialized
INFO - 2025-11-18 05:33:07 --> Helper loaded: form_helper
INFO - 2025-11-18 05:33:07 --> Form Validation Class Initialized
INFO - 2025-11-18 05:33:07 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:33:07 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:33:07 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:33:07 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:07 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:07 --> Model "Topk_service_model" initialized
INFO - 2025-11-18 05:33:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-11-18 05:33:07 --> Final output sent to browser
INFO - 2025-11-18 05:33:07 --> Total execution time: 0.1219
INFO - 2025-11-18 05:33:07 --> Config Class Initialized
INFO - 2025-11-18 05:33:07 --> Hooks Class Initialized
INFO - 2025-11-18 05:33:07 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:33:07 --> Utf8 Class Initialized
INFO - 2025-11-18 05:33:07 --> URI Class Initialized
INFO - 2025-11-18 05:33:07 --> Router Class Initialized
INFO - 2025-11-18 05:33:07 --> Output Class Initialized
INFO - 2025-11-18 05:33:07 --> Security Class Initialized
INFO - 2025-11-18 05:33:07 --> Input Class Initialized
INFO - 2025-11-18 05:33:07 --> Language Class Initialized
INFO - 2025-11-18 05:33:07 --> Loader Class Initialized
INFO - 2025-11-18 05:33:07 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:33:07 --> Helper loaded: url_helper
INFO - 2025-11-18 05:33:07 --> Helper loaded: file_helper
INFO - 2025-11-18 05:33:07 --> Helper loaded: main_helper
INFO - 2025-11-18 05:33:07 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:33:07 --> Database Driver Class Initialized
INFO - 2025-11-18 05:33:07 --> Email Class Initialized
DEBUG - 2025-11-18 05:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:33:07 --> Controller Class Initialized
INFO - 2025-11-18 05:33:07 --> Model "Subscription_model" initialized
INFO - 2025-11-18 05:33:07 --> Model "User_model" initialized
INFO - 2025-11-18 05:33:07 --> Model "Auth_model" initialized
INFO - 2025-11-18 05:33:07 --> Model "Project_model" initialized
INFO - 2025-11-18 05:33:07 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-18 05:33:07 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-18 05:33:07 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-18 05:33:07 --> File loaded: D:\laragon\www\acumena\application\views\projects/swot.php
INFO - 2025-11-18 05:33:07 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-18 05:33:07 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-18 05:33:07 --> Final output sent to browser
INFO - 2025-11-18 05:33:07 --> Total execution time: 0.1116
INFO - 2025-11-18 05:33:07 --> Config Class Initialized
INFO - 2025-11-18 05:33:07 --> Hooks Class Initialized
INFO - 2025-11-18 05:33:07 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:33:07 --> Utf8 Class Initialized
INFO - 2025-11-18 05:33:07 --> URI Class Initialized
INFO - 2025-11-18 05:33:07 --> Router Class Initialized
INFO - 2025-11-18 05:33:07 --> Output Class Initialized
INFO - 2025-11-18 05:33:07 --> Security Class Initialized
INFO - 2025-11-18 05:33:07 --> Input Class Initialized
INFO - 2025-11-18 05:33:07 --> Language Class Initialized
INFO - 2025-11-18 05:33:07 --> Loader Class Initialized
INFO - 2025-11-18 05:33:07 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:33:07 --> Helper loaded: url_helper
INFO - 2025-11-18 05:33:07 --> Helper loaded: file_helper
INFO - 2025-11-18 05:33:07 --> Helper loaded: main_helper
INFO - 2025-11-18 05:33:07 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:33:07 --> Database Driver Class Initialized
INFO - 2025-11-18 05:33:07 --> Email Class Initialized
DEBUG - 2025-11-18 05:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:33:07 --> Controller Class Initialized
INFO - 2025-11-18 05:33:07 --> Model "User_model" initialized
INFO - 2025-11-18 05:33:07 --> Model "Project_model" initialized
INFO - 2025-11-18 05:33:07 --> Helper loaded: form_helper
INFO - 2025-11-18 05:33:07 --> Form Validation Class Initialized
INFO - 2025-11-18 05:33:07 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:33:07 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:33:07 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:33:07 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:07 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:07 --> Model "Topk_service_model" initialized
INFO - 2025-11-18 05:33:07 --> Final output sent to browser
INFO - 2025-11-18 05:33:07 --> Total execution time: 0.1291
INFO - 2025-11-18 05:33:41 --> Config Class Initialized
INFO - 2025-11-18 05:33:41 --> Hooks Class Initialized
INFO - 2025-11-18 05:33:41 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:33:41 --> Utf8 Class Initialized
INFO - 2025-11-18 05:33:41 --> URI Class Initialized
INFO - 2025-11-18 05:33:41 --> Router Class Initialized
INFO - 2025-11-18 05:33:41 --> Output Class Initialized
INFO - 2025-11-18 05:33:41 --> Security Class Initialized
INFO - 2025-11-18 05:33:41 --> Input Class Initialized
INFO - 2025-11-18 05:33:41 --> Language Class Initialized
INFO - 2025-11-18 05:33:41 --> Loader Class Initialized
INFO - 2025-11-18 05:33:41 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:33:41 --> Helper loaded: url_helper
INFO - 2025-11-18 05:33:41 --> Helper loaded: file_helper
INFO - 2025-11-18 05:33:41 --> Helper loaded: main_helper
INFO - 2025-11-18 05:33:41 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:33:41 --> Database Driver Class Initialized
INFO - 2025-11-18 05:33:41 --> Email Class Initialized
DEBUG - 2025-11-18 05:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:33:41 --> Controller Class Initialized
INFO - 2025-11-18 05:33:41 --> Model "Subscription_model" initialized
INFO - 2025-11-18 05:33:41 --> Model "User_model" initialized
INFO - 2025-11-18 05:33:41 --> Model "Auth_model" initialized
INFO - 2025-11-18 05:33:41 --> Model "Project_model" initialized
INFO - 2025-11-18 05:33:41 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-18 05:33:41 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-18 05:33:41 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-18 05:33:41 --> File loaded: D:\laragon\www\acumena\application\views\projects/index.php
INFO - 2025-11-18 05:33:41 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-18 05:33:41 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-18 05:33:41 --> Final output sent to browser
INFO - 2025-11-18 05:33:41 --> Total execution time: 0.1082
INFO - 2025-11-18 05:33:41 --> Config Class Initialized
INFO - 2025-11-18 05:33:41 --> Hooks Class Initialized
INFO - 2025-11-18 05:33:41 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:33:41 --> Utf8 Class Initialized
INFO - 2025-11-18 05:33:41 --> URI Class Initialized
INFO - 2025-11-18 05:33:41 --> Router Class Initialized
INFO - 2025-11-18 05:33:41 --> Output Class Initialized
INFO - 2025-11-18 05:33:41 --> Security Class Initialized
INFO - 2025-11-18 05:33:41 --> Input Class Initialized
INFO - 2025-11-18 05:33:41 --> Language Class Initialized
INFO - 2025-11-18 05:33:41 --> Loader Class Initialized
INFO - 2025-11-18 05:33:41 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:33:41 --> Helper loaded: url_helper
INFO - 2025-11-18 05:33:41 --> Helper loaded: file_helper
INFO - 2025-11-18 05:33:41 --> Helper loaded: main_helper
INFO - 2025-11-18 05:33:41 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:33:41 --> Database Driver Class Initialized
INFO - 2025-11-18 05:33:41 --> Email Class Initialized
DEBUG - 2025-11-18 05:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:33:41 --> Controller Class Initialized
INFO - 2025-11-18 05:33:41 --> Model "User_model" initialized
INFO - 2025-11-18 05:33:41 --> Model "Project_model" initialized
INFO - 2025-11-18 05:33:41 --> Helper loaded: form_helper
INFO - 2025-11-18 05:33:41 --> Form Validation Class Initialized
INFO - 2025-11-18 05:33:41 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:33:41 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:33:41 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:33:41 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:41 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:41 --> Model "Topk_service_model" initialized
INFO - 2025-11-18 05:33:41 --> Final output sent to browser
INFO - 2025-11-18 05:33:41 --> Total execution time: 0.0949
INFO - 2025-11-18 05:33:47 --> Config Class Initialized
INFO - 2025-11-18 05:33:47 --> Hooks Class Initialized
INFO - 2025-11-18 05:33:47 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:33:47 --> Utf8 Class Initialized
INFO - 2025-11-18 05:33:47 --> URI Class Initialized
INFO - 2025-11-18 05:33:47 --> Router Class Initialized
INFO - 2025-11-18 05:33:47 --> Output Class Initialized
INFO - 2025-11-18 05:33:47 --> Security Class Initialized
INFO - 2025-11-18 05:33:47 --> Input Class Initialized
INFO - 2025-11-18 05:33:47 --> Language Class Initialized
INFO - 2025-11-18 05:33:47 --> Loader Class Initialized
INFO - 2025-11-18 05:33:47 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:33:47 --> Helper loaded: url_helper
INFO - 2025-11-18 05:33:47 --> Helper loaded: file_helper
INFO - 2025-11-18 05:33:47 --> Helper loaded: main_helper
INFO - 2025-11-18 05:33:47 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:33:47 --> Database Driver Class Initialized
INFO - 2025-11-18 05:33:47 --> Email Class Initialized
DEBUG - 2025-11-18 05:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:33:47 --> Controller Class Initialized
INFO - 2025-11-18 05:33:47 --> Model "Subscription_model" initialized
INFO - 2025-11-18 05:33:47 --> Model "User_model" initialized
INFO - 2025-11-18 05:33:47 --> Model "Auth_model" initialized
INFO - 2025-11-18 05:33:47 --> Model "Project_model" initialized
INFO - 2025-11-18 05:33:47 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-18 05:33:47 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-18 05:33:47 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-18 05:33:47 --> File loaded: D:\laragon\www\acumena\application\views\projects/profile.php
INFO - 2025-11-18 05:33:47 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-18 05:33:47 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-18 05:33:47 --> Final output sent to browser
INFO - 2025-11-18 05:33:47 --> Total execution time: 0.1011
INFO - 2025-11-18 05:33:47 --> Config Class Initialized
INFO - 2025-11-18 05:33:47 --> Hooks Class Initialized
INFO - 2025-11-18 05:33:47 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:33:47 --> Utf8 Class Initialized
INFO - 2025-11-18 05:33:47 --> URI Class Initialized
INFO - 2025-11-18 05:33:47 --> Router Class Initialized
INFO - 2025-11-18 05:33:47 --> Output Class Initialized
INFO - 2025-11-18 05:33:47 --> Security Class Initialized
INFO - 2025-11-18 05:33:47 --> Input Class Initialized
INFO - 2025-11-18 05:33:47 --> Language Class Initialized
INFO - 2025-11-18 05:33:47 --> Loader Class Initialized
INFO - 2025-11-18 05:33:47 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:33:47 --> Helper loaded: url_helper
INFO - 2025-11-18 05:33:48 --> Helper loaded: file_helper
INFO - 2025-11-18 05:33:48 --> Helper loaded: main_helper
INFO - 2025-11-18 05:33:48 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:33:48 --> Database Driver Class Initialized
INFO - 2025-11-18 05:33:48 --> Email Class Initialized
DEBUG - 2025-11-18 05:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:33:48 --> Controller Class Initialized
INFO - 2025-11-18 05:33:48 --> Model "User_model" initialized
INFO - 2025-11-18 05:33:48 --> Model "Project_model" initialized
INFO - 2025-11-18 05:33:48 --> Helper loaded: form_helper
INFO - 2025-11-18 05:33:48 --> Form Validation Class Initialized
INFO - 2025-11-18 05:33:48 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:33:48 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:33:48 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:33:48 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:48 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:48 --> Model "Topk_service_model" initialized
INFO - 2025-11-18 05:33:48 --> Final output sent to browser
INFO - 2025-11-18 05:33:48 --> Total execution time: 0.1090
INFO - 2025-11-18 05:33:50 --> Config Class Initialized
INFO - 2025-11-18 05:33:50 --> Hooks Class Initialized
INFO - 2025-11-18 05:33:50 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:33:50 --> Utf8 Class Initialized
INFO - 2025-11-18 05:33:50 --> URI Class Initialized
INFO - 2025-11-18 05:33:50 --> Router Class Initialized
INFO - 2025-11-18 05:33:50 --> Output Class Initialized
INFO - 2025-11-18 05:33:50 --> Security Class Initialized
INFO - 2025-11-18 05:33:50 --> Input Class Initialized
INFO - 2025-11-18 05:33:50 --> Language Class Initialized
INFO - 2025-11-18 05:33:50 --> Loader Class Initialized
INFO - 2025-11-18 05:33:50 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:33:50 --> Helper loaded: url_helper
INFO - 2025-11-18 05:33:50 --> Helper loaded: file_helper
INFO - 2025-11-18 05:33:50 --> Helper loaded: main_helper
INFO - 2025-11-18 05:33:50 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:33:50 --> Database Driver Class Initialized
INFO - 2025-11-18 05:33:50 --> Email Class Initialized
DEBUG - 2025-11-18 05:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:33:50 --> Controller Class Initialized
INFO - 2025-11-18 05:33:50 --> Model "User_model" initialized
INFO - 2025-11-18 05:33:50 --> Model "Project_model" initialized
INFO - 2025-11-18 05:33:50 --> Helper loaded: form_helper
INFO - 2025-11-18 05:33:50 --> Form Validation Class Initialized
INFO - 2025-11-18 05:33:50 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:33:50 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:33:50 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:33:50 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:50 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:50 --> Model "Topk_service_model" initialized
INFO - 2025-11-18 05:33:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-11-18 05:33:50 --> Final output sent to browser
INFO - 2025-11-18 05:33:50 --> Total execution time: 0.1076
INFO - 2025-11-18 05:33:50 --> Config Class Initialized
INFO - 2025-11-18 05:33:50 --> Hooks Class Initialized
INFO - 2025-11-18 05:33:50 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:33:50 --> Utf8 Class Initialized
INFO - 2025-11-18 05:33:50 --> URI Class Initialized
INFO - 2025-11-18 05:33:50 --> Router Class Initialized
INFO - 2025-11-18 05:33:50 --> Output Class Initialized
INFO - 2025-11-18 05:33:50 --> Security Class Initialized
INFO - 2025-11-18 05:33:50 --> Input Class Initialized
INFO - 2025-11-18 05:33:50 --> Language Class Initialized
INFO - 2025-11-18 05:33:50 --> Loader Class Initialized
INFO - 2025-11-18 05:33:50 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:33:50 --> Helper loaded: url_helper
INFO - 2025-11-18 05:33:50 --> Helper loaded: file_helper
INFO - 2025-11-18 05:33:50 --> Helper loaded: main_helper
INFO - 2025-11-18 05:33:50 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:33:50 --> Database Driver Class Initialized
INFO - 2025-11-18 05:33:50 --> Email Class Initialized
DEBUG - 2025-11-18 05:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:33:50 --> Controller Class Initialized
INFO - 2025-11-18 05:33:50 --> Model "Subscription_model" initialized
INFO - 2025-11-18 05:33:50 --> Model "User_model" initialized
INFO - 2025-11-18 05:33:50 --> Model "Auth_model" initialized
INFO - 2025-11-18 05:33:50 --> Model "Project_model" initialized
INFO - 2025-11-18 05:33:50 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-18 05:33:50 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-18 05:33:50 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-18 05:33:50 --> File loaded: D:\laragon\www\acumena\application\views\projects/swot.php
INFO - 2025-11-18 05:33:50 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-18 05:33:50 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-18 05:33:50 --> Final output sent to browser
INFO - 2025-11-18 05:33:50 --> Total execution time: 0.1003
INFO - 2025-11-18 05:33:50 --> Config Class Initialized
INFO - 2025-11-18 05:33:50 --> Hooks Class Initialized
INFO - 2025-11-18 05:33:50 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:33:50 --> Utf8 Class Initialized
INFO - 2025-11-18 05:33:50 --> URI Class Initialized
INFO - 2025-11-18 05:33:50 --> Router Class Initialized
INFO - 2025-11-18 05:33:50 --> Output Class Initialized
INFO - 2025-11-18 05:33:50 --> Security Class Initialized
INFO - 2025-11-18 05:33:50 --> Input Class Initialized
INFO - 2025-11-18 05:33:50 --> Language Class Initialized
INFO - 2025-11-18 05:33:50 --> Loader Class Initialized
INFO - 2025-11-18 05:33:50 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:33:50 --> Helper loaded: url_helper
INFO - 2025-11-18 05:33:50 --> Helper loaded: file_helper
INFO - 2025-11-18 05:33:50 --> Helper loaded: main_helper
INFO - 2025-11-18 05:33:50 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:33:50 --> Database Driver Class Initialized
INFO - 2025-11-18 05:33:50 --> Email Class Initialized
DEBUG - 2025-11-18 05:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:33:50 --> Controller Class Initialized
INFO - 2025-11-18 05:33:50 --> Model "User_model" initialized
INFO - 2025-11-18 05:33:50 --> Model "Project_model" initialized
INFO - 2025-11-18 05:33:50 --> Helper loaded: form_helper
INFO - 2025-11-18 05:33:50 --> Form Validation Class Initialized
INFO - 2025-11-18 05:33:50 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:33:50 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:33:50 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:33:50 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:50 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:50 --> Model "Topk_service_model" initialized
INFO - 2025-11-18 05:33:50 --> Final output sent to browser
INFO - 2025-11-18 05:33:50 --> Total execution time: 0.1263
INFO - 2025-11-18 05:33:52 --> Config Class Initialized
INFO - 2025-11-18 05:33:52 --> Hooks Class Initialized
INFO - 2025-11-18 05:33:52 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:33:52 --> Utf8 Class Initialized
INFO - 2025-11-18 05:33:52 --> URI Class Initialized
INFO - 2025-11-18 05:33:52 --> Router Class Initialized
INFO - 2025-11-18 05:33:52 --> Output Class Initialized
INFO - 2025-11-18 05:33:52 --> Security Class Initialized
INFO - 2025-11-18 05:33:52 --> Input Class Initialized
INFO - 2025-11-18 05:33:52 --> Language Class Initialized
INFO - 2025-11-18 05:33:52 --> Loader Class Initialized
INFO - 2025-11-18 05:33:52 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:33:52 --> Helper loaded: url_helper
INFO - 2025-11-18 05:33:52 --> Helper loaded: file_helper
INFO - 2025-11-18 05:33:52 --> Helper loaded: main_helper
INFO - 2025-11-18 05:33:52 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:33:52 --> Database Driver Class Initialized
INFO - 2025-11-18 05:33:53 --> Email Class Initialized
DEBUG - 2025-11-18 05:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:33:53 --> Controller Class Initialized
INFO - 2025-11-18 05:33:53 --> Model "User_model" initialized
INFO - 2025-11-18 05:33:53 --> Model "Project_model" initialized
INFO - 2025-11-18 05:33:53 --> Helper loaded: form_helper
INFO - 2025-11-18 05:33:53 --> Form Validation Class Initialized
INFO - 2025-11-18 05:33:53 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:33:53 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:33:53 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:33:53 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:53 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:53 --> Model "Topk_service_model" initialized
INFO - 2025-11-18 05:33:53 --> Final output sent to browser
INFO - 2025-11-18 05:33:53 --> Total execution time: 0.1319
INFO - 2025-11-18 05:33:53 --> Config Class Initialized
INFO - 2025-11-18 05:33:53 --> Hooks Class Initialized
INFO - 2025-11-18 05:33:53 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:33:53 --> Utf8 Class Initialized
INFO - 2025-11-18 05:33:53 --> URI Class Initialized
INFO - 2025-11-18 05:33:53 --> Router Class Initialized
INFO - 2025-11-18 05:33:53 --> Output Class Initialized
INFO - 2025-11-18 05:33:53 --> Security Class Initialized
INFO - 2025-11-18 05:33:53 --> Input Class Initialized
INFO - 2025-11-18 05:33:53 --> Language Class Initialized
INFO - 2025-11-18 05:33:53 --> Loader Class Initialized
INFO - 2025-11-18 05:33:53 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:33:53 --> Helper loaded: url_helper
INFO - 2025-11-18 05:33:53 --> Helper loaded: file_helper
INFO - 2025-11-18 05:33:53 --> Helper loaded: main_helper
INFO - 2025-11-18 05:33:53 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:33:53 --> Database Driver Class Initialized
INFO - 2025-11-18 05:33:53 --> Email Class Initialized
DEBUG - 2025-11-18 05:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:33:53 --> Controller Class Initialized
INFO - 2025-11-18 05:33:53 --> Model "Subscription_model" initialized
INFO - 2025-11-18 05:33:53 --> Model "User_model" initialized
INFO - 2025-11-18 05:33:53 --> Model "Auth_model" initialized
INFO - 2025-11-18 05:33:53 --> Model "Project_model" initialized
INFO - 2025-11-18 05:33:53 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-18 05:33:53 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-18 05:33:53 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-18 05:33:53 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ife.php
INFO - 2025-11-18 05:33:53 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-18 05:33:53 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-18 05:33:53 --> Final output sent to browser
INFO - 2025-11-18 05:33:53 --> Total execution time: 0.1051
INFO - 2025-11-18 05:33:53 --> Config Class Initialized
INFO - 2025-11-18 05:33:53 --> Hooks Class Initialized
INFO - 2025-11-18 05:33:53 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:33:53 --> Utf8 Class Initialized
INFO - 2025-11-18 05:33:53 --> URI Class Initialized
INFO - 2025-11-18 05:33:53 --> Router Class Initialized
INFO - 2025-11-18 05:33:53 --> Output Class Initialized
INFO - 2025-11-18 05:33:53 --> Security Class Initialized
INFO - 2025-11-18 05:33:53 --> Input Class Initialized
INFO - 2025-11-18 05:33:53 --> Language Class Initialized
INFO - 2025-11-18 05:33:53 --> Loader Class Initialized
INFO - 2025-11-18 05:33:53 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:33:53 --> Helper loaded: url_helper
INFO - 2025-11-18 05:33:53 --> Helper loaded: file_helper
INFO - 2025-11-18 05:33:53 --> Helper loaded: main_helper
INFO - 2025-11-18 05:33:53 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:33:53 --> Database Driver Class Initialized
INFO - 2025-11-18 05:33:53 --> Email Class Initialized
DEBUG - 2025-11-18 05:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:33:53 --> Controller Class Initialized
INFO - 2025-11-18 05:33:53 --> Model "User_model" initialized
INFO - 2025-11-18 05:33:53 --> Model "Project_model" initialized
INFO - 2025-11-18 05:33:53 --> Helper loaded: form_helper
INFO - 2025-11-18 05:33:53 --> Form Validation Class Initialized
INFO - 2025-11-18 05:33:53 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:33:53 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:33:53 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:33:53 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:53 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:53 --> Model "Topk_service_model" initialized
INFO - 2025-11-18 05:33:53 --> Final output sent to browser
INFO - 2025-11-18 05:33:53 --> Total execution time: 0.0980
INFO - 2025-11-18 05:33:56 --> Config Class Initialized
INFO - 2025-11-18 05:33:56 --> Hooks Class Initialized
INFO - 2025-11-18 05:33:56 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:33:56 --> Utf8 Class Initialized
INFO - 2025-11-18 05:33:56 --> URI Class Initialized
INFO - 2025-11-18 05:33:56 --> Router Class Initialized
INFO - 2025-11-18 05:33:56 --> Output Class Initialized
INFO - 2025-11-18 05:33:56 --> Security Class Initialized
INFO - 2025-11-18 05:33:56 --> Input Class Initialized
INFO - 2025-11-18 05:33:56 --> Language Class Initialized
INFO - 2025-11-18 05:33:56 --> Loader Class Initialized
INFO - 2025-11-18 05:33:56 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:33:56 --> Helper loaded: url_helper
INFO - 2025-11-18 05:33:56 --> Helper loaded: file_helper
INFO - 2025-11-18 05:33:56 --> Helper loaded: main_helper
INFO - 2025-11-18 05:33:56 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:33:56 --> Database Driver Class Initialized
INFO - 2025-11-18 05:33:56 --> Email Class Initialized
DEBUG - 2025-11-18 05:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:33:56 --> Controller Class Initialized
INFO - 2025-11-18 05:33:56 --> Model "Subscription_model" initialized
INFO - 2025-11-18 05:33:56 --> Model "User_model" initialized
INFO - 2025-11-18 05:33:56 --> Model "Auth_model" initialized
INFO - 2025-11-18 05:33:56 --> Model "Project_model" initialized
INFO - 2025-11-18 05:33:56 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-18 05:33:56 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-18 05:33:56 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-18 05:33:56 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ai.php
INFO - 2025-11-18 05:33:56 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-18 05:33:56 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-18 05:33:56 --> Final output sent to browser
INFO - 2025-11-18 05:33:56 --> Total execution time: 0.0942
INFO - 2025-11-18 05:33:56 --> Config Class Initialized
INFO - 2025-11-18 05:33:56 --> Hooks Class Initialized
INFO - 2025-11-18 05:33:56 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:33:56 --> Utf8 Class Initialized
INFO - 2025-11-18 05:33:56 --> URI Class Initialized
INFO - 2025-11-18 05:33:56 --> Router Class Initialized
INFO - 2025-11-18 05:33:56 --> Output Class Initialized
INFO - 2025-11-18 05:33:56 --> Security Class Initialized
INFO - 2025-11-18 05:33:56 --> Input Class Initialized
INFO - 2025-11-18 05:33:56 --> Language Class Initialized
INFO - 2025-11-18 05:33:56 --> Loader Class Initialized
INFO - 2025-11-18 05:33:56 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:33:56 --> Helper loaded: url_helper
INFO - 2025-11-18 05:33:56 --> Helper loaded: file_helper
INFO - 2025-11-18 05:33:56 --> Helper loaded: main_helper
INFO - 2025-11-18 05:33:56 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:33:56 --> Database Driver Class Initialized
INFO - 2025-11-18 05:33:56 --> Email Class Initialized
DEBUG - 2025-11-18 05:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:33:56 --> Controller Class Initialized
INFO - 2025-11-18 05:33:56 --> Model "User_model" initialized
INFO - 2025-11-18 05:33:56 --> Model "Project_model" initialized
INFO - 2025-11-18 05:33:56 --> Helper loaded: form_helper
INFO - 2025-11-18 05:33:56 --> Form Validation Class Initialized
INFO - 2025-11-18 05:33:56 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:33:56 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:33:56 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:33:56 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:56 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:56 --> Model "Topk_service_model" initialized
INFO - 2025-11-18 05:33:56 --> Final output sent to browser
INFO - 2025-11-18 05:33:56 --> Total execution time: 0.1180
INFO - 2025-11-18 05:33:56 --> Config Class Initialized
INFO - 2025-11-18 05:33:56 --> Config Class Initialized
INFO - 2025-11-18 05:33:56 --> Config Class Initialized
INFO - 2025-11-18 05:33:56 --> Hooks Class Initialized
INFO - 2025-11-18 05:33:56 --> Hooks Class Initialized
INFO - 2025-11-18 05:33:56 --> Hooks Class Initialized
INFO - 2025-11-18 05:33:56 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:33:56 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:33:56 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:33:56 --> Utf8 Class Initialized
INFO - 2025-11-18 05:33:56 --> Utf8 Class Initialized
INFO - 2025-11-18 05:33:56 --> Utf8 Class Initialized
INFO - 2025-11-18 05:33:56 --> URI Class Initialized
INFO - 2025-11-18 05:33:56 --> URI Class Initialized
INFO - 2025-11-18 05:33:56 --> URI Class Initialized
INFO - 2025-11-18 05:33:56 --> Router Class Initialized
INFO - 2025-11-18 05:33:56 --> Router Class Initialized
INFO - 2025-11-18 05:33:56 --> Router Class Initialized
INFO - 2025-11-18 05:33:56 --> Output Class Initialized
INFO - 2025-11-18 05:33:56 --> Output Class Initialized
INFO - 2025-11-18 05:33:56 --> Output Class Initialized
INFO - 2025-11-18 05:33:56 --> Security Class Initialized
INFO - 2025-11-18 05:33:56 --> Security Class Initialized
INFO - 2025-11-18 05:33:56 --> Security Class Initialized
INFO - 2025-11-18 05:33:56 --> Input Class Initialized
INFO - 2025-11-18 05:33:56 --> Input Class Initialized
INFO - 2025-11-18 05:33:56 --> Input Class Initialized
INFO - 2025-11-18 05:33:56 --> Language Class Initialized
INFO - 2025-11-18 05:33:56 --> Language Class Initialized
INFO - 2025-11-18 05:33:56 --> Language Class Initialized
INFO - 2025-11-18 05:33:56 --> Loader Class Initialized
INFO - 2025-11-18 05:33:56 --> Loader Class Initialized
INFO - 2025-11-18 05:33:56 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:33:56 --> Loader Class Initialized
INFO - 2025-11-18 05:33:56 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:33:56 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:33:56 --> Helper loaded: url_helper
INFO - 2025-11-18 05:33:56 --> Helper loaded: url_helper
INFO - 2025-11-18 05:33:56 --> Helper loaded: url_helper
INFO - 2025-11-18 05:33:56 --> Helper loaded: file_helper
INFO - 2025-11-18 05:33:56 --> Helper loaded: file_helper
INFO - 2025-11-18 05:33:56 --> Helper loaded: file_helper
INFO - 2025-11-18 05:33:56 --> Helper loaded: main_helper
INFO - 2025-11-18 05:33:56 --> Helper loaded: main_helper
INFO - 2025-11-18 05:33:56 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:33:56 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:33:56 --> Helper loaded: main_helper
INFO - 2025-11-18 05:33:56 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:33:56 --> Database Driver Class Initialized
INFO - 2025-11-18 05:33:56 --> Database Driver Class Initialized
INFO - 2025-11-18 05:33:56 --> Database Driver Class Initialized
INFO - 2025-11-18 05:33:56 --> Email Class Initialized
INFO - 2025-11-18 05:33:56 --> Email Class Initialized
INFO - 2025-11-18 05:33:56 --> Email Class Initialized
DEBUG - 2025-11-18 05:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-11-18 05:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:33:56 --> Controller Class Initialized
DEBUG - 2025-11-18 05:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:33:56 --> Model "User_model" initialized
INFO - 2025-11-18 05:33:56 --> Model "Project_model" initialized
INFO - 2025-11-18 05:33:56 --> Helper loaded: form_helper
INFO - 2025-11-18 05:33:56 --> Form Validation Class Initialized
INFO - 2025-11-18 05:33:56 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:33:56 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:33:56 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:33:56 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:56 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:56 --> Model "Topk_service_model" initialized
INFO - 2025-11-18 05:33:56 --> Final output sent to browser
INFO - 2025-11-18 05:33:56 --> Total execution time: 0.1274
INFO - 2025-11-18 05:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:33:56 --> Controller Class Initialized
INFO - 2025-11-18 05:33:56 --> Model "User_model" initialized
INFO - 2025-11-18 05:33:56 --> Model "Project_model" initialized
INFO - 2025-11-18 05:33:56 --> Helper loaded: form_helper
INFO - 2025-11-18 05:33:56 --> Form Validation Class Initialized
INFO - 2025-11-18 05:33:56 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:33:56 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:33:56 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:33:56 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:56 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:56 --> Model "Topk_service_model" initialized
INFO - 2025-11-18 05:33:56 --> Final output sent to browser
INFO - 2025-11-18 05:33:56 --> Total execution time: 0.1517
INFO - 2025-11-18 05:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:33:57 --> Controller Class Initialized
INFO - 2025-11-18 05:33:57 --> Model "User_model" initialized
INFO - 2025-11-18 05:33:57 --> Model "Project_model" initialized
INFO - 2025-11-18 05:33:57 --> Helper loaded: form_helper
INFO - 2025-11-18 05:33:57 --> Form Validation Class Initialized
INFO - 2025-11-18 05:33:57 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:33:57 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:33:57 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:33:57 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:57 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:57 --> Model "Topk_service_model" initialized
INFO - 2025-11-18 05:33:57 --> Final output sent to browser
INFO - 2025-11-18 05:33:57 --> Total execution time: 0.1930
INFO - 2025-11-18 05:33:57 --> Config Class Initialized
INFO - 2025-11-18 05:33:57 --> Hooks Class Initialized
INFO - 2025-11-18 05:33:57 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:33:57 --> Utf8 Class Initialized
INFO - 2025-11-18 05:33:57 --> URI Class Initialized
INFO - 2025-11-18 05:33:57 --> Router Class Initialized
INFO - 2025-11-18 05:33:57 --> Output Class Initialized
INFO - 2025-11-18 05:33:57 --> Security Class Initialized
INFO - 2025-11-18 05:33:57 --> Input Class Initialized
INFO - 2025-11-18 05:33:57 --> Language Class Initialized
INFO - 2025-11-18 05:33:57 --> Loader Class Initialized
INFO - 2025-11-18 05:33:57 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:33:57 --> Helper loaded: url_helper
INFO - 2025-11-18 05:33:57 --> Helper loaded: file_helper
INFO - 2025-11-18 05:33:57 --> Helper loaded: main_helper
INFO - 2025-11-18 05:33:57 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:33:57 --> Database Driver Class Initialized
INFO - 2025-11-18 05:33:57 --> Email Class Initialized
DEBUG - 2025-11-18 05:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:33:57 --> Controller Class Initialized
INFO - 2025-11-18 05:33:57 --> Model "User_model" initialized
INFO - 2025-11-18 05:33:57 --> Model "Project_model" initialized
INFO - 2025-11-18 05:33:57 --> Helper loaded: form_helper
INFO - 2025-11-18 05:33:57 --> Form Validation Class Initialized
INFO - 2025-11-18 05:33:57 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:33:57 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:33:57 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:33:57 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:57 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:33:57 --> Model "Topk_service_model" initialized
INFO - 2025-11-18 05:33:57 --> Final output sent to browser
INFO - 2025-11-18 05:33:57 --> Total execution time: 0.0968
INFO - 2025-11-18 05:34:02 --> Config Class Initialized
INFO - 2025-11-18 05:34:02 --> Hooks Class Initialized
INFO - 2025-11-18 05:34:02 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:34:02 --> Utf8 Class Initialized
INFO - 2025-11-18 05:34:02 --> URI Class Initialized
INFO - 2025-11-18 05:34:02 --> Router Class Initialized
INFO - 2025-11-18 05:34:02 --> Output Class Initialized
INFO - 2025-11-18 05:34:02 --> Security Class Initialized
INFO - 2025-11-18 05:34:02 --> Input Class Initialized
INFO - 2025-11-18 05:34:02 --> Language Class Initialized
INFO - 2025-11-18 05:34:02 --> Loader Class Initialized
INFO - 2025-11-18 05:34:02 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:34:02 --> Helper loaded: url_helper
INFO - 2025-11-18 05:34:02 --> Helper loaded: file_helper
INFO - 2025-11-18 05:34:02 --> Helper loaded: main_helper
INFO - 2025-11-18 05:34:02 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:34:02 --> Database Driver Class Initialized
INFO - 2025-11-18 05:34:02 --> Email Class Initialized
DEBUG - 2025-11-18 05:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:34:02 --> Controller Class Initialized
INFO - 2025-11-18 05:34:02 --> Model "User_model" initialized
INFO - 2025-11-18 05:34:02 --> Model "Project_model" initialized
INFO - 2025-11-18 05:34:02 --> Helper loaded: form_helper
INFO - 2025-11-18 05:34:02 --> Form Validation Class Initialized
INFO - 2025-11-18 05:34:02 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:34:02 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:34:02 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:34:02 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:34:02 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:34:02 --> Model "Topk_service_model" initialized
INFO - 2025-11-18 05:34:02 --> Final output sent to browser
INFO - 2025-11-18 05:34:02 --> Total execution time: 0.1055
INFO - 2025-11-18 05:34:02 --> Config Class Initialized
INFO - 2025-11-18 05:34:02 --> Hooks Class Initialized
INFO - 2025-11-18 05:34:02 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:34:02 --> Utf8 Class Initialized
INFO - 2025-11-18 05:34:02 --> URI Class Initialized
INFO - 2025-11-18 05:34:02 --> Router Class Initialized
INFO - 2025-11-18 05:34:02 --> Output Class Initialized
INFO - 2025-11-18 05:34:02 --> Security Class Initialized
INFO - 2025-11-18 05:34:02 --> Input Class Initialized
INFO - 2025-11-18 05:34:02 --> Language Class Initialized
INFO - 2025-11-18 05:34:02 --> Loader Class Initialized
INFO - 2025-11-18 05:34:02 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:34:02 --> Helper loaded: url_helper
INFO - 2025-11-18 05:34:02 --> Helper loaded: file_helper
INFO - 2025-11-18 05:34:02 --> Helper loaded: main_helper
INFO - 2025-11-18 05:34:02 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:34:02 --> Database Driver Class Initialized
INFO - 2025-11-18 05:34:02 --> Email Class Initialized
DEBUG - 2025-11-18 05:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:34:02 --> Controller Class Initialized
INFO - 2025-11-18 05:34:02 --> Model "User_model" initialized
INFO - 2025-11-18 05:34:02 --> Model "Project_model" initialized
INFO - 2025-11-18 05:34:02 --> Helper loaded: form_helper
INFO - 2025-11-18 05:34:02 --> Form Validation Class Initialized
INFO - 2025-11-18 05:34:02 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:34:02 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:34:02 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:34:02 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:34:02 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:34:02 --> Model "Topk_service_model" initialized
ERROR - 2025-11-18 05:34:15 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 282,
    "totalTokenCount": 1081,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 282
      }
    ],
    "thoughtsTokenCount": 799
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "VQUcaa6ZBeLdqfkP07SQgQw"
}

INFO - 2025-11-18 05:34:15 --> Final output sent to browser
INFO - 2025-11-18 05:34:15 --> Total execution time: 12.9015
INFO - 2025-11-18 05:34:15 --> Config Class Initialized
INFO - 2025-11-18 05:34:15 --> Hooks Class Initialized
INFO - 2025-11-18 05:34:15 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:34:15 --> Utf8 Class Initialized
INFO - 2025-11-18 05:34:15 --> URI Class Initialized
INFO - 2025-11-18 05:34:15 --> Router Class Initialized
INFO - 2025-11-18 05:34:15 --> Output Class Initialized
INFO - 2025-11-18 05:34:15 --> Security Class Initialized
INFO - 2025-11-18 05:34:15 --> Input Class Initialized
INFO - 2025-11-18 05:34:15 --> Language Class Initialized
INFO - 2025-11-18 05:34:15 --> Loader Class Initialized
INFO - 2025-11-18 05:34:15 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:34:15 --> Helper loaded: url_helper
INFO - 2025-11-18 05:34:15 --> Helper loaded: file_helper
INFO - 2025-11-18 05:34:15 --> Helper loaded: main_helper
INFO - 2025-11-18 05:34:15 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:34:15 --> Database Driver Class Initialized
INFO - 2025-11-18 05:34:15 --> Email Class Initialized
DEBUG - 2025-11-18 05:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:34:15 --> Controller Class Initialized
INFO - 2025-11-18 05:34:15 --> Model "User_model" initialized
INFO - 2025-11-18 05:34:15 --> Model "Project_model" initialized
INFO - 2025-11-18 05:34:15 --> Helper loaded: form_helper
INFO - 2025-11-18 05:34:15 --> Form Validation Class Initialized
INFO - 2025-11-18 05:34:15 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:34:15 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:34:15 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:34:15 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:34:15 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:34:15 --> Model "Topk_service_model" initialized
ERROR - 2025-11-18 05:34:20 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 350,
    "totalTokenCount": 1049,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 350
      }
    ],
    "thoughtsTokenCount": 699
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "WgUcaeqGGazv4-EPqqe5wQ8"
}

ERROR - 2025-11-18 05:34:24 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 367,
    "totalTokenCount": 855,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 367
      }
    ],
    "thoughtsTokenCount": 488
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "XQUcadSXKPL_4-EP6s7EkAw"
}

ERROR - 2025-11-18 05:34:24 --> strategies error: AI tidak mengembalikan data strategi (respons kosong atau format tidak sesuai).
INFO - 2025-11-18 05:34:24 --> Final output sent to browser
INFO - 2025-11-18 05:34:24 --> Total execution time: 8.6097
INFO - 2025-11-18 05:37:11 --> Config Class Initialized
INFO - 2025-11-18 05:37:11 --> Hooks Class Initialized
INFO - 2025-11-18 05:37:11 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:37:11 --> Utf8 Class Initialized
INFO - 2025-11-18 05:37:11 --> URI Class Initialized
INFO - 2025-11-18 05:37:11 --> Router Class Initialized
INFO - 2025-11-18 05:37:11 --> Output Class Initialized
INFO - 2025-11-18 05:37:11 --> Security Class Initialized
INFO - 2025-11-18 05:37:11 --> Input Class Initialized
INFO - 2025-11-18 05:37:11 --> Language Class Initialized
INFO - 2025-11-18 05:37:11 --> Loader Class Initialized
INFO - 2025-11-18 05:37:11 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:37:11 --> Helper loaded: url_helper
INFO - 2025-11-18 05:37:11 --> Helper loaded: file_helper
INFO - 2025-11-18 05:37:11 --> Helper loaded: main_helper
INFO - 2025-11-18 05:37:11 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:37:11 --> Database Driver Class Initialized
INFO - 2025-11-18 05:37:11 --> Email Class Initialized
DEBUG - 2025-11-18 05:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:37:11 --> Controller Class Initialized
INFO - 2025-11-18 05:37:11 --> Model "Subscription_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "User_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "Auth_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "Project_model" initialized
INFO - 2025-11-18 05:37:11 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-18 05:37:11 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-18 05:37:11 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-18 05:37:11 --> File loaded: D:\laragon\www\acumena\application\views\projects/matrix-ai.php
INFO - 2025-11-18 05:37:11 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-18 05:37:11 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-18 05:37:11 --> Final output sent to browser
INFO - 2025-11-18 05:37:11 --> Total execution time: 0.1300
INFO - 2025-11-18 05:37:11 --> Config Class Initialized
INFO - 2025-11-18 05:37:11 --> Hooks Class Initialized
INFO - 2025-11-18 05:37:11 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:37:11 --> Utf8 Class Initialized
INFO - 2025-11-18 05:37:11 --> URI Class Initialized
INFO - 2025-11-18 05:37:11 --> Router Class Initialized
INFO - 2025-11-18 05:37:11 --> Output Class Initialized
INFO - 2025-11-18 05:37:11 --> Security Class Initialized
INFO - 2025-11-18 05:37:11 --> Input Class Initialized
INFO - 2025-11-18 05:37:11 --> Language Class Initialized
INFO - 2025-11-18 05:37:11 --> Loader Class Initialized
INFO - 2025-11-18 05:37:11 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:37:11 --> Helper loaded: url_helper
INFO - 2025-11-18 05:37:11 --> Helper loaded: file_helper
INFO - 2025-11-18 05:37:11 --> Helper loaded: main_helper
INFO - 2025-11-18 05:37:11 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:37:11 --> Database Driver Class Initialized
INFO - 2025-11-18 05:37:11 --> Email Class Initialized
DEBUG - 2025-11-18 05:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:37:11 --> Controller Class Initialized
INFO - 2025-11-18 05:37:11 --> Model "User_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "Project_model" initialized
INFO - 2025-11-18 05:37:11 --> Helper loaded: form_helper
INFO - 2025-11-18 05:37:11 --> Form Validation Class Initialized
INFO - 2025-11-18 05:37:11 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "Topk_service_model" initialized
INFO - 2025-11-18 05:37:11 --> Final output sent to browser
INFO - 2025-11-18 05:37:11 --> Total execution time: 0.0856
INFO - 2025-11-18 05:37:11 --> Config Class Initialized
INFO - 2025-11-18 05:37:11 --> Hooks Class Initialized
INFO - 2025-11-18 05:37:11 --> Config Class Initialized
INFO - 2025-11-18 05:37:11 --> Config Class Initialized
INFO - 2025-11-18 05:37:11 --> Hooks Class Initialized
INFO - 2025-11-18 05:37:11 --> Hooks Class Initialized
INFO - 2025-11-18 05:37:11 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:37:11 --> Utf8 Class Initialized
INFO - 2025-11-18 05:37:11 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:37:11 --> Utf8 Class Initialized
INFO - 2025-11-18 05:37:11 --> URI Class Initialized
INFO - 2025-11-18 05:37:11 --> URI Class Initialized
INFO - 2025-11-18 05:37:11 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:37:11 --> Utf8 Class Initialized
INFO - 2025-11-18 05:37:11 --> Router Class Initialized
INFO - 2025-11-18 05:37:11 --> URI Class Initialized
INFO - 2025-11-18 05:37:11 --> Router Class Initialized
INFO - 2025-11-18 05:37:11 --> Router Class Initialized
INFO - 2025-11-18 05:37:11 --> Output Class Initialized
INFO - 2025-11-18 05:37:11 --> Output Class Initialized
INFO - 2025-11-18 05:37:11 --> Output Class Initialized
INFO - 2025-11-18 05:37:11 --> Security Class Initialized
INFO - 2025-11-18 05:37:11 --> Security Class Initialized
INFO - 2025-11-18 05:37:11 --> Input Class Initialized
INFO - 2025-11-18 05:37:11 --> Input Class Initialized
INFO - 2025-11-18 05:37:11 --> Security Class Initialized
INFO - 2025-11-18 05:37:11 --> Language Class Initialized
INFO - 2025-11-18 05:37:11 --> Language Class Initialized
INFO - 2025-11-18 05:37:11 --> Input Class Initialized
INFO - 2025-11-18 05:37:11 --> Language Class Initialized
INFO - 2025-11-18 05:37:11 --> Loader Class Initialized
INFO - 2025-11-18 05:37:11 --> Loader Class Initialized
INFO - 2025-11-18 05:37:11 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:37:11 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:37:11 --> Helper loaded: url_helper
INFO - 2025-11-18 05:37:11 --> Loader Class Initialized
INFO - 2025-11-18 05:37:11 --> Helper loaded: file_helper
INFO - 2025-11-18 05:37:11 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:37:11 --> Helper loaded: url_helper
INFO - 2025-11-18 05:37:11 --> Helper loaded: url_helper
INFO - 2025-11-18 05:37:11 --> Helper loaded: main_helper
INFO - 2025-11-18 05:37:11 --> Helper loaded: file_helper
INFO - 2025-11-18 05:37:11 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:37:11 --> Helper loaded: file_helper
INFO - 2025-11-18 05:37:11 --> Helper loaded: main_helper
INFO - 2025-11-18 05:37:11 --> Helper loaded: main_helper
INFO - 2025-11-18 05:37:11 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:37:11 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:37:11 --> Database Driver Class Initialized
INFO - 2025-11-18 05:37:11 --> Database Driver Class Initialized
INFO - 2025-11-18 05:37:11 --> Database Driver Class Initialized
INFO - 2025-11-18 05:37:11 --> Email Class Initialized
INFO - 2025-11-18 05:37:11 --> Email Class Initialized
INFO - 2025-11-18 05:37:11 --> Email Class Initialized
DEBUG - 2025-11-18 05:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:37:11 --> Controller Class Initialized
DEBUG - 2025-11-18 05:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-11-18 05:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:37:11 --> Model "User_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "Project_model" initialized
INFO - 2025-11-18 05:37:11 --> Helper loaded: form_helper
INFO - 2025-11-18 05:37:11 --> Form Validation Class Initialized
INFO - 2025-11-18 05:37:11 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "Topk_service_model" initialized
INFO - 2025-11-18 05:37:11 --> Final output sent to browser
INFO - 2025-11-18 05:37:11 --> Total execution time: 0.1366
INFO - 2025-11-18 05:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:37:11 --> Controller Class Initialized
INFO - 2025-11-18 05:37:11 --> Model "User_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "Project_model" initialized
INFO - 2025-11-18 05:37:11 --> Helper loaded: form_helper
INFO - 2025-11-18 05:37:11 --> Form Validation Class Initialized
INFO - 2025-11-18 05:37:11 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "Topk_service_model" initialized
INFO - 2025-11-18 05:37:11 --> Final output sent to browser
INFO - 2025-11-18 05:37:11 --> Total execution time: 0.1610
INFO - 2025-11-18 05:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:37:11 --> Controller Class Initialized
INFO - 2025-11-18 05:37:11 --> Model "User_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "Project_model" initialized
INFO - 2025-11-18 05:37:11 --> Helper loaded: form_helper
INFO - 2025-11-18 05:37:11 --> Form Validation Class Initialized
INFO - 2025-11-18 05:37:11 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:37:11 --> Model "Topk_service_model" initialized
INFO - 2025-11-18 05:37:11 --> Final output sent to browser
INFO - 2025-11-18 05:37:11 --> Total execution time: 0.1854
INFO - 2025-11-18 05:37:12 --> Config Class Initialized
INFO - 2025-11-18 05:37:12 --> Hooks Class Initialized
INFO - 2025-11-18 05:37:12 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:37:12 --> Utf8 Class Initialized
INFO - 2025-11-18 05:37:12 --> URI Class Initialized
INFO - 2025-11-18 05:37:12 --> Router Class Initialized
INFO - 2025-11-18 05:37:12 --> Output Class Initialized
INFO - 2025-11-18 05:37:12 --> Security Class Initialized
INFO - 2025-11-18 05:37:12 --> Input Class Initialized
INFO - 2025-11-18 05:37:12 --> Language Class Initialized
INFO - 2025-11-18 05:37:12 --> Loader Class Initialized
INFO - 2025-11-18 05:37:12 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:37:12 --> Helper loaded: url_helper
INFO - 2025-11-18 05:37:12 --> Helper loaded: file_helper
INFO - 2025-11-18 05:37:12 --> Helper loaded: main_helper
INFO - 2025-11-18 05:37:12 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:37:12 --> Database Driver Class Initialized
INFO - 2025-11-18 05:37:12 --> Email Class Initialized
DEBUG - 2025-11-18 05:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:37:12 --> Controller Class Initialized
INFO - 2025-11-18 05:37:12 --> Model "User_model" initialized
INFO - 2025-11-18 05:37:12 --> Model "Project_model" initialized
INFO - 2025-11-18 05:37:12 --> Helper loaded: form_helper
INFO - 2025-11-18 05:37:12 --> Form Validation Class Initialized
INFO - 2025-11-18 05:37:12 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:37:12 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:37:12 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:37:12 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:37:12 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:37:12 --> Model "Topk_service_model" initialized
INFO - 2025-11-18 05:37:12 --> Final output sent to browser
INFO - 2025-11-18 05:37:12 --> Total execution time: 0.1176
INFO - 2025-11-18 05:37:13 --> Config Class Initialized
INFO - 2025-11-18 05:37:13 --> Hooks Class Initialized
INFO - 2025-11-18 05:37:13 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:37:13 --> Utf8 Class Initialized
INFO - 2025-11-18 05:37:13 --> URI Class Initialized
INFO - 2025-11-18 05:37:13 --> Router Class Initialized
INFO - 2025-11-18 05:37:13 --> Output Class Initialized
INFO - 2025-11-18 05:37:13 --> Security Class Initialized
INFO - 2025-11-18 05:37:13 --> Input Class Initialized
INFO - 2025-11-18 05:37:13 --> Language Class Initialized
INFO - 2025-11-18 05:37:13 --> Loader Class Initialized
INFO - 2025-11-18 05:37:13 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:37:13 --> Helper loaded: url_helper
INFO - 2025-11-18 05:37:13 --> Helper loaded: file_helper
INFO - 2025-11-18 05:37:13 --> Helper loaded: main_helper
INFO - 2025-11-18 05:37:13 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:37:13 --> Database Driver Class Initialized
INFO - 2025-11-18 05:37:13 --> Email Class Initialized
DEBUG - 2025-11-18 05:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:37:13 --> Controller Class Initialized
INFO - 2025-11-18 05:37:13 --> Model "User_model" initialized
INFO - 2025-11-18 05:37:13 --> Model "Project_model" initialized
INFO - 2025-11-18 05:37:13 --> Helper loaded: form_helper
INFO - 2025-11-18 05:37:13 --> Form Validation Class Initialized
INFO - 2025-11-18 05:37:13 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:37:13 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:37:13 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:37:13 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:37:13 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:37:13 --> Model "Topk_service_model" initialized
INFO - 2025-11-18 05:37:13 --> Final output sent to browser
INFO - 2025-11-18 05:37:13 --> Total execution time: 0.1220
INFO - 2025-11-18 05:37:13 --> Config Class Initialized
INFO - 2025-11-18 05:37:13 --> Hooks Class Initialized
INFO - 2025-11-18 05:37:13 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:37:13 --> Utf8 Class Initialized
INFO - 2025-11-18 05:37:13 --> URI Class Initialized
INFO - 2025-11-18 05:37:13 --> Router Class Initialized
INFO - 2025-11-18 05:37:13 --> Output Class Initialized
INFO - 2025-11-18 05:37:13 --> Security Class Initialized
INFO - 2025-11-18 05:37:13 --> Input Class Initialized
INFO - 2025-11-18 05:37:13 --> Language Class Initialized
INFO - 2025-11-18 05:37:13 --> Loader Class Initialized
INFO - 2025-11-18 05:37:13 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:37:13 --> Helper loaded: url_helper
INFO - 2025-11-18 05:37:13 --> Helper loaded: file_helper
INFO - 2025-11-18 05:37:13 --> Helper loaded: main_helper
INFO - 2025-11-18 05:37:13 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:37:13 --> Database Driver Class Initialized
INFO - 2025-11-18 05:37:14 --> Email Class Initialized
DEBUG - 2025-11-18 05:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:37:14 --> Controller Class Initialized
INFO - 2025-11-18 05:37:14 --> Model "User_model" initialized
INFO - 2025-11-18 05:37:14 --> Model "Project_model" initialized
INFO - 2025-11-18 05:37:14 --> Helper loaded: form_helper
INFO - 2025-11-18 05:37:14 --> Form Validation Class Initialized
INFO - 2025-11-18 05:37:14 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:37:14 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:37:14 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:37:14 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:37:14 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:37:14 --> Model "Topk_service_model" initialized
ERROR - 2025-11-18 05:37:20 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 267,
    "totalTokenCount": 1066,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 267
      }
    ],
    "thoughtsTokenCount": 799
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "DQYcab_IK-j7juMPyNejsAU"
}

ERROR - 2025-11-18 05:37:23 --> Gemini missing text parts: {
  "candidates": [
    {
      "content": {
        "role": "model"
      },
      "finishReason": "MAX_TOKENS",
      "index": 0
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 284,
    "totalTokenCount": 843,
    "promptTokensDetails": [
      {
        "modality": "TEXT",
        "tokenCount": 284
      }
    ],
    "thoughtsTokenCount": 559
  },
  "modelVersion": "gemini-2.5-flash",
  "responseId": "EQYcaZTSFMT-juMP2ZuTqQU"
}

INFO - 2025-11-18 05:37:23 --> Final output sent to browser
INFO - 2025-11-18 05:37:23 --> Total execution time: 9.8748
INFO - 2025-11-18 05:37:23 --> Config Class Initialized
INFO - 2025-11-18 05:37:23 --> Hooks Class Initialized
INFO - 2025-11-18 05:37:23 --> UTF-8 Support Enabled
INFO - 2025-11-18 05:37:23 --> Utf8 Class Initialized
INFO - 2025-11-18 05:37:23 --> URI Class Initialized
INFO - 2025-11-18 05:37:23 --> Router Class Initialized
INFO - 2025-11-18 05:37:23 --> Output Class Initialized
INFO - 2025-11-18 05:37:23 --> Security Class Initialized
INFO - 2025-11-18 05:37:23 --> Input Class Initialized
INFO - 2025-11-18 05:37:23 --> Language Class Initialized
INFO - 2025-11-18 05:37:23 --> Loader Class Initialized
INFO - 2025-11-18 05:37:23 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 05:37:23 --> Helper loaded: url_helper
INFO - 2025-11-18 05:37:23 --> Helper loaded: file_helper
INFO - 2025-11-18 05:37:23 --> Helper loaded: main_helper
INFO - 2025-11-18 05:37:23 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 05:37:23 --> Database Driver Class Initialized
INFO - 2025-11-18 05:37:23 --> Email Class Initialized
DEBUG - 2025-11-18 05:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 05:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 05:37:23 --> Controller Class Initialized
INFO - 2025-11-18 05:37:23 --> Model "User_model" initialized
INFO - 2025-11-18 05:37:23 --> Model "Project_model" initialized
INFO - 2025-11-18 05:37:23 --> Helper loaded: form_helper
INFO - 2025-11-18 05:37:23 --> Form Validation Class Initialized
INFO - 2025-11-18 05:37:23 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-18 05:37:23 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-18 05:37:23 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-18 05:37:23 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:37:23 --> Model "Swot_model" initialized
INFO - 2025-11-18 05:37:23 --> Model "Topk_service_model" initialized
INFO - 2025-11-18 05:37:30 --> Final output sent to browser
INFO - 2025-11-18 05:37:30 --> Total execution time: 6.9526
INFO - 2025-11-18 10:07:28 --> Config Class Initialized
INFO - 2025-11-18 10:07:28 --> Hooks Class Initialized
INFO - 2025-11-18 10:07:28 --> UTF-8 Support Enabled
INFO - 2025-11-18 10:07:28 --> Utf8 Class Initialized
INFO - 2025-11-18 10:07:28 --> URI Class Initialized
DEBUG - 2025-11-18 10:07:28 --> No URI present. Default controller set.
INFO - 2025-11-18 10:07:28 --> Router Class Initialized
INFO - 2025-11-18 10:07:28 --> Output Class Initialized
INFO - 2025-11-18 10:07:28 --> Security Class Initialized
INFO - 2025-11-18 10:07:28 --> Input Class Initialized
INFO - 2025-11-18 10:07:28 --> Language Class Initialized
INFO - 2025-11-18 10:07:28 --> Loader Class Initialized
INFO - 2025-11-18 10:07:28 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 10:07:28 --> Helper loaded: url_helper
INFO - 2025-11-18 10:07:28 --> Helper loaded: file_helper
INFO - 2025-11-18 10:07:28 --> Helper loaded: main_helper
INFO - 2025-11-18 10:07:28 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 10:07:28 --> Database Driver Class Initialized
INFO - 2025-11-18 10:07:28 --> Email Class Initialized
DEBUG - 2025-11-18 10:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 10:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 10:07:28 --> Controller Class Initialized
INFO - 2025-11-18 10:07:28 --> Config Class Initialized
INFO - 2025-11-18 10:07:28 --> Hooks Class Initialized
INFO - 2025-11-18 10:07:28 --> UTF-8 Support Enabled
INFO - 2025-11-18 10:07:28 --> Utf8 Class Initialized
INFO - 2025-11-18 10:07:28 --> URI Class Initialized
INFO - 2025-11-18 10:07:28 --> Router Class Initialized
INFO - 2025-11-18 10:07:28 --> Output Class Initialized
INFO - 2025-11-18 10:07:28 --> Security Class Initialized
INFO - 2025-11-18 10:07:28 --> Input Class Initialized
INFO - 2025-11-18 10:07:28 --> Language Class Initialized
INFO - 2025-11-18 10:07:28 --> Loader Class Initialized
INFO - 2025-11-18 10:07:28 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 10:07:28 --> Helper loaded: url_helper
INFO - 2025-11-18 10:07:28 --> Helper loaded: file_helper
INFO - 2025-11-18 10:07:28 --> Helper loaded: main_helper
INFO - 2025-11-18 10:07:28 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 10:07:28 --> Database Driver Class Initialized
INFO - 2025-11-18 10:07:28 --> Email Class Initialized
DEBUG - 2025-11-18 10:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 10:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 10:07:28 --> Controller Class Initialized
INFO - 2025-11-18 10:07:28 --> Model "Subscription_model" initialized
INFO - 2025-11-18 10:07:28 --> Model "User_model" initialized
INFO - 2025-11-18 10:07:28 --> Model "Auth_model" initialized
INFO - 2025-11-18 10:07:28 --> Config Class Initialized
INFO - 2025-11-18 10:07:28 --> Hooks Class Initialized
INFO - 2025-11-18 10:07:28 --> UTF-8 Support Enabled
INFO - 2025-11-18 10:07:28 --> Utf8 Class Initialized
INFO - 2025-11-18 10:07:28 --> URI Class Initialized
INFO - 2025-11-18 10:07:28 --> Router Class Initialized
INFO - 2025-11-18 10:07:28 --> Output Class Initialized
INFO - 2025-11-18 10:07:28 --> Security Class Initialized
INFO - 2025-11-18 10:07:28 --> Input Class Initialized
INFO - 2025-11-18 10:07:28 --> Language Class Initialized
INFO - 2025-11-18 10:07:28 --> Loader Class Initialized
INFO - 2025-11-18 10:07:28 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 10:07:28 --> Helper loaded: url_helper
INFO - 2025-11-18 10:07:28 --> Helper loaded: file_helper
INFO - 2025-11-18 10:07:28 --> Helper loaded: main_helper
INFO - 2025-11-18 10:07:28 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 10:07:28 --> Database Driver Class Initialized
INFO - 2025-11-18 10:07:28 --> Email Class Initialized
DEBUG - 2025-11-18 10:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 10:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 10:07:28 --> Controller Class Initialized
INFO - 2025-11-18 10:07:28 --> Config Class Initialized
INFO - 2025-11-18 10:07:28 --> Hooks Class Initialized
INFO - 2025-11-18 10:07:28 --> UTF-8 Support Enabled
INFO - 2025-11-18 10:07:28 --> Utf8 Class Initialized
INFO - 2025-11-18 10:07:28 --> URI Class Initialized
INFO - 2025-11-18 10:07:28 --> Router Class Initialized
INFO - 2025-11-18 10:07:28 --> Output Class Initialized
INFO - 2025-11-18 10:07:28 --> Security Class Initialized
INFO - 2025-11-18 10:07:28 --> Input Class Initialized
INFO - 2025-11-18 10:07:28 --> Language Class Initialized
INFO - 2025-11-18 10:07:28 --> Loader Class Initialized
INFO - 2025-11-18 10:07:28 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-18 10:07:28 --> Helper loaded: url_helper
INFO - 2025-11-18 10:07:28 --> Helper loaded: file_helper
INFO - 2025-11-18 10:07:28 --> Helper loaded: main_helper
INFO - 2025-11-18 10:07:28 --> Helper loaded: sendgrid_helper
INFO - 2025-11-18 10:07:28 --> Database Driver Class Initialized
INFO - 2025-11-18 10:07:28 --> Email Class Initialized
DEBUG - 2025-11-18 10:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-18 10:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-18 10:07:28 --> Controller Class Initialized
INFO - 2025-11-18 10:07:28 --> Model "Subscription_model" initialized
INFO - 2025-11-18 10:07:28 --> Model "User_model" initialized
INFO - 2025-11-18 10:07:28 --> Model "Auth_model" initialized
INFO - 2025-11-18 10:07:28 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-18 10:07:28 --> Final output sent to browser
INFO - 2025-11-18 10:07:28 --> Total execution time: 0.0759
