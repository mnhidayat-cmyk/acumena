<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-11-14 13:02:31 --> Config Class Initialized
INFO - 2025-11-14 13:02:31 --> Hooks Class Initialized
INFO - 2025-11-14 13:02:31 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:02:31 --> Utf8 Class Initialized
INFO - 2025-11-14 13:02:31 --> URI Class Initialized
DEBUG - 2025-11-14 13:02:31 --> No URI present. Default controller set.
INFO - 2025-11-14 13:02:31 --> Router Class Initialized
INFO - 2025-11-14 13:02:31 --> Output Class Initialized
INFO - 2025-11-14 13:02:31 --> Security Class Initialized
INFO - 2025-11-14 13:02:31 --> Input Class Initialized
INFO - 2025-11-14 13:02:31 --> Language Class Initialized
INFO - 2025-11-14 13:02:31 --> Loader Class Initialized
INFO - 2025-11-14 13:02:31 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:02:31 --> Helper loaded: url_helper
INFO - 2025-11-14 13:02:31 --> Helper loaded: file_helper
INFO - 2025-11-14 13:02:31 --> Helper loaded: main_helper
INFO - 2025-11-14 13:02:31 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:02:31 --> Database Driver Class Initialized
INFO - 2025-11-14 13:02:31 --> Email Class Initialized
DEBUG - 2025-11-14 13:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:02:31 --> Controller Class Initialized
INFO - 2025-11-14 13:02:31 --> Config Class Initialized
INFO - 2025-11-14 13:02:31 --> Hooks Class Initialized
INFO - 2025-11-14 13:02:31 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:02:31 --> Utf8 Class Initialized
INFO - 2025-11-14 13:02:31 --> URI Class Initialized
INFO - 2025-11-14 13:02:31 --> Router Class Initialized
INFO - 2025-11-14 13:02:31 --> Output Class Initialized
INFO - 2025-11-14 13:02:31 --> Security Class Initialized
INFO - 2025-11-14 13:02:31 --> Input Class Initialized
INFO - 2025-11-14 13:02:31 --> Language Class Initialized
INFO - 2025-11-14 13:02:31 --> Loader Class Initialized
INFO - 2025-11-14 13:02:31 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:02:31 --> Helper loaded: url_helper
INFO - 2025-11-14 13:02:31 --> Helper loaded: file_helper
INFO - 2025-11-14 13:02:31 --> Helper loaded: main_helper
INFO - 2025-11-14 13:02:31 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:02:31 --> Database Driver Class Initialized
INFO - 2025-11-14 13:02:31 --> Email Class Initialized
DEBUG - 2025-11-14 13:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:02:31 --> Controller Class Initialized
INFO - 2025-11-14 13:02:31 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:02:31 --> Model "User_model" initialized
INFO - 2025-11-14 13:02:31 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:02:31 --> Config Class Initialized
INFO - 2025-11-14 13:02:31 --> Hooks Class Initialized
INFO - 2025-11-14 13:02:31 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:02:31 --> Utf8 Class Initialized
INFO - 2025-11-14 13:02:31 --> URI Class Initialized
INFO - 2025-11-14 13:02:31 --> Router Class Initialized
INFO - 2025-11-14 13:02:31 --> Output Class Initialized
INFO - 2025-11-14 13:02:31 --> Security Class Initialized
INFO - 2025-11-14 13:02:31 --> Input Class Initialized
INFO - 2025-11-14 13:02:31 --> Language Class Initialized
INFO - 2025-11-14 13:02:31 --> Loader Class Initialized
INFO - 2025-11-14 13:02:31 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:02:31 --> Helper loaded: url_helper
INFO - 2025-11-14 13:02:31 --> Helper loaded: file_helper
INFO - 2025-11-14 13:02:31 --> Helper loaded: main_helper
INFO - 2025-11-14 13:02:31 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:02:32 --> Database Driver Class Initialized
INFO - 2025-11-14 13:02:32 --> Email Class Initialized
DEBUG - 2025-11-14 13:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:02:32 --> Controller Class Initialized
INFO - 2025-11-14 13:02:32 --> Config Class Initialized
INFO - 2025-11-14 13:02:32 --> Hooks Class Initialized
INFO - 2025-11-14 13:02:32 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:02:32 --> Utf8 Class Initialized
INFO - 2025-11-14 13:02:32 --> URI Class Initialized
INFO - 2025-11-14 13:02:32 --> Router Class Initialized
INFO - 2025-11-14 13:02:32 --> Output Class Initialized
INFO - 2025-11-14 13:02:32 --> Security Class Initialized
INFO - 2025-11-14 13:02:32 --> Input Class Initialized
INFO - 2025-11-14 13:02:32 --> Language Class Initialized
INFO - 2025-11-14 13:02:32 --> Loader Class Initialized
INFO - 2025-11-14 13:02:32 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:02:32 --> Helper loaded: url_helper
INFO - 2025-11-14 13:02:32 --> Helper loaded: file_helper
INFO - 2025-11-14 13:02:32 --> Helper loaded: main_helper
INFO - 2025-11-14 13:02:32 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:02:32 --> Database Driver Class Initialized
INFO - 2025-11-14 13:02:32 --> Email Class Initialized
DEBUG - 2025-11-14 13:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:02:32 --> Controller Class Initialized
INFO - 2025-11-14 13:02:32 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:02:32 --> Model "User_model" initialized
INFO - 2025-11-14 13:02:32 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:02:32 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-14 13:02:32 --> Final output sent to browser
INFO - 2025-11-14 13:02:32 --> Total execution time: 0.0818
INFO - 2025-11-14 13:02:35 --> Config Class Initialized
INFO - 2025-11-14 13:02:35 --> Hooks Class Initialized
INFO - 2025-11-14 13:02:35 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:02:35 --> Utf8 Class Initialized
INFO - 2025-11-14 13:02:35 --> URI Class Initialized
INFO - 2025-11-14 13:02:35 --> Router Class Initialized
INFO - 2025-11-14 13:02:35 --> Output Class Initialized
INFO - 2025-11-14 13:02:35 --> Security Class Initialized
INFO - 2025-11-14 13:02:35 --> Input Class Initialized
INFO - 2025-11-14 13:02:35 --> Language Class Initialized
INFO - 2025-11-14 13:02:35 --> Loader Class Initialized
INFO - 2025-11-14 13:02:35 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:02:35 --> Helper loaded: url_helper
INFO - 2025-11-14 13:02:35 --> Helper loaded: file_helper
INFO - 2025-11-14 13:02:35 --> Helper loaded: main_helper
INFO - 2025-11-14 13:02:35 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:02:35 --> Database Driver Class Initialized
INFO - 2025-11-14 13:02:35 --> Email Class Initialized
DEBUG - 2025-11-14 13:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:02:35 --> Controller Class Initialized
INFO - 2025-11-14 13:02:35 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:02:35 --> Model "User_model" initialized
INFO - 2025-11-14 13:02:35 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:02:35 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-14 13:02:35 --> Final output sent to browser
INFO - 2025-11-14 13:02:35 --> Total execution time: 0.1079
INFO - 2025-11-14 13:02:47 --> Config Class Initialized
INFO - 2025-11-14 13:02:47 --> Hooks Class Initialized
INFO - 2025-11-14 13:02:47 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:02:47 --> Utf8 Class Initialized
INFO - 2025-11-14 13:02:47 --> URI Class Initialized
INFO - 2025-11-14 13:02:47 --> Router Class Initialized
INFO - 2025-11-14 13:02:47 --> Output Class Initialized
INFO - 2025-11-14 13:02:47 --> Security Class Initialized
INFO - 2025-11-14 13:02:47 --> Input Class Initialized
INFO - 2025-11-14 13:02:47 --> Language Class Initialized
INFO - 2025-11-14 13:02:47 --> Loader Class Initialized
INFO - 2025-11-14 13:02:47 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:02:48 --> Helper loaded: url_helper
INFO - 2025-11-14 13:02:48 --> Helper loaded: file_helper
INFO - 2025-11-14 13:02:48 --> Helper loaded: main_helper
INFO - 2025-11-14 13:02:48 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:02:48 --> Database Driver Class Initialized
INFO - 2025-11-14 13:02:48 --> Email Class Initialized
DEBUG - 2025-11-14 13:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:02:48 --> Controller Class Initialized
INFO - 2025-11-14 13:02:48 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:02:48 --> Model "User_model" initialized
INFO - 2025-11-14 13:02:48 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:02:48 --> Final output sent to browser
INFO - 2025-11-14 13:02:48 --> Total execution time: 0.3541
INFO - 2025-11-14 13:02:49 --> Config Class Initialized
INFO - 2025-11-14 13:02:49 --> Hooks Class Initialized
INFO - 2025-11-14 13:02:49 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:02:49 --> Utf8 Class Initialized
INFO - 2025-11-14 13:02:49 --> URI Class Initialized
INFO - 2025-11-14 13:02:49 --> Router Class Initialized
INFO - 2025-11-14 13:02:49 --> Output Class Initialized
INFO - 2025-11-14 13:02:49 --> Security Class Initialized
INFO - 2025-11-14 13:02:49 --> Input Class Initialized
INFO - 2025-11-14 13:02:49 --> Language Class Initialized
INFO - 2025-11-14 13:02:49 --> Loader Class Initialized
INFO - 2025-11-14 13:02:49 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:02:49 --> Helper loaded: url_helper
INFO - 2025-11-14 13:02:49 --> Helper loaded: file_helper
INFO - 2025-11-14 13:02:49 --> Helper loaded: main_helper
INFO - 2025-11-14 13:02:49 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:02:49 --> Database Driver Class Initialized
INFO - 2025-11-14 13:02:49 --> Email Class Initialized
DEBUG - 2025-11-14 13:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:02:49 --> Controller Class Initialized
INFO - 2025-11-14 13:02:49 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:02:49 --> Model "User_model" initialized
INFO - 2025-11-14 13:02:49 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:02:49 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-14 13:02:49 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-14 13:02:49 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-14 13:02:49 --> File loaded: D:\laragon\www\acumena\application\views\dashboard.php
INFO - 2025-11-14 13:02:49 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-14 13:02:49 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-14 13:02:49 --> Final output sent to browser
INFO - 2025-11-14 13:02:49 --> Total execution time: 0.0948
INFO - 2025-11-14 13:02:50 --> Config Class Initialized
INFO - 2025-11-14 13:02:50 --> Hooks Class Initialized
INFO - 2025-11-14 13:02:50 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:02:50 --> Utf8 Class Initialized
INFO - 2025-11-14 13:02:50 --> URI Class Initialized
INFO - 2025-11-14 13:02:50 --> Router Class Initialized
INFO - 2025-11-14 13:02:50 --> Output Class Initialized
INFO - 2025-11-14 13:02:50 --> Security Class Initialized
INFO - 2025-11-14 13:02:50 --> Input Class Initialized
INFO - 2025-11-14 13:02:50 --> Language Class Initialized
INFO - 2025-11-14 13:02:50 --> Loader Class Initialized
INFO - 2025-11-14 13:02:50 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:02:50 --> Helper loaded: url_helper
INFO - 2025-11-14 13:02:50 --> Helper loaded: file_helper
INFO - 2025-11-14 13:02:50 --> Helper loaded: main_helper
INFO - 2025-11-14 13:02:50 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:02:50 --> Database Driver Class Initialized
INFO - 2025-11-14 13:02:50 --> Email Class Initialized
DEBUG - 2025-11-14 13:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:02:50 --> Controller Class Initialized
INFO - 2025-11-14 13:02:50 --> Model "User_model" initialized
INFO - 2025-11-14 13:02:50 --> Model "Project_model" initialized
INFO - 2025-11-14 13:02:50 --> Helper loaded: form_helper
INFO - 2025-11-14 13:02:50 --> Form Validation Class Initialized
INFO - 2025-11-14 13:02:50 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-14 13:02:50 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-14 13:02:50 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-14 13:02:50 --> Model "Swot_model" initialized
INFO - 2025-11-14 13:02:50 --> Model "Swot_model" initialized
INFO - 2025-11-14 13:02:50 --> Model "Topk_service_model" initialized
INFO - 2025-11-14 13:02:50 --> Final output sent to browser
INFO - 2025-11-14 13:02:50 --> Total execution time: 0.1257
INFO - 2025-11-14 13:02:55 --> Config Class Initialized
INFO - 2025-11-14 13:02:55 --> Hooks Class Initialized
INFO - 2025-11-14 13:02:55 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:02:56 --> Utf8 Class Initialized
INFO - 2025-11-14 13:02:56 --> URI Class Initialized
INFO - 2025-11-14 13:02:56 --> Router Class Initialized
INFO - 2025-11-14 13:02:56 --> Output Class Initialized
INFO - 2025-11-14 13:02:56 --> Security Class Initialized
INFO - 2025-11-14 13:02:56 --> Input Class Initialized
INFO - 2025-11-14 13:02:56 --> Language Class Initialized
INFO - 2025-11-14 13:02:56 --> Loader Class Initialized
INFO - 2025-11-14 13:02:56 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:02:56 --> Helper loaded: url_helper
INFO - 2025-11-14 13:02:56 --> Helper loaded: file_helper
INFO - 2025-11-14 13:02:56 --> Helper loaded: main_helper
INFO - 2025-11-14 13:02:56 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:02:56 --> Database Driver Class Initialized
INFO - 2025-11-14 13:02:56 --> Email Class Initialized
DEBUG - 2025-11-14 13:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:02:56 --> Controller Class Initialized
INFO - 2025-11-14 13:02:56 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:02:56 --> Model "User_model" initialized
INFO - 2025-11-14 13:02:56 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:02:56 --> Config Class Initialized
INFO - 2025-11-14 13:02:56 --> Hooks Class Initialized
INFO - 2025-11-14 13:02:56 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:02:56 --> Utf8 Class Initialized
INFO - 2025-11-14 13:02:56 --> URI Class Initialized
INFO - 2025-11-14 13:02:56 --> Router Class Initialized
INFO - 2025-11-14 13:02:56 --> Output Class Initialized
INFO - 2025-11-14 13:02:56 --> Security Class Initialized
INFO - 2025-11-14 13:02:56 --> Input Class Initialized
INFO - 2025-11-14 13:02:56 --> Language Class Initialized
INFO - 2025-11-14 13:02:56 --> Loader Class Initialized
INFO - 2025-11-14 13:02:56 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:02:56 --> Helper loaded: url_helper
INFO - 2025-11-14 13:02:56 --> Helper loaded: file_helper
INFO - 2025-11-14 13:02:56 --> Helper loaded: main_helper
INFO - 2025-11-14 13:02:56 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:02:56 --> Database Driver Class Initialized
INFO - 2025-11-14 13:02:56 --> Email Class Initialized
DEBUG - 2025-11-14 13:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:02:56 --> Controller Class Initialized
INFO - 2025-11-14 13:02:56 --> Config Class Initialized
INFO - 2025-11-14 13:02:56 --> Hooks Class Initialized
INFO - 2025-11-14 13:02:56 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:02:56 --> Utf8 Class Initialized
INFO - 2025-11-14 13:02:56 --> URI Class Initialized
INFO - 2025-11-14 13:02:56 --> Router Class Initialized
INFO - 2025-11-14 13:02:56 --> Output Class Initialized
INFO - 2025-11-14 13:02:56 --> Security Class Initialized
INFO - 2025-11-14 13:02:56 --> Input Class Initialized
INFO - 2025-11-14 13:02:56 --> Language Class Initialized
INFO - 2025-11-14 13:02:56 --> Loader Class Initialized
INFO - 2025-11-14 13:02:56 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:02:56 --> Helper loaded: url_helper
INFO - 2025-11-14 13:02:56 --> Helper loaded: file_helper
INFO - 2025-11-14 13:02:56 --> Helper loaded: main_helper
INFO - 2025-11-14 13:02:56 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:02:56 --> Database Driver Class Initialized
INFO - 2025-11-14 13:02:56 --> Email Class Initialized
DEBUG - 2025-11-14 13:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:02:56 --> Controller Class Initialized
INFO - 2025-11-14 13:02:56 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:02:56 --> Model "User_model" initialized
INFO - 2025-11-14 13:02:56 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:02:56 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-14 13:02:56 --> Final output sent to browser
INFO - 2025-11-14 13:02:56 --> Total execution time: 0.0982
INFO - 2025-11-14 13:02:58 --> Config Class Initialized
INFO - 2025-11-14 13:02:58 --> Hooks Class Initialized
INFO - 2025-11-14 13:02:58 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:02:58 --> Utf8 Class Initialized
INFO - 2025-11-14 13:02:58 --> URI Class Initialized
INFO - 2025-11-14 13:02:58 --> Router Class Initialized
INFO - 2025-11-14 13:02:58 --> Output Class Initialized
INFO - 2025-11-14 13:02:58 --> Security Class Initialized
INFO - 2025-11-14 13:02:58 --> Input Class Initialized
INFO - 2025-11-14 13:02:58 --> Language Class Initialized
INFO - 2025-11-14 13:02:58 --> Loader Class Initialized
INFO - 2025-11-14 13:02:58 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:02:58 --> Helper loaded: url_helper
INFO - 2025-11-14 13:02:58 --> Helper loaded: file_helper
INFO - 2025-11-14 13:02:58 --> Helper loaded: main_helper
INFO - 2025-11-14 13:02:58 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:02:58 --> Database Driver Class Initialized
INFO - 2025-11-14 13:02:58 --> Email Class Initialized
DEBUG - 2025-11-14 13:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:02:58 --> Controller Class Initialized
INFO - 2025-11-14 13:02:58 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:02:58 --> Model "User_model" initialized
INFO - 2025-11-14 13:02:58 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:02:58 --> File loaded: D:\laragon\www\acumena\application\views\auth/register.php
INFO - 2025-11-14 13:02:58 --> Final output sent to browser
INFO - 2025-11-14 13:02:58 --> Total execution time: 0.0954
INFO - 2025-11-14 13:03:21 --> Config Class Initialized
INFO - 2025-11-14 13:03:21 --> Hooks Class Initialized
INFO - 2025-11-14 13:03:21 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:03:21 --> Utf8 Class Initialized
INFO - 2025-11-14 13:03:21 --> URI Class Initialized
INFO - 2025-11-14 13:03:21 --> Router Class Initialized
INFO - 2025-11-14 13:03:21 --> Output Class Initialized
INFO - 2025-11-14 13:03:21 --> Security Class Initialized
INFO - 2025-11-14 13:03:21 --> Input Class Initialized
INFO - 2025-11-14 13:03:21 --> Language Class Initialized
INFO - 2025-11-14 13:03:21 --> Loader Class Initialized
INFO - 2025-11-14 13:03:21 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:03:21 --> Helper loaded: url_helper
INFO - 2025-11-14 13:03:21 --> Helper loaded: file_helper
INFO - 2025-11-14 13:03:21 --> Helper loaded: main_helper
INFO - 2025-11-14 13:03:21 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:03:21 --> Database Driver Class Initialized
INFO - 2025-11-14 13:03:21 --> Email Class Initialized
DEBUG - 2025-11-14 13:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:03:21 --> Controller Class Initialized
INFO - 2025-11-14 13:03:21 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:03:21 --> Model "User_model" initialized
INFO - 2025-11-14 13:03:21 --> Model "Auth_model" initialized
DEBUG - 2025-11-14 13:03:21 --> Email class already loaded. Second attempt ignored.
INFO - 2025-11-14 13:03:31 --> Language file loaded: language/english/email_lang.php
ERROR - 2025-11-14 13:03:42 --> Mailjet send error: <br /><pre>hello: </pre>The following SMTP error was encountered: <br /><pre>starttls: 554 5.5.0 Error: SMTP protocol synchronization
</pre>The following SMTP error was encountered: 554 5.5.0 Error: SMTP protocol synchronization
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Fri, 14 Nov 2025 13:03:21 +0000
From: &quot;Acumena&quot; &lt;anam@sevencols.com&gt;
Return-Path: &lt;anam@sevencols.com&gt;
To: iyunk21@gmail.com
Subject: =?UTF-8?Q?Verify=20Account?=
Reply-To: &lt;anam@sevencols.com&gt;
User-Agent: CI3-Hostinger
X-Sender: anam@sevencols.com
X-Mailer: CI3-Hostinger
X-Priority: 3 (Normal)
Message-ID: &lt;6917289999d91@sevencols.com&gt;
Mime-Version: 1.0

</pre>
INFO - 2025-11-14 13:03:42 --> Final output sent to browser
INFO - 2025-11-14 13:03:42 --> Total execution time: 20.7222
INFO - 2025-11-14 13:03:44 --> Config Class Initialized
INFO - 2025-11-14 13:03:44 --> Hooks Class Initialized
INFO - 2025-11-14 13:03:44 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:03:44 --> Utf8 Class Initialized
INFO - 2025-11-14 13:03:44 --> URI Class Initialized
INFO - 2025-11-14 13:03:44 --> Router Class Initialized
INFO - 2025-11-14 13:03:44 --> Output Class Initialized
INFO - 2025-11-14 13:03:44 --> Security Class Initialized
INFO - 2025-11-14 13:03:44 --> Input Class Initialized
INFO - 2025-11-14 13:03:44 --> Language Class Initialized
INFO - 2025-11-14 13:03:44 --> Loader Class Initialized
INFO - 2025-11-14 13:03:44 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:03:44 --> Helper loaded: url_helper
INFO - 2025-11-14 13:03:44 --> Helper loaded: file_helper
INFO - 2025-11-14 13:03:44 --> Helper loaded: main_helper
INFO - 2025-11-14 13:03:44 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:03:44 --> Database Driver Class Initialized
INFO - 2025-11-14 13:03:44 --> Email Class Initialized
DEBUG - 2025-11-14 13:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:03:44 --> Controller Class Initialized
INFO - 2025-11-14 13:03:44 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:03:44 --> Model "User_model" initialized
INFO - 2025-11-14 13:03:44 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:03:44 --> File loaded: D:\laragon\www\acumena\application\views\auth/verify.php
INFO - 2025-11-14 13:03:44 --> Final output sent to browser
INFO - 2025-11-14 13:03:44 --> Total execution time: 0.1107
INFO - 2025-11-14 13:05:35 --> Config Class Initialized
INFO - 2025-11-14 13:05:35 --> Hooks Class Initialized
INFO - 2025-11-14 13:05:35 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:05:35 --> Utf8 Class Initialized
INFO - 2025-11-14 13:05:35 --> URI Class Initialized
INFO - 2025-11-14 13:05:35 --> Router Class Initialized
INFO - 2025-11-14 13:05:35 --> Output Class Initialized
INFO - 2025-11-14 13:05:35 --> Security Class Initialized
INFO - 2025-11-14 13:05:35 --> Input Class Initialized
INFO - 2025-11-14 13:05:35 --> Language Class Initialized
INFO - 2025-11-14 13:05:35 --> Loader Class Initialized
INFO - 2025-11-14 13:05:35 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:05:35 --> Helper loaded: url_helper
INFO - 2025-11-14 13:05:35 --> Helper loaded: file_helper
INFO - 2025-11-14 13:05:35 --> Helper loaded: main_helper
INFO - 2025-11-14 13:05:35 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:05:35 --> Database Driver Class Initialized
INFO - 2025-11-14 13:05:35 --> Email Class Initialized
DEBUG - 2025-11-14 13:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:05:35 --> Controller Class Initialized
INFO - 2025-11-14 13:05:35 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:05:35 --> Model "User_model" initialized
INFO - 2025-11-14 13:05:35 --> Model "Auth_model" initialized
DEBUG - 2025-11-14 13:05:35 --> Email class already loaded. Second attempt ignored.
INFO - 2025-11-14 13:05:45 --> Language file loaded: language/english/email_lang.php
ERROR - 2025-11-14 13:05:58 --> Mailjet send error: <br /><pre>hello: </pre>The following SMTP error was encountered: <br /><pre>starttls: 554 5.5.0 Error: SMTP protocol synchronization
</pre>The following SMTP error was encountered: 554 5.5.0 Error: SMTP protocol synchronization
<br />The following SMTP error was encountered: <br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Fri, 14 Nov 2025 13:05:35 +0000
From: &quot;Acumena&quot; &lt;anam@sevencols.com&gt;
Return-Path: &lt;anam@sevencols.com&gt;
To: iyunk21@gmail.com
Subject: =?UTF-8?Q?Verify=20Account?=
Reply-To: &lt;anam@sevencols.com&gt;
User-Agent: CI3-Hostinger
X-Sender: anam@sevencols.com
X-Mailer: CI3-Hostinger
X-Priority: 3 (Normal)
Message-ID: &lt;6917291f76058@sevencols.com&gt;
Mime-Version: 1.0

</pre>
INFO - 2025-11-14 13:05:58 --> Final output sent to browser
INFO - 2025-11-14 13:05:58 --> Total execution time: 23.5278
INFO - 2025-11-14 13:08:51 --> Config Class Initialized
INFO - 2025-11-14 13:08:51 --> Hooks Class Initialized
INFO - 2025-11-14 13:08:51 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:08:51 --> Utf8 Class Initialized
INFO - 2025-11-14 13:08:51 --> URI Class Initialized
INFO - 2025-11-14 13:08:51 --> Router Class Initialized
INFO - 2025-11-14 13:08:51 --> Output Class Initialized
INFO - 2025-11-14 13:08:51 --> Security Class Initialized
INFO - 2025-11-14 13:08:51 --> Input Class Initialized
INFO - 2025-11-14 13:08:51 --> Language Class Initialized
INFO - 2025-11-14 13:08:51 --> Loader Class Initialized
INFO - 2025-11-14 13:08:51 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:08:51 --> Helper loaded: url_helper
INFO - 2025-11-14 13:08:51 --> Helper loaded: file_helper
INFO - 2025-11-14 13:08:51 --> Helper loaded: main_helper
INFO - 2025-11-14 13:08:51 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:08:51 --> Database Driver Class Initialized
INFO - 2025-11-14 13:08:51 --> Email Class Initialized
DEBUG - 2025-11-14 13:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:08:51 --> Controller Class Initialized
INFO - 2025-11-14 13:08:51 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:08:51 --> Model "User_model" initialized
INFO - 2025-11-14 13:08:51 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:08:51 --> File loaded: D:\laragon\www\acumena\application\views\auth/verify.php
INFO - 2025-11-14 13:08:51 --> Final output sent to browser
INFO - 2025-11-14 13:08:51 --> Total execution time: 0.1115
INFO - 2025-11-14 13:08:53 --> Config Class Initialized
INFO - 2025-11-14 13:08:53 --> Hooks Class Initialized
INFO - 2025-11-14 13:08:53 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:08:53 --> Utf8 Class Initialized
INFO - 2025-11-14 13:08:53 --> URI Class Initialized
INFO - 2025-11-14 13:08:53 --> Router Class Initialized
INFO - 2025-11-14 13:08:53 --> Output Class Initialized
INFO - 2025-11-14 13:08:53 --> Security Class Initialized
INFO - 2025-11-14 13:08:53 --> Input Class Initialized
INFO - 2025-11-14 13:08:53 --> Language Class Initialized
INFO - 2025-11-14 13:08:53 --> Loader Class Initialized
INFO - 2025-11-14 13:08:53 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:08:53 --> Helper loaded: url_helper
INFO - 2025-11-14 13:08:53 --> Helper loaded: file_helper
INFO - 2025-11-14 13:08:53 --> Helper loaded: main_helper
INFO - 2025-11-14 13:08:53 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:08:53 --> Database Driver Class Initialized
INFO - 2025-11-14 13:08:53 --> Email Class Initialized
DEBUG - 2025-11-14 13:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:08:53 --> Controller Class Initialized
INFO - 2025-11-14 13:08:53 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:08:53 --> Model "User_model" initialized
INFO - 2025-11-14 13:08:53 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:08:55 --> Final output sent to browser
INFO - 2025-11-14 13:08:55 --> Total execution time: 1.8936
INFO - 2025-11-14 13:09:05 --> Config Class Initialized
INFO - 2025-11-14 13:09:05 --> Hooks Class Initialized
INFO - 2025-11-14 13:09:05 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:09:05 --> Utf8 Class Initialized
INFO - 2025-11-14 13:09:05 --> URI Class Initialized
INFO - 2025-11-14 13:09:05 --> Router Class Initialized
INFO - 2025-11-14 13:09:05 --> Output Class Initialized
INFO - 2025-11-14 13:09:05 --> Security Class Initialized
INFO - 2025-11-14 13:09:05 --> Input Class Initialized
INFO - 2025-11-14 13:09:05 --> Language Class Initialized
INFO - 2025-11-14 13:09:05 --> Loader Class Initialized
INFO - 2025-11-14 13:09:05 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:09:05 --> Helper loaded: url_helper
INFO - 2025-11-14 13:09:05 --> Helper loaded: file_helper
INFO - 2025-11-14 13:09:05 --> Helper loaded: main_helper
INFO - 2025-11-14 13:09:05 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:09:05 --> Database Driver Class Initialized
INFO - 2025-11-14 13:09:05 --> Email Class Initialized
DEBUG - 2025-11-14 13:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:09:05 --> Controller Class Initialized
INFO - 2025-11-14 13:09:05 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:09:05 --> Model "User_model" initialized
INFO - 2025-11-14 13:09:05 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:09:05 --> Final output sent to browser
INFO - 2025-11-14 13:09:05 --> Total execution time: 0.0920
INFO - 2025-11-14 13:09:07 --> Config Class Initialized
INFO - 2025-11-14 13:09:07 --> Hooks Class Initialized
INFO - 2025-11-14 13:09:07 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:09:07 --> Utf8 Class Initialized
INFO - 2025-11-14 13:09:07 --> URI Class Initialized
INFO - 2025-11-14 13:09:07 --> Router Class Initialized
INFO - 2025-11-14 13:09:07 --> Output Class Initialized
INFO - 2025-11-14 13:09:07 --> Security Class Initialized
INFO - 2025-11-14 13:09:07 --> Input Class Initialized
INFO - 2025-11-14 13:09:07 --> Language Class Initialized
INFO - 2025-11-14 13:09:07 --> Loader Class Initialized
INFO - 2025-11-14 13:09:07 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:09:07 --> Helper loaded: url_helper
INFO - 2025-11-14 13:09:07 --> Helper loaded: file_helper
INFO - 2025-11-14 13:09:07 --> Helper loaded: main_helper
INFO - 2025-11-14 13:09:07 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:09:07 --> Database Driver Class Initialized
INFO - 2025-11-14 13:09:07 --> Email Class Initialized
DEBUG - 2025-11-14 13:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:09:07 --> Controller Class Initialized
INFO - 2025-11-14 13:09:07 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:09:07 --> Model "User_model" initialized
INFO - 2025-11-14 13:09:07 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:09:07 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-14 13:09:07 --> Final output sent to browser
INFO - 2025-11-14 13:09:07 --> Total execution time: 0.0872
INFO - 2025-11-14 13:09:17 --> Config Class Initialized
INFO - 2025-11-14 13:09:17 --> Hooks Class Initialized
INFO - 2025-11-14 13:09:17 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:09:17 --> Utf8 Class Initialized
INFO - 2025-11-14 13:09:17 --> URI Class Initialized
INFO - 2025-11-14 13:09:17 --> Router Class Initialized
INFO - 2025-11-14 13:09:17 --> Output Class Initialized
INFO - 2025-11-14 13:09:17 --> Security Class Initialized
INFO - 2025-11-14 13:09:17 --> Input Class Initialized
INFO - 2025-11-14 13:09:17 --> Language Class Initialized
INFO - 2025-11-14 13:09:17 --> Loader Class Initialized
INFO - 2025-11-14 13:09:17 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:09:17 --> Helper loaded: url_helper
INFO - 2025-11-14 13:09:17 --> Helper loaded: file_helper
INFO - 2025-11-14 13:09:17 --> Helper loaded: main_helper
INFO - 2025-11-14 13:09:17 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:09:17 --> Database Driver Class Initialized
INFO - 2025-11-14 13:09:17 --> Email Class Initialized
DEBUG - 2025-11-14 13:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:09:17 --> Controller Class Initialized
INFO - 2025-11-14 13:09:17 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:09:17 --> Model "User_model" initialized
INFO - 2025-11-14 13:09:17 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:09:17 --> Final output sent to browser
INFO - 2025-11-14 13:09:17 --> Total execution time: 0.2217
INFO - 2025-11-14 13:09:22 --> Config Class Initialized
INFO - 2025-11-14 13:09:22 --> Hooks Class Initialized
INFO - 2025-11-14 13:09:22 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:09:22 --> Utf8 Class Initialized
INFO - 2025-11-14 13:09:22 --> URI Class Initialized
INFO - 2025-11-14 13:09:22 --> Router Class Initialized
INFO - 2025-11-14 13:09:22 --> Output Class Initialized
INFO - 2025-11-14 13:09:22 --> Security Class Initialized
INFO - 2025-11-14 13:09:22 --> Input Class Initialized
INFO - 2025-11-14 13:09:22 --> Language Class Initialized
INFO - 2025-11-14 13:09:22 --> Loader Class Initialized
INFO - 2025-11-14 13:09:22 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:09:22 --> Helper loaded: url_helper
INFO - 2025-11-14 13:09:22 --> Helper loaded: file_helper
INFO - 2025-11-14 13:09:22 --> Helper loaded: main_helper
INFO - 2025-11-14 13:09:22 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:09:22 --> Database Driver Class Initialized
INFO - 2025-11-14 13:09:22 --> Email Class Initialized
DEBUG - 2025-11-14 13:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:09:22 --> Controller Class Initialized
INFO - 2025-11-14 13:09:22 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:09:22 --> Model "User_model" initialized
INFO - 2025-11-14 13:09:22 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:09:22 --> Final output sent to browser
INFO - 2025-11-14 13:09:22 --> Total execution time: 0.4247
INFO - 2025-11-14 13:09:24 --> Config Class Initialized
INFO - 2025-11-14 13:09:24 --> Hooks Class Initialized
INFO - 2025-11-14 13:09:24 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:09:24 --> Utf8 Class Initialized
INFO - 2025-11-14 13:09:24 --> URI Class Initialized
INFO - 2025-11-14 13:09:24 --> Router Class Initialized
INFO - 2025-11-14 13:09:24 --> Output Class Initialized
INFO - 2025-11-14 13:09:24 --> Security Class Initialized
INFO - 2025-11-14 13:09:24 --> Input Class Initialized
INFO - 2025-11-14 13:09:24 --> Language Class Initialized
INFO - 2025-11-14 13:09:24 --> Loader Class Initialized
INFO - 2025-11-14 13:09:24 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:09:24 --> Helper loaded: url_helper
INFO - 2025-11-14 13:09:24 --> Helper loaded: file_helper
INFO - 2025-11-14 13:09:24 --> Helper loaded: main_helper
INFO - 2025-11-14 13:09:24 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:09:24 --> Database Driver Class Initialized
INFO - 2025-11-14 13:09:24 --> Email Class Initialized
DEBUG - 2025-11-14 13:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:09:24 --> Controller Class Initialized
INFO - 2025-11-14 13:09:24 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:09:24 --> Model "User_model" initialized
INFO - 2025-11-14 13:09:24 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:09:24 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-14 13:09:24 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-14 13:09:24 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-14 13:09:24 --> File loaded: D:\laragon\www\acumena\application\views\dashboard.php
INFO - 2025-11-14 13:09:24 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-14 13:09:24 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-14 13:09:24 --> Final output sent to browser
INFO - 2025-11-14 13:09:24 --> Total execution time: 0.0933
INFO - 2025-11-14 13:09:24 --> Config Class Initialized
INFO - 2025-11-14 13:09:24 --> Hooks Class Initialized
INFO - 2025-11-14 13:09:24 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:09:24 --> Utf8 Class Initialized
INFO - 2025-11-14 13:09:24 --> URI Class Initialized
INFO - 2025-11-14 13:09:24 --> Router Class Initialized
INFO - 2025-11-14 13:09:24 --> Output Class Initialized
INFO - 2025-11-14 13:09:24 --> Security Class Initialized
INFO - 2025-11-14 13:09:24 --> Input Class Initialized
INFO - 2025-11-14 13:09:24 --> Language Class Initialized
INFO - 2025-11-14 13:09:24 --> Loader Class Initialized
INFO - 2025-11-14 13:09:24 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:09:24 --> Helper loaded: url_helper
INFO - 2025-11-14 13:09:24 --> Helper loaded: file_helper
INFO - 2025-11-14 13:09:24 --> Helper loaded: main_helper
INFO - 2025-11-14 13:09:24 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:09:24 --> Database Driver Class Initialized
INFO - 2025-11-14 13:09:24 --> Email Class Initialized
DEBUG - 2025-11-14 13:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:09:24 --> Controller Class Initialized
INFO - 2025-11-14 13:09:24 --> Model "User_model" initialized
INFO - 2025-11-14 13:09:24 --> Model "Project_model" initialized
INFO - 2025-11-14 13:09:24 --> Helper loaded: form_helper
INFO - 2025-11-14 13:09:24 --> Form Validation Class Initialized
INFO - 2025-11-14 13:09:24 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-14 13:09:24 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-14 13:09:24 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-14 13:09:24 --> Model "Swot_model" initialized
INFO - 2025-11-14 13:09:24 --> Model "Swot_model" initialized
INFO - 2025-11-14 13:09:24 --> Model "Topk_service_model" initialized
INFO - 2025-11-14 13:09:24 --> Final output sent to browser
INFO - 2025-11-14 13:09:24 --> Total execution time: 0.1043
INFO - 2025-11-14 13:09:49 --> Config Class Initialized
INFO - 2025-11-14 13:09:49 --> Hooks Class Initialized
INFO - 2025-11-14 13:09:49 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:09:49 --> Utf8 Class Initialized
INFO - 2025-11-14 13:09:49 --> URI Class Initialized
DEBUG - 2025-11-14 13:09:49 --> No URI present. Default controller set.
INFO - 2025-11-14 13:09:49 --> Router Class Initialized
INFO - 2025-11-14 13:09:49 --> Output Class Initialized
INFO - 2025-11-14 13:09:49 --> Security Class Initialized
INFO - 2025-11-14 13:09:49 --> Input Class Initialized
INFO - 2025-11-14 13:09:49 --> Language Class Initialized
INFO - 2025-11-14 13:09:49 --> Loader Class Initialized
INFO - 2025-11-14 13:09:49 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:09:49 --> Helper loaded: url_helper
INFO - 2025-11-14 13:09:49 --> Helper loaded: file_helper
INFO - 2025-11-14 13:09:49 --> Helper loaded: main_helper
INFO - 2025-11-14 13:09:49 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:09:49 --> Database Driver Class Initialized
INFO - 2025-11-14 13:09:49 --> Email Class Initialized
DEBUG - 2025-11-14 13:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:09:49 --> Controller Class Initialized
INFO - 2025-11-14 13:09:49 --> Config Class Initialized
INFO - 2025-11-14 13:09:49 --> Hooks Class Initialized
INFO - 2025-11-14 13:09:49 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:09:49 --> Utf8 Class Initialized
INFO - 2025-11-14 13:09:49 --> URI Class Initialized
INFO - 2025-11-14 13:09:49 --> Router Class Initialized
INFO - 2025-11-14 13:09:49 --> Output Class Initialized
INFO - 2025-11-14 13:09:49 --> Security Class Initialized
INFO - 2025-11-14 13:09:49 --> Input Class Initialized
INFO - 2025-11-14 13:09:49 --> Language Class Initialized
INFO - 2025-11-14 13:09:49 --> Loader Class Initialized
INFO - 2025-11-14 13:09:49 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:09:49 --> Helper loaded: url_helper
INFO - 2025-11-14 13:09:49 --> Helper loaded: file_helper
INFO - 2025-11-14 13:09:49 --> Helper loaded: main_helper
INFO - 2025-11-14 13:09:49 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:09:49 --> Database Driver Class Initialized
INFO - 2025-11-14 13:09:49 --> Email Class Initialized
DEBUG - 2025-11-14 13:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:09:49 --> Controller Class Initialized
INFO - 2025-11-14 13:09:49 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:09:49 --> Model "User_model" initialized
INFO - 2025-11-14 13:09:49 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:09:49 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-desktop.php
INFO - 2025-11-14 13:09:49 --> File loaded: D:\laragon\www\acumena\application\views\components/sidebar-mobile.php
INFO - 2025-11-14 13:09:49 --> File loaded: D:\laragon\www\acumena\application\views\components/header.php
INFO - 2025-11-14 13:09:49 --> File loaded: D:\laragon\www\acumena\application\views\dashboard.php
INFO - 2025-11-14 13:09:49 --> File loaded: D:\laragon\www\acumena\application\views\components/footer.php
INFO - 2025-11-14 13:09:49 --> File loaded: D:\laragon\www\acumena\application\views\template.php
INFO - 2025-11-14 13:09:49 --> Final output sent to browser
INFO - 2025-11-14 13:09:49 --> Total execution time: 0.0971
INFO - 2025-11-14 13:09:49 --> Config Class Initialized
INFO - 2025-11-14 13:09:49 --> Hooks Class Initialized
INFO - 2025-11-14 13:09:49 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:09:49 --> Utf8 Class Initialized
INFO - 2025-11-14 13:09:49 --> URI Class Initialized
INFO - 2025-11-14 13:09:49 --> Router Class Initialized
INFO - 2025-11-14 13:09:49 --> Output Class Initialized
INFO - 2025-11-14 13:09:49 --> Security Class Initialized
INFO - 2025-11-14 13:09:49 --> Input Class Initialized
INFO - 2025-11-14 13:09:49 --> Language Class Initialized
INFO - 2025-11-14 13:09:49 --> Loader Class Initialized
INFO - 2025-11-14 13:09:49 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:09:49 --> Helper loaded: url_helper
INFO - 2025-11-14 13:09:49 --> Helper loaded: file_helper
INFO - 2025-11-14 13:09:49 --> Helper loaded: main_helper
INFO - 2025-11-14 13:09:49 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:09:49 --> Database Driver Class Initialized
INFO - 2025-11-14 13:09:49 --> Email Class Initialized
DEBUG - 2025-11-14 13:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:09:49 --> Controller Class Initialized
INFO - 2025-11-14 13:09:49 --> Model "User_model" initialized
INFO - 2025-11-14 13:09:49 --> Model "Project_model" initialized
INFO - 2025-11-14 13:09:49 --> Helper loaded: form_helper
INFO - 2025-11-14 13:09:49 --> Form Validation Class Initialized
INFO - 2025-11-14 13:09:49 --> Model "Project_ai_generation_run_model" initialized
INFO - 2025-11-14 13:09:49 --> Model "Ai_pair_filtered_model" initialized
INFO - 2025-11-14 13:09:49 --> Model "Ai_strategy_model" initialized
INFO - 2025-11-14 13:09:49 --> Model "Swot_model" initialized
INFO - 2025-11-14 13:09:49 --> Model "Swot_model" initialized
INFO - 2025-11-14 13:09:49 --> Model "Topk_service_model" initialized
INFO - 2025-11-14 13:09:49 --> Final output sent to browser
INFO - 2025-11-14 13:09:49 --> Total execution time: 0.1111
INFO - 2025-11-14 13:09:53 --> Config Class Initialized
INFO - 2025-11-14 13:09:53 --> Hooks Class Initialized
INFO - 2025-11-14 13:09:53 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:09:53 --> Utf8 Class Initialized
INFO - 2025-11-14 13:09:53 --> URI Class Initialized
INFO - 2025-11-14 13:09:53 --> Router Class Initialized
INFO - 2025-11-14 13:09:53 --> Output Class Initialized
INFO - 2025-11-14 13:09:53 --> Security Class Initialized
INFO - 2025-11-14 13:09:53 --> Input Class Initialized
INFO - 2025-11-14 13:09:53 --> Language Class Initialized
INFO - 2025-11-14 13:09:53 --> Loader Class Initialized
INFO - 2025-11-14 13:09:53 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:09:53 --> Helper loaded: url_helper
INFO - 2025-11-14 13:09:53 --> Helper loaded: file_helper
INFO - 2025-11-14 13:09:53 --> Helper loaded: main_helper
INFO - 2025-11-14 13:09:53 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:09:53 --> Database Driver Class Initialized
INFO - 2025-11-14 13:09:53 --> Email Class Initialized
DEBUG - 2025-11-14 13:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:09:53 --> Controller Class Initialized
INFO - 2025-11-14 13:09:53 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:09:53 --> Model "User_model" initialized
INFO - 2025-11-14 13:09:53 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:09:53 --> Config Class Initialized
INFO - 2025-11-14 13:09:53 --> Hooks Class Initialized
INFO - 2025-11-14 13:09:53 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:09:53 --> Utf8 Class Initialized
INFO - 2025-11-14 13:09:53 --> URI Class Initialized
INFO - 2025-11-14 13:09:53 --> Router Class Initialized
INFO - 2025-11-14 13:09:53 --> Output Class Initialized
INFO - 2025-11-14 13:09:53 --> Security Class Initialized
INFO - 2025-11-14 13:09:53 --> Input Class Initialized
INFO - 2025-11-14 13:09:53 --> Language Class Initialized
INFO - 2025-11-14 13:09:53 --> Loader Class Initialized
INFO - 2025-11-14 13:09:53 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:09:53 --> Helper loaded: url_helper
INFO - 2025-11-14 13:09:53 --> Helper loaded: file_helper
INFO - 2025-11-14 13:09:53 --> Helper loaded: main_helper
INFO - 2025-11-14 13:09:53 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:09:53 --> Database Driver Class Initialized
INFO - 2025-11-14 13:09:53 --> Email Class Initialized
DEBUG - 2025-11-14 13:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:09:53 --> Controller Class Initialized
INFO - 2025-11-14 13:09:53 --> Config Class Initialized
INFO - 2025-11-14 13:09:53 --> Hooks Class Initialized
INFO - 2025-11-14 13:09:54 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:09:54 --> Utf8 Class Initialized
INFO - 2025-11-14 13:09:54 --> URI Class Initialized
INFO - 2025-11-14 13:09:54 --> Router Class Initialized
INFO - 2025-11-14 13:09:54 --> Output Class Initialized
INFO - 2025-11-14 13:09:54 --> Security Class Initialized
INFO - 2025-11-14 13:09:54 --> Input Class Initialized
INFO - 2025-11-14 13:09:54 --> Language Class Initialized
INFO - 2025-11-14 13:09:54 --> Loader Class Initialized
INFO - 2025-11-14 13:09:54 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:09:54 --> Helper loaded: url_helper
INFO - 2025-11-14 13:09:54 --> Helper loaded: file_helper
INFO - 2025-11-14 13:09:54 --> Helper loaded: main_helper
INFO - 2025-11-14 13:09:54 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:09:54 --> Database Driver Class Initialized
INFO - 2025-11-14 13:09:54 --> Email Class Initialized
DEBUG - 2025-11-14 13:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:09:54 --> Controller Class Initialized
INFO - 2025-11-14 13:09:54 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:09:54 --> Model "User_model" initialized
INFO - 2025-11-14 13:09:54 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:09:54 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-14 13:09:54 --> Final output sent to browser
INFO - 2025-11-14 13:09:54 --> Total execution time: 0.0828
INFO - 2025-11-14 13:10:02 --> Config Class Initialized
INFO - 2025-11-14 13:10:02 --> Hooks Class Initialized
INFO - 2025-11-14 13:10:02 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:10:02 --> Utf8 Class Initialized
INFO - 2025-11-14 13:10:02 --> URI Class Initialized
INFO - 2025-11-14 13:10:02 --> Router Class Initialized
INFO - 2025-11-14 13:10:02 --> Output Class Initialized
INFO - 2025-11-14 13:10:02 --> Security Class Initialized
INFO - 2025-11-14 13:10:02 --> Input Class Initialized
INFO - 2025-11-14 13:10:02 --> Language Class Initialized
INFO - 2025-11-14 13:10:02 --> Loader Class Initialized
INFO - 2025-11-14 13:10:02 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:10:02 --> Helper loaded: url_helper
INFO - 2025-11-14 13:10:02 --> Helper loaded: file_helper
INFO - 2025-11-14 13:10:02 --> Helper loaded: main_helper
INFO - 2025-11-14 13:10:02 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:10:02 --> Database Driver Class Initialized
INFO - 2025-11-14 13:10:02 --> Email Class Initialized
DEBUG - 2025-11-14 13:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:10:02 --> Controller Class Initialized
INFO - 2025-11-14 13:10:02 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:10:02 --> Model "User_model" initialized
INFO - 2025-11-14 13:10:02 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:10:02 --> Final output sent to browser
INFO - 2025-11-14 13:10:02 --> Total execution time: 0.2125
INFO - 2025-11-14 13:10:03 --> Config Class Initialized
INFO - 2025-11-14 13:10:03 --> Hooks Class Initialized
INFO - 2025-11-14 13:10:03 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:10:03 --> Utf8 Class Initialized
INFO - 2025-11-14 13:10:03 --> URI Class Initialized
INFO - 2025-11-14 13:10:03 --> Router Class Initialized
INFO - 2025-11-14 13:10:03 --> Output Class Initialized
INFO - 2025-11-14 13:10:03 --> Security Class Initialized
INFO - 2025-11-14 13:10:03 --> Input Class Initialized
INFO - 2025-11-14 13:10:03 --> Language Class Initialized
INFO - 2025-11-14 13:10:03 --> Loader Class Initialized
INFO - 2025-11-14 13:10:03 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:10:03 --> Helper loaded: url_helper
INFO - 2025-11-14 13:10:03 --> Helper loaded: file_helper
INFO - 2025-11-14 13:10:03 --> Helper loaded: main_helper
INFO - 2025-11-14 13:10:03 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:10:03 --> Database Driver Class Initialized
INFO - 2025-11-14 13:10:03 --> Email Class Initialized
DEBUG - 2025-11-14 13:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:10:03 --> Controller Class Initialized
INFO - 2025-11-14 13:10:03 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:10:03 --> Model "User_model" initialized
INFO - 2025-11-14 13:10:03 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:10:03 --> File loaded: D:\laragon\www\acumena\application\views\auth/verify.php
INFO - 2025-11-14 13:10:03 --> Final output sent to browser
INFO - 2025-11-14 13:10:03 --> Total execution time: 0.0917
INFO - 2025-11-14 13:11:10 --> Config Class Initialized
INFO - 2025-11-14 13:11:10 --> Hooks Class Initialized
INFO - 2025-11-14 13:11:10 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:11:10 --> Utf8 Class Initialized
INFO - 2025-11-14 13:11:10 --> URI Class Initialized
INFO - 2025-11-14 13:11:10 --> Router Class Initialized
INFO - 2025-11-14 13:11:10 --> Output Class Initialized
INFO - 2025-11-14 13:11:10 --> Security Class Initialized
INFO - 2025-11-14 13:11:10 --> Input Class Initialized
INFO - 2025-11-14 13:11:10 --> Language Class Initialized
INFO - 2025-11-14 13:11:10 --> Loader Class Initialized
INFO - 2025-11-14 13:11:10 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:11:10 --> Helper loaded: url_helper
INFO - 2025-11-14 13:11:10 --> Helper loaded: file_helper
INFO - 2025-11-14 13:11:10 --> Helper loaded: main_helper
INFO - 2025-11-14 13:11:10 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:11:10 --> Database Driver Class Initialized
INFO - 2025-11-14 13:11:10 --> Email Class Initialized
DEBUG - 2025-11-14 13:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:11:10 --> Controller Class Initialized
INFO - 2025-11-14 13:11:10 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:11:10 --> Model "User_model" initialized
INFO - 2025-11-14 13:11:10 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:11:12 --> Final output sent to browser
INFO - 2025-11-14 13:11:12 --> Total execution time: 2.1001
INFO - 2025-11-14 13:15:56 --> Config Class Initialized
INFO - 2025-11-14 13:15:56 --> Hooks Class Initialized
INFO - 2025-11-14 13:15:56 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:15:56 --> Utf8 Class Initialized
INFO - 2025-11-14 13:15:56 --> URI Class Initialized
INFO - 2025-11-14 13:15:56 --> Router Class Initialized
INFO - 2025-11-14 13:15:56 --> Output Class Initialized
INFO - 2025-11-14 13:15:56 --> Security Class Initialized
INFO - 2025-11-14 13:15:56 --> Input Class Initialized
INFO - 2025-11-14 13:15:56 --> Language Class Initialized
INFO - 2025-11-14 13:15:56 --> Loader Class Initialized
INFO - 2025-11-14 13:15:56 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:15:56 --> Helper loaded: url_helper
INFO - 2025-11-14 13:15:56 --> Helper loaded: file_helper
INFO - 2025-11-14 13:15:56 --> Helper loaded: main_helper
INFO - 2025-11-14 13:15:56 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:15:56 --> Database Driver Class Initialized
INFO - 2025-11-14 13:15:56 --> Email Class Initialized
DEBUG - 2025-11-14 13:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:15:56 --> Controller Class Initialized
INFO - 2025-11-14 13:15:56 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:15:56 --> Model "User_model" initialized
INFO - 2025-11-14 13:15:56 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:15:56 --> Final output sent to browser
INFO - 2025-11-14 13:15:56 --> Total execution time: 0.1081
INFO - 2025-11-14 13:15:58 --> Config Class Initialized
INFO - 2025-11-14 13:15:58 --> Hooks Class Initialized
INFO - 2025-11-14 13:15:58 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:15:58 --> Utf8 Class Initialized
INFO - 2025-11-14 13:15:58 --> URI Class Initialized
INFO - 2025-11-14 13:15:58 --> Router Class Initialized
INFO - 2025-11-14 13:15:58 --> Output Class Initialized
INFO - 2025-11-14 13:15:58 --> Security Class Initialized
INFO - 2025-11-14 13:15:58 --> Input Class Initialized
INFO - 2025-11-14 13:15:58 --> Language Class Initialized
INFO - 2025-11-14 13:15:58 --> Loader Class Initialized
INFO - 2025-11-14 13:15:58 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:15:58 --> Helper loaded: url_helper
INFO - 2025-11-14 13:15:58 --> Helper loaded: file_helper
INFO - 2025-11-14 13:15:58 --> Helper loaded: main_helper
INFO - 2025-11-14 13:15:58 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:15:58 --> Database Driver Class Initialized
INFO - 2025-11-14 13:15:58 --> Email Class Initialized
DEBUG - 2025-11-14 13:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:15:58 --> Controller Class Initialized
INFO - 2025-11-14 13:15:58 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:15:58 --> Model "User_model" initialized
INFO - 2025-11-14 13:15:58 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:15:58 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-14 13:15:58 --> Final output sent to browser
INFO - 2025-11-14 13:15:58 --> Total execution time: 0.0882
INFO - 2025-11-14 13:16:30 --> Config Class Initialized
INFO - 2025-11-14 13:16:30 --> Hooks Class Initialized
INFO - 2025-11-14 13:16:30 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:16:30 --> Utf8 Class Initialized
INFO - 2025-11-14 13:16:30 --> URI Class Initialized
INFO - 2025-11-14 13:16:30 --> Router Class Initialized
INFO - 2025-11-14 13:16:30 --> Output Class Initialized
INFO - 2025-11-14 13:16:30 --> Security Class Initialized
INFO - 2025-11-14 13:16:30 --> Input Class Initialized
INFO - 2025-11-14 13:16:30 --> Language Class Initialized
INFO - 2025-11-14 13:16:30 --> Loader Class Initialized
INFO - 2025-11-14 13:16:30 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:16:30 --> Helper loaded: url_helper
INFO - 2025-11-14 13:16:30 --> Helper loaded: file_helper
INFO - 2025-11-14 13:16:30 --> Helper loaded: main_helper
INFO - 2025-11-14 13:16:30 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:16:30 --> Database Driver Class Initialized
INFO - 2025-11-14 13:16:30 --> Email Class Initialized
DEBUG - 2025-11-14 13:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:16:30 --> Controller Class Initialized
INFO - 2025-11-14 13:16:30 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:16:30 --> Model "User_model" initialized
INFO - 2025-11-14 13:16:30 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:16:32 --> Final output sent to browser
INFO - 2025-11-14 13:16:32 --> Total execution time: 1.9954
INFO - 2025-11-14 13:16:33 --> Config Class Initialized
INFO - 2025-11-14 13:16:33 --> Hooks Class Initialized
INFO - 2025-11-14 13:16:33 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:16:33 --> Utf8 Class Initialized
INFO - 2025-11-14 13:16:33 --> URI Class Initialized
INFO - 2025-11-14 13:16:33 --> Router Class Initialized
INFO - 2025-11-14 13:16:33 --> Output Class Initialized
INFO - 2025-11-14 13:16:33 --> Security Class Initialized
INFO - 2025-11-14 13:16:33 --> Input Class Initialized
INFO - 2025-11-14 13:16:33 --> Language Class Initialized
INFO - 2025-11-14 13:16:33 --> Loader Class Initialized
INFO - 2025-11-14 13:16:33 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:16:33 --> Helper loaded: url_helper
INFO - 2025-11-14 13:16:33 --> Helper loaded: file_helper
INFO - 2025-11-14 13:16:33 --> Helper loaded: main_helper
INFO - 2025-11-14 13:16:33 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:16:33 --> Database Driver Class Initialized
INFO - 2025-11-14 13:16:33 --> Email Class Initialized
DEBUG - 2025-11-14 13:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:16:34 --> Controller Class Initialized
INFO - 2025-11-14 13:16:34 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:16:34 --> Model "User_model" initialized
INFO - 2025-11-14 13:16:34 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:16:34 --> File loaded: D:\laragon\www\acumena\application\views\auth/verify.php
INFO - 2025-11-14 13:16:34 --> Final output sent to browser
INFO - 2025-11-14 13:16:34 --> Total execution time: 0.0953
INFO - 2025-11-14 13:19:05 --> Config Class Initialized
INFO - 2025-11-14 13:19:05 --> Hooks Class Initialized
INFO - 2025-11-14 13:19:05 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:19:05 --> Utf8 Class Initialized
INFO - 2025-11-14 13:19:05 --> URI Class Initialized
INFO - 2025-11-14 13:19:05 --> Router Class Initialized
INFO - 2025-11-14 13:19:05 --> Output Class Initialized
INFO - 2025-11-14 13:19:05 --> Security Class Initialized
INFO - 2025-11-14 13:19:05 --> Input Class Initialized
INFO - 2025-11-14 13:19:05 --> Language Class Initialized
INFO - 2025-11-14 13:19:05 --> Loader Class Initialized
INFO - 2025-11-14 13:19:05 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:19:05 --> Helper loaded: url_helper
INFO - 2025-11-14 13:19:05 --> Helper loaded: file_helper
INFO - 2025-11-14 13:19:05 --> Helper loaded: main_helper
INFO - 2025-11-14 13:19:05 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:19:05 --> Database Driver Class Initialized
INFO - 2025-11-14 13:19:05 --> Email Class Initialized
DEBUG - 2025-11-14 13:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:19:05 --> Controller Class Initialized
INFO - 2025-11-14 13:19:05 --> Config Class Initialized
INFO - 2025-11-14 13:19:05 --> Hooks Class Initialized
INFO - 2025-11-14 13:19:05 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:19:05 --> Utf8 Class Initialized
INFO - 2025-11-14 13:19:05 --> URI Class Initialized
INFO - 2025-11-14 13:19:05 --> Router Class Initialized
INFO - 2025-11-14 13:19:05 --> Output Class Initialized
INFO - 2025-11-14 13:19:05 --> Security Class Initialized
INFO - 2025-11-14 13:19:05 --> Input Class Initialized
INFO - 2025-11-14 13:19:05 --> Language Class Initialized
INFO - 2025-11-14 13:19:05 --> Loader Class Initialized
INFO - 2025-11-14 13:19:05 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:19:05 --> Helper loaded: url_helper
INFO - 2025-11-14 13:19:05 --> Helper loaded: file_helper
INFO - 2025-11-14 13:19:05 --> Helper loaded: main_helper
INFO - 2025-11-14 13:19:05 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:19:05 --> Database Driver Class Initialized
INFO - 2025-11-14 13:19:05 --> Email Class Initialized
DEBUG - 2025-11-14 13:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:19:06 --> Controller Class Initialized
INFO - 2025-11-14 13:19:06 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:19:06 --> Model "User_model" initialized
INFO - 2025-11-14 13:19:06 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:19:06 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-14 13:19:06 --> Final output sent to browser
INFO - 2025-11-14 13:19:06 --> Total execution time: 0.0901
INFO - 2025-11-14 13:19:14 --> Config Class Initialized
INFO - 2025-11-14 13:19:14 --> Hooks Class Initialized
INFO - 2025-11-14 13:19:14 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:19:14 --> Utf8 Class Initialized
INFO - 2025-11-14 13:19:14 --> URI Class Initialized
INFO - 2025-11-14 13:19:14 --> Router Class Initialized
INFO - 2025-11-14 13:19:14 --> Output Class Initialized
INFO - 2025-11-14 13:19:14 --> Security Class Initialized
INFO - 2025-11-14 13:19:14 --> Input Class Initialized
INFO - 2025-11-14 13:19:14 --> Language Class Initialized
INFO - 2025-11-14 13:19:14 --> Loader Class Initialized
INFO - 2025-11-14 13:19:14 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:19:14 --> Helper loaded: url_helper
INFO - 2025-11-14 13:19:14 --> Helper loaded: file_helper
INFO - 2025-11-14 13:19:14 --> Helper loaded: main_helper
INFO - 2025-11-14 13:19:14 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:19:14 --> Database Driver Class Initialized
INFO - 2025-11-14 13:19:14 --> Email Class Initialized
DEBUG - 2025-11-14 13:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:19:14 --> Controller Class Initialized
INFO - 2025-11-14 13:19:14 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:19:14 --> Model "User_model" initialized
INFO - 2025-11-14 13:19:14 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:19:15 --> Final output sent to browser
INFO - 2025-11-14 13:19:15 --> Total execution time: 0.2095
INFO - 2025-11-14 13:19:20 --> Config Class Initialized
INFO - 2025-11-14 13:19:20 --> Hooks Class Initialized
INFO - 2025-11-14 13:19:20 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:19:20 --> Utf8 Class Initialized
INFO - 2025-11-14 13:19:20 --> URI Class Initialized
INFO - 2025-11-14 13:19:20 --> Router Class Initialized
INFO - 2025-11-14 13:19:20 --> Output Class Initialized
INFO - 2025-11-14 13:19:20 --> Security Class Initialized
INFO - 2025-11-14 13:19:20 --> Input Class Initialized
INFO - 2025-11-14 13:19:20 --> Language Class Initialized
INFO - 2025-11-14 13:19:20 --> Loader Class Initialized
INFO - 2025-11-14 13:19:20 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:19:20 --> Helper loaded: url_helper
INFO - 2025-11-14 13:19:20 --> Helper loaded: file_helper
INFO - 2025-11-14 13:19:20 --> Helper loaded: main_helper
INFO - 2025-11-14 13:19:20 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:19:20 --> Database Driver Class Initialized
INFO - 2025-11-14 13:19:20 --> Email Class Initialized
DEBUG - 2025-11-14 13:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:19:20 --> Controller Class Initialized
INFO - 2025-11-14 13:19:20 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:19:20 --> Model "User_model" initialized
INFO - 2025-11-14 13:19:20 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:19:21 --> Final output sent to browser
INFO - 2025-11-14 13:19:21 --> Total execution time: 1.5704
INFO - 2025-11-14 13:19:23 --> Config Class Initialized
INFO - 2025-11-14 13:19:23 --> Hooks Class Initialized
INFO - 2025-11-14 13:19:23 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:19:23 --> Utf8 Class Initialized
INFO - 2025-11-14 13:19:23 --> URI Class Initialized
INFO - 2025-11-14 13:19:23 --> Router Class Initialized
INFO - 2025-11-14 13:19:23 --> Output Class Initialized
INFO - 2025-11-14 13:19:23 --> Security Class Initialized
INFO - 2025-11-14 13:19:23 --> Input Class Initialized
INFO - 2025-11-14 13:19:23 --> Language Class Initialized
INFO - 2025-11-14 13:19:23 --> Loader Class Initialized
INFO - 2025-11-14 13:19:23 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:19:23 --> Helper loaded: url_helper
INFO - 2025-11-14 13:19:23 --> Helper loaded: file_helper
INFO - 2025-11-14 13:19:23 --> Helper loaded: main_helper
INFO - 2025-11-14 13:19:23 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:19:23 --> Database Driver Class Initialized
INFO - 2025-11-14 13:19:23 --> Email Class Initialized
DEBUG - 2025-11-14 13:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:19:23 --> Controller Class Initialized
INFO - 2025-11-14 13:19:23 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:19:23 --> Model "User_model" initialized
INFO - 2025-11-14 13:19:23 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:19:23 --> File loaded: D:\laragon\www\acumena\application\views\auth/verify.php
INFO - 2025-11-14 13:19:23 --> Final output sent to browser
INFO - 2025-11-14 13:19:23 --> Total execution time: 0.1160
INFO - 2025-11-14 13:19:40 --> Config Class Initialized
INFO - 2025-11-14 13:19:40 --> Hooks Class Initialized
INFO - 2025-11-14 13:19:40 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:19:40 --> Utf8 Class Initialized
INFO - 2025-11-14 13:19:40 --> URI Class Initialized
INFO - 2025-11-14 13:19:40 --> Router Class Initialized
INFO - 2025-11-14 13:19:40 --> Output Class Initialized
INFO - 2025-11-14 13:19:40 --> Security Class Initialized
INFO - 2025-11-14 13:19:40 --> Input Class Initialized
INFO - 2025-11-14 13:19:40 --> Language Class Initialized
INFO - 2025-11-14 13:19:40 --> Loader Class Initialized
INFO - 2025-11-14 13:19:40 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:19:40 --> Helper loaded: url_helper
INFO - 2025-11-14 13:19:40 --> Helper loaded: file_helper
INFO - 2025-11-14 13:19:40 --> Helper loaded: main_helper
INFO - 2025-11-14 13:19:40 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:19:40 --> Database Driver Class Initialized
INFO - 2025-11-14 13:19:40 --> Email Class Initialized
DEBUG - 2025-11-14 13:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:19:40 --> Controller Class Initialized
INFO - 2025-11-14 13:19:40 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:19:40 --> Model "User_model" initialized
INFO - 2025-11-14 13:19:40 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:19:40 --> Final output sent to browser
INFO - 2025-11-14 13:19:40 --> Total execution time: 0.1005
INFO - 2025-11-14 13:19:41 --> Config Class Initialized
INFO - 2025-11-14 13:19:41 --> Hooks Class Initialized
INFO - 2025-11-14 13:19:41 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:19:41 --> Utf8 Class Initialized
INFO - 2025-11-14 13:19:41 --> URI Class Initialized
INFO - 2025-11-14 13:19:41 --> Router Class Initialized
INFO - 2025-11-14 13:19:41 --> Output Class Initialized
INFO - 2025-11-14 13:19:41 --> Security Class Initialized
INFO - 2025-11-14 13:19:41 --> Input Class Initialized
INFO - 2025-11-14 13:19:41 --> Language Class Initialized
INFO - 2025-11-14 13:19:42 --> Loader Class Initialized
INFO - 2025-11-14 13:19:42 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:19:42 --> Helper loaded: url_helper
INFO - 2025-11-14 13:19:42 --> Helper loaded: file_helper
INFO - 2025-11-14 13:19:42 --> Helper loaded: main_helper
INFO - 2025-11-14 13:19:42 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:19:42 --> Database Driver Class Initialized
INFO - 2025-11-14 13:19:42 --> Email Class Initialized
DEBUG - 2025-11-14 13:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:19:42 --> Controller Class Initialized
INFO - 2025-11-14 13:19:42 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:19:42 --> Model "User_model" initialized
INFO - 2025-11-14 13:19:42 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:19:42 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-14 13:19:42 --> Final output sent to browser
INFO - 2025-11-14 13:19:42 --> Total execution time: 0.1030
INFO - 2025-11-14 13:21:40 --> Config Class Initialized
INFO - 2025-11-14 13:21:40 --> Hooks Class Initialized
INFO - 2025-11-14 13:21:40 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:21:40 --> Utf8 Class Initialized
INFO - 2025-11-14 13:21:40 --> URI Class Initialized
INFO - 2025-11-14 13:21:40 --> Router Class Initialized
INFO - 2025-11-14 13:21:40 --> Output Class Initialized
INFO - 2025-11-14 13:21:40 --> Security Class Initialized
INFO - 2025-11-14 13:21:40 --> Input Class Initialized
INFO - 2025-11-14 13:21:40 --> Language Class Initialized
INFO - 2025-11-14 13:21:40 --> Loader Class Initialized
INFO - 2025-11-14 13:21:40 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:21:40 --> Helper loaded: url_helper
INFO - 2025-11-14 13:21:40 --> Helper loaded: file_helper
INFO - 2025-11-14 13:21:40 --> Helper loaded: main_helper
INFO - 2025-11-14 13:21:40 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:21:40 --> Database Driver Class Initialized
INFO - 2025-11-14 13:21:40 --> Email Class Initialized
DEBUG - 2025-11-14 13:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:21:40 --> Controller Class Initialized
INFO - 2025-11-14 13:21:40 --> API /auth/forgot_password invoked
INFO - 2025-11-14 13:21:40 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-14 13:21:40 --> Final output sent to browser
INFO - 2025-11-14 13:21:40 --> Total execution time: 0.1058
INFO - 2025-11-14 13:22:41 --> Config Class Initialized
INFO - 2025-11-14 13:22:41 --> Hooks Class Initialized
INFO - 2025-11-14 13:22:41 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:22:41 --> Utf8 Class Initialized
INFO - 2025-11-14 13:22:41 --> URI Class Initialized
INFO - 2025-11-14 13:22:41 --> Router Class Initialized
INFO - 2025-11-14 13:22:41 --> Output Class Initialized
INFO - 2025-11-14 13:22:41 --> Security Class Initialized
INFO - 2025-11-14 13:22:41 --> Input Class Initialized
INFO - 2025-11-14 13:22:41 --> Language Class Initialized
INFO - 2025-11-14 13:22:41 --> Loader Class Initialized
INFO - 2025-11-14 13:22:41 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:22:41 --> Helper loaded: url_helper
INFO - 2025-11-14 13:22:41 --> Helper loaded: file_helper
INFO - 2025-11-14 13:22:41 --> Helper loaded: main_helper
INFO - 2025-11-14 13:22:41 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:22:41 --> Database Driver Class Initialized
INFO - 2025-11-14 13:22:41 --> Email Class Initialized
DEBUG - 2025-11-14 13:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:22:41 --> Controller Class Initialized
INFO - 2025-11-14 13:22:41 --> API /auth/forgot_password invoked
INFO - 2025-11-14 13:22:41 --> File loaded: D:\laragon\www\acumena\application\views\auth/forgot_password.php
INFO - 2025-11-14 13:22:41 --> Final output sent to browser
INFO - 2025-11-14 13:22:41 --> Total execution time: 0.1068
INFO - 2025-11-14 13:28:08 --> Config Class Initialized
INFO - 2025-11-14 13:28:08 --> Hooks Class Initialized
INFO - 2025-11-14 13:28:08 --> UTF-8 Support Enabled
INFO - 2025-11-14 13:28:08 --> Utf8 Class Initialized
INFO - 2025-11-14 13:28:08 --> URI Class Initialized
INFO - 2025-11-14 13:28:08 --> Router Class Initialized
INFO - 2025-11-14 13:28:08 --> Output Class Initialized
INFO - 2025-11-14 13:28:08 --> Security Class Initialized
INFO - 2025-11-14 13:28:08 --> Input Class Initialized
INFO - 2025-11-14 13:28:08 --> Language Class Initialized
INFO - 2025-11-14 13:28:08 --> Loader Class Initialized
INFO - 2025-11-14 13:28:08 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 13:28:08 --> Helper loaded: url_helper
INFO - 2025-11-14 13:28:08 --> Helper loaded: file_helper
INFO - 2025-11-14 13:28:08 --> Helper loaded: main_helper
INFO - 2025-11-14 13:28:08 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 13:28:08 --> Database Driver Class Initialized
INFO - 2025-11-14 13:28:08 --> Email Class Initialized
DEBUG - 2025-11-14 13:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 13:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 13:28:08 --> Controller Class Initialized
INFO - 2025-11-14 13:28:08 --> Model "Subscription_model" initialized
INFO - 2025-11-14 13:28:08 --> Model "User_model" initialized
INFO - 2025-11-14 13:28:08 --> Model "Auth_model" initialized
INFO - 2025-11-14 13:28:08 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-14 13:28:08 --> Final output sent to browser
INFO - 2025-11-14 13:28:08 --> Total execution time: 0.1221
INFO - 2025-11-14 14:28:41 --> Config Class Initialized
INFO - 2025-11-14 14:28:41 --> Hooks Class Initialized
INFO - 2025-11-14 14:28:41 --> UTF-8 Support Enabled
INFO - 2025-11-14 14:28:41 --> Utf8 Class Initialized
INFO - 2025-11-14 14:28:41 --> URI Class Initialized
DEBUG - 2025-11-14 14:28:41 --> No URI present. Default controller set.
INFO - 2025-11-14 14:28:41 --> Router Class Initialized
INFO - 2025-11-14 14:28:41 --> Output Class Initialized
INFO - 2025-11-14 14:28:41 --> Security Class Initialized
INFO - 2025-11-14 14:28:41 --> Input Class Initialized
INFO - 2025-11-14 14:28:41 --> Language Class Initialized
INFO - 2025-11-14 14:28:41 --> Loader Class Initialized
INFO - 2025-11-14 14:28:41 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 14:28:41 --> Helper loaded: url_helper
INFO - 2025-11-14 14:28:41 --> Helper loaded: file_helper
INFO - 2025-11-14 14:28:41 --> Helper loaded: main_helper
INFO - 2025-11-14 14:28:41 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 14:28:41 --> Database Driver Class Initialized
INFO - 2025-11-14 14:28:41 --> Email Class Initialized
DEBUG - 2025-11-14 14:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 14:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 14:28:41 --> Controller Class Initialized
INFO - 2025-11-14 14:28:41 --> Config Class Initialized
INFO - 2025-11-14 14:28:41 --> Hooks Class Initialized
INFO - 2025-11-14 14:28:41 --> UTF-8 Support Enabled
INFO - 2025-11-14 14:28:41 --> Utf8 Class Initialized
INFO - 2025-11-14 14:28:41 --> URI Class Initialized
INFO - 2025-11-14 14:28:41 --> Router Class Initialized
INFO - 2025-11-14 14:28:41 --> Output Class Initialized
INFO - 2025-11-14 14:28:41 --> Security Class Initialized
INFO - 2025-11-14 14:28:41 --> Input Class Initialized
INFO - 2025-11-14 14:28:41 --> Language Class Initialized
INFO - 2025-11-14 14:28:41 --> Loader Class Initialized
INFO - 2025-11-14 14:28:41 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 14:28:41 --> Helper loaded: url_helper
INFO - 2025-11-14 14:28:41 --> Helper loaded: file_helper
INFO - 2025-11-14 14:28:41 --> Helper loaded: main_helper
INFO - 2025-11-14 14:28:41 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 14:28:41 --> Database Driver Class Initialized
INFO - 2025-11-14 14:28:41 --> Email Class Initialized
DEBUG - 2025-11-14 14:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 14:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 14:28:41 --> Controller Class Initialized
INFO - 2025-11-14 14:28:41 --> Model "Subscription_model" initialized
INFO - 2025-11-14 14:28:41 --> Model "User_model" initialized
INFO - 2025-11-14 14:28:41 --> Model "Auth_model" initialized
INFO - 2025-11-14 14:28:41 --> Config Class Initialized
INFO - 2025-11-14 14:28:41 --> Hooks Class Initialized
INFO - 2025-11-14 14:28:41 --> UTF-8 Support Enabled
INFO - 2025-11-14 14:28:41 --> Utf8 Class Initialized
INFO - 2025-11-14 14:28:41 --> URI Class Initialized
INFO - 2025-11-14 14:28:41 --> Router Class Initialized
INFO - 2025-11-14 14:28:41 --> Output Class Initialized
INFO - 2025-11-14 14:28:41 --> Security Class Initialized
INFO - 2025-11-14 14:28:41 --> Input Class Initialized
INFO - 2025-11-14 14:28:41 --> Language Class Initialized
INFO - 2025-11-14 14:28:41 --> Loader Class Initialized
INFO - 2025-11-14 14:28:41 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 14:28:41 --> Helper loaded: url_helper
INFO - 2025-11-14 14:28:41 --> Helper loaded: file_helper
INFO - 2025-11-14 14:28:41 --> Helper loaded: main_helper
INFO - 2025-11-14 14:28:41 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 14:28:41 --> Database Driver Class Initialized
INFO - 2025-11-14 14:28:41 --> Email Class Initialized
DEBUG - 2025-11-14 14:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 14:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 14:28:41 --> Controller Class Initialized
INFO - 2025-11-14 14:28:41 --> Config Class Initialized
INFO - 2025-11-14 14:28:41 --> Hooks Class Initialized
INFO - 2025-11-14 14:28:41 --> UTF-8 Support Enabled
INFO - 2025-11-14 14:28:41 --> Utf8 Class Initialized
INFO - 2025-11-14 14:28:41 --> URI Class Initialized
INFO - 2025-11-14 14:28:41 --> Router Class Initialized
INFO - 2025-11-14 14:28:41 --> Output Class Initialized
INFO - 2025-11-14 14:28:41 --> Security Class Initialized
INFO - 2025-11-14 14:28:41 --> Input Class Initialized
INFO - 2025-11-14 14:28:41 --> Language Class Initialized
INFO - 2025-11-14 14:28:41 --> Loader Class Initialized
INFO - 2025-11-14 14:28:41 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 14:28:41 --> Helper loaded: url_helper
INFO - 2025-11-14 14:28:41 --> Helper loaded: file_helper
INFO - 2025-11-14 14:28:41 --> Helper loaded: main_helper
INFO - 2025-11-14 14:28:41 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 14:28:41 --> Database Driver Class Initialized
INFO - 2025-11-14 14:28:41 --> Email Class Initialized
DEBUG - 2025-11-14 14:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 14:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 14:28:41 --> Controller Class Initialized
INFO - 2025-11-14 14:28:41 --> Model "Subscription_model" initialized
INFO - 2025-11-14 14:28:41 --> Model "User_model" initialized
INFO - 2025-11-14 14:28:41 --> Model "Auth_model" initialized
INFO - 2025-11-14 14:28:41 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-14 14:28:41 --> Final output sent to browser
INFO - 2025-11-14 14:28:41 --> Total execution time: 0.0797
INFO - 2025-11-14 14:56:31 --> Config Class Initialized
INFO - 2025-11-14 14:56:31 --> Hooks Class Initialized
INFO - 2025-11-14 14:56:31 --> UTF-8 Support Enabled
INFO - 2025-11-14 14:56:31 --> Utf8 Class Initialized
INFO - 2025-11-14 14:56:31 --> URI Class Initialized
DEBUG - 2025-11-14 14:56:31 --> No URI present. Default controller set.
INFO - 2025-11-14 14:56:31 --> Router Class Initialized
INFO - 2025-11-14 14:56:31 --> Output Class Initialized
INFO - 2025-11-14 14:56:31 --> Security Class Initialized
INFO - 2025-11-14 14:56:31 --> Input Class Initialized
INFO - 2025-11-14 14:56:31 --> Language Class Initialized
INFO - 2025-11-14 14:56:31 --> Loader Class Initialized
INFO - 2025-11-14 14:56:31 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 14:56:31 --> Helper loaded: url_helper
INFO - 2025-11-14 14:56:31 --> Helper loaded: file_helper
INFO - 2025-11-14 14:56:31 --> Helper loaded: main_helper
INFO - 2025-11-14 14:56:31 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 14:56:31 --> Database Driver Class Initialized
INFO - 2025-11-14 14:56:31 --> Email Class Initialized
DEBUG - 2025-11-14 14:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 14:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 14:56:31 --> Controller Class Initialized
INFO - 2025-11-14 14:56:31 --> Config Class Initialized
INFO - 2025-11-14 14:56:31 --> Hooks Class Initialized
INFO - 2025-11-14 14:56:31 --> UTF-8 Support Enabled
INFO - 2025-11-14 14:56:31 --> Utf8 Class Initialized
INFO - 2025-11-14 14:56:31 --> URI Class Initialized
INFO - 2025-11-14 14:56:31 --> Router Class Initialized
INFO - 2025-11-14 14:56:31 --> Output Class Initialized
INFO - 2025-11-14 14:56:31 --> Security Class Initialized
INFO - 2025-11-14 14:56:31 --> Input Class Initialized
INFO - 2025-11-14 14:56:31 --> Language Class Initialized
INFO - 2025-11-14 14:56:31 --> Loader Class Initialized
INFO - 2025-11-14 14:56:32 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 14:56:32 --> Helper loaded: url_helper
INFO - 2025-11-14 14:56:32 --> Helper loaded: file_helper
INFO - 2025-11-14 14:56:32 --> Helper loaded: main_helper
INFO - 2025-11-14 14:56:32 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 14:56:32 --> Database Driver Class Initialized
INFO - 2025-11-14 14:56:32 --> Email Class Initialized
DEBUG - 2025-11-14 14:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 14:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 14:56:32 --> Controller Class Initialized
INFO - 2025-11-14 14:56:32 --> Model "Subscription_model" initialized
INFO - 2025-11-14 14:56:32 --> Model "User_model" initialized
INFO - 2025-11-14 14:56:32 --> Model "Auth_model" initialized
INFO - 2025-11-14 14:56:32 --> Config Class Initialized
INFO - 2025-11-14 14:56:32 --> Hooks Class Initialized
INFO - 2025-11-14 14:56:32 --> UTF-8 Support Enabled
INFO - 2025-11-14 14:56:32 --> Utf8 Class Initialized
INFO - 2025-11-14 14:56:32 --> URI Class Initialized
INFO - 2025-11-14 14:56:32 --> Router Class Initialized
INFO - 2025-11-14 14:56:32 --> Output Class Initialized
INFO - 2025-11-14 14:56:32 --> Security Class Initialized
INFO - 2025-11-14 14:56:32 --> Input Class Initialized
INFO - 2025-11-14 14:56:32 --> Language Class Initialized
INFO - 2025-11-14 14:56:32 --> Loader Class Initialized
INFO - 2025-11-14 14:56:32 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 14:56:32 --> Helper loaded: url_helper
INFO - 2025-11-14 14:56:32 --> Helper loaded: file_helper
INFO - 2025-11-14 14:56:32 --> Helper loaded: main_helper
INFO - 2025-11-14 14:56:32 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 14:56:32 --> Database Driver Class Initialized
INFO - 2025-11-14 14:56:32 --> Email Class Initialized
DEBUG - 2025-11-14 14:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 14:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 14:56:32 --> Controller Class Initialized
INFO - 2025-11-14 14:56:32 --> Config Class Initialized
INFO - 2025-11-14 14:56:32 --> Hooks Class Initialized
INFO - 2025-11-14 14:56:32 --> UTF-8 Support Enabled
INFO - 2025-11-14 14:56:32 --> Utf8 Class Initialized
INFO - 2025-11-14 14:56:32 --> URI Class Initialized
INFO - 2025-11-14 14:56:32 --> Router Class Initialized
INFO - 2025-11-14 14:56:32 --> Output Class Initialized
INFO - 2025-11-14 14:56:32 --> Security Class Initialized
INFO - 2025-11-14 14:56:32 --> Input Class Initialized
INFO - 2025-11-14 14:56:32 --> Language Class Initialized
INFO - 2025-11-14 14:56:32 --> Loader Class Initialized
INFO - 2025-11-14 14:56:32 --> Config file loaded: D:\laragon\www\acumena\application\config/sendgrid.php
INFO - 2025-11-14 14:56:32 --> Helper loaded: url_helper
INFO - 2025-11-14 14:56:32 --> Helper loaded: file_helper
INFO - 2025-11-14 14:56:32 --> Helper loaded: main_helper
INFO - 2025-11-14 14:56:32 --> Helper loaded: sendgrid_helper
INFO - 2025-11-14 14:56:32 --> Database Driver Class Initialized
INFO - 2025-11-14 14:56:32 --> Email Class Initialized
DEBUG - 2025-11-14 14:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-14 14:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-14 14:56:32 --> Controller Class Initialized
INFO - 2025-11-14 14:56:32 --> Model "Subscription_model" initialized
INFO - 2025-11-14 14:56:32 --> Model "User_model" initialized
INFO - 2025-11-14 14:56:32 --> Model "Auth_model" initialized
INFO - 2025-11-14 14:56:32 --> File loaded: D:\laragon\www\acumena\application\views\auth/login.php
INFO - 2025-11-14 14:56:32 --> Final output sent to browser
INFO - 2025-11-14 14:56:32 --> Total execution time: 0.1091
