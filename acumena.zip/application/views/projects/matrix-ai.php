<!-- Header -->
<div class="container px-6 mx-auto">
  <div class="flex items-center justify-between my-6">
    <div>
        <h2 class="text-2xl font-bold text-gray-700 dark:text-gray-200"><span class="text-gray-400">Create Project::</span> SWOT Analysis</h2>
        <p class="text-gray-500">Identify your organization's Strengths, Weaknesses, Opportunities, and Threats</p>
    </div>
  </div>
</div>

<div class="container mx-auto px-6">
    <style>
    @media (max-width: 1024px) {
        .steps { gap:6px !important; }
        .step { padding:8px !important; }
        .step__desc { display:none !important; }
        .step__title { font-size:13px !important; line-height:1.2 !important; }
    }
    </style>

    <div>
        <div class="steps flex items-stretch justify-between gap-3">

            <!-- STEP 1 (Active) -->
            <div class="step step--inactive bg-white dark:bg-gray-800 rounded-2xl px-4 py-2 items-center border border-gray-200 dark:border-gray-600 gap-2 flex flex-1 basis-0">
                <div class="step__num w-6 h-6 flex items-center justify-center rounded-full shadow-md font-bold  bg-gray-300 dark:bg-gray-700 dark:text-white w-9 h-9 flex-shrink-0 flex-grow-0 basis-9 flex justify-center">1</div>
                <div class="flex flex-col gap-1 min-w-0">
                    <div class="step__title font-bold text-sm dark:text-white">Company Profile</div>
                    <div class="step__desc text-xs text-gray-500">Complete your company data</div>
                </div>
            </div>

            <!-- STEP 2 -->
            <div class="step step--inactive bg-white dark:bg-gray-800 rounded-2xl px-4 py-2 items-center border border-gray-200 dark:border-gray-600 gap-2 flex flex-1 basis-0">
                <div class="step__num w-6 h-6 flex items-center justify-center rounded-full shadow-md font-bold  bg-gray-300 dark:bg-gray-700 dark:text-white w-9 h-9 flex-shrink-0 flex-grow-0 basis-9 flex justify-center">2</div>
                <div class="flex flex-col gap-1 min-w-0">
                    <div class="step__title font-bold text-sm dark:text-white">SWOT Analysis</div>
                    <div class="step__desc text-xs text-gray-500">Assess Strengths, Weaknesses, Opportunities, and Threats</div>
                </div>
            </div>

            <!-- STEP 3 -->
            <div class="step step--active bg-blue-300 rounded-2xl px-4 py-2 items-center gap-2 flex flex-1 basis-0 border border-gray-200">
                <div class="step__num w-6 h-6 flex items-center justify-center rounded-full shadow-md font-bold text-white bg-blue-600 w-9 h-9 flex-shrink-0 flex-grow-0 basis-9 flex justify-center">3</div>
                <div class="flex flex-col gap-1 min-w-0">
                    <div class="step__title font-bold text-sm">Matrix Analysis</div>
                    <div class="step__desc text-xs text-gray-500">Evaluate IE Matrix and strategic recommendations</div>
                </div>
            </div>

        </div>
    </div>

    <div class="rounded-2xl bg-white dark:bg-gray-800 shadow-md mx-auto mt-8 p-6">
        <!-- Tabs Wrapper -->
        <div class="rounded-lg bg-gray-100 dark:bg-gray-900 border border-gray-200 dark:border-gray-600 flex flex-wrap p-2 gap-2">

            <!-- IFE -->
            <a href="<?= base_url('project/add?step=matrix-ife') ?>" class="text-gray-700 dark:text-white flex items-center gap-2 px-4 py-2 rounded-lg text-sm">
                <!-- Desktop label -->
                <span class="font-bold hidden md:inline">IFE Matrix</span>
                <!-- Mobile label -->
                <span class="font-bold md:hidden inline">IFE</span>
                <!-- Keterangan: tampil hanya di md+ -->
                <span class="hidden md:inline">(Internal)</span>
            </a>

            <!-- EFE -->
            <a href="<?= base_url('project/add?step=matrix-efe') ?>" class="text-gray-700 dark:text-white flex items-center gap-2 px-4 py-2 rounded-lg text-sm">
                <span class="font-bold hidden md:inline">EFE Matrix</span>
                <span class="font-bold md:hidden inline">EFE</span>
                <span class="hidden md:inline">(External)</span>
            </a>

            <!-- IE -->
            <a href="<?= base_url('project/add?step=matrix-ie') ?>" class="text-gray-700 dark:text-white flex items-center gap-2 px-4 py-2 rounded-lg text-sm">
                <span class="font-bold hidden md:inline">IE Matrix</span>
                <span class="font-bold md:hidden inline">IE</span>
                <span class="hidden md:inline">(Combined)</span>
            </a>

            <!-- AI Integration -->
            <a href="<?= base_url('project/add?step=matrix-ai') ?>" class="bg-success text-white shadow-md flex items-center gap-2 px-4 py-2 rounded-lg text-sm">
                <!-- Sama di mobile & desktop: "AI Integration" -->
                <span class="font-bold">AI Integration</span>
                <!-- Keterangan hanya di md+ -->
                <span class="hidden md:inline">(Strategies)</span>
            </a>
        </div>

        <div class="mt-6">
            <h2 class="text-2xl font-bold text-gray-700 dark:text-gray-200">AI-Powered Strategy Generation</h2>
            <span class="text-gray-500">Generate strategic recommendations using AI models based on your SWOT analysis and IE Matrix position. The system will analyze your inputs and suggest tailored strategies for your organization.</span>
        </div>


    </div>

    <button class="btn btn-block gradient-primary mt-8" style="border-radius: 10px;">
        <div class="font-bold">Generate All SWOT Strategies</div>
        <span class="text-sm text-white">This will generate strategies for all four quadrants of the SWOT Matrix</span>
    </button>
        
    <!-- GRID -->
    <div class="flex flex-wrap gap-6 items-stretch mt-8">
        <!-- ========== STRENGTHS ========== -->
            <section class="section-swot dark:section-swot">
                <!-- header -->
                <div class="section-swot-header bg-soft-success dark:text-white flex flex-col gap-1">
                    <div class="font-bold" style="margin-bottom: -10px;">SO Strategies</div>
                    <span class="text-sm">Use strengths to take advantage of opportunities</span>
                </div>

                <!-- body -->
                <div class="section-swot-body">
                    <!-- item 1 -->
                    <div id="soStrategiesContainer" class="py-2 mb-4">
                        <div id="soPlaceholder" class="p-4 flex flex-col items-center justify-center text-center">
                            <svg xmlns="http://www.w3.org/2000/svg" 
                                width="24" height="24" viewBox="0 0 24 24" 
                                fill="none" stroke="currentColor" stroke-width="2" 
                                stroke-linecap="round" stroke-linejoin="round" 
                                class="h-8 w-8 mb-2 opacity-50">
                                <path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"></path>
                                <path d="M9 18h6"></path>
                                <path d="M10 22h4"></path>
                            </svg>
                            <span class="text-sm text-gray-500">No strategies generated yet</span>
                        </div>
                        <ul id="soStrategiesList" style="list-style:none; margin:0; padding:0; display:none;">
                        </ul>
                        <div id="soStatus" class="mt-2 text-xs text-gray-600" style="display:none;"></div>
                    </div>


                    <!-- add button -->
                    <button id="generateSOBtn" class="flex items-center justify-center btn-soft-success rounded-md w-full font-semibold px-4 py-2">
                        <span class="button-text">Generate Strategies</span>
                        <div class="loading-spinner hidden ml-2">
                            <svg class="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                        </div>
                    </button>


                </div>
            </section>

            <!-- ========== OPPORTUNITIES ========== -->
            <section class="section-swot dark:section-swot">
                <div class="section-swot-header bg-soft-primary dark:text-white flex flex-col gap-1">
                    <div class="font-bold" style="margin-bottom: -10px;">ST Strategies</div>
                    <span class="text-sm">Use strengths to minimize threats</span>
                </div>
                <div class="section-swot-body">
                    <div id="stStrategiesContainer" class="py-2 mb-4">
                        <div id="stPlaceholder" class="p-4 flex flex-col items-center justify-center text-center">
                            <svg xmlns="http://www.w3.org/2000/svg" 
                                width="24" height="24" viewBox="0 0 24 24" 
                                fill="none" stroke="currentColor" stroke-width="2" 
                                stroke-linecap="round" stroke-linejoin="round" 
                                class="h-8 w-8 mb-2 opacity-50">
                                <path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"></path>
                                <path d="M9 18h6"></path>
                                <path d="M10 22h4"></path>
                            </svg>
                            <span class="text-sm text-gray-500">No strategies generated yet</span>
                        </div>
                        <ul id="stStrategiesList" style="list-style:none; margin:0; padding:0; display:none;"></ul>
                        <div id="stStatus" class="mt-2 text-xs text-gray-600" style="display:none;"></div>
                    </div>

                    <button id="generateSTBtn" class="flex items-center justify-center btn-soft-primary rounded-md w-full font-semibold px-4 py-2">
                        <span class="button-text">Generate Strategies</span>
                        <div class="loading-spinner hidden ml-2">
                            <svg class="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                        </div>
                    </button>
                </div>
            </section>

            <!-- ========== WEAKNESSES ========== -->
            <section class="section-swot dark:section-swot">
            <div class="section-swot-header bg-soft-warning dark:text-white flex flex-col gap-1">
                <div class="font-bold" style="margin-bottom: -10px;">WO Strategies</div>
                <span class="text-sm">Use weaknesses to improve opportunities</span>
            </div>
            <div class="section-swot-body">
                <div id="woStrategiesContainer" class="py-2 mb-4">
                    <div id="woPlaceholder" class="p-4 flex flex-col items-center justify-center text-center">
                        <svg xmlns="http://www.w3.org/2000/svg" 
                            width="24" height="24" viewBox="0 0 24 24" 
                            fill="none" stroke="currentColor" stroke-width="2" 
                            stroke-linecap="round" stroke-linejoin="round" 
                            class="h-8 w-8 mb-2 opacity-50">
                            <path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"></path>
                            <path d="M9 18h6"></path>
                            <path d="M10 22h4"></path>
                        </svg>
                        <span class="text-sm text-gray-500">No strategies generated yet</span>
                    </div>
                    <ul id="woStrategiesList" style="list-style:none; margin:0; padding:0; display:none;"></ul>
                    <div id="woStatus" class="mt-2 text-xs text-gray-600" style="display:none;"></div>
                </div>

                <button id="generateWOBtn" class="flex items-center justify-center btn-soft-warning rounded-md w-full font-semibold px-4 py-2">
                    <span class="button-text">Generate Strategies</span>
                    <div class="loading-spinner hidden ml-2">
                        <svg class="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                    </div>
                </button>
            </div>
            </section>

            <!-- ========== THREATS ========== -->
            <section class="section-swot dark:section-swot">
            <div class="section-swot-header bg-soft-danger dark:text-white flex flex-col gap-1">
                <div class="font-bold" style="margin-bottom: -10px;">WT Strategies</div>
                <span class="text-sm">Minimize weaknesses and avoid threats</span>
            </div>
            <div class="section-swot-body">
                <div id="wtStrategiesContainer" class="py-2 mb-4">
                    <div id="wtPlaceholder" class="p-4 flex flex-col items-center justify-center text-center">
                        <svg xmlns="http://www.w3.org/2000/svg" 
                            width="24" height="24" viewBox="0 0 24 24" 
                            fill="none" stroke="currentColor" stroke-width="2" 
                            stroke-linecap="round" stroke-linejoin="round" 
                            class="h-8 w-8 mb-2 opacity-50">
                            <path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"></path>
                            <path d="M9 18h6"></path>
                            <path d="M10 22h4"></path>
                        </svg>
                        <span class="text-sm text-gray-500">No strategies generated yet</span>
                    </div>
                    <ul id="wtStrategiesList" style="list-style:none; margin:0; padding:0; display:none;"></ul>
                    <div id="wtStatus" class="mt-2 text-xs text-gray-600" style="display:none;"></div>
                </div>

                <button id="generateWTBtn" class="flex items-center justify-center btn-soft-danger rounded-md w-full font-semibold px-4 py-2">
                    <span class="button-text">Generate Strategies</span>
                    <div class="loading-spinner hidden ml-2">
                        <svg class="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                    </div>
                </button>
            </div>
            </section>
    </div>

    <div class="rounded-2xl bg-white dark:bg-gray-800 shadow-md mx-auto mt-8 p-6">
        <div class="mt-6">
            <h2 class="text-2xl font-bold text-gray-700 dark:text-gray-200">Strategic Recommendations Based on IE Matrix</h2>
        </div>

        <div class="p-4 mt-4 bg-soft-primary rounded-lg">
            <div class="flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-12 h-12 text-blue-500">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m9-.75a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9 3.75h.008v.008H12v-.008Z"></path>
                </svg>
                <div>
                    <h3 class="flex gap-2 text-gray-700 dark:text-gray-300">
                            Your position in the IE Matrix (Cell I) suggests a <span class="font-bold">Grow and Build</span> approach.
                    </h3>
                    <span class="text-sm text-gray-700 dark:text-gray-300">Focus on SO and WO strategies that leverage opportunities</span>
                </div>
            </div>
        </div>

        <div class="flex items-center gap-2 justify-between mt-8">
            <h3 class="text-gray-700 dark:text-gray-300 font-bold text-lg">Prioritized Strategies</h3>
            <button class="btn gradient-primary flex gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" 
                            width="24" height="24" viewBox="0 0 24 24" 
                            fill="none" stroke="currentColor" stroke-width="2" 
                            stroke-linecap="round" stroke-linejoin="round" 
                            class="h-5 w-5">
                            <path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"></path>
                            <path d="M9 18h6"></path>
                            <path d="M10 22h4"></path>
                </svg>
                Generate Recommendations
            </button>
        </div>

        <div class="mt-4 border border-gray-300 dark:border-gray-600 bg-gray-100 dark:bg-gray-800 p-4 rounded-lg">
            <div class="p-4 flex flex-col items-center justify-center text-center">
                        <svg xmlns="http://www.w3.org/2000/svg" 
                            width="60" height="60" viewBox="0 0 24 24" 
                            fill="none" stroke="currentColor" stroke-width="2" 
                            stroke-linecap="round" stroke-linejoin="round" 
                            class="mb-2 opacity-50">
                            <path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"></path>
                            <path d="M9 18h6"></path>
                            <path d="M10 22h4"></path>
                        </svg>
                        <span class="text-sm text-gray-500">Generate strategies in the quadrants above, then click "Generate Recommendations" to get prioritized strategies based on your IE Matrix position.</span>
            </div>
        </div>


        <!-- Button Next -->
        <div class="flex justify-between mt-8">
            <!-- <button type="submit" class="btn gradient-primary text-white" style="padding-left: 24px;padding-right: 24px;">
                Next
            </button> -->
            <a href="?step=profile" class="btn btn-soft-secondary" style="padding-left: 24px;padding-right: 24px;">
                Previous
            </a>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // SO/ST/WO/WT buttons and lists
    const btnSO = document.getElementById('generateSOBtn');
    const btnST = document.getElementById('generateSTBtn');
    const btnWO = document.getElementById('generateWOBtn');
    const btnWT = document.getElementById('generateWTBtn');

    const listSO = document.getElementById('soStrategiesList');
    const listST = document.getElementById('stStrategiesList');
    const listWO = document.getElementById('woStrategiesList');
    const listWT = document.getElementById('wtStrategiesList');

    const phSO = document.getElementById('soPlaceholder');
    const phST = document.getElementById('stPlaceholder');
    const phWO = document.getElementById('woPlaceholder');
    const phWT = document.getElementById('wtPlaceholder');

    const stSO = document.getElementById('soStatus');
    const stST = document.getElementById('stStatus');
    const stWO = document.getElementById('woStatus');
    const stWT = document.getElementById('wtStatus');

    // Konfigurasi API
    const apiBase = '<?= base_url('api/project') ?>';
    const urlParams = new URLSearchParams(window.location.search);
    const projectKey = urlParams.get('key');
    let projectId = null;
    const language = 'id'; // default Indonesia; bisa diganti ke 'en'
    const mapTypeGlobal = { SO: 'S-O', ST: 'S-T', WO: 'W-O', WT: 'W-T' };

    async function resolveProjectId() {
        try {
            if (!projectKey) return null;
            const resp = await fetch(`${apiBase}/profile_get?uuid=${projectKey}`);
            const json = await resp.json();
            projectId = json?.data?.id || json?.data?.project_id || null;
            return projectId;
        } catch (e) {
            console.error('Gagal memuat project ID:', e);
            return null;
        }
    }

    // Placeholder loader & status text updater
    function placeholderSetLoading(placeholderEl, message) {
        if (!placeholderEl.dataset.original) {
            placeholderEl.dataset.original = placeholderEl.innerHTML;
        }
        const msg = message.endsWith('...') ? message : `${message}...`;
        placeholderEl.style.display = 'block';
        placeholderEl.innerHTML = `
            <div class="p-4 flex flex-col items-center justify-center text-center">
                <svg class="animate-spin h-8 w-8 text-gray-500 mb-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <span class="text-sm text-gray-600">${msg}</span>
            </div>
        `;
    }
    function placeholderSetError(placeholderEl, message) {
        const msg = message;
        placeholderEl.style.display = 'block';
        placeholderEl.innerHTML = `
            <div class="p-4 flex flex-col items-center justify-center text-center">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-red-500 mb-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m9-.75a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9 3.75h.008v.008H12v-.008Z" />
                </svg>
                <span class="text-sm text-red-600">${msg}</span>
            </div>
        `;
    }
    function placeholderReset(placeholderEl) {
        if (placeholderEl.dataset.original) {
            placeholderEl.innerHTML = placeholderEl.dataset.original;
        }
    }

    function typeText(element, text, callback) {
        let index = 0;
        element.textContent = '';
        function typeNextChar() {
            if (index < text.length) {
                element.textContent += text.charAt(index);
                index++;
                setTimeout(typeNextChar, Math.random() * 50 + 30);
            } else {
                callback();
            }
        }
        typeNextChar();
    }

    function renderStrategies(listEl, strategies, btnEl) {
        let i = 0;
        function addNext() {
            if (i >= strategies.length) {
                btnEl.disabled = false;
                btnEl.querySelector('.button-text').textContent = 'Regenerate Strategies';
                return;
            }
            const s = strategies[i];
            const li = document.createElement('li');
            li.style.cssText = 'padding:12px 20px; border-bottom:1px solid #eee; display:flex; justify-content:space-between; align-items:top; opacity:0; transform:translateY(10px); transition:all 0.3s ease;';
            const idSpan = document.createElement('span');
            idSpan.style.cssText = 'font-weight:bold;margin-right:20px;';
            idSpan.textContent = s.id;
            const textSpan = document.createElement('span');
            textSpan.style.cssText = 'flex:1;';
            li.appendChild(idSpan);
            li.appendChild(textSpan);
            listEl.appendChild(li);
            setTimeout(() => { li.style.opacity = '1'; li.style.transform = 'translateY(0)'; }, 100);
            typeText(textSpan, s.text, () => { i++; setTimeout(addNext, 400); });
        }
        addNext();
    }

    // Render tanpa efek ketik untuk data yang sudah ada
    function renderStrategiesImmediate(listEl, strategies, btnEl) {
        listEl.innerHTML = '';
        strategies.forEach((s) => {
            const li = document.createElement('li');
            li.style.cssText = 'padding:12px 20px; border-bottom:1px solid #eee; display:flex; justify-content:space-between; align-items:top; opacity:1; transform:translateY(0); transition:all 0.3s ease;';
            const idSpan = document.createElement('span');
            idSpan.style.cssText = 'font-weight:bold;margin-right:20px;';
            idSpan.textContent = s.id;
            const textSpan = document.createElement('span');
            textSpan.style.cssText = 'flex:1;';
            textSpan.textContent = s.text;
            li.appendChild(idSpan);
            li.appendChild(textSpan);
            listEl.appendChild(li);
        });
        btnEl.disabled = false;
        btnEl.querySelector('.button-text').textContent = 'Regenerate Strategies';
    }

    async function runGeneration(quadrant, btnEl, placeholderEl, listEl, statusEl) {
        const textEl = btnEl.querySelector('.button-text');
        const spinnerEl = btnEl.querySelector('.loading-spinner');
        const mapType = { SO: 'S-O', ST: 'S-T', WO: 'W-O', WT: 'W-T' };

        // pastikan projectId
        if (!projectId) await resolveProjectId();
        if (!projectId) {
            placeholderSetError(placeholderEl, 'Gagal: project tidak ditemukan di URL (key).');
            return;
        }

        // UI awal
        btnEl.disabled = true;
        textEl.textContent = 'Generating...';
        spinnerEl.classList.remove('hidden');
        listEl.style.display = 'none';
        listEl.innerHTML = '';
        statusEl.style.display = 'none';
        placeholderSetLoading(placeholderEl, 'Mengambil Top-K pairs');

        try {
            // Step 1: generating_top_k_pairs
            const r1 = await fetch(`${apiBase}/generating_top_k_pairs?project=${projectId}&pair_type=${mapType[quadrant]}`, { method: 'POST' });
            const j1 = await r1.json();
            if (!j1.success || !j1.data || !j1.data.run_id) {
                placeholderSetError(placeholderEl, 'Gagal mengambil Top-K pairs');
                throw new Error(j1.message || 'Top-K pairs failed');
            }
            const runId = j1.data.run_id;
            placeholderSetLoading(placeholderEl, 'Menjalankan Semantic Filter');

            // Step 2: semantic_filter
            const r2 = await fetch(`${apiBase}/semantic_filter?project=${projectId}&run=${runId}`, { method: 'POST' });
            const j2 = await r2.json();
            if (!j2.success) {
                placeholderSetError(placeholderEl, 'Gagal menjalankan Semantic Filter');
                throw new Error(j2.message || 'Semantic filter failed');
            }
            placeholderSetLoading(placeholderEl, 'Menghasilkan Strategi');

            // Step 3: strategies
            const r3 = await fetch(`${apiBase}/strategies?project=${projectId}&run=${runId}&lang=${language}`, { method: 'POST' });
            const j3 = await r3.json();
            if (!j3.success || !Array.isArray(j3.data?.strategies)) {
                placeholderSetError(placeholderEl, 'Gagal menghasilkan strategi');
                throw new Error(j3.message || 'Strategies generation failed');
            }

            // render hasil dengan penyesuaian prefix kode sesuai quadrant (SO/ST/WO/WT)
            const items = j3.data.strategies.map((s, idx) => {
                const rawCode = typeof s.code === 'string' ? s.code : '';
                const m = rawCode.match(/^(SO|ST|WO|WT)(\d+)/i);
                const id = m ? `${quadrant}${m[2]}` : `${quadrant}${idx + 1}`;
                return { id, text: s.statement };
            });
            placeholderReset(placeholderEl);
            placeholderEl.style.display = 'none';
            listEl.style.display = 'block';
            spinnerEl.classList.add('hidden');
            textEl.textContent = 'Generating Strategies...';
            renderStrategies(listEl, items, btnEl);
        } catch (e) {
            spinnerEl.classList.add('hidden');
            btnEl.disabled = false;
            textEl.textContent = 'Generate Strategies';
            console.error('Error:', e);
        }
    }

    // Memuat strategi yang sudah ada saat halaman diload (tanpa efek ketik)
    async function loadExisting(quadrant, btnEl, placeholderEl, listEl) {
        try {
            if (!projectId) return;
            const res = await fetch(`${apiBase}/strategies_list?project=${projectId}&pair_type=${mapTypeGlobal[quadrant]}`);
            const json = await res.json();
            const strategies = json?.data?.strategies || [];
            if (json.success && Array.isArray(strategies) && strategies.length > 0) {
                const items = strategies.map((s, idx) => {
                    const rawCode = typeof s.code === 'string' ? s.code : '';
                    const m = rawCode.match(/^(SO|ST|WO|WT)(\d+)/i);
                    const id = m ? `${quadrant}${m[2]}` : `${quadrant}${idx + 1}`;
                    return { id, text: s.statement };
                });
                placeholderReset(placeholderEl);
                placeholderEl.style.display = 'none';
                listEl.style.display = 'block';
                renderStrategiesImmediate(listEl, items, btnEl);
            }
        } catch (e) {
            // Abaikan kesalahan, user masih bisa generate
            console.warn('Gagal memuat strategi existing untuk', quadrant, e);
        }
    }

    btnSO?.addEventListener('click', () => runGeneration('SO', btnSO, phSO, listSO, stSO));
    btnST?.addEventListener('click', () => runGeneration('ST', btnST, phST, listST, stST));
    btnWO?.addEventListener('click', () => runGeneration('WO', btnWO, phWO, listWO, stWO));
    btnWT?.addEventListener('click', () => runGeneration('WT', btnWT, phWT, listWT, stWT));

    // Resolusi project dan muat strategi existing
    resolveProjectId().then(() => {
        if (!projectId) return;
        loadExisting('SO', btnSO, phSO, listSO);
        loadExisting('ST', btnST, phST, listST);
        loadExisting('WO', btnWO, phWO, listWO);
        loadExisting('WT', btnWT, phWT, listWT);
    });
});
</script>
        </div>
    </div>



</div>
